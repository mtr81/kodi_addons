# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.play_now')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
fanart=''

mode = addon.getSetting('mode')
#UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
UA='MMozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'
baseurl='https://playnow.pl/'
apiURL='https://playnow.pl/api/v2/'
platform='BROWSER'

def heaGen():
    HEA={
        'referer':baseurl,
        'User-Agent':UA,
        'API-DeviceInfo':'Firefox 115.0 on Windows 10 64-bit;Windows;10;Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0;3.28.4-web',
        'API-DeviceUid':addon.getSetting('uid'),
        'API-SN':addon.getSetting('uid'),
        'API-CorrelationId':'%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12)),
        'Origin':baseurl[:-1]
    }
    return HEA

def cookiesGen():
    cookies={
        'rememberMe':addon.getSetting('rememberMe'),
        'uid':addon.getSetting('uid'),
        'JSESSIONID':addon.getSetting('JSESSIONID'),
    }
    return cookies

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt)
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF) 

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':
        items=[
            ['Kanały TV','tvList','DefaultTVShows.png'],
            ['Archiwum programów','replay','DefaultTVShows.png'],
            ['Wyloguj','logOut','OverlayUnwatched.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','OverlayUnwatched.png']
        ]
    for i in items:
        setArt={'icon': i[2]}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)   

def logIn():
    phone=addon.getSetting('phone')
    if phone!='':
        url=apiURL+'subscribers/login/url?type=BROWSER&redirectUri=https://playnow.pl/logowanie&platform='+platform
        hea_=heaGen()
        cookies={'uid':addon.getSetting('uid')}
        resp=requests.get(url,headers=hea_,cookies=cookies).json()
        
        #url='https://oauth.play.pl/oauth/authorize?layout=auto&response_type=code&client_id=ATDSLOGIN&display=ipcheck link&scope=oauth/*&redirect_uri=http://www.tv.play.pl/logowanie'
        url=resp['url']
        hea={
            'User-Agent':UA
        }
        resp=requests.get(url,headers=hea,allow_redirects=False)
        cookies=dict(resp.cookies)
        addon.setSetting('cook_auth',str(cookies))
        #print(cookies)
        resp=requests.get(url,headers=hea,cookies=cookies)
        
        data='_csrf=%s&msisdn=%s&_eventId_submit=&_eventId_submit='%(cookies['XSRF-TOKEN'],addon.getSetting('phone'))
        #print(data)
        hea={
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'origin':'https://oauth.play.pl',
            'User-Agent':UA,
            'Content-Type':'application/x-www-form-urlencoded'
        }
        url_auth='https://oauth.play.pl/login?execution=e1s1'
        resp=requests.post(url_auth,headers=hea,data=data,cookies=cookies)
        if 'Kliknij link' in resp.text:
            setArt={'icon': 'OverlayUnwatched.png'}
            url = build_url({'mode':'logInCont'})
            addItemList(url, 'Kontynuuj logowanie po autoryzacji via SMS', setArt)
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            xbmcplugin.endOfDirectory(addon_handle)#do poprawy
    else:
        xbmcgui.Dialog().notification('Play Now', 'Uzupełnij nr telefonu lub nr zarządzania usługą w ustawieniach.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
def logInCont():
    cookies=eval(addon.getSetting('cook_auth'))
    url='https://oauth.play.pl/login?execution=e1s2'
    hea={
        'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'origin':'https://oauth.play.pl',
        'User-Agent':UA,
        'Content-Type':'application/x-www-form-urlencoded'
    }
    data='_csrf=%s&_eventId_submit='%(cookies['XSRF-TOKEN'])
    resp=requests.post(url,headers=hea,data=data,cookies=cookies,allow_redirects=False)    
    if 'location' not in resp.headers:
        xbmcgui.Dialog().notification('Play Now', 'Brak przekierowania', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    elif 'execution' in resp.headers['location']:#dodać mechanizm powtórzenia weryfikacji (ileś tam razy)
        xbmcgui.Dialog().notification('Play Now', 'Nie załapało SMS-a - jest przekierowanie z execution', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    elif 'authorize?' in resp.headers['location']: #https://oauth.play.pl/oauth/authorize?layout=auto&response_type=code&client_id=ATDSLOGIN&display=ipcheck link&scope=oauth/*&redirect_uri=https://playnow.pl/logowanie
        hea={
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'referer':'https://oauth.play.pl/login?execution=e1s2',
            'User-Agent':UA,
            'Connection':'keep-alive',
            'Accept-Language':'pl,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding':'gzip, deflate, br',
            'Content-Type':'',
            'Sec-Fetch-Dest':'document',
            'Sec-Fetch-Mode':'navigate',
            'Sec-Fetch-Site':'same-origin',
            'Upgrade-Insecure-Requests':'1',
            'Host':'oauth.play.pl'
            
        }
        resp1=requests.get(resp.headers['location'],headers=hea,cookies=cookies,allow_redirects=False)
        url_login=resp1.headers['location'] #https://playnow.pl/logowanie?code=ny8vkgzhxwysgnu
        cooks={
            'uid':addon.getSetting('uid')
        }
        hea={
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'referer':'https://oauth.play.pl/',
            'User-Agent':UA,
        }
        respLogin=requests.get(url_login,headers=hea,cookies=cooks)
        
        hea_=heaGen()
        hea_.update({'Referer':url_login})
        data={
            'code':url_login.split('code=')[-1],
            'redirectUri':'https://playnow.pl/logowanie'
        }
        url=apiURL+'subscribers/login/play?platform='+platform
        resp=requests.post(url,json=data,headers=hea,cookies=cooks)
        addon.setSetting('rememberMe',dict(resp.cookies)['rememberMe'])
        addon.setSetting('JSESSIONID',dict(resp.cookies)['JSESSIONID'])
        respJSON=resp.json()
        if 'token' in respJSON:
            addon.setSetting('token',respJSON['token'])
            products()
            addon.setSetting('logged','true')
        else:
            xbmcgui.Dialog().notification('Play Now', 'Nieokreslony błąd logowania', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def products():
    hea_=heaGen()
    cookies=cookiesGen()
    url=apiURL+'subscribers/products?platform='+platform
    resp=requests.get(url,headers=hea_,cookies=cookies).json()
    if 'message' in resp:
        if resp['message']=='authentication.required':
            return False
    else:
        priceStrategyIds=resp['priceStrategyIds']
        availableProductIds=resp['availableProductIds']
        tenant=resp['tenant']
        addon.setSetting('priceStrategyIds',str(priceStrategyIds))
        addon.setSetting('availableProductIds',str(availableProductIds))
        addon.setSetting('tenant',str(tenant))
        
        return True
    
def logOut():
    hea_=heaGen()
    cookies=cookiesGen()
    hea_.update({'Accept':'application/json, text/plain, */*'})
    url=apiURL+'subscribers/logout?platform='+platform
    resp=requests.post(url,headers=hea_,cookies=cookies)
    if 'rememberMe' in dict(resp.cookies):
        try:
            url='https://oauth.play.pl/logout.do?continue=https://playnow.pl&client_id=ATDSLOGIN'
            hea={
                'User-Agent':UA,
                'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Referer':baseurl,
            }
            resp=requests.get(url,headers=hea)
            addon.setSetting('logged','false')
            addon.setSetting('rememberMe','')
            addon.setSetting('JSESSIONID','')
            addon.setSetting('cook_auth','')
            addon.setSetting('token','')
            addon.setSetting('priceStrategyIds','')
            addon.setSetting('availableProductIds','')
            addon.setSetting('tenant','')
        except:
            xbmcgui.Dialog().notification('Play Now', 'Nie wylogowano (e2)', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())        
        
    else:
        xbmcgui.Dialog().notification('Play Now', 'Nie wylogowano (e1)', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
'''
def relogin():#TO DO #wygasł token (po dłuższym nieużywaniu wtyczki - prawdopodobnie 7 dni)
    addon.setSetting('logged','false')
    addon.setSetting('packets','')
    addon.setSetting('uuid','')
    addon.setSetting('token','')
    logIn()
    xbmcgui.Dialog().notification('Play Now', 'Przelogowano', xbmcgui.NOTIFICATION_INFO)
 '''   
      
def getEPG(cid,ts,te):
    
    def getStrTime(x):
        return datetime.datetime.fromtimestamp(x).astimezone().strftime('%Y-%m-%dT%H:%M%z')
    
    since=getStrTime(ts)
    till=getStrTime(te)
    
    hea_=heaGen()
    hea_.update({'Sync-With-Server':'true'})
    cookies=cookiesGen()
    tenant=addon.getSetting('tenant')
    url=apiURL+	'products/lives/epgs?liveId[]='+cid+'&since='+quote(since)+'&till='+quote(till)+'&platform='+platform+'&tenant='+tenant

    resp=requests.get(url,headers=hea_,cookies=cookies).json()

    return resp

def EPGinfo(cid):
    now=int(time.time())
    epg=getEPG(cid,now,now+12*60*60)
    plot=''
    for e in epg:
        title=e['title']
        since=e['since'].split(' ')[-1][:-3]
        till=e['till'].split(' ')[-1][:-3]
        plot+='[B]%s - %s[/B] %s\n'%(since,till,title)
    
    if plot=='':
        plot='Brak danych EPG'
    dialog = xbmcgui.Dialog()
    dialog.textviewer('EPG', plot)     

'''
def availTest(u):#TO DO
    avail=False
    uuids=eval(addon.getSetting('uuid'))
    for uu in u:
        if uu in uuids:
            avail=True
    return avail
'''
    
def channels():
    hea_=heaGen()
    cookies=cookiesGen()
    tenant=addon.getSetting('tenant')
    url=apiURL+'products/lives?platform='+platform+'&tenant='+tenant
    resp=requests.get(url,headers=hea_,cookies=cookies).json()
    chans=[]
    for c in resp:
        if c['liveType']=='LIVE':
            chName=c['title']
            cid=c['id']
            if 'timeshiftDuration' in c:
                tsDur=c['timeshiftDuration']
            else:
                tsDur=0
            if 'catchUpAvailable' in c:
                cu=True
            else:
                cu=False
            try:
                img=c['logos']['L1x1_cl'][0]['url']
            except:
                img=img_empty
            chans.append([chName,cid,img,tsDur,cu])
    
    return chans
        
def tvList(t):
    chans=channels()
    #epg=getEPG()
    for c in chans:
        if t=='live' or (t=='replay' and c[4]):
            img='https:'+c[2] if c[2].startswith('//') else c[2]
            name=c[0]
            cid=c[1]

            if t=='live':
                isPlayable='true'
                isFolder=False
                url=build_url({'mode':'playSource','cid':cid,'tsDur':str(c[3])})
                plot='EPG dostępne z poziomu menu kontekstowego'
                contMenu=True
                cmItems=[
                    ('[B]EPG[/B]','RunPlugin(plugin://plugin.video.play_now?mode=EPGinfo&cid='+str(cid)+')')
                ]
                
            elif t=='replay':
                isPlayable='false'
                isFolder=True
                url=build_url({'mode':'calendar','cid':cid})
                plot=''
                contMenu=False
                cmItems=[]
                        
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
            iL={'title': name,'sorttitle': name,'plot': plot}
            addItemList(url, name, setArt, 'video', iL, isF=isFolder, isPla=isPlayable, contMenu=contMenu, cmItems=cmItems)
    
    xbmcplugin.endOfDirectory(addon_handle)

def calendar(cid):
    days=7 #sprawdzić ile dni catchup
    now=datetime.datetime.now()
    for i in range(0,days+1):
        date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
       
        setArt={'icon': 'DefaultYear.png'}
        url=build_url({'mode':'programList','cid':cid,'date':date})
        addItemList(url, date, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def programList(cid,d):
    now=time.time()
    ts=datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6])).timestamp()
    if ts<now-7*24*60*60: #do spr
        ts=now-int(t)*7*24*60*60 #do spr
    te=(datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6]))+datetime.timedelta(days=1)).timestamp()
    if te>now:
        te=now
    epg=getEPG(cid,int(ts),int(te))
    for e in epg:
        pid=str(e['id'])
        title=e['title']
        since=e['since'].split(' ')[-1][:-3]
        till=e['till'].split(' ')[-1][:-3]
        name='[B]%s - %s[/B] %s'%(since,till,title)
        desc=e['description'] if 'description' in e else ''
        try:
            img=e['covers']['L16x9'][0]['url']
        except:
            img=img_empty
        #tStart=int(datetime.datetime(*(time.strptime(e['since'], "%Y-%m-%d %H:%M:%S")[0:6])).timestamp()*1000)-int(datetime.datetime(*(time.strptime('2001-01-01 01:00:00', "%Y-%m-%d %H:%M:%S")[0:6])).timestamp()*1000)

        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        iL={'title': title,'sorttitle': title,'plot': desc}
        url=build_url({'mode':'playReplay','pid':pid})
        addItemList(url, name, setArt, 'video', iL, isF=False, isPla='true')
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def playSource(c,tsDur,contType='LIVE'):
    hea_=heaGen()
    cookies=cookiesGen()
    url=apiURL+'products/'+c+'/player/configuration?type='+contType+'&platform='+platform
    resp=requests.get(url,headers=hea_,cookies=cookies).json()
    if 'message' in resp:
        xbmcgui.Dialog().notification('Play Now', 'Usługa niedostępna: '+resp['message'], xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        vidSess=resp['videoSession']['videoSessionId']
        
        url=apiURL+'products/'+c+'/playlist?type='+contType+'&version=3&videoSessionId='+vidSess+'&drmMultikey=false&platform='+platform
        resp=requests.get(url,headers=hea_,cookies=cookies).json()
        try:
            stream_url=resp['sources']['DASH'][0]['src']
            if int(tsDur)>0:
                tStart=int(time.time()*1000)-int(tsDur)*1000-int(datetime.datetime(*(time.strptime('2001-01-01 01:00:00', "%Y-%m-%d %H:%M:%S")[0:6])).timestamp()*1000)
                stream_url+='&startTime='+str(tStart)
            if stream_url.startswith('//'):
                stream_url='https:'+stream_url
            if 'WIDEVINE' in resp['drm']:
                licURL=resp['drm']['WIDEVINE']['src']
                heaLic={
                    'User-Agent':UA,
                    'Referer':baseurl,
                    'Origin':baseurl[:-1],
                    'Cookie':'; '.join([str(x) + '=' + str(y) for x, y in cookies.items()]),
                    'content-type':''
                }
                lic='%s|%s|%s|'%(licURL,urlencode(heaLic),'R{SSM}')
            else:
                licURL=''
                heaLic=''
                lic=''
                
        except:
            stream_url=None
        print(stream_url)
        
        if stream_url!=None:
            import inputstreamhelper
            PROTOCOL = 'mpd'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=stream_url)
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA)
                if contType=='EPG_ITEM':
                    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                    play_item.setProperty('ResumeTime', '1')
                    play_item.setProperty('TotalTime', '1')
                if licURL!='':
                    play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                    play_item.setProperty('inputstream.adaptive.license_key',lic)
                              
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
        else:
            xbmcgui.Dialog().notification('Play Now', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    

def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Play Now', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Play Now', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    if chans !=False:
        data = '#EXTM3U\n'
        for c in chans:
            name=c[0]
            img='https:'+c[2] if c[2].startswith('//') else c[2]
            
            cid=c[1]
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Play Now" ,%s\nplugin://plugin.video.play_now?mode=playSource&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('Play Now', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Play Now', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)
   

mode = params.get('mode', None)

if not mode:
    if addon.getSetting('uid')=='' or addon.getSetting('uid')==None:#uid[c]=API-DeviceUid[h]=API-SN[h]
        addon.setSetting('uid',code_gen(32))
    if addon.getSetting('logged')=='true':
        main_menu()
        #TO DO: wygasający token
        '''
        if not products():
            relogin()
            if products():
                main_menu()
            else:
                logOut()
        else:
            main_menu()
        '''
    else:
        main_menu()
else:
    if mode=='logIn':#
        logIn()
    
    if mode=='logInCont':#
        logInCont()
        if addon.getSetting('logged')=='true':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.play_now/,replace)')
    
    if mode=='logOut':
        logOut()
        if addon.getSetting('logged')=='false':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.play_now/,replace)')
    
    if mode=='tvList':
        tvList('live')
    
    if mode=='replay':
        tvList('replay')
        
    if mode=='calendar':
        cid=params.get('cid')
        calendar(cid)
        
    if mode=='programList':
        cid=params.get('cid')
        date=params.get('date')
        programList(cid,date)
        
    if mode=='playReplay':
        pid=params.get('pid')
        playSource(pid,'0','EPG_ITEM')
        
    if mode=='EPGinfo':
        cid=params.get('cid')
        EPGinfo(cid)
        
    if mode=='playSource':
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            tsDur=params.get('tsDur')
            playSource(cid,tsDur)
        else:
            xbmcgui.Dialog().notification('Play Now', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
            
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('Play Now', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
            