# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.play_now')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
img_icon=PATH+'icon.png'

#UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'
baseurl='https://playnow.pl/'
apiURL='https://playnow.pl/api/v2/'
platform='BROWSER'

platforms={'PC':'BROWSER','Android TV':'ANDROID_TV'}
p2=addon.getSetting('platform')
platform2=platforms[p2]

def heaGen():
    HEA={
        'referer':baseurl,
        'User-Agent':UA,
        'API-DeviceInfo':'Firefox 115.0 on Windows 10 64-bit;Windows;10;Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0;3.28.4-web',
        'API-DeviceUid':addon.getSetting('uid'),
        'API-SN':addon.getSetting('uid'),
        'API-CorrelationId':'%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12)),
        'Origin':baseurl[:-1]
    }
    return HEA

def cookiesGen():
    cookies={
        'rememberMe':addon.getSetting('rememberMe'),
        'uid':addon.getSetting('uid'),
        'JSESSIONID':addon.getSetting('JSESSIONID'),
    }
    return cookies

def paramsGen():
    p={
        'platform':platform2,
        'tenant':addon.getSetting('tenant')
    }
    return p

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code
    
def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def addToUrl(u,x):
    result='?'+x if '?' not in u else '&'+x
    return result

    
def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':
        #refresh()
        items=[
            ['Kanały TV','tvList','DefaultTVShows.png'],
            ['Archiwum programów','replay','DefaultYear.png'],
            ['Wideo','vodCategs','DefaultAddonVideo.png'],
            ['Szukaj','search','DefaultAddonsSearch.png'],
            ['Moje nagrania','rec','DefaultAddonVideo.png'],
            ['Program TV','ptv','DefaultTVShows.png'],
            ['Ulubione','favList','DefaultMusicPlaylists.png'],
            ['Wyloguj','logOut','DefaultUser.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','DefaultUser.png']
        ]
    for i in items:
        isF=False if i[1] in ['logOut'] else True
        setArt={'icon': i[2],'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt, isF=isF)
    xbmcplugin.endOfDirectory(addon_handle)   

def logIn():
    phone=addon.getSetting('phone')
    if phone!='':
        url=apiURL+'subscribers/login/url?type=BROWSER&redirectUri=https://playnow.pl/logowanie&platform='+platform
        hea_=heaGen()
        cookies={'uid':addon.getSetting('uid')}
        resp=requests.get(url,headers=hea_,cookies=cookies).json()
        
        #url='https://oauth.play.pl/oauth/authorize?layout=auto&response_type=code&client_id=ATDSLOGIN&display=ipcheck link&scope=oauth/*&redirect_uri=http://www.tv.play.pl/logowanie'
        url=resp['url']
        hea={
            'User-Agent':UA
        }
        resp=requests.get(url,headers=hea,allow_redirects=False)
        cookies=dict(resp.cookies)
        addon.setSetting('cook_auth',str(cookies))
        #print(cookies)
        resp=requests.get(url,headers=hea,cookies=cookies)
        
        data='_csrf=%s&msisdn=%s&_eventId_submit=&_eventId_submit='%(cookies['XSRF-TOKEN'],addon.getSetting('phone'))
        #print(data)
        hea={
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'origin':'https://oauth.play.pl',
            'User-Agent':UA,
            'Content-Type':'application/x-www-form-urlencoded'
        }
        url_auth='https://oauth.play.pl/login?execution=e1s1'
        resp=requests.post(url_auth,headers=hea,data=data,cookies=cookies)
        if 'Kliknij link' in resp.text:
            setArt={'icon': 'DefaultUser.png','fanart':fanart}
            url = build_url({'mode':'logInCont'})
            addItemList(url, 'Kontynuuj logowanie po autoryzacji via SMS', setArt, isF=False)
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            xbmcgui.Dialog().notification('Play Now', 'Logowanie nie powiodło się (brak uprawnień)', xbmcgui.NOTIFICATION_INFO)
            
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.play_now/,replace)')
            xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    else:
        xbmcgui.Dialog().notification('Play Now', 'Uzupełnij nr telefonu lub nr zarządzania usługą w ustawieniach', xbmcgui.NOTIFICATION_INFO)

        xbmc.executebuiltin('Container.Update(plugin://plugin.video.play_now/,replace)')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        
def logInCont():
    cookies=eval(addon.getSetting('cook_auth'))
    url='https://oauth.play.pl/login?execution=e1s2'
    hea={
        'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'origin':'https://oauth.play.pl',
        'User-Agent':UA,
        'Content-Type':'application/x-www-form-urlencoded'
    }
    data='_csrf=%s&_eventId_submit='%(cookies['XSRF-TOKEN'])
    resp=requests.post(url,headers=hea,data=data,cookies=cookies,allow_redirects=False)    
    if 'location' not in resp.headers:
        xbmc.log('@@@Brak przekierowania', level=xbmc.LOGINFO)
    elif 'execution' in resp.headers['location']:#dodać mechanizm powtórzenia weryfikacji (ileś tam razy)
        xbmc.log('@@@Jest przekierowanie z execution, ale wystąpił problem z autoryzacją via SMS', level=xbmc.LOGINFO)
    elif 'authorize?' in resp.headers['location']: #https://oauth.play.pl/oauth/authorize?layout=auto&response_type=code&client_id=ATDSLOGIN&display=ipcheck link&scope=oauth/*&redirect_uri=https://playnow.pl/logowanie
        hea={
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'referer':'https://oauth.play.pl/login?execution=e1s2',
            'User-Agent':UA,
            'Connection':'keep-alive',
            'Accept-Language':'pl,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding':'gzip, deflate, br',
            'Content-Type':'',
            'Sec-Fetch-Dest':'document',
            'Sec-Fetch-Mode':'navigate',
            'Sec-Fetch-Site':'same-origin',
            'Upgrade-Insecure-Requests':'1',
            'Host':'oauth.play.pl'
            
        }
        resp1=requests.get(resp.headers['location'],headers=hea,cookies=cookies,allow_redirects=False)
        url_login=resp1.headers['location'] #https://playnow.pl/logowanie?code=ny8vkgzhxwysgnu
        cooks={
            'uid':addon.getSetting('uid')
        }
        hea={
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'referer':'https://oauth.play.pl/',
            'User-Agent':UA,
        }
        respLogin=requests.get(url_login,headers=hea,cookies=cooks)
        
        hea_=heaGen()
        hea_.update({'Referer':url_login})
        data={
            'code':url_login.split('code=')[-1],
            'redirectUri':'https://playnow.pl/logowanie'
        }
        url=apiURL+'subscribers/login/play?platform='+platform
        resp=requests.post(url,json=data,headers=hea,cookies=cooks)
        addon.setSetting('rememberMe',dict(resp.cookies)['rememberMe'])
        addon.setSetting('JSESSIONID',dict(resp.cookies)['JSESSIONID'])
        respJSON=resp.json()
        if 'token' in respJSON:
            addon.setSetting('token',respJSON['token'])
            products()
            addon.setSetting('logged','true')
        else:
            xbmcgui.Dialog().notification('Play Now', 'Błąd autoryzacji', xbmcgui.NOTIFICATION_INFO)
            xbmc.log('@@@Błąd-autoryzacja: '+str(respJSON), level=xbmc.LOGINFO)

def logOut():
    hea_=heaGen()
    cookies=cookiesGen()
    hea_.update({'Accept':'application/json, text/plain, */*'})
    url=apiURL+'subscribers/logout?platform='+platform
    resp=requests.post(url,headers=hea_,cookies=cookies)

    #if 'rememberMe' in dict(resp.cookies):
    if resp.status_code==200:
        try:
            url='https://oauth.play.pl/logout.do?continue=https://playnow.pl&client_id=ATDSLOGIN'
            hea={
                'User-Agent':UA,
                'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
                'Referer':baseurl,
            }
            resp=requests.get(url,headers=hea)
            addon.setSetting('logged','false')
            addon.setSetting('rememberMe','')
            addon.setSetting('JSESSIONID','')
            addon.setSetting('cook_auth','')
            addon.setSetting('token','')
            addon.setSetting('priceStrategyIds','')
            addon.setSetting('availableProductIds','')
            addon.setSetting('tenant','')
        except:
            xbmcgui.Dialog().notification('Play Now', 'Nie wylogowano (e2)', xbmcgui.NOTIFICATION_INFO)
            para_logout()
            xbmc.log('@@@Para_logout(1):', level=xbmc.LOGINFO)
        
    else:
        xbmcgui.Dialog().notification('Play Now', 'Nie wylogowano (e1)', xbmcgui.NOTIFICATION_INFO)
        para_logout()
        xbmc.log('@@@Para_logout(2):', level=xbmc.LOGINFO)

def para_logout():
    addon.setSetting('logged','false')
    addon.setSetting('rememberMe','')
    addon.setSetting('JSESSIONID','')
    addon.setSetting('cook_auth','')
    addon.setSetting('token','')
    addon.setSetting('priceStrategyIds','')
    addon.setSetting('availableProductIds','')
    addon.setSetting('tenant','')

def req(t,u,h,c,p=None,d={},j=True):
    if t=='get':
        resp=requests.get(u,headers=h,cookies=c,params=p)
    elif t=='delete':
        resp=requests.delete(u,headers=h,cookies=c,params=p)
    elif t=='post':
        resp=requests.post(u,headers=h,cookies=c,params=p,json=d)
    cookiesIn=dict(resp.cookies)
    c=['JSESSIONID','rememberMe']
    for cc in c:
        if cc in cookiesIn:
            addon.setSetting(cc,cookiesIn[cc])
            xbmc.log('@@@Odświeżono cookies: '+cc, level=xbmc.LOGINFO)
            #xbmcgui.Dialog().notification('Play Now', "Odświeżono cookies: "+cc, xbmcgui.NOTIFICATION_INFO)
    if j:
        resp=resp.json()
    return resp

def strToDate(d,f='%Y-%m-%d %H:%M:%S'):
    return datetime.datetime(*(time.strptime(d,f)[0:6]))

def products():
    hea_=heaGen()
    cookies=cookiesGen()
    url=apiURL+'subscribers/products?platform='+platform
    resp=requests.get(url,headers=hea_,cookies=cookies).json()
    if 'message' in resp:
        if resp['message']=='authentication.required':
            return False
    else:
        priceStrategyIds=resp['priceStrategyIds']
        availableProductIds=resp['availableProductIds']
        tenant=resp['tenant']
        addon.setSetting('priceStrategyIds',str(priceStrategyIds))
        addon.setSetting('availableProductIds',str(availableProductIds))
        addon.setSetting('tenant',str(tenant))
        
        return True
        
def availVer(pid): #test
    isVer=addon.getSetting('tvProductVerify')
    prods=eval(addon.getSetting('availableProductIds'))
    ver=True if pid in prods or isVer=='false' else False
    return ver

def tvCategs():
    hea_=heaGen()
    cookies=cookiesGen()
    url=apiURL+'products/categories'
    paramsURL=paramsGen()
    paramsURL['type']='LIVE'
    resp=requests.get(url,headers=hea_,cookies=cookies,params=paramsURL).json()
    if 'message' in resp:
        if resp['message']=='authentication.required':
            return False
    else:
        saveF(PATH_profile+'tv_categs.txt',str(resp))
        return True
      
def getEPG(cid,ts,te):
    
    def getStrTime(x):
        return datetime.datetime.fromtimestamp(x).astimezone().strftime('%Y-%m-%dT%H:%M%z')
    
    since=getStrTime(ts)
    till=getStrTime(te)
    
    hea_=heaGen()
    hea_.update({'Sync-With-Server':'true'})
    cookies=cookiesGen()
    tenant=addon.getSetting('tenant')
    url=apiURL+	'products/lives/epgs'
    par=paramsGen()
    par.update({
        'liveId[]':cid,
        'since':since,
        'till':till,
    })
    resp=req('get',url,hea_,cookies,par)

    return resp

def EPGinfo(cid):
    now=int(time.time())
    epg=getEPG(cid,now,now+12*60*60)
    plot=''
    for e in epg:
        end=strToDate(e['till']).timestamp()
        if end>now:
            title=e['title']
            since=e['since'].split(' ')[-1][:-3]
            till=e['till'].split(' ')[-1][:-3]
            if 'genres' in e:
                if len(e['genres'])>0:
                    genres=', '.join([g['name'] for g in e['genres']])
                    title+=' [I]- %s[/I]'%(genres)
            ep_data=''
            if 'season' in e:
                if e['season']!=None:
                    ep_data+='S'+str(e['season'])
            if 'episode' in e:
                if e['episode']!=None:
                    ep_data+='E'+str(e['episode'])
            
            if ep_data!='':
                title+=' [%s]'%(ep_data)
            plot+='[B]%s - %s[/B] %s\n'%(since,till,title)
    
    if plot=='':
        plot='Brak danych EPG'
    dialog = xbmcgui.Dialog()
    dialog.textviewer('EPG', plot)     

    
def channels(categ=None):
    url=apiURL+'products/lives'
    paramsURL=paramsGen()
    if categ!=None:
        paramsURL['categorySlug[]']=categ
    resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
    chans=[]
    for c in resp:
        if c['liveType']=='LIVE':
            if availVer(c['id']) : #test
                chName=c['title']
                cid=c['id']
                #cu
                if 'catchUpAvailable' in c or 'backwardsEpgAvailable' in c or addon.getSetting('cuAll')=='true':
                    cu=True
                    if 'backwardsEpgAvailabilityInDays' in c:
                        cuDur=c['backwardsEpgAvailabilityInDays']
                    else:
                        cuDur=7
                else:
                    cu=False
                    cuDur=0
                #npvr
                npvr=False
                if addon.getSetting('cuAll')=='true':
                    npvr=True
                if 'npvrAvailable' in c:
                    if c['npvrAvailable']:
                        npvr=True
                try:
                    img=c['logos']['L1x1_cl'][0]['url']
                except:
                    img=img_empty
                chans.append([chName,cid,img,cuDur,cu,npvr])
    
    return chans

def setTvCateg(): #helper
    tv_categ=addon.getSetting('tv_categ')
    tv_categ='live-Wszystkie' if tv_categ=='' else tv_categ
    categs=eval(openF(PATH_profile+'tv_categs.txt'))
    
    labs=[c['name'] for c in categs]
    
    select=xbmcgui.Dialog().select('Kategoria:', labs)
    if select>-1:
        new_tv_categ=categs[select]['slug']
    else:
        new_tv_categ=tv_categ
    
    if new_tv_categ!=tv_categ:
        addon.setSetting('tv_categ',new_tv_categ)
        xbmc.executebuiltin('Container.Refresh()')

        
def tvList(t):
    tv_categ=addon.getSetting('tv_categ')
    tv_categ='live-Wszystkie' if tv_categ=='' else tv_categ
    categs=eval(openF(PATH_profile+'tv_categs.txt'))
    
    if len(categs)>0:
        #wybór kategorii
        categName=[ct['name'] for ct in categs if ct['slug']==tv_categ][0]
        tit='[COLOR=cyan][B] Kategoria: [/B][/COLOR]%s'%(categName)
        url=build_url({'mode':'setTvCateg'})
        img='DefaultGenre.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        addItemList(url, tit, setArt, isF=False)
    
        chans=channels(tv_categ)
    else:
        chans=channels()
        
    for c in chans:
        if t=='live' or (t=='replay' and c[4]) or (t=='ptv' and c[5]):
            img='https:'+c[2] if c[2].startswith('//') else c[2]
            name=c[0]
            cid=c[1]

            if t=='live':
                isPlayable='true'
                isFolder=False
                url=build_url({'mode':'playSource','cid':cid,'tsDur':'7200'})
                plot='EPG dostępne z poziomu menu kontekstowego'
                contMenu=True
                cmItems=[
                    ('[B]EPG[/B]','RunPlugin(plugin://plugin.video.play_now?mode=EPGinfo&cid='+str(cid)+')')
                ]
                
            elif t in ['replay','ptv']:
                isPlayable='false'
                isFolder=True
                if t=='replay':
                    url=build_url({'mode':'calendar','cid':cid,'cuDur':str(c[3]),'chName':name})
                else:
                    url=build_url({'mode':'calendar','cid':cid})
                plot=''
                contMenu=False
                cmItems=[]
                        
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
            iL={'title': name,'sorttitle': name,'plot': plot}
            addItemList(url, name, setArt, 'video', iL, isF=isFolder, isPla=isPlayable, contMenu=contMenu, cmItems=cmItems)
    
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)

def calendar(cid,cuDur,chName):
    days=int(cuDur) if cuDur!=None else 7
    now=datetime.datetime.now()
    for i in range(0,days+1):
        if cuDur!=None:
            date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
            cd=cuDur
        else:
            date=(now+datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
            cd=''
        
        chName='' if chName==None else chName
        
        setArt={'icon': 'DefaultYear.png','fanart':fanart}
        url=build_url({'mode':'programList','cid':cid,'date':date,'cuDur':cd,'chName':chName})
        addItemList(url, date, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def convStrDate(x):
    ar=[[':',''],['-',''],[' ','_']]
    for a in ar:
        x=x.replace(a[0],a[1])
    return x

def programList(cid,d,cuDur,chName):
    period=int(cuDur) if cuDur!=None else 7
    now=time.time()
    ts_d=strToDate(d,'%Y-%m-%d')
    ts=ts_d.timestamp()
    if ts<now-period*24*60*60 and cuDur!=None: 
        ts=now-period*24*60*60
    te=(ts_d+datetime.timedelta(days=1)).timestamp()
    if te>now and cuDur!=None:
        te=now
    epg=getEPG(cid,int(ts),int(te))
    for e in epg:
        start=strToDate(e['since']).timestamp()
        end=strToDate(e['till']).timestamp()
        if (start>now-period*24*60*60 and start<now and cuDur!=None) or (end>now and end<now+period*24*60*60 and cuDur==None):
            pid=str(e['id'])
            title=e['title']
            since=e['since'].split(' ')[-1][:-3]
            till=e['till'].split(' ')[-1][:-3]
            name='[B]%s - %s[/B] %s'%(since,till,title)
            if 'season' in e:
                if e['season']!='' and e['season']!=None:
                    name+= ' sez. %s'%(str(e['season']))
            if 'episode' in e:
                if e['episode']!='' and e['episode']!=None:
                    name+= ' odc. %s'%(str(e['episode']))
            if 'genres' in e:
                if e['genres']!=None:
                    if len(e['genres'])>0:
                        name+= ' - [I]%s[/I]'%(str(e['genres'][0]['name']))
                        
            iL,title,img=contDet(e)
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            cuType=addon.getSetting('cuType')
            
            if cuDur!=None: #cu
                isP='true'
                if cuType=='time':
                    t_s=convStrDate(e['since'])
                    t_e=convStrDate(e['till'])
                    url=build_url({'mode':'playSource','cid':cid,'s':t_s,'e':t_e})
                else:
                    url=build_url({'mode':'playReplay','pid':pid})
                titleFav='%s | %s %s'%(chName,d,name)
                cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.play_now?mode=favAdd&url='+quote(url)+'&title='+quote(titleFav)+'&iL='+quote(str(iL))+'&art='+quote(str(setArt))+')')]
            else: #ptv
                isP='false'
                url=build_url({'mode':'setRec','pid':pid})
                cmItems=[]
            
            
            addItemList(url, name, setArt, 'video', iL, False, isP, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def setRec(pid):
    recs=recList()
    recsIds=[str(r['epgId']) for r in recs]
    if pid in recsIds:
        xbmcgui.Dialog().notification('Play Now', 'Nagranie zostało już wcześniej zlecone', xbmcgui.NOTIFICATION_INFO)
        return
    
    url=apiURL+'products/lives/recordings/epgs/'+pid
    resp=req('post',url,heaGen(),cookiesGen(),paramsGen())
    if 'message' in resp:
        xbmcgui.Dialog().notification('Play Now', 'Usługa niedostępna: '+resp['message'], xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Play Now', 'Nagranie zlecone', xbmcgui.NOTIFICATION_INFO)

def delRec(pid):
    url=apiURL+'products/lives/recordings/'+pid
    resp=req('delete',url,heaGen(),cookiesGen(),paramsGen(),j=False)
    if resp.status_code==200:
        xbmc.executebuiltin('Container.Refresh()')
    else:
        xbmc.log('@@@Błąd-usuwanie nagrania: '+str(resp.text), level=xbmc.LOGINFO)
        
def pendRec():
    xbmcgui.Dialog().notification('Play Now', 'Oczekujące na nagranie', xbmcgui.NOTIFICATION_INFO)

def replaceStreamParams(Url,type,limit): #helper
    url_qsl=dict(parse_qsl(Url))
    if type=='lic':
        if 'securityLevel' in url_qsl:
            p=url_qsl['securityLevel']
            Url=Url.replace('securityLevel=%s'%(p),'securityLevel=L1')
        if 'maxHeight' in url_qsl:
             p=url_qsl['maxHeight']
             if int(p)<limit:
                 Url=Url.replace('maxHeight=%s'%(p),'maxHeight=%s'%(str(limit)))
    elif type=='manifest':
        if 'maxBitrate' in url_qsl:
            p=url_qsl['maxBitrate']
            if int(p)<limit:
                Url=Url.replace('maxBitrate=%s'%(p),'maxBitrate=%s'%(str(limit)))
    return Url
    
def playSource(c,tsDur,contType='LIVE',ts=None,te=None):
    url=apiURL+'products/'+c+'/player/configuration?type='+contType+'&platform='+platform2
    resp=req('get',url,heaGen(),cookiesGen())
    
    if 'message' in resp:
        xbmcgui.Dialog().notification('Play Now', 'Usługa niedostępna: '+resp['message'], xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        vidSess=resp['videoSession']['videoSessionId']
        drmMultikey=resp['drmMultikey']
        
        url=apiURL+'products/'+c+'/playlist'#?type='+contType+'&version=3&dai=false&videoSessionId='+vidSess+'&drmMultikey=false&platform='+platform2
        paramsURL={
            'type':contType,
            'version':'3',
            'dai':'false',
            'videoSessionId':vidSess,
            'drmMultikey':drmMultikey,
            'platform':platform2
        }
        
        resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
        try:
            drm_profile=addon.getSetting('drm_profile') #2026-02-25
            s_url=resp['sources']['DASH'][0]['src']
            s_url=s_url.replace('&dvr=28+800+000','')
            if drmMultikey:
                if drm_profile!='L1':
                    s_url+='&maxBitrate=2500000'
                
 
            xbmc.log('@@@STREAM_URL: '+s_url, level=xbmc.LOGINFO)
                       
            if ts !=None: #catchup SC
                base=datetime.datetime(*(time.strptime('2001-01-01 01:00', "%Y-%m-%d %H:%M")[0:6])).timestamp()
                tstart=int(int(ts)-base)*1000
                tend=int(int(te)-base)*1000 
                stream_url=s_url+addToUrl(s_url,'startTime='+str(tstart)+'&stopTime='+str(tend))
                
                if int(te)>=int(time.time()): #arch: trwający program
                    stream_url=stream_url.split('&stopTime')[0]

            else:
                stream_url=s_url
                if contType=='LIVE' and tsDur!=None: #timeshift ISA
                    stream_url+=addToUrl(stream_url,'dvr=7200000')
            
            if stream_url.startswith('//'):
                stream_url='https:'+stream_url
            
            cdnType=resp['sources']['DASH'][0]['cdnType']
            
            if 'drm' in resp and cdnType not in ['POLSAT']:
                if 'WIDEVINE' in resp['drm']:
                    if 'multikey' in resp['drm']['WIDEVINE']:
                        if drm_profile=='L1':
                            licURLs=[l['src'] for l in resp['drm']['WIDEVINE']['multikey'] if l['securityLevel']=='L1']
                        else:
                            licURLs=[l['src'] for l in resp['drm']['WIDEVINE']['multikey'] if l['securityLevel']=='L3']
                        licURL=licURLs[0]
                    else:
                        licURL=resp['drm']['WIDEVINE']['src']

                    cookies=cookiesGen()
                    heaLic={
                        'User-Agent':UA,
                        'Referer':baseurl,
                        'Origin':baseurl[:-1],
                        'Cookie':'; '.join([str(x) + '=' + str(y) for x, y in cookies.items()]),
                        'Content-Type':''
                    }
                    lic='%s|%s|%s|'%(licURL,urlencode(heaLic),'R{SSM}')
                    #K22
                    drm_config={
                        "com.widevine.alpha": {
                            "license": {
                                "server_url": licURL,
                                "req_headers": urlencode(heaLic)
                            }
                        }
                    }
            else:
                licURL=''
                heaLic=''
                lic=''
                
        except:
            stream_url=None
        print(stream_url)
        
        if stream_url!=None:
            import inputstreamhelper
            PROTOCOL = 'mpd'
            DRM = 'com.widevine.alpha'
            is_helper = inputstreamhelper.Helper(PROTOCOL,DRM)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=stream_url)
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty('IsPlayable', 'true')
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA)
                
                if 'startTime' in stream_url and 'stopTime' not in stream_url: #arch: trwający program #contType=='EPG_ITEM' or ts!=None:
                    play_item.setProperty('ResumeTime', '1')
                    play_item.setProperty('TotalTime', '1')
                
                if licURL!='':
                    kodiVer=xbmc.getInfoLabel('System.BuildVersion')
                    if int(kodiVer.split('.')[0])<22:
                        play_item.setProperty('inputstream.adaptive.license_type',DRM)
                        play_item.setProperty('inputstream.adaptive.license_key',lic)
                    else:
                        play_item.setProperty('inputstream.adaptive.drm', json.dumps(drm_config))
                  
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

        else:
            xbmcgui.Dialog().notification('Play Now', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    

def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Play Now', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Play Now', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    if chans !=False:
        data = '#EXTM3U\n'
        for c in chans:
            name=c[0]
            img='https:'+c[2] if c[2].startswith('//') else c[2]
            
            cid=c[1]
            if c[3]!=0: #CATCHUP SC
                cuDur=str(c[3])#'7'
                data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="PlayNow" catchup="append" catchup-source="&s={utc:Ymd_HMS}&e={utcend:Ymd_HMS}" catchup-days="%s" catchup-correction="0.0",%s\nplugin://plugin.video.play_now?mode=playSource&cid=%s\n' %(name,img,cuDur,name,cid)

            else:
                data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Play Now" ,%s\nplugin://plugin.video.play_now?mode=playSource&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('Play Now', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Play Now', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)
   

def vodCategs():
    url=apiURL+'products/categories'
    paramsURL=paramsGen()
    paramsURL['type']='VOD'
    resp=req('get',url,heaGen(),cookiesGen(),paramsURL)

    for r in resp:
        name=r['name']
        categ=r['slug']
        img='DefaultGenre.png'
        
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url=build_url({'mode':'vodList','categ':categ})
        addItemList(url, name, setArt)
    
    if len(resp)<=1:
        url=apiURL+'products/sections/movie'
        paramsURL={
            'maxResults':'50',
            'firstResult':'0'
        }
        ps=eval(addon.getSetting('priceStrategyIds'))
        for p in ps:
            paramsURL['priceStrategyId[]']=str(p)
        paramsURL.update(paramsGen())
        resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
        for r in resp:
            if r['type']=='SECTION' and r['layout']=='HORIZONTAL_SLIDER':
                name=r['title']
                categ=r['urlBrowser'].split('?')[0]
                img='DefaultGenre.png'
                
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
                url=build_url({'mode':'vodList','categ':categ})
                addItemList(url, name, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

sortTypes={'Data dodania':'validSince|desc','Tytuł':'title|asc','Ocena Filmweb':'filmweb|desc','Rok produkcji':'year|desc'}

def setSortType():
    sort=addon.getSetting('sort_vod')
    sort=sort if sort!='' else 'Data dodania'
    
    labs=list(sortTypes)
    
    select=xbmcgui.Dialog().select('Sortuj wg:', labs)
    if select>-1:
        new_sort=labs[select]
    else:
        new_sort=sort
    
    if new_sort!=sort:
        addon.setSetting('sort_vod',new_sort)
        xbmc.executebuiltin('Container.Refresh()')

def addItem(i,seasNo=None,record=False):#helper
    cid=str(i['id'])
    iL,title,img=contDet(i,seasNo,record)
    if record:
        isF=False
        status=i['status']
        if status=='READY':
            isP='true'
            URL=build_url({'mode':'playRec','vid':cid})
        else:
            isP='false'
            URL=build_url({'mode':'pendRec'})
            title='[COLOR=gray]'+title+'[/COLOR]'
    
    elif iL['mediatype'] in ['movie','episode']:
        isF=False
        isP='true'
        ct='VOD' if iL['mediatype']=='movie' else 'VOD_EPISODE'
        if i['type']!='EPG_ITEM': #do search
            URL=build_url({'mode':'playVOD','vid':cid,'ct':ct})
        else:
            URL=build_url({'mode':'playReplay','pid':cid})
            
    elif iL['mediatype']=='tvshow':
        isF=True
        isP='false'
        URL=build_url({'mode':'seasList','cid':cid})
    
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
    
    if not record:
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.play_now?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&art='+quote(str(setArt))+')')]
    else:
        cmItems=[('[B]Usuń nagranie[/B]','RunPlugin(plugin://plugin.video.play_now?mode=delRec&pid='+cid+')')]
    
    addItemList(URL, title, setArt, 'video', iL, isF, isP, True, cmItems)
            
def contDet(i,seasNo=None,record=False):#helper
    title=i['title'] if not record else i['name']
    originalTitle=i['originalTitle'] if 'originalTitle' in i else ''
    desc=i['description'] if 'description' in i else ''
    if 'genres' in i:
        genres=[g['name'] for g in i['genres']]
    else:
        genres=[]
    if len(genres)==0:
        if 'genre' in i:
            if i['genre']!=None:
                genres=[i['genre']['name']]
    
    year=i['year'] if 'year' in i else 0
    mpaa=str(i['rating']) if 'rating' in i else ''
    dur=i['duration']*60 if 'duration' in i else 0
    
    iL={'title':title,'originaltitle':originalTitle,'plot':desc,'year':year,'genre':genres,'duration':dur}
    
    if record:
        iL['mediatype']='movie'
        recData={
            'Start':i['since'],
            'Stop':i['till'],
            'Dostępne do':i['expiresAt'],
            'Kanał':i['live']['title']
        }
        desc=iL['plot']
        iL['plot']='\n'.join(['[COLOR=cyan]%s:[/COLOR] %s'%(k,recData[k]) for k in recData])+'\n\n'+desc
    else:    
        type=i['type']
        if type=='VOD':
            iL['mediatype']='movie'
        elif type=='VOD_SERIAL':
            iL['mediatype']='tvshow'
        elif type=='VOD_EPISODE':
            iL['mediatype']='episode'
            if 'episode' in i:
                iL['episode']=i['episode']
                iL['season']=int(seasNo)

        elif type=='EPG_ITEM': #do search
            try:
                chan=i['live']['title']
                date=i['since'].replace(' ',' | ')[:-3]
                desc='[COLOR=cyan]%s[/COLOR]\n%s\n\n%s'%(chan,date,iL['plot'])
                iL['plot']=desc
            except:
                pass
            if 'season' in i:
                iL['mediatype']='episode'
                iL['episode']=i['episode'] if 'episode' in i else 0
                iL['season']=i['season']
                title +=' odc. %s'%(str(iL['episode']))
                iL['title']=title
            else:
                iL['mediatype']='movie'
    
    
    if 'covers' in i:
        img=i['covers']['L16x9'][0]['url']
    elif 'images' in i:
        img=i['images']['L16x9'][0]['url']
    img='https:'+img if img.startswith('//') else img
    
    return iL,title,img

def vodList(c,p):
    cnt=100
    page=p if p!=None else '1'
    sort=addon.getSetting('sort_vod')
    sort=sort if sort!='' else 'Data dodania'
    st,sd=sortTypes[sort].split('|')
    ct=['VOD','SERIAL'] if c!='vod-Seriale' else ['SERIAL']
    if page=='1':
        #wybór sortowania
        tit='[B][COLOR=cyan]Sortowanie: [/COLOR][/B]%s'%(sort)
        img=img_empty
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url=build_url({'mode':'setSortType'})
        addItemList(url, tit, setArt, isF=False)
    
    url=apiURL+'products/vods'
    paramsURL=paramsGen()
    paramsURL.update({
        'firstResult':str((int(page)-1)*cnt),
        'sort':st,
        'order':sd,
        'maxResults':str(cnt),
        'categorySlug[]':c,
        'type[]':ct
    })


    resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
    if 'items' in resp:
        for i in resp['items']:
            addItem(i)
    
        #paginacja
        totalCount=resp['meta']['totalCount']
        if cnt*(int(page)-1)+len(resp['items'])<totalCount:
            img=img_empty
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            url=build_url({'mode':'vodList','categ':c,'page':str(int(page)+1)})
            addItemList(url, '[B][COLOR=cyan]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
 
def seasList(cid):
    url=apiURL+'products/vods/'+cid
    paramsURL=paramsGen()
    resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
    if 'seasons' in resp:
        saveF(PATH_profile+'seasons.txt',str(resp['seasons']))
        for s in resp['seasons']:
            seasNo=str(s['number'])
            title='Sezon %s'%(seasNo)
            sid=str(s['id'])
            img='DefaultAddonVideo.png'
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            url=build_url({'mode':'epList','sid':sid,'seasNo':seasNo})
            addItemList(url, title, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def epList(sid,seasNo):
    seasons=eval(openF(PATH_profile+'seasons.txt'))
    season=[s for s in seasons if s['id']==int(sid)]
    if len(season)>0:
        episodes=season[0]['episodes']
        for e in episodes:
            addItem(e,seasNo)
            
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def recList(): #helper
    url=apiURL+'products/lives/recordings/directories'
    paramsURL=paramsGen()
    resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
    if 'recordings' in resp:
        res=resp['recordings']
    else:
        res=[]
    return res
        
def rec():
    '''
    url=apiURL+'products/lives/recordings/directories'
    paramsURL=paramsGen()
    resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
    if 'recordings' in resp:
    '''
    resp=recList()
    for r in resp:
        addItem(r,record=True)
            
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)        
    
        
def search():
    qry=xbmcgui.Dialog().input('Szukaj:', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        url=apiURL+'products/search'
        paramsURL={
            'firstResult':'0',
            'maxResults':'100',
            'keyword':qry,
        }
        paramsURL.update(paramsGen())

        contTypes=['VOD','EPG_ITEM']
        labels={'VOD':'Wideo','EPG_ITEM':'Było w TV - oglądaj teraz'}
        for c in contTypes:
            if c=='EPG_ITEM':
                paramsURL['dateFilterType']='PAST'
            paramsURL['type[]']=c
            resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
            if c in resp:
                data=resp[c]
                if 'meta' in data:
                    totalCount=data['meta']['totalCount']
                    if totalCount>0:
                        name='%s (%s)'%(labels[c],str(totalCount))
                        img='DefaultGenre.png'
            
                        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
                        URL=build_url({'mode':'searchRes','query':qry,'contType':c})
                        addItemList(URL, name, setArt)

        xbmcplugin.endOfDirectory(addon_handle)
    else:
        main_menu()

def searchRes(ct,q,p):
    cnt=100
    page=p if p!=None else '1'
    url=apiURL+'products/search'
    paramsURL={
        'firstResult':str((int(page)-1)*cnt),
        'maxResults':str(cnt),
        'keyword':q,
        'type[]':ct,
    }
    paramsURL.update(paramsGen())

    if ct=='EPG_ITEM':
        paramsURL['dateFilterType']='PAST'
    resp=req('get',url,heaGen(),cookiesGen(),paramsURL)
    if ct in resp:
        data=resp[ct]
        for i in data['items']:
            addItem(i)
        
        #paginacja
        totalCount=data['meta']['totalCount']
        if cnt*(int(page)-1)+len(data['items'])<totalCount:
            img=img_empty
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            url=build_url({'mode':'searchRes','contType':ct,'page':str(int(page)+1)})
            addItemList(url, '[B][COLOR=cyan]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

#FAV
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        URL=j[0]
        if 'playReplay' in URL or 'playVOD' in URL or 'playSource' in URL:
            isP='true'
            isF=False
        else:
            isP='false'
            isF=True
        
        cmItems=[('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.play_now?mode=favDel&url='+quote(j[0])+')')]
        iL=eval(j[2])
        setArt=eval(j[3])
        addItemList(URL, j[1], setArt, 'video', iL, isF, isP, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,l,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,l,i])
        xbmcgui.Dialog().notification('PlayNow', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('PlayNow', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('PlayNow', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('PlayNow', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO) 


mode = params.get('mode', None)

if not mode:
    if addon.getSetting('uid')=='' or addon.getSetting('uid')==None:
        addon.setSetting('uid',code_gen(32))
    if addon.getSetting('logged')=='true':
        products()
        tvCategs()
        main_menu()

    else:
        main_menu()
else:
    if mode=='logIn':#
        logIn()
    
    if mode=='logInCont':#
        logInCont()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.play_now/,replace)')
    
    if mode=='logOut':
        logOut()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.play_now/,replace)')
    
    if mode=='setTvCateg':
        setTvCateg()
    
    if mode=='tvList':
        tvList('live')
    
    if mode=='replay':
        tvList('replay')
        
    if mode=='ptv':
        tvList('ptv')
        
    if mode=='calendar':
        cid=params.get('cid')
        cuDur=params.get('cuDur')
        chName=params.get('chName')
        calendar(cid,cuDur,chName)
        
    if mode=='programList':
        cid=params.get('cid')
        date=params.get('date')
        cuDur=params.get('cuDur')
        chName=params.get('chName')
        programList(cid,date,cuDur,chName)
        
    if mode=='playReplay':
        pid=params.get('pid')
        playSource(pid,'0','EPG_ITEM')
        
    if mode=='EPGinfo':
        cid=params.get('cid')
        EPGinfo(cid)
        
    if mode=='playSource':
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            tsDur=params.get('tsDur')
            ts=None
            te=None
            s=params.get('s')
            e=params.get('e')
            if s!=None and e!=None:
                co=int(addon.getSetting('cuOffset'))
                ts=str(int((strToDate(s, "%Y%m%d_%H%M%S")+datetime.timedelta(hours=co)).timestamp()))
                te=str(int((strToDate(e, "%Y%m%d_%H%M%S")+datetime.timedelta(hours=co)).timestamp()))            
            playSource(cid,tsDur,'LIVE',ts,te)
        else:
            xbmcgui.Dialog().notification('Play Now', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
            
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('Play Now', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
            
    if mode=='vodCategs':
        vodCategs()
        
    if mode=='vodList':
        categ=params.get('categ')
        page=params.get('page')
        vodList(categ,page)
        
    if mode=='setSortType':
        setSortType()
        
    if mode=='seasList':
        cid=params.get('cid')
        seasList(cid)
        
    if mode=='epList':
        sid=params.get('sid')
        seasNo=params.get('seasNo')
        epList(sid,seasNo)
        
    if mode=='playVOD':
        vid=params.get('vid')
        ct=params.get('ct')
        playSource(vid,'0','MOVIE')
        
    if mode=='playRec':
        vid=params.get('vid')
        playSource(vid,'0','RECORDING')
    
    if mode=='pendRec':
        pendRec()
    
    if mode=='rec':
        rec()
        
    if mode=='setRec':
        pid=params.get('pid')
        setRec(pid)
    
    if mode=='delRec':
        pid=params.get('pid')
        delRec(pid)
    
    if mode=='search':
        search()
        
    if mode=='searchRes':
        contType=params.get('contType')
        query=params.get('query')
        page=params.get('page')
        searchRes(contType,query,page)
    
    #FAV
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        i=params.get('iL')
        a=params.get('art')
        favAdd(u,t,i,a)
        
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
