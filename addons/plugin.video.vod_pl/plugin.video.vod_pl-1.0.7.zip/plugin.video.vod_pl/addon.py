# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import random
import time
import datetime
import math
from base64 import b64decode as getData
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.vod_pl')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=''

mode = addon.getSetting('mode')
baseurl='https://vod.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/116.0'
platform='BROWSER'
hea={
    'User-Agent':UA,
    'Referer':baseurl
}

tl='eyd0dm4nOnsnbmFtZSc6J1RWTicsJ3NyYyc6J2h0dHBzOi8vci5kY3MucmVkY2RuLnBsL2xpdmVkYXNoL28yL3R2bnBsYXllci9saXZlL3R2bi9saXZlLmlzbWwvcGxheWxpc3QubXBkP2luZGV4TW9kZT0mZHVtbXlmaWxlPScsJ2xpY1VSTCc6J2h0dHBzOi8vcGxheWVyLnBsL3BsYXllcmFwaS9wcm9kdWN0L2RybS93aWRldmluZS8xOTA4NDczP3BsYXRmb3JtPUFORFJPSURfVFYmdHlwZT1MSVZFfFVzZXItQWdlbnQ9dWF1YXVhJkNvbnRlbnQtVHlwZT18UntTU019fCd9LCdtZXRybyc6eyduYW1lJzonTWV0cm8nLCdzcmMnOidodHRwczovL3IuZGNzLnJlZGNkbi5wbC9saXZlZGFzaC9vMi90dm5wbGF5ZXIvbGl2ZS9tZXRyby9saXZlLmlzbWwvcGxheWxpc3QubXBkP2luZGV4TW9kZT0mZHVtbXlmaWxlJywnbGljVVJMJzonaHR0cHM6Ly9wbGF5ZXIucGwvcGxheWVyYXBpL3Byb2R1Y3QvZHJtL3dpZGV2aW5lLzI5MzA3NTI/cGxhdGZvcm09QU5EUk9JRF9UViZ0eXBlPUxJVkV8VXNlci1BZ2VudD11YXVhdWEmQ29udGVudC1UeXBlPXxSe1NTTX18J30sJ3R2bjI0Jzp7J25hbWUnOidUVk4yNCBhdWRpbycsJ3NyYyc6J2h0dHBzOi8vci5kY3MucmVkY2RuLnBsL2xpdmVkYXNoL28yL3R2bjI0Z28vbGl2ZS90dm4yNC9hdWRpby5pc21sP2luZGV4TW9kZT0nLCdsaWNVUkwnOidodHRwczovL2dvLnR2bjI0LnBsL2FwaS9wcm9kdWN0cy8xMjMzMC9kcm0vd2lkZXZpbmU/cGxhdGZvcm09QU5EUk9JRF9UViZ0eXBlPUxJVkV8VXNlci1BZ2VudD11YXVhdWEmQ29udGVudC1UeXBlPXxSe1NTTX18J30sJ3R2bjI0YmlzJzp7J25hbWUnOidUVk4yNCBCaVMgYXVkaW8nLCdzcmMnOidodHRwczovL3IuZGNzLnJlZGNkbi5wbC9saXZlZGFzaC9vMi90dm4yNGdvL2xpdmUvdHZuMjRfYmlzL2F1ZGlvLmlzbWw/aW5kZXhNb2RlPScsJ2xpY1VSTCc6J2h0dHBzOi8vZ28udHZuMjQucGwvYXBpL3Byb2R1Y3RzLzEyMzMxL2RybS93aWRldmluZT9wbGF0Zm9ybT1BTkRST0lEX1RWJnR5cGU9TElWRXxVc2VyLUFnZW50PXVhdWF1YSZDb250ZW50LVR5cGU9fFJ7U1NNfXwnfX0='

def build_url(query):
    return base_url + '?' + urlencode(query)
    
def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt)
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def heaGen():
    CorrelationID='client_'+code_gen(8)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(12)
    hea.update({'API-CorrelationId':CorrelationID,'API-DeviceUid':addon.getSetting('DeviceUid')})
    '''
    if addon.getSetting('logged')=='true':
        hea.update({'API-Authentication':addon.getSetting('API_Authentication'),'API-ProfileUid':addon.getSetting('API_ProfileUid')})
    '''
    return hea
    
def sortMethod():
    sm=''
    m=addon.getSetting('sortContent')
    tb={
        'Najnowsze':'sort=createdAt&order=desc',
        'Najstarsze':'sort=createdAt&order=asc',
        'A-Z':'order=asc',
        'Z-A':'order=desc'
    }
    return tb[m] 
        
def locTime(x):
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%d %H:%M:%S')[0:6]))
    z=y.strftime('%Y-%m-%d %H:%M')
    return z

mainCategs=[
    ['SERIALE','categList','1','DefaultAddonVideo.png'],
    ['FILMY','categList','3','DefaultAddonVideo.png'],
    ['PROGRAMY','categList','2','DefaultAddonVideo.png'],
    ['SHORTY','categList','130','DefaultAddonVideo.png'],
    ['TV','tv','live','DefaultTVShows.png'],
    ['Archiwum TV','tv','replay','DefaultTVShows.png'],
    ['Strona główna','mainPage','main','OverlayUnwatched.png'],
    ['Ostatnio dodane','mainPage','recently_added','OverlayUnwatched.png'],
    ['wyszukiwarka','search','','DefaultAddonsSearch.png'],
    ['ULUBIONE','favList','','DefaultMusicRecentlyAdded.png']
]

category={'1':'seriale-online','2':'programy-online','3':'filmy-online','130':'shorty','131':'ostatnio-dodane'}

def main_menu():
    for s in mainCategs:
        if s[1]=='categList' or s[1]=='mainPage':
            URL=build_url({'mode':s[1],'mainCateg':s[2]})
        elif s[1]=='tv':
            URL=build_url({'mode':s[1],'type':s[2]})
        else:
            URL=build_url({'mode':s[1]})
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': s[3], 'fanart':''}
        addItemList(URL, s[0], setArt, 'video')
    xbmcplugin.endOfDirectory(addon_handle)

def categList(mc):
    u='https://vod.pl/playerapi/item/category/'+mc+'/genre/list?4K=true&platform='+platform
    hea_=heaGen()
    resp=requests.get(u,headers=hea_).json()
    arCateg=[['Wszystkie','all']]
    for c in resp:
        arCateg.append([c['name'],c['id']])
    for ac in arCateg:        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':str(ac[1]),'page':'1'})
        addItemList(url, ac[0], setArt, 'video')
    xbmcplugin.endOfDirectory(addon_handle)

def detCont(x):#
    plot=''
    if 'year' in x:
        plot+='[B]Rok prod.: [/B]'+str(x['year'])+'\n'
    if 'rating' in x:
        plot+='[B]Kat. wiekowa: [/B]'+str(x['rating'])+'\n'
    if 'displaySchedules' in x:
        i_cur=[i for i,t in enumerate(x['displaySchedules']) if t['active'] ][0]
        
        if x['displaySchedules'][i_cur]['type']!='SOON':
            '''
            if 'payable' in x:
                if x['payable']:
                    plot+='Płatny\n'
                else:
                    plot+='Bezpłatny\n'
            '''
            if 'since' in x['displaySchedules'][i_cur]:
                plot+='[B]Data publikacji: [/B]'+x['displaySchedules'][i_cur]['since'].split(' ')[0]+'\n'
            
            if x['displaySchedules'][i_cur]['type']=='PREMIERE':
                if 'till' in x['displaySchedules'][i_cur]:
                    plot+='[B]Dostępny do: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'#x['displaySchedules'][i_cur]['till'].split(' ')[0]
                plot+='[COLOR=yellow]PRAPREMIERA[/COLOR]\n'
            else:
                if 'till' in x['displaySchedules'][i_cur]:
                    plot+='[B]Dostępny do: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'
                if x['displaySchedules'][i_cur]['type']=='LAST_BELL':
                    plot+='[COLOR=yellow]OSTATNIA SZANSA[/COLOR]\n'
            

        else:
            plot+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
            plot+='[B]Dostępny od: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'
            '''
            if 'payableSince' in x:
                if x['displaySchedules'][i_cur]['till'].split(' ')[0]==x['payableSince'].split(' ')[0] :
                    plot+='Płatny\n'
                else:
                    plot+='Bezpłatny\n'
            else:
                plot+='Bezpłatny\n'
            '''
    if 'lead' in x:
        if x['lead']!='':
            plot+='[B]Opis: [/B][I]'+cleanText(x['lead'])+'[/I]'
    return plot

def getImg(x):#
    try:
        img=x['pc'][0]['mainUrl']
    except:
        img=''
    if img.startswith('//'):
        img='https:'+img
    return img
    
def titleWithTill(d,t):#data dostępności w tytule
    title=t
    tillPeriod=int(addon.getSetting('tillPeriod'))
    if 'Dostępny do: ' in d:
        till=re.compile('Dostępny do: (.*)').findall(d.replace('[/B]',''))[0]
        now=datetime.datetime.now()
        if (datetime.datetime(*(time.strptime(till,'%Y-%m-%d %H:%M')[0:6]))-now).days<=tillPeriod:
            title=t+' [COLOR=yellow]/do: '+till+'/[/COLOR]'
    return title

def contList(mc,c,p,v=None):
    cnt=addon.getSetting('epCount')
    start=(int(p)-1)*int(cnt)
    if c=='all':
        u=baseurl+'playerapi/product/vod/list?'+sortMethod()+'&maxResults='+cnt+'&firstResult='+str(start)+'&category[]='+category[mc]+'&4K=true&platform='+platform
    else:
        u=baseurl+'playerapi/product/vod/list?'+sortMethod()+'&maxResults='+cnt+'&firstResult='+str(start)+'&category[]='+category[mc]+'&genreId[]='+c+'&4K=true&platform='+platform
    if v:
        u+='&vodType[]='+'&vodType[]='.join(eval(v))
    if mc=='131': #ostatnio dodane    
        u=u.replace(sortMethod()+'&','')
        u+='&createdSinceDays=14'
        print('SSS')
        print(u)
    hea_=heaGen()
    resp=requests.get(u,headers=hea_).json()
    total=resp['meta']['totalCount']
    
    for r in resp['items']:
        cid=str(r['id'])
        name=r['title']
        type=r['type']
        img=getImg(r['images'])
        plot=''
        plot=detCont(r)#
        tid=r['shareUrl'].replace(baseurl,'').replace(',','_').replace('-','_').replace('/','_')
        
        mod=''
        isPlayable='false'
        isFolder=True
        if type=='SERIAL':
            mod='sezonList'
            URL = build_url({'mode':mod,'cid':cid,'title':name,'tid':tid})
        if type=='VOD' or type=='EPISODE':###
            if type=='EPISODE':
                if name=='':
                    try:
                        name='sez. '+str(r['season']['number'])+' odc. '+str(r['episode'])
                    except:
                        pass
                name=r['season']['serial']['title']+' | '+name
            name=titleWithTill(plot,name)
            if addon.getSetting('playFromList')=='true':
                mod='playVid'
                URL = build_url({'mode':mod,'eid':cid,'tid':tid})
                isPlayable='true'
                isFolder=False
            else:
                mod='progDetails'
                URL = build_url({'mode':mod,'eid':cid})
        
        i_cur=[i for i,t in enumerate(r['displaySchedules']) if t['active'] ][0]
        if (type=='SERIAL' or type=='VOD') and r['displaySchedules'][i_cur]['type']=='SOON':
            isPlayable='false'
            isFolder=False
                
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=favAdd&cid='+cid+'&name='+quote(name)+'&tid='+quote(tid)+'&mod='+mod+'&plot='+quote(plot)+'&img='+quote(img)+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=showDet&eid='+cid+')')
        ]
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
    
    if start+int(cnt)+1<total:
        vodType='' if v==None else str(v)
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':c,'page':str(int(p)+1),'vodType':vodType})
        addItemList(url, '[B]>>> Następna strona[/B]', setArt, 'video')
    
    if addon.getSetting('playFromList')=='true':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)

def sezonList(cid,tit,tid):
    hea_=heaGen()
    u=baseurl+'playerapi/product/vod/serial/'+cid+'/season/list?4K=true&platform='+platform
    resp=requests.get(u,headers=hea_).json()
    if len(resp)==1: #jeden sezon
        sezId=str(resp[0]['id'])
        episodeList(cid,sezId,tit,'1','yes',tid)
    else:
        for r in resp:
            sez_id=str(r['id'])
            sez_name=r['title']
            if sez_name=='':
                sez_name='sezon '+str(r['number'])
            
            iL={'title': '','sorttitle': '','plot': tit}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart':fanart}
            url = build_url({'mode':'episodeList','cid':cid,'sezId':sez_id,'title':tit,'init':'yes','page':'1','tid':tid})
            addItemList(url, sez_name, setArt, 'video', iL)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)    

def episodeList(cid,sezId,tit,pg,init,tid):
    cnt=int(addon.getSetting('epCount'))
    p=int(pg)
    if init=='yes':
        hea_=heaGen()
        u=baseurl+'playerapi/product/vod/serial/'+cid+'/season/'+sezId+'/episode/list?4K=true&platform='+platform
        resp=requests.get(u,headers=hea_).json()#list
        addon.setSetting('episodeJSON',str(resp))
    
    resp=eval(addon.getSetting('episodeJSON'))
    total=len(resp)
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        r=resp[i]
        eid=str(r['id'])
        title=''
        episode=r['episode']
        season=r['season']['number']
        if season!='':
            title+='sezon '+str(season)+' '
        title+='odcinek '+str(episode)
        episodeName=r['title']
        if episodeName !='':
            title+=' | '+r['title']
        img=getImg(r['images'])
        #st=r['externalUid']
        
        plot='[B]'+tit+'[/B]\n'
        plot+=detCont(r)#próba
        
        mod=''
        isPlayable='false'
        isFolder=True
        if addon.getSetting('playFromList')=='true':
            mod='playVid'
            isPlayable='true'
            isFolder=False
        else:
            mod='progDetails'
        
        i_cur=[i for i,t in enumerate(r['displaySchedules']) if t['active'] ][0]
        if r['displaySchedules'][i_cur]['type']=='SOON':
            mod='noPlay'
            isPlayable='false'
            isFolder=False
               
        cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=showDet&eid='+eid+')')]
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        url = build_url({'mode':mod,'eid':eid,'tid':tid})
        addItemList(url, titleWithTill(plot,title), setArt, 'video', iL, isFolder, isPlayable, True, cmItems)

    if p<math.ceil(total/cnt):
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''}
        url = build_url({'mode':'episodeList','init':'no','cid':cid,'sezId':sezId,'title':tit,'page':str(p+1),'tid':tid})
        addItemList(url, '[B]>>> Następna strona[/B]', setArt, 'video')
    
    if addon.getSetting('playFromList')=='true':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    #xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_PLAYLIST_ORDER)

def det(x):
    def iterTable(t,n):
        result=''
        for tt in t:
            result+=tt[n]+', '
        return result[:-2]
    
    title=''
    if x['type']=='EPISODE':
        episode=x['episode']
        season=x['season']['number']
        if season!='':
            title+='sezon '+str(season)+' '
        title+='odcinek '+str(episode)
        episodeName=x['title']
        if episodeName !='':
            title+=' | '+x['title']
    else:
        title=x['title']
    img=getImg(x['images'])
    plot=title+'\n'
    if 'rating' in x:
        plot+='[B]Wiek: [/B]'+str(x['rating'])+'\n'
    if 'duration' in x:
        plot+='[B]Długość: [/B]'+str(x['duration'])+' min.\n'
    if 'year' in x:
        plot+='[B]Rok prod.: [/B]'+str(x['year'])+'\n'
    if 'countries' in x:
        plot+='[B]'+iterTable(x['countries'],'name')+'[/B]\n'
    if 'genres' in x:
        if len(x['genres']):
            plot+='[B]Gatunek[/B]: '+iterTable(x['genres'],'name')+'\n'
    
    i_cur=[i for i,t in enumerate(x['displaySchedules']) if t['active'] ][0]
    if x['displaySchedules'][i_cur]['type']!='SOON':
        '''
        if 'payable' in x:
            if x['payable']:
                plot+='Płatny\n'
            else:
                plot+='Bezpłatny\n'
        '''
        if 'since' in x['displaySchedules'][i_cur]:
                plot+='[B]Data publikacji: [/B]'+x['displaySchedules'][i_cur]['since'].split(' ')[0]+'\n'
        if 'till' in x['displaySchedules'][i_cur]:
                plot+='[B]Dostępny do: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'
    else:
        plot+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
        plot+='[B]Dostępny od: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'
        '''
        if 'payableSince' in x:
            if x['displaySchedules'][i_cur]['till'].split(' ')[0]==x['payableSince'].split(' ')[0] :
                plot+='Płatny\n'
            else:
                plot+='Bezpłatny\n'
        else:
            plot+='Bezpłatny\n'
        '''
    if 'description' in x:
        plot+='[B]Opis: [/B][I]'+cleanText(x['description'])+'[/I]\n'
    if 'directors' in x:
        if len(x['directors']):
            plot+='[B]Reżyseria[/B]: '+iterTable(x['directors'],'name')+'\n'
    if 'actors' in x:
        if len(x['actors']):
            plot+='[B]Obsada[/B]: '+iterTable(x['actors'],'name')+'\n'
    if 'provider' in x:
        if 'name' in x['provider']:
            plot+='[B]Dystrybutor[/B]: '+x['provider']['name']+'\n'
                
    return title,img,plot

def showDet(eid):#menu kont
    hea_=heaGen()
    u=baseurl+'playerapi/product/vod/'+eid+'?4K=true&platform='+platform
    resp=requests.get(u,headers=hea_).json()
    title,img,plot=det(resp)
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)
    
def progDetails(eid,tid):
    hea_=heaGen()
    u=baseurl+'playerapi/product/vod/'+eid+'?4K=true&platform='+platform
    resp=requests.get(u,headers=hea_).json()
    title,img,plot=det(resp)
    tid=resp['shareUrl']
    
    iL={'title': '','sorttitle': '','plot': plot}
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
    url = build_url({'mode':'playVid','eid':eid,'tid':tid})
    addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def playVid(eid,tid,resume,isT,ts):
    if isT:
        d=eval(getData(tl).decode('utf-8'))
        protocol='mpd'
        stream_url=d[eid]['src']
        hea_player='User-Agent='+UA
        if ts !=None: #arch TV
            diff=(int(time.time())-int(ts))*1000
            stream_url=d[eid]['src']+'&dvr='+str(diff)
        lic_url=d[eid]['licURL'].replace('uauaua',quote(UA))
        subt=''
        subActive=False
    else:
        hea_=heaGen()
        u=baseurl+'playerapi/item/'+eid+'/playlist?type=MOVIE&page='+tid+'&version=3.1&4K=true&platform='+platform #zmienic na ANDROID ???
        resp=requests.get(u,headers=hea_).json()
        protocol='mpd'
        stream_url=resp['movie']['video']['sources']['dash']['url']
        hea_player='User-Agent='+UA+'&Referer='+baseurl
        hea.update({'Content-Type':''})
        heaLic=urlencode(hea)
        lic_url=resp['movie']['video']['protections']['widevine']['src'].replace('BROWSER','ANDROID')+'|'+heaLic+'|R{SSM}|'
        
        subt=resp['movie']['video']['subtitles']
        subActive=False
    
    import inputstreamhelper
    PROTOCOL = protocol
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hea_player)#K21
        play_item.setProperty('inputstream.adaptive.stream_headers', hea_player) 
        play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        if resume!=False: #start od wskazanego momentu (resume)
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            play_item.setProperty('ResumeTime', resume)
            play_item.setProperty('TotalTime', '1')
        if ts!=None:
            play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            play_item.setProperty('ResumeTime', '1')
            play_item.setProperty('TotalTime', '1')
        if 'pol' in subt:
            if subt['pol']['default']==True:
                play_item.setSubtitles([subt['pol']['src']])
                subActive=True
                
        #play_item.setSubtitles(sbt_src)
        play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
        play_item.setProperty("inputstream.adaptive.license_key", lic_url)
                  
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
        if subActive==True:
            while not xbmc.Player().isPlaying():
                xbmc.sleep(100)
            xbmc.Player().showSubtitles(True)

def tv(t):
    d=eval(getData(tl).decode('utf-8'))
    st=list(d.keys())
    for s in st:
        img=PATH+'/resources/img/'+d[s]['name']+'.png'
        
        if t=='live':
            url=build_url({'mode':'playT','sid':s})
            isPlayable='true'
            isFolder=False
            epg=getEPG(d[s]['name'])
        elif t=='replay':
            url=build_url({'mode':'calendar','sid':s})
            isPlayable='false'
            isFolder=True
            epg=''
        
        iL={'title': '','sorttitle': '','plot': epg}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
        addItemList(url, d[s]['name'], setArt, 'video', iL, isFolder, isPlayable)
    xbmcplugin.endOfDirectory(addon_handle)

def calendar(sid):
    now=datetime.datetime.now()
    for i in range(0,4):
        date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart':''}
        url=build_url({'mode':'programList','sid':sid, 'date':date})
        addItemList(url, date, setArt, 'video')
    xbmcplugin.endOfDirectory(addon_handle)

def programList(d,sid):
    epgProv=addon.getSetting('epgProv')
    if epgProv=='Emi' and sid!='tvn24' and sid!='tvn24bis':
        cs={'tvn':'17','metro':'753'}
        ts=int(datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6])).timestamp())*1000
        te=ts+24*60*60*1000
        url='http://lcapi.emitel.pl/api/programs?channelNumber='+cs[sid]+'&begin='+str(ts)+'&end='+str(te)
        h={
            'User-Agent':UA,
            'Referer':'http://hbbtvtest.emitel.pl/',
            'Origin':'http://hbbtvtest.emitel.pl'
        }
        try:
            resp=requests.get(url,headers=h).json()
        except:
            resp={'items':[]}
        for r in resp['items']:
            now=int(time.time())
            if r['startDate']>now-262140 and r['startDate']<now:
                title=r['title']
                if 'categories' in r:
                    if len(r['categories'])>0:
                        title+=' - [I]'+ '/'.join(r['categories'])+'[/I]'
                ts=timeEPG(r['startDate'])
                #te=timeEPG(r['endDate'])
                name='[B]%s[/B] %s\n'%(ts,title)
                tstart=str(r['startDate'])
                img='http://hbbtvtest.emitel.pl/hbb-resources/'+r['urlImage']
                desc=r['description'] #uzupełnić do biblioteki - rok produkcji, obsada itd
                descLong=r['descriptionLong']
                try:
                    year=int(r['productionYear']) if 'productionYear' in r else 0
                except:
                    year=0
                directors=r['persons']['directors'] if 'directors' in r['persons'] else []
                actors=r['persons']['actors'] if 'actors' in r['persons'] else []
                dur=r['duration']/1000 if 'duration' in r else 0
                genre=r['categories'] if 'categories' in r else ''
                                
                iL={'title': title,'sorttitle': '','plot': descLong,'plotoutline':desc,'year':year,'duration':dur,'director':directors,'cast':actors,'mediatype':'movie'}
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
                url=build_url({'mode':'playT','sid':s,'ts':tstart})
                addItemList(url, name, setArt, 'video', iL, False, 'true')
        xbmcplugin.setContent(addon_handle, 'videos') 
        xbmcplugin.endOfDirectory(addon_handle)
    
    elif epgProv=='WP':
        cs={'tvn':'17','metro':'753'}
        t0=strToTime(d)-datetime.timedelta(days=1)
        d0=timeToStr(t0,'%Y-%m-%d')
        progs=[]
        url='https://tv.wp.pl/api/v1/program/'+d0+'/'+cs[sid]
        h={
            'User-Agent':UA,
        }
        resp=requests.get(url,headers=h).json()
        progs=resp['data'][0]['entries']
        url='https://tv.wp.pl/api/v1/program/'+d+'/'+cs[sid]
        resp=requests.get(url,headers=h).json()
        progs+=resp['data'][0]['entries']
        
        for r in progs:
            now=datetime.datetime.now()
            start=now-datetime.timedelta(seconds=262140)
            if getTime(r['start'])>start and getTime(r['start'])<now and timeToStr(getTime(r['start']),'%Y-%m-%d')==d:
                title=r['title']
                if 'episode_title' in r:
                    title+=' - ' + r['episode_title']
                if 'genre' in r:
                    title+=' [I]('+ r['genre']+')[/I]'
                ts=timeToStr(getTime(r['start']),'%H:%M')
                name='[B]%s[/B] %s\n'%(ts,title)
                tstart=str(int(getTime(r['start']).timestamp()))
                img=r['photo'][0]['file']
                            
                #iL={'title': title,'sorttitle': '','plot': descLong,'plotoutline':desc,'year':year,'duration':dur,'director':directors,'cast':actors,'mediatype':'movie'}
                iL={'title': title,'sorttitle': '','plot': ''}
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
                url=build_url({'mode':'playT','sid':s,'ts':tstart})
                addItemList(url, name, setArt, 'video', iL, False, 'true')
        
        xbmcplugin.setContent(addon_handle, 'videos') 
        xbmcplugin.endOfDirectory(addon_handle)
    
    elif epgProv=='Player' or sid=='tvn24' or sid=='tvn24bis':
        cs={'tvn':'1908473','metro':'2930752','tvn24':'57630','tvn24bis':'57633'}
        t=datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6]))
        ts=str(1000*int(t.timestamp()))
        te=str(1000*int((t+datetime.timedelta(days=1)).timestamp()))
        url='https://player.pl/playerapi/product/live/epg/list?liveId[]=%s&since=%s&till=%s&platform=BROWSER'%(cs[sid],ts,te)
        h={
            'User-Agent':UA,
        }
        resp=requests.get(url,headers=h).json()
        def sortFN(i):
            return i['since']
        resp.sort(key=sortFN,reverse=False)
        now=time.time()
        epg=''
        for r in resp:
            now=int(time.time())
            since=datetime.datetime(*(time.strptime(r['since'], '%Y-%m-%d %H:%M:%S')[0:6])).timestamp()
            #till=datetime.datetime(*(time.strptime(r['till'], '%Y-%m-%d %H:%M:%S')[0:6])).timestamp()
            if since>now-262140 and since<now:
                title=r['title']
                t_s=r['since'].split(' ')[-1][:-3]
                if 'genres' in r:
                    title+=' - ' + r['genres'][0]['name']
                name='[B]%s[/B] %s\n'%(t_s,title)
                tstart=str(int(since))
                img=PATH+'/resources/img/'+sid+'.png'
                desc=r['description'] #        
                
                iL={'title': title,'sorttitle': '','plot': desc}
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
                url=build_url({'mode':'playT','sid':s,'ts':tstart})
                addItemList(url, name, setArt, 'video', iL, False, 'true')
        
        xbmcplugin.setContent(addon_handle, 'videos') 
        xbmcplugin.endOfDirectory(addon_handle)

def timeEPG(x):#Emi
    return datetime.datetime.fromtimestamp(x).strftime('%H:%M')

def getTime(x):#WP
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    t_utc=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    t_loc=t_utc+diff+datetime.timedelta(seconds=1)
    return t_loc
def timeToStr(x,y):#WP
    return x.strftime(y)
def strToTime(x):#WP
    return datetime.datetime(*(time.strptime(x,'%Y-%m-%d')[0:6]))
    
def getEPG(c):#Emitel
    epgProv=addon.getSetting('epgProv')
    if epgProv=='Emi' and c!='TVN24 audio' and c!='TVN24 BiS audio':
        cs={'TVN':'17','Metro':'753'}
        ts=int(time.time())*1000
        te=ts+12*60*60*1000
        url='http://lcapi.emitel.pl/api/programs?channelNumber='+cs[c]+'&begin='+str(ts)+'&end='+str(te)
        h={
            'User-Agent':UA,
            'Referer':'http://hbbtvtest.emitel.pl/',
            'Origin':'http://hbbtvtest.emitel.pl'
        }
        try:
            resp=requests.get(url,headers=h).json()
        except:
            resp={'items':[]}
        epg=''
        for r in resp['items']:
            title=r['title']
            if 'categories' in r:
                if len(r['categories'])>0:
                    title+=' - [I]'+ '/'.join(r['categories'])+'[/I]'
            ts=timeEPG(r['startDate'])
            #te=timeEPG(r['endDate'])
            epg+='[B]%s[/B] %s\n'%(ts,title)
        
        return epg
    
    elif epgProv=='WP':
        cs={'TVN':'17','Metro':'753'}
        today=datetime.datetime.now()
        yest=datetime.datetime.now()-datetime.timedelta(days=1)
        t=timeToStr(today,'%Y-%m-%d')
        y=timeToStr(yest,'%Y-%m-%d')
        progs=[]
        url='https://tv.wp.pl/api/v1/program/'+y+'/'+cs[c]
        h={
            'User-Agent':UA,
        }
        resp=requests.get(url,headers=h).json()
        progs=resp['data'][0]['entries']
        url='https://tv.wp.pl/api/v1/program/'+t+'/'+cs[c]
        resp=requests.get(url,headers=h).json()
        progs+=resp['data'][0]['entries']
        epg=''
        for r in progs:
            if getTime(r['end'])>datetime.datetime.now():
                title=r['title']
                if 'episode_title' in r:
                    title+=' - ' + r['episode_title']
                if 'genre' in r:
                    title+=' [I]('+ r['genre']+')[/I]'
                ts=timeToStr(getTime(r['start']),'%H:%M')
                epg+='[B]%s[/B] %s\n'%(ts,title)
        
        return epg        
    
    elif epgProv=='Player' or c=='TVN24 audio' or c=='TVN24 BiS audio':
        cs={'TVN':'1908473','Metro':'2930752','TVN24 audio':'57630','TVN24 BiS audio':'57633'}
        d=datetime.datetime.now().strftime('%Y-%m-%d')
        t=datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6]))
        ts=str(1000*int(t.timestamp()))
        t1=str(1000*int((t+datetime.timedelta(days=1)).timestamp()))
        t2=str(1000*int((t+datetime.timedelta(days=2)).timestamp()))
        url='https://player.pl/playerapi/product/live/epg/list?liveId[]=%s&since=%s&till=%s&platform=BROWSER'%(cs[c],ts,t1)
        h={
            'User-Agent':UA,
        }
        resp=requests.get(url,headers=h).json()
        progs=resp
        url='https://player.pl/playerapi/product/live/epg/list?liveId[]=%s&since=%s&till=%s&platform=BROWSER'%(cs[c],t1,t2)
        resp=requests.get(url,headers=h).json()
        progs+=resp
        def sortFN(i):
            return i['since']
        progs.sort(key=sortFN,reverse=False)
        now=time.time()
        epg=''
        for r in progs:
            till=datetime.datetime(*(time.strptime(r['till'], '%Y-%m-%d %H:%M:%S')[0:6])).timestamp()
            if till>now:
                t_s=r['since'].split(' ')[-1][:-3]
                title=r['title']
                if 'genres' in r:
                    title+=' - ' + r['genres'][0]['name']
                
                epg+='[B]%s[/B] %s\n'%(t_s,title)
        return epg        

#Wyszukiwarka
def searchResGen(Resp,t,ct):#
    if ct=='Seriale' or ct=='Filmy' or ct=='Shorty':
        res=[r for r in Resp if r['type']==t and r['element']['mainCategory']['name']==ct]
    elif ct=='Programy':
        res=[r for r in Resp if (r['type']=='SERIAL' and r['element']['mainCategory']['name']!='Seriale') or (r['type']=='VOD' and r['element']['mainCategory']['name']!='Filmy' and r['element']['mainCategory']['name']!='Shorty')]
    else:
        res=[r for r in Resp if r['type']==t]
    return res
    
def search():
    qry=xbmcgui.Dialog().input(u'Szukaj (przynajmniej 3 znaki):', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        hea_=heaGen()
        u=baseurl+'playerapi/item/search?4K=true&platform='+platform+'&keyword='+qry+'&episodes=true'
        resp=requests.get(u,headers=hea_).json()
        addon.setSetting('searchResult',str(resp))
        
        s=[
            ['Filmy'+' (%s)'%(len(searchResGen(resp,'VOD','Filmy'))),'VOD|Filmy'],
            ['Seriale'+' (%s)'%(len(searchResGen(resp,'SERIAL','Seriale'))),'SERIAL|Seriale'],
            ['Programy'+' (%s)'%(len(searchResGen(resp,'','Programy'))),'|Programy'],
            ['Shorty'+' (%s)'%(len(searchResGen(resp,'VOD','Shorty'))),'VOD|Shorty'],
            ['Odcinki'+' (%s)'%(len(searchResGen(resp,'EPISODE',''))),'EPISODE|']
        ]
        for ss in s:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''}
            url = build_url({'mode':'searchRes','cat':ss[1]})
            addItemList(url, ss[0], setArt, 'video')

        xbmcplugin.endOfDirectory(addon_handle)
    else:
        main_menu()

def searchRes(t,ct):
    res=eval(addon.getSetting('searchResult'))
    res=searchResGen(res,t,ct)
    for r in res:
        mod=''
        cid=''
        eid=''
        name=''
        title=''
        img=''
        plot=''
        isPlayable='false'
        isFolder=True
        rr=r['element']
        if r['type']!='EPISODE':
            cid=str(rr['id'])
            eid=cid
            name=rr['title']
            title=name
            type=rr['type']
            img=getImg(rr['images'])
            plot=detCont(rr)
            tid=''
            if type=='SERIAL':
                mod='sezonList'
                tid=(rr['mainCategory']['slug']+'_'+str(rr['mainCategory']['id'])+'_'+rr['slug']+'_odcinki_'+cid).replace('-','_')
                URL=build_url({'mode':mod,'cid':cid,'title':name,'tid':tid})
            if type=='VOD':
                title=titleWithTill(plot,title)
                tid=(rr['mainCategory']['slug']+'_'+str(rr['mainCategory']['id'])+'_'+rr['slug']+'_'+cid).replace('-','_')
                if addon.getSetting('playFromList')=='true':
                    mod='playVid'
                    URL=build_url({'mode':mod,'eid':eid,'tid':tid})
                    isPlayable='true'
                    isFolder=False
                else:
                    mod='progDetails'
                    URL=build_url({'mode':mod,'eid':eid,'tid':tid})
        else:
            eid=str(rr['id'])
            title=rr['fullTitle'] if 'fullTitle' in rr else ''
            if title=='':
                title=rr['season']['serial']['title']
                episode=rr['episode']
                season=rr['season']['number']
                if season!='':
                    title+=' sezon '+str(season)
                title+=' odcinek '+str(episode)
                episodeName=rr['title']
                if episodeName !='':
                    title+=' | '+rr['title']
                
            img=getImg(rr['images'])
            plot=detCont(rr)
            title=titleWithTill(plot,title)
            tid=(rr['mainCategory']['slug']+'_'+str(rr['mainCategory']['id'])+'_'+rr['season']['serial']['slug']+'_odcinki_'+str(rr['season']['serial']['id'])).replace('-','_')
            
            if addon.getSetting('playFromList')=='true':
                mod='playVid'
                URL=build_url({'mode':mod,'eid':eid,'tid':tid})
                isPlayable='true'
                isFolder=False
            else:
                mod='progDetails'
                URL=build_url({'mode':mod,'eid':eid,'tid':tid})
        
        i_cur=[i for i,t in enumerate(rr['displaySchedules']) if t['active'] ][0]
        if rr['displaySchedules'][i_cur]['type']=='SOON':
            isPlayable='false'
            isFolder=False
                
        if r['type']!='EPISODE':
            cm=True
            cmItems=[
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=favAdd&cid='+cid+'&name='+quote(name)+'&tid='+quote(tid)+'&mod='+mod+'&plot='+quote(plot)+'&img='+quote(img)+')'),
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=showDet&eid='+eid+')')
            ]
        else:
            cm=False
            cmItems=[]
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable, cm, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)

#Strona główna/Ostatnio dodane
def mainPage(mc):
    hea_=heaGen()
    u=baseurl+'playerapi/product/section/list/'+mc+'?4K=true&platform='+platform+'&subscriberData=false&recommendationData=false&firstResult=1'
    resp=requests.get(u,headers=hea_).json()
    for c in resp:
        if 'showTitle' in c:
            if c['showTitle']==True and c['title'] not in ['Kontynuuj oglądanie','Ulubione']:                          
                setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
                url = build_url({'mode':'mainPageCateg','mc':mc,'categID':str(c['id'])})
                addItemList(url, c['title'], setArt, 'video')
                
    if mc=='recently_added':
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
        url = build_url({'mode':'contList','mainCateg':'131','Categ':'all','page':'1','vodType':str(['VOD','EPISODE'])})
        addItemList(url, 'Wszystkie', setArt, 'video')
    
    xbmcplugin.endOfDirectory(addon_handle)

def mainPageCateg(mpc,mc):
    hea_=heaGen()
    u=baseurl+'playerapi/product/section/list/'+mc+'?4K=true&platform='+platform+'&subscriberData=false&recommendationData=false&firstResult=1'
    resp=requests.get(u,headers=hea_).json()
    for r in resp:
        if r['id']==int(mpc):
            for rr in r['items']:
                addContToList(rr)
    xbmcplugin.endOfDirectory(addon_handle)

def sectionList(cid):
    hea_=heaGen()
    u=baseurl+'playerapi/product/section/'+cid+'?4K=true&platform='+platform+'&firstResult=0&maxResults=50'
    resp=requests.get(u,headers=hea_).json()
    for r in resp['items']:
        addContToList(r)
    xbmcplugin.endOfDirectory(addon_handle)    

def addContToList(r):#
    cid=str(r['id'])
    name=r['title']
    type=r['type']
    img=getImg(r['images'])
    plot=''
    plot=detCont(r)#próba
    mod=''
    isPlayable='false'
    isFolder=True
    if type=='SERIAL':
        mod='sezonList'
        tid=(r['mainCategory']['slug']+'_'+str(r['mainCategory']['id'])+'_'+r['slug']+'_odcinki_'+cid).replace('-','_')
        URL = build_url({'mode':mod,'cid':cid,'title':name,'tid':tid})
    if type=='VOD':
        name=titleWithTill(plot,name)
        tid=(r['mainCategory']['slug']+'_'+str(r['mainCategory']['id'])+'_'+r['slug']+'_'+cid).replace('-','_')
        if addon.getSetting('playFromList')=='true':
            mod='playVid'
            URL = build_url({'mode':mod,'eid':cid,'tid':tid})
            isPlayable='true'
            isFolder=False
        else:
            mod='progDetails'
            URL = build_url({'mode':mod,'eid':cid,'tid':tid})
    if type=='EPISODE':
        serial_title=r['season']['serial']['title']
        if name!='': 
            name=serial_title+' | '+name
        else:
            try:
                name=serial_title+' | sez. '+str(r['season']['number'])+' odc. '+str(r['episode'])
            except:
                name=serial_title
        name=titleWithTill(plot,name)
        mod='playVid'
        tid=(r['mainCategory']['slug']+'_'+str(r['mainCategory']['id'])+'_'+r['slug']+'_odcinki_'+cid).replace('-','_')
        URL = build_url({'mode':mod,'eid':cid,'tid':tid})
        isPlayable='true'
        isFolder=False
    if type=='SECTION':
        mod='sectionList'
        URL = build_url({'mode':mod,'cid':cid})
    if type=='BANNER':#do weryfikacji
        if 'urlWeb' in r:
            cid=r['urlWeb'].split(',')[-1]
            if '/kolekcje/' in r['urlWeb']:
                mod='sectionList'
                URL = build_url({'mode':mod,'cid':cid})
            else:
                URL = build_url({'mode':'mainPage'})
            '''
            elif '/programy' in r['urlWeb'] or '/seriale' in r['urlWeb']:
                mod='sezonList'
                tid=''
                URL = build_url({'mode':mod,'cid':cid,'title':name,'tid':tid})
            elif '/filmy' in r['urlWeb']:
                name=titleWithTill(plot,name)
                tid=''
                if addon.getSetting('playFromList')=='true':
                    tid=''
                    mod='playVid'
                    URL = build_url({'mode':mod,'eid':cid,'tid':tid})
                    isPlayable='true'
                    isFolder=False
                else:
                    mod='progDetails'
                    URL = build_url({'mode':mod,'eid':cid,'tid':tid})
            '''
            
    i_cur=[i for i,t in enumerate(r['displaySchedules']) if t['active'] ][0]
    if (type=='SERIAL' or type=='VOD' or type=='EPISODE') and r['displaySchedules'][i_cur]['type']=='SOON':
        isPlayable='false'
        isFolder=False
                
    cmItems = []
    if type=='VOD' or type=='SERIAL' or type=='EPISODE':
        if type!='EPISODE':
            cmItems.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=favAdd&cid='+cid+'&name='+quote(name)+'&tid='+quote(tid)+'&mod='+mod+'&plot='+quote(plot)+'&img='+quote(img)+')'))
        cmItems.append(('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=showDet&eid='+cid+')'))
    
    if addon.getSetting('playFromList')=='true':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    iL={'title': '','sorttitle': '','plot': plot}
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
    addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)

#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        isPlayable='false'
        isFolder=True
        URL=build_url({'mode':j[2],'cid':j[1],'eid':j[1],'title':j[0],'tid':j[3]})
        if j[2]=='playVid':
            URL=build_url({'mode':j[2],'eid':j[1],'tid':j[3]})
            isPlayable='true'
            isFolder=False

        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=favDel&cid='+j[1]+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.vod_pl?mode=showDet&eid='+j[1]+')')
        ]
        iL={'title': '','sorttitle': '','plot': j[4]}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': j[5], 'fanart':''}
        addItemList(URL, j[0], setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[1]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(c,n,t,m,p,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[1]==c:
            duplTest=True
    if not duplTest:
        js.append([n,c,m,t,p,i])
        xbmcgui.Dialog().notification('VODpl', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('VODpl', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('VODpl', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('VODpl', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)    

def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ').replace('&oacute;','ó').replace('&ouml;','ö').replace('&nbsp;',' ').replace('&ndash;',' - ')
    t=re.sub('<([^<]+?)>','',t)
    return t    

  
mode = params.get('mode', None)

if not mode:
    if addon.getSetting('DeviceUid')=='' or addon.getSetting('DeviceUid')==None:
        addon.setSetting('DeviceUid',code_gen(32))
    main_menu()
else:
    if mode=='categList':
        mc=params.get('mainCateg')
        categList(mc)

    if mode=='tv':
        t=params.get('type')
        tv(t)
        
    if mode=='programList':
        d=params.get('date')
        s=params.get('sid')
        programList(d,s)
        
    if mode=='calendar':
        sid=params.get('sid')
        calendar(sid)
        
    if mode=='contList':
        mc=params.get('mainCateg')
        c=params.get('Categ')
        pg=params.get('page')
        vt=params.get('vodType')
        contList(mc,c,pg,vt)
    
    if mode=='sezonList':
        cid=params.get('cid')
        tit=params.get('title')
        tid=params.get('tid')
        sezonList(cid,tit,tid)
    
    if mode=='episodeList':
        cid=params.get('cid')
        sezId=params.get('sezId')
        tit=params.get('title')
        pg=params.get('page')
        init=params.get('init')
        tid=params.get('tid')
        episodeList(cid,sezId,tit,pg,init,tid)
    
    if mode=='showDet':
        eid=params.get('eid')
        showDet(eid)
    
    if mode=='progDetails':
        eid=params.get('eid')
        tid=params.get('tid')
        progDetails(eid,tid)
    
    if mode=='playVid':
        eid=params.get('eid')
        tid=params.get('tid')
        playVid(eid,tid,False,False,None)
        
    if mode=='playT':
        sid=params.get('sid')
        ts=params.get('ts')
        playVid(sid,None,False,True,ts)
    
    if mode=='noPlay':
        pass
    
    if mode=='search':
        search()
    
    if mode=='searchRes':
        type,contType=params.get('cat').split('|')
        searchRes(type,contType)
        
    if mode=='mainPage':
        mc=params.get('mainCateg')
        mainPage(mc)
    
    if mode=='mainPageCateg':
        mpc=params.get('categID')
        mc=params.get('mc')
        mainPageCateg(mpc,mc)
        
    if mode=='sectionList':
        cid=params.get('cid')
        sectionList(cid)
        
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        cid=params.get('cid')
        favDel(cid)
        
    if mode=='favAdd':
        cid=params.get('cid')
        name=params.get('name')
        tid=params.get('tid')
        mod=params.get('mod')
        plot=params.get('plot')
        img=params.get('img')
        favAdd(cid,name,tid,mod,plot,img)
        
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
    