# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
#import json
import random
import datetime,time
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.toya_go')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'

mode = addon.getSetting('mode')
baseurl='https://go.toya.net.pl/'
#UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

def build_url(query):
    return base_url + '?' + urlencode(query)

def getTID():
    def code_gen(x):
        base='0123456789abcdef'
        code=''
        for i in range(0,x):
            code+=base[random.randint(0,15)]
        return code
    addon.setSetting('tid',code_gen(8)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(12))
    addon.setSetting('toyago_config',code_gen(18))
        
def main_menu():    
    sources=[
        ['Oglądaj TV','tvList',True,''],
        ['Radio','itemCateg',True,'15-radio-internetowe'],
        ['Kamery','itemCateg',True,'25-kamery'],
        ['VOD','VODcateg',True,'']
        #['wyszukiwarka','search',True],
    ]
    if addon.getSetting('logged')=='false':
        sources.append(['ZALOGUJ','login',False,''])
    else:
        sources.append(['WYLOGUJ','logout',False,''])
    for s in sources:
        li=xbmcgui.ListItem(s[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':s[1],'page':'1','link':s[3]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=s[2])
    xbmcplugin.endOfDirectory(addon_handle)
    
def logRefresh():
    if addon.getSetting('logged')=='true':
        hea,cookies=req_params(baseurl)
        resp=requests.get(baseurl,headers=hea,cookies=cookies).text
        if '/logout' not in resp:
            logout()
            login()
            xbmcgui.Dialog().notification('ToyaGO', 'Login refresh', xbmcgui.NOTIFICATION_INFO)
            

def req_params(ref_url):#hea,cookies
    SID=addon.getSetting('SID')
    toya_token=addon.getSetting('toya_token')
    url='https://go.toya.net.pl/11-ogladaj-tv'
    hea={
        'User-Agent':UA,
        'Referer':ref_url,
        'Origin': 'https://go.toya.net.pl'
    }
    cookies={
        '__tid':addon.getSetting('tid'),
        "ua_resolution": "1920x1080",
        "toyago.config": addon.getSetting('toyago_config')
    }
    
    if SID and toya_token: 
        cookies.update({'GO_SID':SID,'SID':SID,'toya_token':toya_token})
    #print(cookies)
    return hea,cookies

def login():
    u=addon.getSetting('username')
    p=addon.getSetting('password')
    if p!='' and u!='':
        url='https://auth.toya.net.pl/'
        hea={
            'User-Agent':UA,
            'Referer':baseurl
        }
        cookies={
            '__tid':addon.getSetting('tid')
        }
        
        data={
            "f_user": u,
            "f_pass": p,
            "f_city": "lodz",
            "from": "toyago-beta",
            "nextURL": "aHR0cHM6Ly9nby50b3lhLm5ldC5wbC8",
            "referrerURL": "aHR0cHM6Ly9nby50b3lhLm5ldC5wbC8",
            "submit": "Zaloguj"
        }
        resp=requests.post(url,data=data,headers=hea,cookies=cookies,allow_redirects=False)
        cookie_dict=dict(resp.cookies)
        #print(resp.headers)
        if 'error=badLoginPass' in resp.headers['Location']:
            xbmcgui.Dialog().notification('ToyaGO', 'Błędny login lub hasło', xbmcgui.NOTIFICATION_INFO)
        elif 'https://toya.net.pl' in resp.headers['Location']:
            xbmcgui.Dialog().notification('ToyaGO', 'Spróbuj później', xbmcgui.NOTIFICATION_INFO)
        elif 'SID' not in cookie_dict or 'toya_token' not in cookie_dict:
            xbmcgui.Dialog().notification('ToyaGO', 'Nieokreślony błąd podczas logowania', xbmcgui.NOTIFICATION_INFO)
        else:
            addon.setSetting('SID',cookie_dict['SID'])
            addon.setSetting('toya_token',cookie_dict['toya_token'])
            addon.setSetting('logged','true')
    else:
        xbmcgui.Dialog().notification('ToyaGO', 'Uzupełnij dane logowania w ustawieniach wtyczki', xbmcgui.NOTIFICATION_INFO)
    
def logout():
    url='https://go.toya.net.pl/logout'
    hea={
        'User-Agent':UA,
        'Referer':baseurl
    }
    SID=addon.getSetting('SID')
    toya_token=addon.getSetting('toya_token')
    cookies={
        '__tid':addon.getSetting('tid'),
        "ua_resolution": "1920x1080",
        "toyago.config": addon.getSetting('toyago_config'),
        'GO_SID':SID,
        'SID':SID,
        'toya_token':toya_token
    }
    resp=requests.get(url,headers=hea,cookies=cookies).text
    addon.setSetting('logged','false')

def EPG_data(c):
    def getChannelNumber(arCH,n):
        chN=''
        for a in arCH['data']:
            if a['name']==n:
                chN=a['global_id']
                break
        return chN
        
    hea,cookies=req_params(baseurl)
    dates=[]
    now=int(time.time())
    d1=''
    d2=''
    if time.localtime()[3]>=21:
        d1=datetime.datetime.now().strftime('%Y-%m-%d')
        d2=(datetime.datetime.now()+datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    else:
        d1=(datetime.datetime.now()-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        d2=datetime.datetime.now().strftime('%Y-%m-%d')
    period=6
    #url_chns='https://webapi.toya.net.pl/v1/tv/guide/list/?=&sort=channel-sort-numeric&offset=0&category=999'
    #resp_chns=requests.get(url_chns,headers=hea,cookies=cookies).json()
    epg={}
    
    url_epg='https://webapi.toya.net.pl/v1/tv/guide/programs/?date='
    resp_epg1=requests.get(url_epg+d1,headers=hea,cookies=cookies).json()
    resp_epg2=requests.get(url_epg+d2,headers=hea,cookies=cookies).json()
    chns1=list(resp_epg1['data'].keys())
    chns2=list(resp_epg2['data'].keys())
    chns=chns1
    for ch in chns2:
        if ch not in chns:
            chns.append(ch)
    resp_epg={}
    for k in chns:
        r1=[]
        r2=[]
        if k in resp_epg1['data']:
            r1=resp_epg1['data'][k]
        if k in resp_epg2['data']:
            r2=resp_epg2['data'][k]
        resp_epg[k]=r1+r2
        for i,rk in enumerate(resp_epg[k]):
            if rk['on_air_at']=='' and i!=0:
                resp_epg[k][i-1]['duration']=int(resp_epg[k][i-1]['duration'])+int(rk['duration'])
            
    for cc in c:
        #chID=getChannelNumber(resp_chns,cc[0])
        chID=cc[2].split('?')[0].split('/')[-1]
        if cc[0] not in epg:
            epg[cc[0]]=[]
        if chID!=None:
            if chID!='':
                epgData=resp_epg[chID]
                for e in epgData:
                    hour=e['on_air_at']
                    if hour !='':
                        start_date=datetime.datetime(*(time.strptime(hour, '%Y-%m-%d %H:%M:%S')[0:6]))
                        end_date=start_date+datetime.timedelta(seconds=60*int(e['duration']))
                        start_tmst=datetime.datetime.timestamp(start_date)
                        end_tmst=datetime.datetime.timestamp(end_date)
                        if end_tmst>now and start_tmst<=now+period*3600:
                            hour=e['on_air_at'].split(' ')[-1][:-3]
                            title=e['title']
                            category=e['category']
                            epg[cc[0]].append([hour,title,category])
    
    return epg
        
def channelsGen():
    url='https://go.toya.net.pl/11-ogladaj-tv'
    hea,cookies=req_params(baseurl)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    
    resp1=resp.split('<div class=\"boxes-grid\">')[1].split('</section>')[0]
    resp2=resp1.replace('\n','').replace('\r','')
    resp3=re.sub('</div>([^<]+?)</div>','</div></div>',resp2)
    resp4=resp3.split('</div></div>')

    channels=[]
    for r in resp4:
        if 'inactive' not in r and 'presentation-outside' in r:
            href=re.compile('<a href=\"([^\"]+?)\"').findall(r)[0]
            name=re.compile('data-search=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('img.*src=\"([^\"]+?)\"').findall(r)[0]
            channels.append([name,href,img])
    return channels
  
def tvList():
    channels=channelsGen()
    epg=EPG_data(channels)
    for c in channels:
        plot=''
        if c[0] in epg:
            epgCH=epg[c[0]]
            for e in epgCH:
                plot+='[B]'+e[0]+'[/B] '+e[1]
                if e[2]!='':
                    plot+=' [I]('+e[2]+')[/I]'
                plot+='\n'
        
        li=xbmcgui.ListItem(c[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': c[2], 'fanart':c[2]})
        url = build_url({'mode':'playTV','link':c[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def itemCateg(c):
    url=baseurl+c
    hea,cookies=req_params(baseurl)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    resp1=resp.split('category-section category-section-')
    categ=[]
    for r in resp1:
        if '<h3 class' in r:
            rr=r.split('</a>')[0]
            name=re.compile('<h3 class.*>([^<]+?)</h3').findall(rr)[0]
            link=re.compile('href=\"([^\"]+?)\"').findall(rr)[0]
            categ.append([name,link])
    mod=''
    #print(c)
    if 'radio' in c:
        mod='radioList'
    elif 'kamery' in c:
        mod='kameryList'
    else:
        mod='VODList'
    for c in categ:
        li=xbmcgui.ListItem(c[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':mod,'link':c[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def VODList(l):
    url=baseurl[:-1]+l
    hea,cookies=req_params(baseurl)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    if 'category-section category-section-' in resp:#subcategories
        itemCateg(l[1:])
    else: #lista VOD
        items=[]
        resp1=resp.split('<ul class=\"items\">')[1].split('</li>')
        for r in resp1:
            if 'class=\"info\"' in r:
                img=re.compile('src=\"([^\"]+?)\"').findall(r.split('class=\"poster\"')[1])[0]
                link=re.compile('href=\"([^\"]+?)\"').findall(r.split('class=\"overlay-buttons\"')[1])[0]
                name=re.compile('alt=\"([^\"]+?)\"').findall(r.split('class=\"poster\"')[1])[0].replace('&oacute;','ó')
                try:
                    desc=r.split('<span class=\"plot\">')[1].split('</span')[0].replace('\\n','')
                except:
                    desc=''
                items.append([name,link,img,desc])
        for i in items:
            li=xbmcgui.ListItem(i[0])
            li.setProperty("IsPlayable", 'true')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': i[3]})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart':i[2]})
            url = build_url({'mode':'playVOD','link':i[1]})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(addon_handle)

def radioList(l):
    url=baseurl[:-1]+l
    hea,cookies=req_params(baseurl)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    resp1=resp.split('item isotope-item category')
    items=[]
    for r in resp1:
        if '<audio' in r:
            img=re.compile('<img.*src=\"([^\"]+?)\"').findall(r)[0]
            link=re.compile('<audio.*src=\"([^\"]+?)\"').findall(r)[0]
            name=re.compile('alt=\"([^\"]+?)\"').findall(r)[0]
            items.append([name,link,img])
    for i in items:
        li=xbmcgui.ListItem(i[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart':i[2]})
        url = build_url({'mode':'playRadio','link':i[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def kameryList(l):
    url=baseurl[:-1]+l
    hea,cookies=req_params(baseurl)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    resp1=resp.split('<ul class=\"items\"')[1].split('</li>')
    items=[]
    for r in resp1:
        if '--locked' in r:
            img=re.compile('src=\"([^\"]+?)\"').findall(r)[0]
            link=re.compile('<a href=\"([^\"]+?)\"').findall(r)[0]
            name=re.compile('alt=\"([^\"]+?)\"').findall(r)[0].replace('&oacute;','ó')
            items.append([name,link,img])
    for i in items:
        li=xbmcgui.ListItem(i[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart':i[2]})
        url = build_url({'mode':'playKamera','link':i[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)
    
def VODcateg():
    categ=[
        ['TV TOYA na życzenie','37-tv-toya-na-zyczenie'],
        ['Free VOD','22-free-vod'],
        ['FilmBox On Demand','28-filmbox-on-demand']
    ]
    for c in categ:
        li=xbmcgui.ListItem(c[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':'itemCateg','link':c[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)
        
def playRadio(l):
    url_stream=l+'|User-Agent='+UA+'&Referer='+baseurl
    play_item = xbmcgui.ListItem(path=url_stream)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def playKamera(l):
    url=baseurl[:-1]+l
    hea,cookies=req_params(baseurl)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    url_stream=re.compile('data-stream=\"([^\"]+?)\"').findall(resp)[0]
    url_stream+='|User-Agent='+UA+'&Referer='+baseurl
    play_item = xbmcgui.ListItem(path=url_stream)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def playVOD(l):
    url=baseurl[:-1]+l
    hea,cookies=req_params(baseurl)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    if '/play' not in l:
        if 'Po zalogowniu uzyskasz dostęp do materiałów.' in resp:
            info='Dostępne po zalogowaniu'
        else:
            try:
                info='Dostępne w pakiecie: '+re.compile('<div class=\"pack-info pack-name\">([^<]+?)</div>').findall(resp)[0]
            except:
                info='Materiał niedostępny'
        xbmcgui.Dialog().notification('ToyaGO', info, xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        url_stream=re.compile('data-stream=\"([^\"]+?)\"').findall(resp)[0]
        if '.m3u' in url_stream:
            url_stream+='|User-Agent='+UA+'&Referer='+baseurl
            play_item = xbmcgui.ListItem(path=url_stream)
            play_item.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def playTV(u):
    url=baseurl[:-1]+u
    ref='https://go.toya.net.pl/11-ogladaj-tv'
    hea,cookies=req_params(ref)
    resp=requests.get(url,headers=hea,cookies=cookies).text
    
    if 'div id=\"player\"' in resp:
        resp1=resp.split('div id=\"player\"')[1].split('</div>')[0]
        print('PLAYERDIV')
        #print(resp1)
        format=re.compile('data-format=\"([^\"]+?)\"').findall(resp1)[0]
        #print(format)
        url_stream=''
        url_lic=''
        try:
            data_manifest_uri=re.compile('data-manifest-uri=\"([^\"]+?)\"').findall(resp1)[0]
        except:
            data_manifest_uri=''
        if format=='dash':
            url_stream=re.compile('data-manifest-uri=\"([^\"]+?)\"').findall(resp1)[0]
            url_stream+='|User-Agent='+UA+'&Referer='+baseurl
            url_lic=re.compile('data-license-server=\"([^\"]+?)\"').findall(resp1)[0]
            data_token_url=re.compile('data-token-url=\"([^\"]+?)\"').findall(resp1)
            hea_lic='User-Agent='+quote(UA)+'&Referer='+quote(baseurl)+'&Origin='+quote(baseurl[:-1])+'&Content-Type=application/octet-stream&Connection=keep-alive&Accept-Encoding='+quote('gzip, deflate, br')+'&Accept-Language='+quote('pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7')
            
            extraHEA=''
            extraHEAvalue=''
            if len(data_token_url)>0:
                hea={
                    'User-Agent':UA,
                    'Referer':baseurl
                }
                
                '''
                r=data_token_url[0].split('dev=')[-1]
                u=data_token_url[0].replace(r,'0123456789ABCDEF')
                resp_preauth=requests.get(u,headers=hea).json()
                '''
                resp_preauth=requests.get(data_token_url[0],headers=hea).json()
                extraHEA=resp_preauth['headerName']
                extraHEAvalue=resp_preauth['headerValue']
            if extraHEA !='':
                hea_lic+='&'+extraHEA.lower()+'='+quote(extraHEAvalue)
            
            cert='CrYCCAMSEJRzG84P41YiqFJz1Z5wB/UYkdXgpQUijgIwggEKAoIBAQC6vlJ9lUo8SDe3y/+eNs2VLLCWOW9ZOU97NUbwOJcN9HLbL9clUvzvVool4cPU6NFDvzWfjcIL3VvUmtQ7IQYNYMK9ps6JaMNN+pHyPkjsc0CLn2mX95gxeWWkZul6PAipMZVVTOWS7gVo4EAydZfa2wH7UZVJuTohFI8MrSZQueLel2FTO3+w+TUFlnqCRqrEiz5tUBqIiUcnO0VSDDx1kDWZkt0OYNNTaGvGex9aLOcBFmjlQOwqiTM+TDdJqJpNEO9Sm6PuKEbZ1K/eOxGiTuQyQgWfJad1onP3g5zYPuezUAgEGRf6BEUDUAuMAJyUwtrq6MH0tjhpxhvINpabAgMBAAE6CWNvbmF4LmNvbRKAA22PoCV8lNpk2b26PGrW5qiX+m9Q7DYRW5SRfYXCpfBM6VsN5WPosUoe26TLJXjBzvEBJRhLB+hN6rKv9KWDqyoQC+jPiIfducCkZngjUh4vdPTODjePE9C5Dx1rDURaZG+I7JD6z0lAKpjKyI1JyFGkfoXyywFp8l5dZbxuB+KJxw1Id0PXDUEQOrayXv9xVVWYXKUFGv4j8FKpFYJR9u0JEkkiMb1ylTBDS+shQznX3ajYUcrrJcB2OLlfVWneJG7/1TgXypLGVFAu/gVcJdtODK+TOT5zmU4Lin0gApOO1Ff7sp7KyzQfKpVEAyivl1GYtEIktEXX9wWPTNpXz05xNEi68FUwwxaKCiT0UdjWydyrV+rF9rUXLX4iWf+FqR9oZ8MV7S/4gm3jCLmthAlCsn6/yZAxLoTTCDqC5NO+tEOvGRSMqMc1CHtD/Py03lcCcoOY7t3GEXBlwKacPNBRfffYuOeDhwH+FXAozQHUkeSjZGm+HMUhUONkx20qEg=='
            
            import inputstreamhelper
            PROTOCOL = 'mpd'
            if 'm3u8' in url_stream:
                PROTOCOL = 'hls'
            DRM = 'com.widevine.alpha'
            is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty("inputstream.adaptive.license_type", DRM)
                play_item.setProperty('inputstream.adaptive.server_certificate', cert)
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
                play_item.setProperty("inputstream.adaptive.license_key", url_lic+'|'+hea_lic+'|R{SSM}|')
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

            
        elif format=='hls':
            url_stream=re.compile('data-stream=\"([^\"]+?)\"').findall(resp1)[0]
            if url_stream.startswith('//'):
                url_stream='https:'+url_stream
            url_stream+='|User-Agent='+UA+'&Referer='+baseurl
            print(url_stream)
            import inputstreamhelper
            PROTOCOL = 'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            xbmcgui.Dialog().notification('ToyaGO', 'Brak url_s', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        xbmcgui.Dialog().notification('ToyaGO', 'Zaloguj się we wtyczce TOYA GO', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def generate_m3u():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('ToyaGO', 'Ustaw nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('ToyaGO', 'Generuję liste M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    channels=channelsGen()
    for c in channels:
        channelID = c[1]
        channelName = c[0]
        channelLogo = c[2]
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s",%s\nplugin://plugin.video.toya_go/?mode=playTV&link=%s\n' % (channelName,channelLogo,channelName,channelID)

    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('ToyaGO', 'Wygenerowano listę M3U.', xbmcgui.NOTIFICATION_INFO)

    
mode = params.get('mode', None)

if not mode:
    if addon.getSetting('tid')=='' and addon.getSetting('toyago_config')=='':
        getTID()
    logRefresh()#
    main_menu()
else:
    if mode=='login':
        login()
        if addon.getSetting('logged')=='true':
            xbmc.executebuiltin('Container.Refresh()')
    
    if mode=='logout':
        logout()
        xbmc.executebuiltin('Container.Refresh()')
        
    if mode=='tvList':
        logRefresh()#
        tvList()
        
    if mode=='playTV':
        logRefresh()#
        link=params.get('link')
        playTV(link)   
    
    if mode=='itemCateg':
        link=params.get('link')
        itemCateg(link)
        
    if mode=='radioList':
        link=params.get('link')
        radioList(link)
        
    if mode=='kameryList':
        link=params.get('link')
        kameryList(link)
        
    if mode=='VODList':
        link=params.get('link')
        VODList(link)
        
    if mode=='VODcateg':
        VODcateg()
        
    if mode=='playRadio':
        link=params.get('link')
        playRadio(link)
    
    if mode=='playKamera':
        link=params.get('link')
        playKamera(link)
        
    if mode=='playVOD':
        logRefresh()#
        link=params.get('link')
        playVOD(link)
        
    if mode=='BUILD_M3U':
        generate_m3u()      
        