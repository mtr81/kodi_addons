# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
import datetime,time
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.onet')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

mode = addon.getSetting('mode')
baseurl='https://polsatnews.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def main_menu():    
    url='https://www.polsatnews.pl/wideo-lista/'
    resp=requests.get(url,headers=hea).text
    categs=re.compile('<a class=\"section__link\" href=\"([^\"]+?)\">([^<]+?)</a').findall(resp)
    for c in categs:
        mod='itemList'
        if c[1]=='Nasze programy':
            mod='programList'
        addon.setSetting('referer',baseurl)
        li=xbmcgui.ListItem(cleanText(c[1]))
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':mod,'link':c[0]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)    
    
    menu_plus=[
        ['Wyszukiwarka','SEARCH','false',True],
        ['Polsat News na żywo','liveTV','true',False]
    ]
    for m in menu_plus:
        li=xbmcgui.ListItem(m[0])
        li.setProperty("IsPlayable", m[2])
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':m[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=m[3]) 
    
    xbmcplugin.endOfDirectory(addon_handle)

def itemList(l):
    hea.update({'Referer':addon.getSetting('referer')})
    resp=requests.get(l,headers=hea).text
    resp1=resp.split('class=\"news-list ')[1].split('</section')[0].split('</article>')
    vids=[]
    for r in resp1:
        if 'href' in r:
            link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('data-src=\"([^\"]+?)\"').findall(r)[0]
            name=re.compile('alt=\"([^\"]+?)\"').findall(r)[0]
            date=re.compile('datetime=\"([^\"]+?)\"').findall(r)[0]
            vids.append([name,link,img,date])
    for v in vids:
        img=v[2]
        plot='[B]Data: [/B]'+v[3]
        li=xbmcgui.ListItem(cleanText(v[0]))
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playVid','link':v[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)    
    
    if '>pokaż więcej<' in cleanText(resp):
        nextPageLink=re.compile('data-url=\"([^\"]+?)\"').findall(resp)[0]
        addon.setSetting('referer',l)
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'itemListNext','link':nextPageLink})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def itemListNext(l):
    hea.update({'Referer':addon.getSetting('referer')})
    resp=requests.get(l,headers=hea).json()
    for i in resp['items']:
        img=i['img']['midi']
        plot='[B]Data: [/B]'+datetime.datetime.fromtimestamp(i['timestamp']/1000).strftime('%Y-%m-%d %H:%M')
        li=xbmcgui.ListItem(cleanText(i['title']))
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playVid','link':i['url']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    
    if 'button' in resp:
        if 'data-url=' in resp['button']: 
            nexturl=re.compile('data-url=\'([^\']+?)\'').findall(resp['button'])[0]
            addon.setSetting('referer',l)
            li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
            url = build_url({'mode':'itemListNext','link':nexturl})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        elif '/wyszukiwarka/' in resp['button']:
            urlSea=re.compile('href=\"([^\"]+?)\"').findall(resp['button'])[0]
            x=dict(parse_qsl(urlSea.split('?')[-1]))
            query=''
            if 'text' in x:
                query=x['text']
            li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
            url = build_url({'mode':'search','query':query,'page':'1'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
            
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def programList(l):   
    def getList(x):
        progs=[]
        for r in x:
            if 'href' in r:
                link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
                img=re.compile('data-src=\"([^\"]+?)\"').findall(r)[0]
                name=re.compile('alt=\"([^\"]+?)\"').findall(r)[0]
                progs.append([name,link,img])
        return progs
    
    hea.update({'Referer':addon.getSetting('referer')})
    resp=requests.get(l,headers=hea).text
    resp1=resp.split('<section')[1].split('</section')[0].split('</article>')#class=\"news-list 
    for r in getList(resp1):
        img=r[2]
        li=xbmcgui.ListItem(cleanText(r[0]))
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'episList','link':r[1],'page':'1'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    resp2=resp.split('<section')[2].split('</section')[0].split('</article>')#class=\"news-list 
    for ra in getList(resp2):
        img=ra[2]
        li=xbmcgui.ListItem('[Archiwalny] '+cleanText(ra[0]))
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'episList','link':ra[1],'page':'1'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def episList(l,p):
    hea.update({'Referer':addon.getSetting('referer')})
    resp=requests.get(l,headers=hea).text
    resp1=resp.split('class=\"news-list ')[1].split('</div')[0].split('</article>')
    vids=[]
    for r in resp1:
        if 'href' in r:
            link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('data-src=\"([^\"]+?)\"').findall(r)[0]
            name=re.compile('alt=\"([^\"]+?)\"').findall(r)[0]
            vids.append([name,link,img])
    for v in vids:
        img=v[2]
        li=xbmcgui.ListItem(cleanText(v[0]))
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot':''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playVid','link':v[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)    
    
    nextPageLink=re.compile('href=\"([^\"]+?)\" class=\"pagination__link\">'+str(int(p)+1)+'<').findall(resp)
    if len(nextPageLink)==1:
        nexturl=nextPageLink[0]
        addon.setSetting('referer',l)
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'episList','link':nexturl,'page':str(int(p)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def playVid(l):
    resp=requests.get(l,headers=hea).text
    try:
        url_stream=re.compile('<source data-src=\"([^\"]+?)\"').findall(resp)[0]
    except:
        url_stream=''
    print(url_stream)
    if url_stream!='' and 'mp4' in url_stream:
        url_stream+='|User-Agent='+UA+'&Referer='+baseurl
        play_item = xbmcgui.ListItem(path=url_stream)
        play_item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('Polsat News', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def search(q,p):
    if q==None:
        q=''
    url='https://www.polsatnews.pl/wyszukiwarka/?text='+q+'&type=vod'
    if p!='1':
        url+='&page='+p
    resp=requests.get(url,headers=hea).text
    if 'search__info-no-results' not in resp:
        resp1=resp.split('\"searchwrap\"')[1].split('\"pagination\"')[0].split('</article')
        vids=[]
        for r in resp1:
            if 'news--video' in r:
                print(r)
                link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
                img=re.compile('data-src=\"([^\"]+?)\"').findall(r)[0]
                name=re.compile('"news__title\">([^<]+?)<').findall(r)[0]
                try:
                    date=re.compile('datetime=\"([^\"]+?)\"').findall(r)[0]
                except:
                    date=''
                vids.append([name,link,img,date])
        for v in vids:
            img=v[2]
            plot='[B]Data: [/B]'+v[3]
            li=xbmcgui.ListItem(cleanText(v[0]))
            li.setProperty("IsPlayable", 'true')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot':plot})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
            url = build_url({'mode':'playVid','link':v[1]})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        if 'pagination__link">'+str(int(p)+1)+'<' in resp:
            li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
            url = build_url({'mode':'search','guery':q,'page':str(int(p)+1)})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    else:
        xbmcgui.Dialog().notification('Polsat News', 'Brak wyników', xbmcgui.NOTIFICATION_INFO)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def liveTV():
    url_stream='https://hls.redefine.pl/665614B1/30394/0/dash_iptv_720/live.mpd'
    import inputstreamhelper
    PROTOCOL = 'mpd'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=url_stream)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'Referer=https://embed-e1-81.pluscdn.pl/&User-Agent='+UA)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'Referer=https://embed-e1-81.pluscdn.pl/&User-Agent='+UA)
                  
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

        

def cleanText(x):
    rep=[['Åº','ź'],['Ä','ę'],['Ä','ą'],['Ã³','ó'],['Å¼','ż'],['Å','ł'],['Å','ś'],['Ä','ć'],['&quot;','\"'],['Å','ń'],['Å','Ś']]
    for r in rep:
        x=x.replace(r[0],r[1])
    return x

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='itemList':
        link=params.get('link')
        itemList(link)
    
    if mode=='itemListNext':
        link=params.get('link')
        itemListNext(link)
    
    if mode=='programList':
        link=params.get('link')
        programList(link)
        
    if mode=='episList':
        link=params.get('link')
        page=params.get('page')
        episList(link,page)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
    
    if mode=='SEARCH':
        query=xbmcgui.Dialog().input(u'Szukaj, Podaj frazę:', type=xbmcgui.INPUT_ALPHANUM)
        if query:
           search(query,'1')
        else:
            xbmcplugin.endOfDirectory(addon_handle)
        main_menu()
    
    if mode=='search':
        query=params.get('query')
        page=params.get('page')
        search(query,page)

    if mode=='liveTV':
        liveTV()
    '''            
    #favorites
    if mode=='favList':
        favList('tvp_info')
        
    if mode=='favDel':
        cid=params.get('cid')
        favDel(cid)
        
    if mode=='favAdd':
        cid=params.get('cid')
        name=params.get('name')
        mod=params.get('mod')
        img=params.get('img')
        favAdd(cid,name,mod,img,'tvp_info')
    '''
    