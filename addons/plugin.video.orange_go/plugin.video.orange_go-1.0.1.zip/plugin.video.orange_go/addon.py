# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
import hashlib
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.orange_go')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
img_icon=PATH+'icon.png'


UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0'
baseurl='https://tvgo.orange.pl/'
apiURL='https://tvgo.orange.pl/gpapi2/'
apiURL_old='https://tvgo.orange.pl/gpapi/'

deviceType='web_otf'
deviceCat='otg'

def odi_gen():
    data={
        'dev_type':'web_otf',
        'app_version':'1.19.2', #1.16.1
        'web_native':UA,
        'hh_tech':'',
        'serial_number':'',
        'offer':''
    }
    if addon.getSetting('logged')=='true':
        data['hh_tech']=addon.getSetting('hhTech')
        data['serial_number']='FIREFOX_WEB_TERMINAL_1'+addon.getSetting('householdExtId')
    
    return urlencode(data)

def heaGen():
    HEA={
        'Origin':baseurl[:-1],
        'Referer':baseurl,
        'User-Agent':UA,
        'OtvDeviceInfo2':odi_gen(),
        'Accept':'application/json;ver=1'
    }
    return HEA


def getC():
    ci=''
    ca=''
    
    hea={
        'User-Agent':UA
    }
    resp=requests.get(baseurl,headers=hea).text
    
    a_ci=re.compile('I12=([^;]+?);').findall(resp)
    ci='' if len(a_ci)==0 else a_ci[0]
    
    scripts=re.compile('<script>((?:(?!</script>).)*?)</script>').findall(resp)
    scr=[s for s in scripts if 'AnalyticsData' in s]
    
    if len(scr)>0:
        data=re.sub('document\[([^]]+?)\]','var result',scr[0])

        jsPayload = '''
        function x(){
        xxx
        return result
        }
        '''
        jsPayload=jsPayload.replace('xxx',data)
        import js2py
        x=js2py.eval_js(jsPayload)
        cont=x()      
        a_ca=re.compile('AnalyticsData=([^;]+?);').findall(cont)
        ca='' if len(a_ca)==0 else a_ca[0]

    return ci,ca

def cookiesGen():
    cookies={}
    
    if  addon.getSetting('ci')=='' or  addon.getSetting('ca')=='':
        ci,ca=getC()
        addon.setSetting('ci',ci)
        addon.setSetting('ca',ca)
    
    cookies.update({
        'AnalyticsData':addon.getSetting('ca'),
        'I12':addon.getSetting('ci')
    })
    
    if addon.getSetting('logged')=='true':
        cookies.update({
            'Token':addon.getSetting('Token'),
            'TokenId':addon.getSetting('TokenId'),
            'Authenticated':'true'
        })
        
    return cookies

def paramsGen():
    p={
        'deviceCat':deviceCat
    }
    return p

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(stream_url, lickey='', drm_config={}, cert_data=None):
    import inputstreamhelper
    PROTOCOL = 'mpd'
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL,DRM)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty('IsPlayable', 'true')
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Origin='+baseurl[:-1])
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Origin='+baseurl[:-1])

        if lickey!='':
            kodiVer=xbmc.getInfoLabel('System.BuildVersion')
            if int(kodiVer.split('.')[0])<22:
                play_item.setProperty('inputstream.adaptive.license_type',DRM)
                play_item.setProperty('inputstream.adaptive.license_key',lickey)
                if cert_data!=None:
                    play_item.setProperty('inputstream.adaptive.server_certificate', cert_data)
            else:
                play_item.setProperty('inputstream.adaptive.drm', json.dumps(drm_config))
          
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def encSHA384(x):
    return hashlib.sha384(x.encode('utf-8')).hexdigest()

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code
    
def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def dateToStr(d,f):
    return d.strftime(f)

def strToDate(s,f='%Y-%m-%d %H:%M:%S'):
    return datetime.datetime(*(time.strptime(s, f)[0:6]))
    
def tmpUtcToDate(t):
    d=datetime.datetime.fromtimestamp(t)
    '''
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    '''
    offset=0
    return d-datetime.timedelta(seconds=offset)
   
def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':        
        items=[
            ['Kanały TV','tvList','DefaultTVShows.png'],
            ['Archiwum programów','replay','DefaultYear.png'],
            ['Wyloguj','logOut','DefaultUser.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','DefaultUser.png']
        ]
    for i in items:
        setArt={'icon': i[2],'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)   

def logIn():
    logged=False
    
    login=addon.getSetting('login')
    pin=addon.getSetting('pin')
    if login!='' and pin !='':
        if re.match(r'^[^\d]', login):
            pin=encSHA384(encSHA384(pin)+'MDAxMTAxMDAgMDAxMTAwMTEgMDAxMTAxMTEgMDAxMTAxMTAgMDAxMTAxMTAgMDAxMTEwMTEgMDAxMTExMDAgMDAxMTAxMTEgMDAxMTAxMTE=')
        
        url=apiURL+'auth/login'
        paramsUrl=paramsGen()
        paramsUrl['deviceType']=deviceType
        hea=heaGen()
        hea['Accept']='application/json;ver=2'
        hea['Content-Type']='application/json;ver=1'
        data={
            'login':login,
            'password':pin
        }
        
        resp=requests.post(url,headers=hea,params=paramsUrl,cookies=cookiesGen(),json=data)
        if 'Token' in dict(resp.cookies):
            addon.setSetting('Token',dict(resp.cookies)['Token'])
            addon.setSetting('TokenId',dict(resp.cookies)['TokenId'])
            addon.setSetting('refreshToken',resp.json()['refreshToken'])
            now=int(time.time())
            addon.setSetting('tokenTime',str(now))
            
            url=apiURL+'core/household/household'
            cookies=cookiesGen()
            cookies['Token']=addon.getSetting('Token')
            cookies['TokenId']=addon.getSetting('TokenId')
            resp=requests.get(url,headers=heaGen(),params=paramsGen(),cookies=cookies).json()
            if 'householdExtId' in resp:
                addon.setSetting('householdExtId',resp['householdExtId'])
                addon.setSetting('hhTech',resp['hhTech'])
                logged=True
                xbmc.log('@@@Login: zalogowano', level=xbmc.LOGINFO)
            else:
                xbmc.log('@@@Login error(2): '+str(resp), level=xbmc.LOGINFO)
                
        else:
            xbmc.log('@@@Login error(1): '+resp.text, level=xbmc.LOGINFO)
                
        if logged:
            addon.setSetting('logged','true')
        else:
            addon.setSetting('logged','false')
            xbmcgui.Dialog().notification('Orange Do', 'Błąd logowania - szczegóły w logu', xbmcgui.NOTIFICATION_INFO)
        
    else:
        xbmcgui.Dialog().notification('Orange Do', 'Uzupełnij dane logowania ustawieniach', xbmcgui.NOTIFICATION_INFO)
    

def logOut():
    url=apiURL+'auth/logout'
    resp=requests.get(url,headers=heaGen(),cookies=cookiesGen(),params=paramsGen())
    if resp.status_code==200:
        para_logout()
        xbmc.log('@@@Logout: wylogowano', level=xbmc.LOGINFO)
    else:
        xbmc.log('@@@Logout error: '+resp.text, level=xbmc.LOGINFO)
    
    
def para_logout():
    addon.setSetting('logged','false')    
    addon.setSetting('Token','')
    addon.setSetting('TokenId','')
    addon.setSetting('refreshToken','')
    addon.setSetting('tokenTime','')
    addon.setSetting('householdExtId','')
    addon.setSetting('hhTech','')
    addon.setSetting('prevC','')
    addon.setSetting('tv_ctg','')

def refreshToken():
    if addon.getSetting('logged')=='true':
        now=int(time.time())
        tokenTime=addon.getSetting('tokenTime')
        tt=0 if tokenTime=='' else int(tokenTime)
        if now-tt>=24*60*60 and now-tt<14*24*60*60:
            url=apiURL+'auth/refresh'
            hea=heaGen()
            hea['Content-Type']='application/json;ver=1'
            data={
                'refreshToken':addon.getSetting('refreshToken')
            }
            resp=requests.post(url,headers=hea,cookies=cookiesGen(),params=paramsGen(),json=data)
            if 'Token' in dict(resp.cookies):
                now=int(time.time())
                addon.setSetting('Token',dict(resp.cookies)['Token'])
                addon.setSetting('TokenId',dict(resp.cookies)['TokenId'])
                addon.setSetting('refreshToken',resp.json()['refreshToken'])
                addon.setSetting('tokenTime',str(now))
                print(resp.text)
                xbmc.log('@@@RefreshToken: nowy token', level=xbmc.LOGINFO)
            else:
                xbmc.log('@@@RefreshToken - error: '+resp.text, level=xbmc.LOGINFO)
        elif now-tt>=14*24*60*60: #refreshToken wygasł
            para_logout()
            xbmc.log('@@@RefreshToken: wylogowanie-token wygasł', level=xbmc.LOGINFO)
            
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.orange_go/,replace)')
    

def epgData(d):
    url=apiURL+'core/tvguide/epg'
    
    d1=strToDate(d+' 00:00:00','%Y-%m-%d %H:%M:%S')
    d0_day=dateToStr(strToDate(d,'%Y-%m-%d')-datetime.timedelta(days=1),'%Y-%m-%d')
    d0=strToDate(d0_day+' 00:00:00','%Y-%m-%d %H:%M:%S')
    
    d1_tmp=int(d1.timestamp())
    d0_tmp=int(d0.timestamp())
        
    epg={}
    
    for dd in [str(d0_tmp),str(d1_tmp)]:
        paramsUrl=paramsGen()
        paramsUrl['date']=dd
        resp=requests.get(url,headers=heaGen(),cookies=cookiesGen(),params=paramsUrl).json()
        epg[dd]=resp['guide'] if 'guide' in resp else {}
        
    return epg

def epgC(epg_data,cid): #do listy kanałów LIVE
    days=epg_data.keys()
    epg=[]
    for dd in days:
        epg_list=[e['programs'] for e in epg_data[dd] if e['channelExtId']==cid] if epg_data[dd]!={} else []
        if len(epg_list)>0:
            epg+=epg_list[0]
    
    epg_chan=''
    now=datetime.datetime.now()
    for e in epg:
        ts=tmpUtcToDate(e['startTimeUtc'])
        te=tmpUtcToDate(e['endTimeUtc'])
        if te>now:
            name=e['name']
            if 'episodeNumber' in e:
                if e['episodeNumber'] not in ['',None]:
                    name+=' (%s)'%(e['episodeNumber'])
            t_start=dateToStr(ts,'%H:%M')
            t_end=dateToStr(te,'%H:%M')
            epg_chan+='[COLOR=cyan]%s-%s[/COLOR]  %s\n'%(t_start,t_end,name)
    
    return epg_chan
            

def channelList(): #helper
    channels=[]
    url=apiURL+'live/channel/all'
    resp=requests.get(url,headers=heaGen(),cookies=cookiesGen(),params=paramsGen())
    xbmc.log('@@@Lista kanałów status_code: '+str(resp.status_code), level=xbmc.LOGINFO)
    resp=resp.json()
    if 'channelList' in resp:
        channels=[c for c in resp['channelList'] if c['isSubscribed']]
    else:
        xbmc.log('@@@Lista kanałów error: '+str(resp), level=xbmc.LOGINFO)
    
    return channels

categs_tv=['Wszystkie','Ogólne','Informacje','Sport','Filmy i seriale','Premium','Lifestyle i rozrywka','Nauka i świat','Dzieci','Muzyka','Obcojęzyczne']

def tvList(t):
    showEpg=addon.getSetting('showEpg')
    chans=channelList()
    if t=='live':
        #filtr wg kategorii
        categ=addon.getSetting('tv_ctg')
        categ=categs_tv[0] if categ=='' else categ
        
        name='[COLOR=cyan][B]Kategoria: [/B][/COLOR] %s'%(categ)
        img='DefaultGenre.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url=build_url({'mode':'setCategTv'})
        addItemList(url, name, setArt, isF=False)
        
        if categ!='Wszystkie':
            chans=[c for c in chans if c['category']==categ]
    
    if t=='live':
        date=dateToStr(datetime.datetime.now(),'%Y-%m-%d')
        if showEpg=='true':
            epg_data=epgData(date)    
    
    for c in chans:
        isCatchUp=c['playFeatures'][deviceCat]['isCatchUp']
        isAllowed=c['playFeatures'][deviceCat]['isChannelAllowed']
        tsDur=c['catchupDuration']
        
        if isAllowed and (t=='live' or (t=='replay' and isCatchUp)):
        
            img=apiURL_old+'resource/image/'+c['logoSignature']
            name=c['name']
            if c['isHomeZoneRestricted']:
                name='%s [COLOR=cyan][HOME][/COLOR]'%(name)
            cid=c['channelExtId']

            if t=='live':
                isPlayable='true'
                isFolder=False
                url=build_url({'mode':'playSource','cid':cid,'tsDur':str(tsDur)})
                epg_chan=epgC(epg_data,cid) if showEpg=='true' else '[COLOR=cyan]%s[/COLOR]'%(c['category'])
                plot=epg_chan if epg_chan!='' else 'Brak danych EPG'
                
            elif t=='replay':
                isPlayable='false'
                isFolder=True
                url=build_url({'mode':'calendar','cid':cid,'cuDur':str(tsDur)})
                plot=''
                contMenu=False
                cmItems=[]
                        
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            iL={'title': name,'sorttitle': name,'plot': plot}
            addItemList(url, name, setArt, 'video', iL, isF=isFolder, isPla=isPlayable)
    
    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)

def setCategTv():
    categ=addon.getSetting('tv_ctg')
    categ=categs_tv[0] if categ=='' else categ
       
    labs=categs_tv
    
    select=xbmcgui.Dialog().select('Kategoria:', labs)
    if select>-1:
        new_categ=labs[select]
    else:
        new_categ=categ
    
    if new_categ!=categ:
        addon.setSetting('tv_ctg',new_categ)
        xbmc.executebuiltin('Container.Refresh()')

    
def calendar(cid,cuDur):
    days=int(int(cuDur)/86400)
    now=datetime.datetime.now()
    for i in range(0,days+1):
        date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
               
        setArt={'icon': 'DefaultYear.png','fanart':fanart}
        url=build_url({'mode':'programList','cid':cid,'date':date,'cuDur':cuDur})
        addItemList(url, date, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def programList(cid,d,cuDur):
    epg_data=epgData(d)
    days=epg_data.keys()
    epg=[]
    for dd in days:
        epg_list=[e['programs'] for e in epg_data[dd] if e['channelExtId']==cid] if epg_data[dd]!={} else []
        if len(epg_list)>0:
            epg+=epg_list[0]
    
    now=datetime.datetime.now()
    tc=now-datetime.timedelta(seconds=int(cuDur))

    for e in epg:
        ts=tmpUtcToDate(e['startTimeUtc'])
        te=tmpUtcToDate(e['endTimeUtc'])
        if te>=tc and te<=now and dateToStr(ts,'%Y-%m-%d')==d:
            pid=e['programExtId']
            title=e['name']
            t_s=dateToStr(ts,'%H:%M')
            t_e=dateToStr(te,'%H:%M')
            name='[COLOR=cyan]%s-%s[/COLOR] %s'%(t_s,t_e,title)
            if 'episodeNumber' in e:
                if e['episodeNumber'] not in ['',None]:
                    name+=' (%s)'%(e['episodeNumber'])
            img=baseurl+'mnapi/gopher-2epgthumb/'+e['image']
            
            iL={'title':title, 'plot':title, 'mediatype':'movie'}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            url=build_url({'mode':'playReplay','pid':pid,'cid':cid})            
            
            addItemList(url, name, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
    
def delSession(c): #helper
    url=apiURL+'live/channel/'+c+'/session'
    resp=requests.delete(url,headers=heaGen(),cookies=cookiesGen(),params=paramsGen())
    xbmc.log('@@@Kasowanie sesji TV: result '+str(resp.status_code), level=xbmc.LOGINFO)
    
    
def registerTerminal(c): #helper
    url=apiURL+'core/device/register'
    hea=heaGen()
    hea['Content-Type']='application/json;ver=1'
    data={
        "deviceManufacture": "web",
        "deviceModel": "web",
        "deviceType": deviceType,
        "name": "FIREFOX",
        "serialNumber": "FIREFOX_WEB_TERMINAL_1"+addon.getSetting('householdExtId')
    }
    resp=requests.post(url,headers=hea,cookies=cookiesGen(),params=paramsGen(),json=data)
    
    return resp

def playSource(c,pid=None,contType='LIVE',ts=None,te=None):
    prevC=addon.getSetting('prevC')
    if prevC!='':
        delSession(prevC)
    
    url=apiURL+'live/channel/'+c
    if contType=='CATCHUP':
        url+='/'+pid+'/catchup'
    resp=requests.get(url,headers=heaGen(),cookies=cookiesGen(),params=paramsGen())
    if resp.status_code==412:
        rt=registerTerminal(c)
        if rt.status_code!=200:
            xbmcgui.Dialog().notification('Orange Go', 'Problem z rejestracją terminala', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            xbmc.log('@@@Rejestracja terminala error: '+rt.text, level=xbmc.LOGINFO)
            return
        resp=requests.get(url,headers=heaGen(),cookies=cookiesGen(),params=paramsGen())
        if resp.status_code==412:
            xbmcgui.Dialog().notification('Orange Go', 'Problem z ustanowieniem sesji', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            xbmc.log('@@@Ustanowienie sesji TV error: '+resp.text, level=xbmc.LOGINFO)
            return
    
    resp=resp.json()
    
    if 'casToken' in resp:
        addon.setSetting('prevC',c)
        
        casToken=resp['casToken']
        stream_url=resp['streamUrl']
        stream_url=stream_url.replace('hhtech='+addon.getSetting('hhTech'),'hhtech=').split('&maxrate=')[0] #profile
        
        #ver TVP3
        if c=='14215':
            url_reg=apiURL+'live/regional-tv/all'
            resp_reg=requests.get(url_reg,headers=heaGen(),cookies=cookiesGen(),params=paramsGen()).json()
            if 'regionalTvPackageList' in resp_reg:
                srcs=[r['regionalTvList'] for r in resp_reg['regionalTvPackageList'] if r['channelExtId']==c]
                if len(srcs)>0:
                    regList=srcs[0]
                    tvreg=[t for t in regList if addon.getSetting('tvreg') in t['channelName']]
                    if len(tvreg)>0:
                        stream_url=stream_url.replace(c,c+tvreg[0]['liveUrlSuffix'])
        
        if ts!=None: #catchup SC
            stream_url+='&begin=%s&end=%s'%(str(int(ts)),str(int(te)))
        
        #cert WV
        url='https://cps.purpledrm.com/wv_certificate/cert_license_widevine_com.bin'
        hc={'User-Agent':UA,'Origin':baseurl[:-1],'Referer':baseurl}
        resp_cert=requests.get(url,headers=hc).content
        cert_data=base64.b64encode(resp_cert).decode('utf-8')
        
        lic_url=baseurl+'RTEFacade_RIGHTV/widevinedrm?token='+quote(casToken)
        
        lic_hea={
            'User-Agent':UA,
            'Origin':baseurl[:-1],
            'Referer':baseurl,
        }
        cookies=cookiesGen()
        lic_hea['Cookie']='; '.join([k+'='+cookies[k] for k in list(cookies)])

        
        #K21
        lickey='%s|%s|R{SSM}|'%(lic_url,urlencode(lic_hea))
        #K22
        drm_conf={
            "com.widevine.alpha": {
                "license": {
                    "server_url": lic_url,
                    "req_headers": urlencode(lic_hea),
                    "server_certificate": cert_data
                }
            }
        }
        
        ISAplayer(stream_url,lickey,drm_conf,cert_data)
    else:
        xbmcgui.Dialog().notification('Orange Go', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        xbmc.log('@@@Odtwarzanie TV error: '+resp.text, level=xbmc.LOGINFO)
    

def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Orange Go', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Orange Go', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channelList()
    if chans !=False:
        data = '#EXTM3U\n'
        for c in chans:
            isCatchUp=c['playFeatures'][deviceCat]['isCatchUp']
            isAllowed=c['playFeatures'][deviceCat]['isChannelAllowed']
            tsDur=c['catchupDuration']
            
            if isAllowed:
                name=c['name']
                img=apiURL_old+'resource/image/'+c['logoSignature']
                cid=c['channelExtId']
                
                if isCatchUp: #CATCHUP SC
                    cuDur=int(int(tsDur)/84600)#'7'
                    data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Orange Go" catchup="append" catchup-source="&s={utc:Y-m-d H:M:S}&e={utcend:Y-m-d H:M:S}" catchup-days="%s" catchup-correction="0.0",%s\nplugin://plugin.video.orange_go?mode=playSource&cid=%s\n' %(name,img,cuDur,name,cid)

                else:
                    data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Orange Go" ,%s\nplugin://plugin.video.orange_go?mode=playSource&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('Orange Go', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Orange Go', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)    



mode = params.get('mode', None)

refreshToken()

if not mode:    
    main_menu()
else:
    if mode=='logIn':#
        logIn()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.orange_go/,replace)')
    
    if mode=='logOut':
        logOut()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.orange_go/,replace)')

    if mode=='tvList':
        tvList('live')
    
    if mode=='replay':
        tvList('replay')
    
    if mode=='setCategTv':
        setCategTv()
    
    if mode=='calendar':
        cid=params.get('cid')
        cuDur=params.get('cuDur')
        calendar(cid,cuDur)
        
    if mode=='programList':
        cid=params.get('cid')
        date=params.get('date')
        cuDur=params.get('cuDur')
        programList(cid,date,cuDur)
        
    if mode=='playReplay':
        pid=params.get('pid')
        cid=params.get('cid')
        playSource(cid,pid,'CATCHUP')


    if mode=='playSource':
        refreshToken()
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            pid=params.get('pid')
            ts=None
            te=None
            s=params.get('s')
            e=params.get('e')
            if s!=None and e!=None:
                ts=strToDate(s).timestamp()
                te=strToDate(e).timestamp()        
            playSource(cid,pid,'LIVE',ts,te)
        else:
            xbmcgui.Dialog().notification('Orange Go', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
            
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('Orange Go', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
