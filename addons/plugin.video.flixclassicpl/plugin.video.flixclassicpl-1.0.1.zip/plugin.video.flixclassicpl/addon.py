# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.flixclassicpl')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
img_addon=PATH+'/icon.png'

baseurl='https://flixclassic.pl/'
apiURL='https://flixclassic.pl/api/'
platform='BROWSER'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) Gecko/20100101 Firefox/127.0'

def build_url(query):
        return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)


def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def heaGen(js=True):
    CorrelationID='client_'+code_gen(8)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(12)
    h={
        'User-Agent':UA,
        'Referer':baseurl,
        'API-DeviceUid':addon.getSetting('uid'),
        'API-CorrelationId':CorrelationID,
    }
    if js:
        h['Accept']='application/json, text/plain, */*'
        
    return h
    
def cookiesGen():
    c={
        'uid':addon.getSetting('uid')
    }
    if addon.getSetting('logged')=='true':
        now=int(1000*time.time())
        sessTill=int(addon.getSetting('session_till'))
        if now>sessTill:
            refreshSession()
        c['session_uid']=addon.getSetting('session_uid')
        c['sso_remember_me']=addon.getSetting('sso_remember_me')
    
    return c
    
def paramsGen():
    p={
        'lang':'POL',
        'platform':platform
    }
    return p

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def logIn():
    password=addon.getSetting('password')
    login=addon.getSetting('login')
    if login!='' and password!='':
        url=apiURL+'subscribers/login'
        h=heaGen()
        h['Content-Type']='application/json'
        data={
            "appVersion":"2ea9f0c",
            "auth":{"type":"PASSWORD","value":password},
            "captcha":"",
            "email":login,
            "rememberMe":True
        }
        res=requests.post(url,headers=h,cookies=cookiesGen(),params=paramsGen(),json=data)
        resp=res.json()
        if 'code' not in resp:
            if 'httpSession' in resp:
                addon.setSetting('session_uid',resp['httpSession']['uid'])
                addon.setSetting('session_till',str(resp['httpSession']['till']))
                addon.setSetting('sso_remember_me',dict(res.cookies)['sso_remember_me'])
                addon.setSetting('logged','true')
        else:
            info=resp['code'] if 'code' in resp else 'nieokreślony' 
            xbmcgui.Dialog().notification('FlixClassic', 'Błąd logowania: %s'%(info), xbmcgui.NOTIFICATION_INFO)    
    else:
        xbmcgui.Dialog().notification('FlixClassic', 'Uzupełnij dane logowania w ustawieniach', xbmcgui.NOTIFICATION_INFO)

def logOut():
    url=apiURL+'subscribers/logout'
    resp=requests.post(url,headers=heaGen(),cookies=cookiesGen(),params=paramsGen())
    
    addon.setSetting('session_uid','')
    addon.setSetting('session_till','')
    addon.setSetting('sso_remember_me','')
    addon.setSetting('logged','false')
        
def refreshSession():
    url=apiURL+'subscribers/detail'
    cookies={
        'uid':addon.getSetting('uid'),
        'sso_remember_me':addon.getSetting('sso_remember_me')
    }
    resp=requests.get(url,headers=heaGen(),cookies=cookies,params=paramsGen()).json()
    addon.setSetting('session_uid',resp['httpSession']['uid'])
    addon.setSetting('session_till',str(resp['httpSession']['till']))

def locTime(x):
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6])) #GMT
    
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    
    z=(y-datetime.timedelta(seconds=offset)).strftime('%Y-%m-%d %H:%M')
    
    return z    

mainCategs=[
    ['Filmy','contList','7305','DefaultAddonVideo.png'],
    ['Seriale','contList','7321','DefaultAddonVideo.png'],
    ['Strona główna','mainPage','main','OverlayUnwatched.png'],
    ['wyszukiwarka','search','','DefaultAddonsSearch.png'],
    ['ULUBIONE','favList','','DefaultMusicRecentlyAdded.png'],
]


def main_menu():
    menu=mainCategs
    if addon.getSetting('logged')=='true':
        menu.append(['Wyloguj','logOut','','DefaultUser.png'])
    else:
        menu.append(['Zaloguj','logIn','','DefaultUser.png'])
        
    for m in menu:
        if m[1]=='contList' or m[1]=='mainPage':
            URL=build_url({'mode':m[1],'mainCateg':m[2]})
        else:
            URL=build_url({'mode':m[1]})

        img=img_addon if m[3]=='OverlayUnwatched.png' else ''
        
        setArt={'thumb': '', 'poster': img, 'banner': '', 'icon': m[3], 'fanart':fanart}
        addItemList(URL, m[0], setArt, 'video')
    xbmcplugin.endOfDirectory(addon_handle)

def detCont(x,seas=0):
    #types: VOD,SERIAL,EPISODE,BANNER,SECTION
    title=x['title']
    originaltitle=x['originalTitle'] if 'originalTitle' in x else ''
    rating=str(x['rating']) if 'rating' in x else ''
    ep=x['number'] if x['type']=='EPISODE' else 0
    descShort=cleanText(x['lead']) if 'lead' in x else ''
    desc=cleanText(x['description']) if 'description' in x else ''
    desc=descShort if desc=='' else desc
    dur=x['duration'] if 'duration' in x else 0
    year=x['year'] if 'year' in x else 0
    country=[c['name'] for c in x['countries']] if 'countries' in x else []
    actors=[c['name'] for c in x['actors']] if 'actors' in x else []
    directors=[c['name'] for c in x['directors']] if 'directors' in x else []
    scriptwriters=[c['name'] for c in x['scriptwriters']] if 'scriptwriters' in x else []
    genre=[c['name'] for c in x['genres']] if 'genres' in x else []
    tags=[c['name'] for c in x['tags']] if 'tags' in x else []
    
    #dostępność
    avail=''
    availLabel=''
    if 'displaySchedules' in x:
        i_cur=[i for i,t in enumerate(x['displaySchedules'])][0]
        
        if x['displaySchedules'][i_cur]['type']!='SOON':
            if 'payable' in x:
                if x['payable']:
                    #avail+='Płatny\n'
                    pass
                else:
                    avail+='[B][COLOR=yellow]Bezpłatny\n[/COLOR][/B]'
                    if 'payableSince' in x:
                        avail+='[COLOR=yellow]do: %s\n[/COLOR]'%(x['payableSince'])

            if 'since' in x['displaySchedules'][i_cur]:
                avail+='[B]Data publikacji: [/B]'+x['displaySchedules'][i_cur]['since'].split('T')[0]+'\n'
            
            if x['displaySchedules'][i_cur]['type']=='PREMIERE':
                if 'till' in x['displaySchedules'][i_cur]:
                    avail+='[B]Dostępny do: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'
                avail+='[COLOR=yellow]PREMIERA[/COLOR]\n'
            else:
                if 'till' in x['displaySchedules'][i_cur]:
                    avail+='[B]Dostępny do: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'
                if x['displaySchedules'][i_cur]['type']=='LAST_BELL':
                    availLabel='LAST_BELL|'+locTime(x['displaySchedules'][i_cur]['till'])
                    avail+='[COLOR=yellow]OSTATNIA SZANSA[/COLOR]\n'
            
        else:
            availLabel='SOON'
            if 'till' in x['displaySchedules'][i_cur]:
                avail+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
                avail+='[B]Dostępny od: [/B]'+locTime(x['displaySchedules'][i_cur]['till'])+'\n'
    
    descShort=avail+descShort
    desc=avail+desc
    
    iL={}
    if x['type']=='EPISODE':
        iL={'title': title,'sorttitle': title,'originalTitle':originaltitle,'mpaa':rating,'plotoutline':descShort,'plot': desc,'year':year,'genre':genre,'duration':dur,'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'season':seas,'episode':ep,'mediatype':'episode'}
    elif x['type'] in ['VOD','SERIAL']:
        iL={'title': title,'sorttitle': title,'originalTitle':originaltitle,'mpaa':rating,'plotoutline':descShort,'plot': desc,'year':year,'genre':genre,'duration':dur,'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'mediatype':'movie'}
        if x['type']=='SERIAL':
            iL['mediatype']='tvshow'
        if 'trailer' in x:
            if x['trailer']:
                iL['trailer']=build_url({'mode':'playVid','eid':str(x['id']),'tenant':x['tenant']['uid'],'trailer':'1'})
        
    else:
        iL={'plot':title}

    return iL,availLabel,tags

def getImg(x):#
    try:
        img=x['16x9'][0]['templateUrl'].format(height=576,width=1024).replace(' ','')
    except:
        try:
            img=x['3x4'][0]['templateUrl'].format(height=576,width=720).replace(' ','')
        except:
            img=''
    
    if img.startswith('//'):
        img='https:'+img
    return img
    
def titleWithTill(d,t):#data dostępności w tytule
    title=t
    if 'LAST_BELL' in d:
        title=t+' [COLOR=yellow]/do: '+d.split('|')[1]+'/[/COLOR]'
    if 'SOON' in d:
        title='[COLOR=gray]%s[/COLOR]'%(title)

    return title

sortTypes={'title|asc':'A-Z','title|desc':'Z-A','createdAt|desc':'Ostatnio dodane','year|asc':'Najstarsze','year|desc':'Najnowsze'}

def categSelect(mc,c):
    url=apiURL+'items/categories'
    paramsURL=paramsGen()
    paramsURL['mainCategoryId']=mc
    resp=requests.get(url,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
    labels=[l['name'] for l in resp]
    labels.append('Wszystkie')
    select=xbmcgui.Dialog().select('Kategorie', labels)
    if select>-1:
        categ=resp[select]['id'] if select<=len(resp)-1 else ''
    else:
        categ=c
    addon.setSetting('c_'+mc,str(categ))
    saveF(PATH_profile+'categs%s.txt'%(mc),str(resp))
    xbmc.executebuiltin('Container.Refresh()')
    
def sortSelect(mc,s):
    labels=list(sortTypes.values())
    labels.append('Domyślnie')
    select=xbmcgui.Dialog().select('Sortowanie', labels)
    if select>-1:
        try:
            sort=[st for st in sortTypes if sortTypes[st]==labels[select]][0]
        except:
            sort=''
    else:
        sort=s
    addon.setSetting('s_'+mc,sort)
    xbmc.executebuiltin('Container.Refresh()')

def contList(mc,p):
    p='1' if p==None else p
    
    c=addon.getSetting('c_'+mc)
    s=addon.getSetting('s_'+mc)
    if p=='1':
        #kategoria
        if c!='':
            categs=eval(openF(PATH_profile+'categs%s.txt'%(mc)))
            categLabel=[ct['name'] for ct in categs if str(ct['id'])==c][0]
            title='[B]Kategoria: [/B]'+categLabel
        else:
            title='[B]Kategoria: [/B]wszystkie'
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'categSelect','mainCateg':mc,'categ':c})
        addItemList(url, title, setArt, isF=False)
        
        #sortowanie
        if s!='':
            sortLabel=sortTypes[s]
            title='[B]Sortowanie: [/B]'+sortLabel
        else:
            title='[B]Sortowanie: [/B]domyślne'
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'sortSelect','mainCateg':mc,'sort':s})
        addItemList(url, title, setArt, isF=False)
    
    cnt=addon.getSetting('listCount') if addon.getSetting('logged')=='true' else '500'
    start=(int(p)-1)*int(cnt)
    
    url=apiURL+'products/vods'
    paramsURL=paramsGen()
    paramsURL.update({
        'mainCategoryId[]':mc,
        'firstResult':str(start),
        'maxResults':cnt
	})
    if c!='':
        paramsURL['categoryId[]']=c
    if s!='': 
        sortData=s.split('|')
        paramsURL.update({'sort':sortData[0],'order':sortData[1]})
    
    resp=requests.get(url,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
    for r in resp['items']:
        addContToList(r)
  
    total=resp['meta']['totalCount']
    if start+int(cnt)+1<total:       
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'contList','mainCateg':mc,'page':str(int(p)+1)})
        addItemList(url, '[B][COLOR=cyan]>>> Następna strona[/COLOR][/B]', setArt, 'video')
    
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)

def sezonList(cid,tit,tenant):
    u=apiURL+'products/vods/serials/'+cid+'/seasons'
    paramsURL=paramsGen()
    resp=requests.get(u,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
    if len(resp)==1: #jeden sezon
        sezId=str(resp[0]['id'])
        episodeList(cid,sezId,tit,'1','yes','1',tenant)
    else:
        for r in resp:
            sez_id=str(r['id'])
            sez_name=r['title']
            if sez_name=='':
                sez_name='sezon '+str(r['number'])
            seasNo=str(r['number'])
            
            iL={'title': '','sorttitle': '','plot': tit}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart':fanart}
            url = build_url({'mode':'episodeList','cid':cid,'sezId':sez_id,'title':tit,'init':'yes','seasNo':seasNo,'tenant':tenant,'page':'1'})
            addItemList(url, sez_name, setArt, 'video', iL)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)    

def episodeList(cid,sezId,tit,pg,init,seasNo,tenant):
    cnt=int(addon.getSetting('listCount'))
    p=int(pg)
    if init=='yes':
        u=apiURL+'products/vods/serials/'+cid+'/seasons/'+sezId+'/episodes'
        paramsURL=paramsGen()
        resp=requests.get(u,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()#list
        saveF(PATH_profile+'episodes.txt',str(resp))
    
    resp=eval(openF(PATH_profile+'episodes.txt'))
    total=len(resp)
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        r=resp[i]
        addContToList(r,int(seasNo),tenant)
    
    nextPage=False
    if p<math.ceil(total/cnt):
        nextPage=True
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'episodeList','init':'no','cid':cid,'sezId':sezId,'title':tit,'seasNo':seasNo,'tenant':tenant,'page':str(p+1)})
        addItemList(url, '[B][COLOR=cyan]>>> Następna strona[/COLOR][/B]', setArt, 'video')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    if not nextPage:
        xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_EPISODE)
    xbmcplugin.endOfDirectory(addon_handle)

def showDet(eid):#menu kont
    u=apiURL+'products/vods/'+eid
    paramsURL=paramsGen()
    resp=requests.get(u,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
    iL,availLabel,tags=detCont(resp)
    
    plot=''
    if iL['year']!=0:
        plot='[B]Rok prod:[/B] %s\n'%(str(iL['year']))
    if len(iL['country'])!=0:
        plot+='[B]Kraj:[/B] %s\n'%(', '.join(iL['country']))
    if len(iL['genre'])!=0:
        plot+='[B]Gatunek:[/B] %s\n'%(', '.join(iL['genre']))
    if iL['duration']!=0:
        plot+='[B]Czas:[/B] %s min.\n'%(str(int(iL['duration']/60)))
    if iL['mpaa']!='':
        plot+='[B]Ograniczenia wiekowe:[/B] %s lat\n'%(str(iL['mpaa']))
    if len(iL['cast'])>0:
        plot+='[B]Obsada:[/B] %s\n'%(', '.join(iL['cast']))
    if len(iL['director'])>0:
        plot+='[B]Reżyseria:[/B] %s\n'%(', '.join(iL['director']))
    if len(iL['writer'])>0:
        plot+='[B]Scenariusz:[/B] %s\n'%(', '.join(iL['writer']))
    if len(tags)!=0:
        plot+='[B]Tagi:[/B] [I]%s[/I]\n\n'%(', '.join(tags))
    plot+=iL['plot']
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)
    

def playVid(eid,tenant,trailer=None): 
    if trailer==None:
        u=apiURL+'products/'+eid+'/videos/player/configuration'
        paramsURL=paramsGen()
        paramsURL['videoType']='MOVIE'
        resp=requests.get(u,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
        playURL=''
        if 'playlistUrl' in resp:
            if resp['playlistUrl']!=None and resp['playlistUrl']!='':
                playURL=resp['playlistUrl']
                paramsURL={}
        
        if playURL=='':
            xbmcgui.Dialog().notification('FlixClassic', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            return
        
    else:
        playURL=apiURL+'products/'+eid+'/videos/playlist'
        paramsURL={
            'videoType':'MOVIE',
            'platform':platform,
            'tenant':tenant,
            'videoType':'TRAILER'
        }
    
    resp=requests.get(playURL,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
    
    if 'code' in resp:
        if resp['code']=='ITEM_NOT_PAID':
            xbmcgui.Dialog().notification('FlixClassic', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().notification('FlixClassic', 'Materiał niedostępny: '+resp['code'], xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
    
    protocol='mpd'
    s_url=resp['sources']['DASH'][0]['src']
    if s_url.startswith('//'):
        s_url='https:'+s_url
    hea_player='User-Agent='+UA+'&Referer='+baseurl
    drm=False
    '''
    if 'WIDEVINE' in resp['drm']:
        drm=True
        hea.update({'Content-Type':''})
        heaLic=urlencode(hea)
        lic_url=resp['WIDEVINE']['src']+'|'+heaLic+'|R{SSM}|' 
    '''
    import inputstreamhelper
    PROTOCOL = protocol
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=s_url)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hea_player)#K21
        play_item.setProperty('inputstream.adaptive.stream_headers', hea_player) 
        play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        if drm:
            play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
            play_item.setProperty("inputstream.adaptive.license_key", lic_url)
                  
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
#Wyszukiwarka    
def search():
    qry=xbmcgui.Dialog().input('Szukaj (przynajmniej 3 znaki):', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        types={'VOD':'Filmy','SERIAL':'Seriale','EPISODE':'Odcinki'}
        u=apiURL+'products/vods/search/'
        paramsURL=paramsGen()
        paramsURL['keyword']=qry
        for t in types:
            resp=requests.get(u+t,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json())
            saveF(PATH_profile+'search_%s.txt'%(t),str(resp['items']))
        
            setArt={'thumb': '', 'poster': img_addon, 'banner': '', 'icon': 'DefaultAddonVideo.png', 'fanart':fanart}
            url = build_url({'mode':'searchRes','cat':t})
            addItemList(url, '%s (%s)'%(types[t],str(len(resp['items']))), setArt, 'video')

        xbmcplugin.endOfDirectory(addon_handle)
    else:
        main_menu()

def searchRes(ct):
    res=eval(openF(PATH_profile+'search_%s.txt'%(ct)))
    for r in res:
        addContToList(r)
        
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)

#Strona główna
def mainPage(mc):
    u=apiURL+'products/sections/'+mc
    paramsURL=paramsGen()
    paramsURL.update({
        'elementsLimit':'10',
        'maxResults':'20'
    })
    resp=requests.get(u,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
    for c in resp:
        if c['title'] not in ['FILMY']:                        
            addContToList(c)
                    
    xbmcplugin.endOfDirectory(addon_handle)

def sectionList(cid):
    u=apiURL+'products/sections/'+cid
    paramsURL=paramsGen()
    paramsURL.update({
        'elementsLimit':'100',
        'maxResults':'20'
    })
    resp=requests.get(u,headers=heaGen(),cookies=cookiesGen(),params=paramsURL).json()
    for r in resp['elements']:
        addContToList(r['item'])
    xbmcplugin.endOfDirectory(addon_handle)    


def addContToList(r,seasNo=0,tenant=None):#
    if 'season' in r:
        seasNo=r['season']['number']
    
    isShow=True
    
    cid=str(r['id'])
    name=r['title']
    type=r['type']
    img=getImg(r['images'])
    iL,availLabel,tags=detCont(r,seasNo)
    mod=''
    isPlayable='false'
    isFolder=True
        
    if type=='SERIAL':
        tenant=r['tenant']['uid']
        
        mod='sezonList'
        URL = build_url({'mode':mod,'cid':cid,'title':name,'tenant':tenant})
    elif type=='VOD':
        if addon.getSetting('logged')=='false' and r['payable']:
            isShow=False
        name=titleWithTill(availLabel,name)
        tenant=r['tenant']['uid']
        
        mod='playVid'
        URL = build_url({'mode':mod,'eid':cid,'tenant':tenant})
        isPlayable='true'
        isFolder=False

    elif type=='EPISODE':
        if 'season' in r:
            if 'serial' in r['season']:
                name='[B]%s[/B] | %s'%(r['season']['serial']['title'],name)
        if tenant==None:
            tenant=r['tenant']['uid']
        
        name=titleWithTill(availLabel,name)
        mod='playVid'
        URL = build_url({'mode':mod,'eid':cid,'tenant':tenant})
        isPlayable='true'
        isFolder=False
    elif type=='SECTION':
        mod='sectionList'
        URL = build_url({'mode':mod,'cid':cid})
    elif type=='BANNER':#do weryfikacji
        if 'urlWeb' in r:
            cid=r['urlWeb'].split(',')[-1]
            if '/kolekcje/' in r['urlWeb']:
                mod='sectionList'
                URL = build_url({'mode':mod,'cid':cid})
            else:
                URL = build_url({'mode':'mainPage'})
    
    if (type=='SERIAL' or type=='VOD' or type=='EPISODE') and availLabel=='SOON':#r['displaySchedules'][i_cur]['type']=='SOON':
        isPlayable='false'
        isFolder=False
        URL = build_url({'mode':'noPlay'})
        
    xbmcplugin.setContent(addon_handle, 'videos')
    
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':img}
    
    cmItems = []
    if type=='VOD' or type=='SERIAL' or type=='EPISODE':
        if type!='EPISODE':
            cmItems.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.flixclassicpl?mode=favAdd&url='+quote(URL)+'&name='+quote(name)+'&art='+quote(str(setArt))+'&iL='+quote(str(iL))+'&cid='+cid+')'))
        cmItems.append(('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.flixclassicpl?mode=showDet&eid='+cid+')'))
                
    if isShow:
        addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)

#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        isPlayable='false'
        isFolder=True
        URL=j[0]
        if 'mode=playVid' in URL:
            isPlayable='true'
            isFolder=False

        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.flixclassicpl?mode=favDel&url='+quote(j[0])+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.flixclassicpl?mode=showDet&eid='+j[4]+')')
        ]
        setArt=eval(j[2])
        iL=eval(j[3])
        addItemList(URL, j[1], setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,n,a,i,c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,n,a,i,c])
        xbmcgui.Dialog().notification('FlixClassic', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('FlixClassic', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('FlixClassic', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('FlixClassic', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)    

def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ').replace('&oacute;','ó').replace('&ouml;','ö').replace('&nbsp;',' ').replace('&ndash;',' - ')
    t=re.sub('<([^<]+?)>','',t)
    return t 

  
mode = params.get('mode', None)

if not mode:
    if addon.getSetting('uid')=='' or addon.getSetting('uid')==None:
        addon.setSetting('uid',code_gen(32))
    main_menu()
else:
  
    if mode=='contList':
        mc=params.get('mainCateg')
        p=params.get('page')
        contList(mc,p)
    
    if mode=='categSelect':
        mc=params.get('mainCateg')
        c=params.get('categ')
        categSelect(mc,c)
        
    if mode=='sortSelect':
        mc=params.get('mainCateg')
        s=params.get('sort')
        sortSelect(mc,s)
    
    if mode=='sezonList':
        cid=params.get('cid')
        tit=params.get('title')
        tenant=params.get('tenant')
        sezonList(cid,tit,tenant)
    
    if mode=='episodeList':
        cid=params.get('cid')
        sezId=params.get('sezId')
        tit=params.get('title')
        pg=params.get('page')
        init=params.get('init')
        seasNo=params.get('seasNo')
        tenant=params.get('tenant')
        episodeList(cid,sezId,tit,pg,init,seasNo,tenant)
    
    if mode=='showDet':
        eid=params.get('eid')
        showDet(eid)
        
    if mode=='playVid':
        eid=params.get('eid')
        tenant=params.get('tenant')
        trailer=params.get('trailer')
        playVid(eid,tenant,trailer)

    if mode=='noPlay':
        pass
    
    if mode=='search':
        search()
    
    if mode=='searchRes':
        cat=params.get('cat')
        searchRes(cat)
        
    if mode=='mainPage':
        mc=params.get('mainCateg')
        mainPage(mc)
            
    if mode=='sectionList':
        cid=params.get('cid')
        sectionList(cid)
        
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        url=params.get('url')
        favDel(url)
        
    if mode=='favAdd':
        u=params.get('url')
        n=params.get('name')
        a=params.get('art')
        i=params.get('iL')
        c=params.get('cid')
        favAdd(u,n,a,i,c)
        
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
                
    if mode=='logIn':
        logIn()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.flixclassicpl/,replace)')
            
    if mode=='logOut':
        logOut()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.flixclassicpl/,replace)')
            