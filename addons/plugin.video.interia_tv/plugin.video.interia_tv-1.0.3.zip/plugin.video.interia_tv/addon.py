# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.interia_tv')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
icon=PATH+'/icon.png'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

baseurl='https://www.interia.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

hea={
    'User-Agent':UA,
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def main_menu():
    items=[
        ['Podcasty','podcasts','DefaultAddonVideo.png']
    ]
    
    for i in items:
        img=i[2]
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)    
    
def podcasts():
    resp=requests.get(baseurl,headers=hea).text
    resp1=resp.split('megamenu-news')[-1].split('</ul')[0].split('</li>')
    for r in resp1:
        if 'title=' in r:
            title=clearTxt(re.compile('title=\"([^\"]+?)\"').findall(r)[0])
            link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('src=\"([^\"]+?)\"').findall(r)[0]
            
            if title not in ['Interia Bliżej Świata']:
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
                url = build_url({'mode':'epList','link':link})
                addItemList(url, title, setArt)
    
    #podcasty serwisów tematycznych        
    items=[
        ['Podcasty - Styl w INTERIA.PL','https://styl.interia.pl',icon],
        ['Podcasty - Kobieta w INTERIA.PL','https://kobieta.interia.pl',icon],
    ]
    
    for i in items:
        setArt={'thumb': i[2], 'poster': i[2], 'banner': i[2], 'icon': i[2], 'fanart':fanart}
        url = build_url({'mode':'podcastSubj','link':i[1]})
        addItemList(url, i[0], setArt)
        
    #podcasty - bezpośrednie linki
    
    items=[
        ['Można zdrowiej','https://zdrowie.interia.pl/podcast-mozna-zdrowiej',icon],
    ]
    
    for i in items:
        setArt={'thumb': i[2], 'poster': i[2], 'banner': i[2], 'icon': i[2], 'fanart':fanart}
        url = build_url({'mode':'epList','link':i[1]})
        addItemList(url, i[0], setArt)
        
    
    xbmcplugin.endOfDirectory(addon_handle)

def podcastSubj(l):
    resp=requests.get(l,headers=hea).text
    datas=re.compile('application/json\">([^<]+?)</script').findall(resp)
    data=[d for d in datas if 'mainMenu' in d]

    if len(data)>0:      
        data=json.loads(data[0])
        menu=data['props']['pageProps']['data']['menu']['mainMenu']
        menu_pod=[m for m in menu if m['name'] in ['Podcasty','Podcasty ']]
        if len(menu_pod)>0:
            for m in menu_pod[0]['children']:
                title=m['name']
                img=icon
                link=l+m['url']
                
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
                url = build_url({'mode':'epList','link':link})
                addItemList(url, title, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def epList(l,p):
    if p!=None:
        l=l+',nPack,'+p
        
    resp=requests.get(l,headers=hea).text
    #print(resp)
    datas=re.compile('application/ld\+json\">([^<]+?)</script').findall(resp)
    #print(datas)
    data=[d for d in datas if 'CollectionPage' in d]
    if len(data)>0:
        dts=[d for d in data if 'CollectionPage' in d]
        dt_cp=json.loads(dts[0])
        #print(dt_cp)
        listName='itemListelement' if 'itemListelement' in dt_cp['mainEntity'] else 'itemListElement'
        for i in dt_cp['mainEntity'][listName]:
            link=i['url']
            try:
                title=i['name']
            except:
                link1=link.split('interia.pl')[1]
                print(link1)
                try:
                    title=re.compile('title=\"([^\"]+?)\"').findall(resp.split(link1)[1])[0]
                except:
                    title=re.compile('alt\":\"([^\"]+?)\"').findall(resp.split(link1)[-1])[0]
                
            title=clearTxt(title)
            img='DefaultAddonVideo.png'
            
            iL={'plot':title}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'playVideo','link':link})
            addItemList(url, title, setArt, 'video', iL, False, 'true' )
            
    if 'next enable' in resp:
        page=str(int(p)+1) if p!=None else '2'
        img=img_empty
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url = build_url({'mode':'epList','link':l,'page':page})
        addItemList(url, '[COLOR=cyan][I]>>> następna strona[/I][/COLOR]', setArt)    
    elif 'title=\"Następna strona\"' in resp:
        burl=l.split('/podcasty')[0]
        np_link=re.compile('href=\"([^\"]+?)\"').findall(resp.split('title=\"Następna strona\"')[1])
        if len(np_link)>0:
            img=img_empty
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'epList','link':burl+np_link[0]})
            addItemList(url, '[COLOR=cyan][I]>>> następna strona[/I][/COLOR]', setArt)
        
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def playVideo(l):
    stream_url=''
    stream_type=''
    
    def getStreamUrl(sources):
        qualities=list(sources.keys())
        select = xbmcgui.Dialog().select('Źródła', qualities)
        if len(qualities)>0:
            if select > -1:
                try:
                    stream_url=sources[qualities[select]][0]['src']
                    stream_type=sources[qualities[select]][0]['type']
                except:
                    stream_url=sources[qualities[select]]
                    stream_type='mp4' if 'mp4' in stream_url else 'nieznany'
            else:
                try:
                    stream_url=sources[qualities[0]][0]['src']
                    stream_type=sources[qualities[0]][0]['type']
                except:
                    stream_url=sources[qualities[0]]
                    stream_type='mp4' if 'mp4' in stream_url else 'nieznany'
        
        print(stream_url)
        print(stream_type)
        return stream_url,stream_type
    
    resp=requests.get(l,headers=hea).text
    if 'Inpl.Video.createInstance' in resp:
        data=re.compile('Inpl.Video.createInstance\(\{((?:(?!\}\)).)*?)\}\);').findall(resp)

        if len(data)>0:
            data=json.loads('{%s}'%(data[0]))
            sources=data['tracks'][0]['src']
            
            stream_url,stream_type=getStreamUrl(sources)
    
    else:
        srcs=re.compile('\"src\":\{([^\}]+?)\}').findall(resp)
        if len(srcs)>0:
            src=[s for s in srcs if '.mp4' in s][0]
            sources=json.loads('{%s}'%src)
        
            stream_url,stream_type=getStreamUrl(sources)
                    
    
    if stream_url!='':
        stream_url+='|User-Agent='+UA+'&Referer='+baseurl
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('Interia.tv', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
 
def clearTxt(t):
    return unescape(t)
    
 
    
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='podcasts':
        podcasts()
        
    if mode=='podcastSubj':
        link=params.get('link')
        podcastSubj(link)
        
    if mode=='epList':
        link=params.get('link')
        page=params.get('page')
        epList(link,page)
        
    if mode=='playVideo':
        link=params.get('link')
        playVideo(link)
    