# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
import urllib
from urllib.request import Request, urlopen
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.trwam')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
img_path=PATH+'/resources/img/'
img_addon=PATH+'/icon.png'
fanart=''

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'
heaUA={'User-Agent':UA}

#trwam
baseurl='https://tv-trwam.pl/'
apiURL='https://api-trwam.app.insysgo.pl/'
platform='www'

hea={
    'User-Agent':UA,
    'Referer':baseurl,
    'Origin':baseurl[:-1]
}
URLparams={
    '$headers':'{"Content-Type":"application/json;charset=utf-8","X-Api-Date-Format":"iso","X-Api-Camel-Case":true}'
}

chCodes=['tv-trwam-cvk']

channels={
    'trwam':['TV TRWAM','450',img_addon,'c',7],
    'ewtn':['EWTN Polska','',img_path+'ewtn.png','',0],
    'ewtn24':['EWTN Adoracja','',img_path+'ewtn.png','',0],
    'republika':['TV Republika','617',img_path+'republika.png','',0],
    'wpolsce':['wPolsce','810',img_path+'wpolsce.png','',0],
    'rm':['Radio Maryja','',img_path+'rm.png','',0],
    'wnet':['Radio Wnet','',img_path+'wnet.png','',0],
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)
    
def ISAplayer(protocol,stream_url, playHea, isDRM=False, licURL=False):
    import inputstreamhelper
    
    PROTOCOL = protocol
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)                     
        #play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)        
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', playHea)
        play_item.setProperty('inputstream.adaptive.manifest_headers', playHea)
        if isDRM:
            play_item.setProperty('inputstream.adaptive.license_type', DRM)
            play_item.setProperty('inputstream.adaptive.license_key', licURL)        
    
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(stream_url,heaP):
    stream_url+='|'+heaP
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def getS(c):
    s='ewoJJ3JlcHVibGlrYSc6J2h0dHBzOi8vcmVkaXIuY2FjaGUub3JhbmdlLnBsL2p1cGl0ZXIvbzItY2w3L3NzbC9saXZlL3R2cmVwdWJsaWthL2xpdmUubTN1OCcsCgknZXd0bic6J2h0dHA6Ly9yci5jZG4uZW1pdGVsLnBsL2Jway10di9FV1ROMUhEL2hiYnR2LWRhc2gvaW5kZXgubXBkJywKCSdld3RuMjQnOidodHRwOi8vcnIuY2RuLmVtaXRlbC5wbC9icGstdHYvRVdUTjJIRC9oYmJ0di1kYXNoL2luZGV4Lm1wZCcsCgkncm0nOidodHRwOi8vNTEuNjguMTM1LjE1NTo4MC9zdHJlYW0nLAoJJ3duZXQnOidodHRwOi8vbWVkaWEud25ldC5mbS9yYWRpb193bmV0Lm1wMycKfQ=='
    return eval(base64.b64decode(s).decode())[c]
    
def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def getTime(x):#WP
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    t_utc=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    t_loc=t_utc+diff+datetime.timedelta(seconds=1)
    return t_loc

def timeToStr(x,y):#WP
    return x.strftime(y)
    
def strToTime(x):#WP
    return datetime.datetime(*(time.strptime(x,'%Y-%m-%d')[0:6]))

def main_menu():
    items=[
        ['Na żywo','live','DefaultTVShows.png'],
        ['Archiwum','replay','DefaultAddonVideo.png']
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': ''}
        url=build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)


def getEPG(c): #WP
    today=datetime.datetime.now()
    yest=datetime.datetime.now()-datetime.timedelta(days=1)
    t=timeToStr(today,'%Y-%m-%d')
    y=timeToStr(yest,'%Y-%m-%d')
    progs=[]
    url='https://tv.wp.pl/api/v1/program/'+y+'/'+c
    resp=requests.get(url,headers=heaUA).json()
    progs=resp['data'][0]['entries']
    url='https://tv.wp.pl/api/v1/program/'+t+'/'+c
    resp=requests.get(url,headers=heaUA).json()
    progs+=resp['data'][0]['entries']
    epg=''
    for r in progs:
        if getTime(r['end'])>datetime.datetime.now():
            title=r['title']
            if 'episode_title' in r:
                title+=' - ' + r['episode_title']
            if 'genre' in r:
                title+=' [I]('+ r['genre']+')[/I]'
            ts=timeToStr(getTime(r['start']),'%H:%M')
            epg+='[B]%s[/B] %s\n'%(ts,title)
    
    return epg

def tvList(t):
    for c in list(channels.keys()):
        cData=channels[c]
        if (t=='replay' and cData[3]=='c') or t=='live':
            cName=cData[0]
            img=cData[2]
            
            if t=='replay':
                isF=True
                isP='false'
                url=build_url({'mode':'calendar','chan':c})
                if c=='rm':
                    url=build_url({'mode':'programList','chan':c})
            elif t=='live':
                isF=False
                isP='true'
                url=build_url({'mode':'playLive','chan':c})
                if cData[1]!='':
                    try:
                        epg=getEPG(cData[1])
                    
                    except:
                        epg='Brak danych EPG'
                    
                else:
                    epg='Brak danych EPG'
            
            plot=epg if t=='live' else cName
            
            iL={'plot':plot}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
            addItemList(url, cName, setArt, 'video', iL, isF, isP )
    xbmcplugin.endOfDirectory(addon_handle)

def calendar(c):
    cuDays=channels[c][4]
    now=datetime.datetime.now()
    for i in range(0,cuDays+1):
        date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart':''}
        url=build_url({'mode':'programList','chan':c,'date':date})
        addItemList(url, date, setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def deltaDate(x,y): #helper
    d=datetime.datetime(*(time.strptime(x,'%Y-%m-%d')[0:6]))
    dd=d+datetime.timedelta(days=y)
    ds=dd.strftime('%Y-%m-%d')
    return ds

def programList(c,d,p):
    global hea
    if c=='trwam':
        d0=deltaDate(d,-1)
        d1=deltaDate(d,1)
        url=apiURL+'v1/EpgTile/FilterProgramTiles'
        data={
            "from": d0+'T23:00:00.000Z',#"2023-12-10T23:00:00.000Z",
            "orChannelCodenames": chCodes,
            "platformCodename": platform,
            "to": d1+'T00:00:00.000Z'#"2023-12-12T04:00:00.000Z"
        }

        resp=requests.post(url,headers=hea,json=data,params=URLparams).json()
        progsIDs=[p['id'] for p in resp['programs'][chCodes[0]]]
        ar_pr=[]
        for i,p in enumerate(progsIDs):
            an=int(i/10)
            if len(ar_pr)!=an+1:
                ar_pr.append([])
            pn=i%10
            ar_pr[an].append({'id':p})
        
        progs=[]
        for pi in ar_pr:
            url=apiURL+'v2/Tile/GetTiles'
            data={
                'platformCodename':platform,
                'requestedTiles':pi
            }
            resp=requests.post(url,headers=hea,json=data,params=URLparams).json()
            progs+=resp['tiles']
            
        now=int(time.time())
        for p in progs:
            cS=datetime.datetime(*(time.strptime(p['catchupAvailableFrom'],'%Y-%m-%dT%H:%M:%S%z')[0:6])).timestamp()
            cE=datetime.datetime(*(time.strptime(p['catchupAvailableTo'],'%Y-%m-%dT%H:%M:%S%z')[0:6])).timestamp()
            dStart=datetime.datetime(*(time.strptime(p['start'],'%Y-%m-%dT%H:%M:%S%z')[0:6])).strftime('%Y-%m-%d')
            if now>=cS and now<=cE and dStart==d:
                codename=p['codename']
                title=p['title']
                subtitle=p['subtitle'] if 'subtitle' in p else ''
                if subtitle!='':
                    title+=' - '+subtitle
                desc=p['description'] if 'description' in p else ''
                year=p['date'] if 'date' in p else None
                dur=p['durationSeconds'] if 'durationSeconds' in p else 0
                countries=[c['name'] for c in p['countries']]
                genres=[c['name'] for c in p['categories']]
                try:
                    img=p['images'][0]['url']
                except:
                    img=img_addon
                        
                ts=p['start']
                te=p['stop']
                start=datetime.datetime(*(time.strptime(ts,'%Y-%m-%dT%H:%M:%S%z')[0:6])).strftime('%H:%M')
                end=datetime.datetime(*(time.strptime(te,'%Y-%m-%dT%H:%M:%S%z')[0:6])).strftime('%H:%M')
                
                titleToList='[B]%s - %s[/B] %s'%(start,end,title)
                
                iL={'title': title,'sorttitle': '','plot': desc,'year':year,'duration':dur,'genre':genres,'country':countries,'mediatype':'movie'}#'director':directors,'cast':actors,
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
                url=build_url({'mode':'playReplay','chan':c,'code':codename})

                addItemList(url, titleToList, setArt, 'video', iL, False, 'true')
           
    elif c=='rm': #CF :-(
        url='https://www.radiomaryja.pl/wp-json/wp/v2/posts?categories=24&per_page=50'
        if p!=None:
            url+='&page='+p
            p='1'
        
        
        hea={
            'Referer':'https://www.radiomaryja.pl/',
            'Origin':'https://www.radiomaryja.pl',
            'connection':'keep-alive',
            'Accept-Encoding':'gzip, deflate, br',
            'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language':'pl,en-US;q=0.7,en;q=0.3',
            'Alt-Used':'www.radiomaryja.pl',
            'Sec-Fetch-Dest':'document',
            'Sec-Fetch-Mode':'navigate',
            'Sec-Fetch-Site':'none',
            'Sec-Fetch-User':'?1',
            'Upgrade-Insecure-Requests':'1',
            'Host':'www.radiomaryja.pl',
            'User-Agent':UA,
            'content-type':'application/json; charset=UTF-8'
        }

        resp = requests.get(url, headers=hea)#.json()

        for r in resp:
            title=r['rendered']['title']
            date,hour=r['date'].split('T')
            dh='[B]%s[/B] %s'%(date,hour[:-3])
            plot='[B]%s[/B]\n%s'%(title,dh)
            pid=str(r['id'])
            
            iL={'plot':plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultMusicSongs.png', 'fanart':''}
            url=build_url({'mode':'playReplay','chan':c,'code':pid})
            addItemList(url, title, setArt, 'video', iL, False, 'true')
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''}
        URL=build_url({'mode':'programList','chan':c,'page':str(int(p)+1)})
        addItemList(URL, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos') 
    xbmcplugin.endOfDirectory(addon_handle)
    
def ytWatch(v):
    stream_url=''
    url='https://www.youtube.com/watch?v='+v
    resp = urllib.request.urlopen(Request(url,headers=heaUA))
    rf = resp.read().decode('utf-8')
    u=re.compile('\"hlsManifestUrl\":\"([^\"]+?)\"').findall(rf)
    if len(u)>0:
        stream_url=u[0]
    if stream_url!='':
        heaPlay='User-Agent='+UA
        ISAplayer('hls',stream_url,heaPlay)
    else:
        xbmcgui.Dialog().notification('TV TRWAM', 'Brak transmisji', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem()) 

def yt(c):    
    liveList=[]
    stream_url=''
    
    '''Ze strony głównej'''
    url='https://youtube.com/channel/'+c
    resp = urllib.request.urlopen(Request(url,headers=heaUA))
    rf = resp.read().decode('utf-8')
    
    jsn=re.compile('ytInitialData = (.*);</script>').findall(rf)[0]
    j=json.loads(jsn)
    mainPageCat=j['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents']
    for m in mainPageCat:
        #if 'transmisje na żywo' in m['itemSectionRenderer']['contents'][0]['channelFeaturedContentRenderer']['title'][1]['text']:
        if 'channelFeaturedContentRenderer' in m['itemSectionRenderer']['contents'][0]:
            itemsList=m['itemSectionRenderer']['contents'][0]['channelFeaturedContentRenderer']['items']
            liveList=[]
            for i in itemsList:
                vidID=i['videoRenderer']['videoId']
                try:
                    countView=int(i['videoRenderer']['viewCountText']['runs'][0]['text'])
                except:
                    countView=0
                liveList.append([vidID,countView])
            #liveList=[[i['videoRenderer']['videoId'],int(i['videoRenderer']['viewCountText']['runs'][0]['text'])] for i in itemsList]
            if len(liveList)>0:
                def sortFN(i):
                    return i[1]
                liveList.sort(key=sortFN,reverse=True)    
            break
    if len(liveList)>0:
        url='https://www.youtube.com/watch?v='+liveList[0][0]
        resp = urllib.request.urlopen(Request(url,headers=heaUA))
        rf = resp.read().decode('utf-8')
        u=re.compile('\"hlsManifestUrl\":\"([^\"]+?)\"').findall(rf)
        if len(u)>0:
            stream_url=u[0]
    
    '''Z zakładki live'''
    if stream_url=='':
        url='https://youtube.com/channel/'+c+'/live'
        resp = urllib.request.urlopen(Request(url,headers=heaUA))
        rf = resp.read().decode('utf-8')
        u=re.compile('\"hlsManifestUrl\":\"([^\"]+?)\"').findall(rf)
        if len(u)>0:
            stream_url=u[0]
    if stream_url!='':
        heaPlay='User-Agent='+UA
        ISAplayer('hls',stream_url,heaPlay)
    else:
        xbmcgui.Dialog().notification('TV TRWAM', 'Brak transmisji', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def trwam(c,s=None,e=None):
    stream_url=''
    protocol=''
    url=apiURL+'v1/Player/AcquireContent'
    paramsPlay={
        'platformCodename':platform,
        'deviceKey':addon.getSetting('deviceKey'),
        'codename':c,
        't':str(time.time()*1000)    
    }
    resp=requests.get(url,headers=hea,params=paramsPlay).json()
    streams=[s['Url'] for s in resp['MediaFiles'][0]['Formats']]
    if len(streams)>0:
        stream_url=streams[0]
        if '.m3u' in stream_url:
            protocol='hls'
        elif '.mpd' in stream_url:
            protocol='mpd'
        else:
            protocol=None
    
        if protocol !=None:
            heaPlay=urlencode(hea)
    
    if stream_url !='' and protocol !='':
        if s!=None and e!=None:
            co=int(addon.getSetting('cuOffset'))
            ts=(datetime.datetime(*(time.strptime(s, "%Y-%m-%dT%H:%M:%S")[0:6]))+datetime.timedelta(hours=co)).strftime('%Y-%m-%dT%H:%M:%S')
            te=(datetime.datetime(*(time.strptime(e, "%Y-%m-%dT%H:%M:%S")[0:6]))+datetime.timedelta(hours=co)).strftime('%Y-%m-%dT%H:%M:%S')
            stream_url=stream_url.split('?')[0]+'?start=%s&end=%s'%(ts,te) #for catchup SC
        else:
            if len(stream_url.split('?'))==2:
                prms=dict(parse_qsl(stream_url.split('?')[1]))
                if 'start' in prms: 
                    start=prms['start']
                    new_start=(datetime.datetime(*(time.strptime(start,'%Y-%m-%dT%H:%M:%S')[0:6]))-datetime.timedelta(seconds=120)).strftime('%Y-%m-%dT%H:%M:%S')
                    prms['start']=new_start
                if 'end' in prms: 
                    end=prms['end']
                    new_end=(datetime.datetime(*(time.strptime(end,'%Y-%m-%dT%H:%M:%S')[0:6]))+datetime.timedelta(seconds=600)).strftime('%Y-%m-%dT%H:%M:%S')
                    prms['end']=new_end
                stream_url=stream_url.split('?')[0]+'?'+urlencode(prms)    
        
        ISAplayer(protocol,stream_url,heaPlay)
    else:
        if streams=='': 
            info='Brak źródła'
        elif protocol=='':
            info='Nieznany protokół strumienia'
        
        xbmcgui.Dialog().notification('TV TRWAM', info, xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
def ewtn():
    url='https://ewtn.pl/na-zywo/'
    resp=requests.get(url,headers=heaUA).text
    ifr=re.compile('<iframe[^>]+?src=\"([^\"]+?)\"').findall(resp)
    try:
        vidYT=re.compile('embed/(.*)\?').findall(ifr[0])[0]
        ytWatch(vidYT)   
    except:
        xbmcgui.Dialog().notification('TV TRWAM', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
def ewtnDir(c):
    stream_url=getS(c)
    heaPlay=urlencode(heaUA)
    ISAplayer('mpd',stream_url,heaPlay)
    
def repub():
    stream_url=getS('republika')
    heaPlay=urlencode(heaUA)
    ISAplayer('hls',stream_url,heaPlay)
 

def rm(c):
    url='https://www.radiomaryja.pl/wp-json/wp/v2/posts/'+c
    resp=requests.get(url,headers=heaUA).json()
    data=resp['content']['rendered']
    streams=re.compile('audio/mpeg\" src=\"([^"]+?)\"').findall(data)
    if len(streams)>0:
        stream_url=streams[0]+'|User-Agent='+UA
        directPlayer(stream_url)
    else:
        xbmcgui.Dialog().notification('TV TRWAM', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('TV TRWAM', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('TV TRWAM', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    for c in list(channels.keys()):
        cData=channels[c]
        name=cData[0]
        img=cData[2]
        cu=cData[3]
        cuTime=str(cData[4])
        if cu=='c':
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="TV TRWAM" catchup="append" catchup-source="&s={utc:Y-m-dTH:M:S}&e={utcend:Y-m-dTH:M:S}" catchup-days="%s",%s\nplugin://plugin.video.trwam?mode=playLive&chan=%s\n' %(name,img,cuTime,name,c)
        else:
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="TV TRWAM" ,%s\nplugin://plugin.video.trwam?mode=playLive&chan=%s\n' %(name,img,name,c)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('TV TRWAM', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('TV TRWAM', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)
  

mode = params.get('mode', None)

if not mode:

    if addon.getSetting('deviceKey')=='' or addon.getSetting('deviceKey')==None:
        addon.setSetting('deviceKey',code_gen(32))

    main_menu()
else:
    if mode=='live' or mode=='replay':
        tvList(mode)
    
    if mode=='playLive':
        chan=params.get('chan')
        if chan=='trwam':
            s=params.get('s')
            e=params.get('e')
            trwam(chCodes[0],s,e)
        elif chan=='ewtn' or chan=='ewtn24':
            ewtnDir(chan)
        elif chan=='republika':
            repub()
        elif chan=='wpolsce':
            yt('UCPiu4CZlknkTworskK79CPg')
        elif chan=='rm' or chan=='wnet':
            hp=urlencode(heaUA)
            directPlayer(getS(chan),hp)
    
    if mode=='calendar':
        chan=params.get('chan')
        calendar(chan)
    
    if mode=='programList':
        chan=params.get('chan')
        date=params.get('date')
        page=params.get('page')
        programList(chan,date,page)
        
    if mode=='playReplay':
        chan=params.get('chan')
        if chan=='trwam':
            code=params.get('code')
            trwam(code)
        elif chan=='rm':
            code=params.get('code')
            rm(code)
            
        
    if mode=='listM3U':
        listM3U()#
        