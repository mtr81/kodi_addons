# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
import json
#import random
import time
import datetime
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.parlament')
PATH=addon.getAddonInfo('path')
img_path=PATH+'/resources/img/'
img_empty=img_path+'empty.png'
fanart=img_path+'fanart.jpg'
mainIcon=PATH+'icon.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0'
hea={
    'User-Agent':UA,
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)
    
def ISAplayer(protocol,stream_url):
    import inputstreamhelper
    
    PROTOCOL = protocol
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)                     
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)        
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)        
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA) 
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(stream_url) :
    stream_url+='|User-Agent='+UA
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def main_menu():
    menu=[
        ['SEJM','sejmCateg','sejm.png'],
        ['SENAT','senatCateg','senat.png']
    ]
    
    for m in menu:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_path+m[2], 'fanart':fanart}
        url = build_url({'mode':m[1]})
        addItemList(url, m[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def sejmCateg():
    categs=[
        ['TRANSMISJE','trans'],
        ['ARCHIWUM - X kadencja','arch10'],
        ['ARCHIWUM - IX kadencja','arch9'],
    ]
    
    for c in categs:
        setArt={'thumb': '', 'poster': img_path+'sejm.png', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
        url = build_url({'mode':'sejmSubcategs','categ':c[1]})
        addItemList(url, c[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def sejmSubcategs(c):
    items=[
        ['Wszystkie',''],
        ['Posiedzenie sejmu','posiedzenie'],
        ['Posiedzenia komisji','komisja'],
        ['Posiedzenia podkomisji','podkomisja'],
        ['Konferencje','konferencja'],
        ['Inne','inne']
    ]
    
    if c=='trans':
        k='10'
    else:
        k=c.replace('arch','')
        c='arch'
        items.append(['Wyszukiwarka','search'])
    
    for i in items:
        icon='OverlayUnwatched.png' if i[1]!='search' else 'DefaultAddonsSearch.png'
        setArt={'thumb': '', 'poster': img_path+'sejm.png', 'banner': '', 'icon': icon, 'fanart':fanart}
        url = build_url({'mode':'sejmItemsList','categ':c,'subcateg':i[1],'page':'1','kad':k})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)


def itemList(j,k):
    jl=json.loads(j)
    if 'params' in jl: #manifest mpd/hls
        params=jl['params']
        
        icon='DefaultTVShows.png' if jl['status']=='VIDEO_PLAYING' else 'DefaultAddonVideo.png'
        unid=jl['unid']
        srcType='hls'
        

    elif jl['videoFile'] !='': #plik mp4
        unid=jl['videoFile']
        srcType='mp4'
        icon='DefaultAddonVideo.png'
        
    desc=unescape(jl['desc']).replace('<br/>','\n') #przedmiot posiedzenia
    title=jl['title'] #np. rodzaj komisji
    try:
        plot='[B]'+title+'[/B]\n'+desc+'\n'+'[B]Rozpoczęcie: [/B]'+params['start']+'\n'+'[B]Zakończenie: [/B]'+params['stop']
        TITLE=title + ' | ' + params['start']
    except:
        plot='[B]'+title+'[/B]\n'+desc+'\n'+'[B]Rozpoczęcie: [/B]'+jl['start']+'\n'+'[B]Zakończenie: [/B]-'
        TITLE=title + ' | ' + jl['start']
    
    iL={'title': TITLE,'sorttitle': TITLE,'plot': plot}
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': icon, 'fanart':fanart}
    url = build_url({'mode':'sejmPlay','link':unid,'srcType':srcType,'kad':k})
    addItemList(url, TITLE, setArt, 'video', iL, False, 'true')
    
def sejmItemsList(c,s,p,k,y):
    s='' if s==None else s
    y='' if y==None else y   
        
    if c=='trans':
        url='https://sejm.gov.pl/Sejm'+k+'.nsf/transmisje.xsp#'
    else:
        url='https://sejm.gov.pl/Sejm'+k+'.nsf/transmisje_arch.xsp?page='+str(p)
        if s!='':
            url+='&type='+s
        if y!='':
            url+='&rok='+y

    resp=requests.get(url,headers=hea).text
    resp1=''
    if c=='trans':
        try:
            tr_block=resp.split('listaTransmisji')[1].split('</ul>')[0]
            tr=tr_block.split('</li>')
            for t in tr:
                if s!='':
                    if 'class=\"'+s+'\"' in t:
                        resp1 +=t
                else:
                    resp1 +=t
        except:
            pass
    else:
        resp1=resp
    
    jsn=re.compile('json hidden\">([^<]+?)<').findall(resp1)
    for j in jsn:
        itemList(j,k)

    if  c=='arch': # sprawdzić czy transmisje nie mają stron 
        if 'aria-label=\"Nast&#281;pna strona\"' in resp:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
            url = build_url({'mode':'sejmItemsList','categ':c,'subcateg':s,'page':str(int(p)+1),'kad':k,'year':y})
            addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/B][/COLOR]', setArt)
        else:
            def getYear(y,years,k):
                i=years[k].index(y)
                result=years[k][i+1] if i+1<=len(years[k])-1 else None
                return result
            
            years={'10':['2023'],'9':['2022','2021','2020','2019']}
            year=years[k][0] if y=='' else getYear(y,years,k)
            if year!=None:
                setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart':fanart}
                url = build_url({'mode':'sejmItemsList','categ':c,'subcateg':s,'page':'1','kad':k,'year':year})
                addItemList(url, 'Rok [B]%s[/B]'%(year), setArt)
                
                
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)


def dateToTmp(x): #2024-06-10 09:59:38
    return str(int(datetime.datetime(*(time.strptime(x, "%Y-%m-%d %H:%M:%S")[0:6])).timestamp()*1000))
    

def sejmPlay(u,st,k):
    stream_url=''
    if st=='mp4':
        stream_url='https://itv.sejm.gov.pl/kadencja'+k+'/mp4/'+u+'.mp4'
        directPlayer(stream_url)
    elif st=='hls':
        url='https://sejm.gov.pl/Sejm'+k+'.nsf/VideoFrame.xsp/'+u
        resp=requests.get(url,headers=hea).text
        baseStream=re.compile('api_url: \"([^"]+?)\"').findall(resp)[0]
        camera=re.compile('cameras: \[([^]]+?)\]').findall(resp)[0]
        camera=eval('[%s]'%(camera))[0]
        period=re.compile('timeShift: {([^}]+?)}').findall(resp)[0]
        
        if 'blueonline' in baseStream:
            stream_url=baseStream+'/stream/'+camera+'/'+u+'/manifest.mpd'
            if 'start' in period:
                start=re.compile('start: \"([^"]+?)\"').findall(period)
                if len(start)>0:
                    stream_url+='?start='+dateToTmp(start[0])
            if 'stop' in period:
                stop=re.compile('stop: \"([^"]+?)\"').findall(period)
                if len(stop)>0:
                    stream_url+='&stop='+dateToTmp(stop[0])
        
        if stream_url!='':
            ISAplayer('mpd',stream_url)
        else:
            xbmcgui.Dialog().notification('Parlament', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            

def searchSejm(s,p,k):
    filtry=eval(addon.getSetting('filtry'))
    filters=[
        ['Dowolne słowa','phrase'],
        ['Typ transmisji','trType'],
        ['Data (od)','since'],
        ['Data (do)','till']
    ]
    for f in filters:
        fLabel='[B]%s[/B]: %s'%(f[0],filtry[f[1]])
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultTags.png', 'fanart':fanart}
        url = build_url({'mode':'filtersSejm','type':f[1]})
        addItemList(url, fLabel, setArt, isF=False)
    
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
    url = build_url({'mode':'searchResultSejm', 'kad':k, 'page':p })
    addItemList(url, '[B][COLOR=yellow]>>> SZUKAJ[/COLOR][/B]', setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def filtersSejm(t):
    def dateVerify(s):
        res=False
        try:
            d=datetime.datetime(*(time.strptime(s, "%Y-%m-%d")[0:6])).timestamp()
            res=True if d<time.time() else False
        except:
            pass
        return res
    
    filtry=eval(addon.getSetting('filtry'))
    if t=='phrase':
        p=xbmcgui.Dialog().input(u'Szukaj, Fraza:', type=xbmcgui.INPUT_ALPHANUM)
        if p:
            filtry['phrase']=p
    
    elif t=='trType':
        types=['wszystkie','posiedzenia Sejmu','posiedzenia komisji','posiedzenia podkomisji','konferencje prasowe','brefingi Marszałka Sejmu']
        select=xbmcgui.Dialog().select('Typ transmisji', types)
        if select > -1:
            filtry['trType']=types[select]
    
    elif t=='since':
        p=xbmcgui.Dialog().input(u'Szukaj, Data (od) w formacie yyyy-mm-dd:', type=xbmcgui.INPUT_ALPHANUM)
        if p and dateVerify(p):
            filtry['since']=p
    
    elif t=='till':
        p=xbmcgui.Dialog().input(u'Szukaj, Data (do) w formacie yyyy-mm-dd:', type=xbmcgui.INPUT_ALPHANUM)
        if p and dateVerify(p):
            filtry['till']=p
        
    addon.setSetting('filtry',str(filtry))
    xbmc.executebuiltin('Container.Refresh')

def searchResultSejm(k,p,sess,sessID):
    filtry=eval(addon.getSetting('filtry'))
    url='https://sejm.gov.pl/Sejm'+k+'.nsf/transmisje_arch.xsp?view=S'
    if sess==None and sessID==None:
        resp=requests.get(url,headers=hea).text
        sess=re.compile('id1__VUID\" value=\"([^"]+?)\"').findall(resp)[0]
        sessID=re.compile('SessionID=([^"]+?)\"').findall(resp)[0]
    dateFil='='
    if filtry['since']!='' and filtry['till']!='':
        dateFil='<>'
    elif filtry['since']!='' and filtry['till']=='':
        dateFil='>'
    elif filtry['since']=='' and filtry['till']!='':
        dateFil='<'
    types={'wszystkie':'','posiedzenia Sejmu':'posiedzenia','posiedzenia komisji':'komisje','posiedzenia podkomisji':'podkomisje','konferencje prasowe':'konferencje','brefingi Marszałka Sejmu':'brifingi'}
    trType='' if filtry['trType']=='' else types[filtry['trType']]
    ids={'10':['_id99:_id100:_id103','_id99:_id100:_id138'],'9':['_id100:_id101:_id104','_id100:_id101:_id139']}
    files={
        'view:_id1:_id2:facetMain:'+ids[k][0]+':edtSearch': (None, filtry['phrase']),#phrase
        'view:_id1:_id2:facetMain:'+ids[k][0]+':cusTransmRodzaj': (None, trType),#type
        'view:_id1:_id2:facetMain:'+ids[k][0]+':cdrData:cbData': (None, dateFil),#
        'view:_id1:_id2:facetMain:'+ids[k][0]+':cdrData:dtpData1': (None, filtry['since']),#since
        'view:_id1:_id2:facetMain:'+ids[k][0]+':cdrData:dtpData2': (None, filtry['till']),#till
        '$$viewid': (None, sess),
        '$$xspsubmitid': (None, 'view:_id1:_id2:facetMain:'+ids[k][1]),
        '$$xspexecid': (None, ''),
        '$$xspsubmitvalue': (None, ''),
        '$$xspsubmitscroll': (None, '0|0'),
        'view:_id1': (None, 'view:_id1'),
    }
    if p!='1':
        url+='&page='+p
    hea.update({'referer':url})
    cookies={'SessionID':sessID}
    resp=requests.post(url,headers=hea,cookies=cookies,files=files).text
    jsn=re.compile('json hidden\">([^<]+?)<').findall(resp)
    for j in jsn:
        itemList(j,k)
    
    if 'page='+str(int(p)+1) in resp:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'searchResultSejm', 'kad':k, 'page':str(int(p)+1),'sess':sess,'sessID':sessID })
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/B][/COLOR]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')   
    xbmcplugin.endOfDirectory(addon_handle)

#SENAT    
def senatCateg():
    categs=[
        ['TRANSMISJE','trans'],
        ['ARCHIWUM','arch'],
    ]
    
    for c in categs:
        setArt={'thumb': '', 'poster': img_path+'senat.png', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
        url = build_url({'mode':'senatItemsList','categ':c[1]})
        addItemList(url, c[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def senatItemsList(c):
    if c=='trans':
        url='https://senat.atmitv.pl/SenatConsole/TransmissionList.go'
        icon='DefaultTVShows.png'
    elif c=='arch':
        url='https://senat.atmitv.pl/SenatConsole/TransmissionHotList.go'
        icon='DefaultAddonVideo.png'
    hea={
        'User-Agent':UA,
    }
    resp=requests.get(url,headers=hea).text
    resp=resp.replace('\n','').replace('\t','').replace('\r','')
    trList=re.compile('<a href=\"([^"]+?)\">([^<]+?)</a').findall(resp)
    for t in trList:
        if 'http' in t[0]:
            iL={'plot': t[1]}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': icon, 'fanart':fanart}
            url = build_url({'mode':'senatPlay','link':t[0],'categ':c})
            addItemList(url, t[1], setArt, 'video', iL, False, 'true')
    
    if c=='arch':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)

def senatPlay(l,c):
    if c=='trans':
        url=l.replace('.pl','.pl/senat-console/side-menu/transmissions')+'/live/player-configuration'
    elif c=='arch':
        url=l.replace('.pl','.pl/senat-console/side-menu/transmissions')+'/vod/player-configuration'
    hea={
        'User-Agent':UA,
    }
    resp=requests.get(url,headers=hea).json()
    url_stream=resp['player']['playlist']['dash']
    if not url_stream.startswith('http'):
        url_stream='https:'+ url_stream
        
    if c=='arch':
        urlVOD=url.replace('/player-configuration','')
        resp=requests.get(urlVOD,headers=hea).json()
        corr=978307200000
        t_start=resp['since']-corr
        t_stop=resp['till']-corr
        url_stream +='&startTime='+str(t_start)+'&stopTime='+str(t_stop)
        
    ISAplayer('mpd',url_stream)

        
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='sejmCateg':
        sejmCateg()
    
    if mode=='sejmSubcategs':
        c=params.get('categ')
        addon.setSetting('filtry',str({'phrase':'','trType':'','since':'','till':''}))
        sejmSubcategs(c)
    
    if mode=='sejmItemsList':
        c=params.get('categ')
        s=params.get('subcateg')
        p=params.get('page')
        k=params.get('kad')
        y=params.get('year')
        if s=='search':
            searchSejm(s,p,k)
        else:
            sejmItemsList(c,s,p,k,y)
    
    if mode=='filtersSejm':
        t=params.get('type')
        filtersSejm(t)
    
    if mode=='searchResultSejm':
        p=params.get('page')
        k=params.get('kad')
        sess=params.get('sess')
        sessID=params.get('sessID')
        searchResultSejm(k,p,sess,sessID)
    
    if mode=='sejmPlay':
        link=params.get('link')
        st=params.get('srcType')
        k=params.get('kad')
        sejmPlay(link,st,k)
        
    if mode=='senatCateg':
        senatCateg()
    if mode=='senatItemsList':
        c=params.get('categ')
        senatItemsList(c)
    if mode=='senatPlay':
        link=params.get('link')
        c=params.get('categ')
        senatPlay(link,c)
        