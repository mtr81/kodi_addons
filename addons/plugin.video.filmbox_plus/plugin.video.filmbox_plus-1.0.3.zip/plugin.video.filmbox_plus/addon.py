# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from hashlib import sha256
import hmac
import codecs
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmbox_plus')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_path=PATH+'/resources/img/'
fanart=img_path+'fanart.jpg'
img_empty=img_path+'empty.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:130.0) Gecko/20100101 Firefox/146.0'
baseurl='https://play.filmboxplus.com/'
apiURL='https://tvapi-hlm2.solocoo.tv/'
appVer='12.8'

def heaGen():
    HEA={
        'Referer':baseurl,
        'Origin':baseurl[:-1],
        'User-Agent':UA,
        'Content-Type':'application/json',
    }
    if addon.getSetting('logged')=='true':
        HEA['Authorization']='Bearer '+addon.getSetting('token')
    return HEA

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def directPlayer(stream_url):
    heaPlay={
        'User-Agent':UA,
        'Referer':baseurl,
        'Origin':baseurl[:-1],
    }
    hp='&'.join([k+'='+heaPlay[k] for k in heaPlay])
    stream_url+='|'+hp
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def ISAplayer(protocol,stream_url, isDRM=False, licURL=False, drm_cfg=None, cert=None):
    heaPlay={
        'User-Agent':UA,
        'Referer':baseurl,
        'Origin':baseurl[:-1],
    }
    hp='&'.join([k+'='+heaPlay[k] for k in heaPlay])
    import inputstreamhelper
    
    PROTOCOL = protocol
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)                     
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)        
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', hp)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hp)
        if isDRM:
            kodiVer=xbmc.getInfoLabel('System.BuildVersion')
            if not kodiVer.startswith('22.'):
                play_item.setProperty('inputstream.adaptive.license_type', DRM)
                play_item.setProperty('inputstream.adaptive.license_key', licURL)
                if cert!=None:
                    play_item.setProperty('inputstream.adaptive.server_certificate', cert)
            else:
                play_item.setProperty("inputstream.adaptive.drm", json.dumps(drm_cfg))

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def fromStrToDate(s,f):
    d=datetime.datetime(*(time.strptime(s,f)[0:6]))
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    dl=d-datetime.timedelta(seconds=offset)
    return dl
    
def fromDateToStr(d,f):
    return d.strftime(f)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def getProvision():#
    url=apiURL+'v1/provision'
    data={
        "appVersion": appVer,
        "brand": "flb",
        "deviceModel": "Firefox",
        "deviceOem": "Firefox",
        "devicePrettyName": "Firefox 146.0",
        "deviceSerial": addon.getSetting('d_id'),
        "deviceType": "ConnectedTV", #PC
        "featureLevel": 6,
        "language": "en_US",
        "osVersion": "Windows 10"
    }
    h=heaGen()
    if 'Authorization' in h:
        del h['Authorization']
    resp=requests.post(url,headers=h,json=data).json()
    if 'session' in resp:
        tkn=resp['session']['provisionData']
    else:
        tkn=None
    return tkn

def getSession(p,t):#
    url=apiURL+'v1/session'
    data={
        "appVersion": appVer,
        "brand": "flb",
        "deviceModel": "Firefox",
        "deviceOem": "Firefox",
        "devicePrettyName": "Firefox 146.0",
        "deviceSerial": addon.getSetting('d_id'),
        "deviceType": "ConnectedTV", #PC
        "featureLevel": 6,
        "language": "pl_PL",
        "memberId": "0",
        "osVersion": "Windows 10",
        "provisionData": p,
        "ssoToken":t 
    }
    h=heaGen()
    if 'Authorization' in h:
        del h['Authorization']
    resp=requests.post(url,headers=h,json=data).json()
    
    return resp
    
def refreshToken(t):#
    p=getProvision()
    if p!=None:
        ssoToken=addon.getSetting('ssoToken')
        resp=getSession(p,ssoToken)
        if 'token' in resp:
            addon.setSetting('token',resp['token'])
            addon.setSetting('ssoToken',resp['ssoToken'])
            addon.setSetting('tokenExp',str(int(t)+30*60-1))
            xbmc.log('@@@refreshToken: Odświeżono token', level=xbmc.LOGINFO)
        else:
            xbmc.log('@@@refreshToken: '+str(resp), level=xbmc.LOGINFO)
            para_logout()
    else:
        xbmc.log('@@@refreshToken: brak provisionData', level=xbmc.LOGINFO)
        para_logout()

def req(t,u,h,d={},p={}):#
    now=int(time.time())
    tokenExp=addon.getSetting('tokenExp')
    if now>int(tokenExp):
        refreshToken(str(now))
        h=heaGen()
    if t=='get':
        resp=requests.get(u,headers=h,params=p)
        #print(resp.json())
    elif t=='post':
        resp=requests.post(u,headers=h,params=p,json=d)
    return resp.json()

def transl():#
    tmp_transl=addon.getSetting('tmp_transl')
    tmp_transl=0 if tmp_transl=='' else int(tmp_transl)
    now=int(time.time())
    if now-tmp_transl>=60*60:
        url='https://flbstatic.solocoo.tv/translations/tvapi-pl_PL.json'
        h=heaGen()
        if 'Authorization' in h:
            del h['Authorization']
        resp=requests.get(url,headers=h).json()
        saveF(PATH_profile+'transl.txt',str(resp))
        addon.setSetting('tmp_transl',str(now))

def main_menu():#

    items=[]
    if addon.getSetting('logged')=='true':
        items=[
            ['Filmy','movies','DefaultAddonVideo.png'],
            ['Seriale','series','DefaultAddonVideo.png'],
            ['TV','tv','DefaultTVShows.png'],
            ['Strona główna','home','DefaultTags.png'],
            ['Wyszukiwarka','search','DefaultAddonsSearch.png'],
            ['Ulubione','favList','DefaultPlaylist.png'],
            ['Wyloguj','logOut','DefaultUser.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','DefaultUser.png']
        ]
    for i in items:
        isF=False if i[1] in ['search','logIn','logOut'] else True
        setArt={'icon': i[2]}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt, isF=isF)
    xbmcplugin.endOfDirectory(addon_handle)

def getImage(x):#helper
    images=[i['url'] for i in x if i['type']=='la']
    if len(images)>0:
        img=images[0]
    else:
        img=PATH+'/icon.png'
    return img

def tv():#
    url=apiURL+'v1/bouquet'
    resp=req('get',url,heaGen())
    for r in resp['channels']:
        data=r['assetInfo']
        if data['type']=='Channel':
            name=data['title']
            img=getImage(data['images'])
            cid=data['id']
            
            cmItems=[('[B]EPG[/B]','RunPlugin(plugin://plugin.video.filmbox_plus?mode=epg&cid='+cid+')')]
            
            iL={'plot':name}
            URL=build_url({'mode':'playTV','cid':cid})
            setArt={'thumb': img ,'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            addItemList(URL, name, setArt, 'video', iL, False, 'true', True, cmItems)
        
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)

def epg(cid):
    url=apiURL+'v1/schedule'
    paramsURL={
        'channels':cid,
    }
    
    dateNow=datetime.datetime.now(datetime.timezone.utc)
    dateStart=dateNow-datetime.timedelta(hours=2)
    dateEnd=dateNow+datetime.timedelta(hours=12)
    paramsURL['from']=fromDateToStr(dateStart,'%Y-%m-%dT%H:00:00.000Z')
    paramsURL['until']=fromDateToStr(dateEnd,'%Y-%m-%dT%H:00:00.000Z')
    
    resp=req('get',url,heaGen(),p=paramsURL)

    epg=''
    if 'epg' in resp:
        for r in resp['epg'][cid]:
            title=r['title']
            genres=[g['title'] for g in r['params']['genres']]
            if len(genres)>0:
                title+= ' [I](%s)[/I]'%(', '.join(genres))
            ts=fromDateToStr(fromStrToDate(r['params']['start'],'%Y-%m-%dT%H:%M:%SZ'),'%H:%M')
            te=fromDateToStr(fromStrToDate(r['params']['end'],'%Y-%m-%dT%H:%M:%SZ'),'%H:%M')
            
            if datetime.datetime.now()<fromStrToDate(r['params']['end'],'%Y-%m-%dT%H:%M:%SZ'):
                epg+='[B]%s - %s[/B] %s\n'%(ts,te,title)
    
    plot=epg if epg!='' else 'Brak danych EPG'
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('EPG', plot)
    
def playVid(vid,trailer=False):#
    type='trailer' if trailer else 'play'
    url=apiURL+'v1/assets/'+vid+'/'+type
    data={
        "player": {
            "capabilities": {
                "drmSystems": [
                    "Widevine"
                ],
                "embeddedSubtitles": True,
                "mediaTypes": [
                    "DASH"
                ],
                "smartLib": True
            },
            "name": "RxPlayer",
            "version": "4.2.0-dev.2024081400"
        }
    }
    resp=req('post',url,heaGen(),data)
    if 'url' in resp:
        url_stream=resp['url']#+'&response=200&bk-ml=1'
        '''
        h=heaGen()
        del h['Authorization']
        resp_m=requests.get(url_stream,headers=h)
        url_stream=resp_m.headers['location']+'&bk-ml=2.0'
        '''
        licurl=resp['drm']['licenseUrl']
        #cert=resp['drm']['cert']
        healic={
            'User-Agent':UA,
            'Origin':baseurl[:-1],
            'Referer':baseurl,
            'Content-Type':'application/octet-stream',
            'Accept-Encoding':'gzip, deflate, br, zstd',
            'Connection':'Keep-Alive',
        }
        #K21
        lickey='%s|%s|R{SSM}|'%(licurl,urlencode(healic))
        #K22
        drm_config= {
            "com.widevine.alpha": {
                "license": {
                    "server_url": licurl,
                    "req_headers": healic
                }
            }
        }
        ISAplayer('mpd',url_stream,True,lickey,drm_config)
    else:
        xbmc.log('@@@playTest '+str(resp) , level=xbmc.LOGINFO)
        xbmcgui.Dialog().notification('Filmbox+', 'Brak dostępu: '+str(resp), xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
 
def selectGenre(t):#helper
    gid=addon.getSetting('genre_'+t)
    gid=gid if gid!='' else 'All|sg.ui.genre.all'
    ct='noseries' if t=='movie' else 'series'
    url=apiURL+'v1/collections/videos,%s,owner,filmboxpl?group=allandgenre&sort=title'%(ct)
    resp=req('get',url,heaGen())
    translat=eval(openF(PATH_profile+'transl.txt'))
    labsT=[translat[i['label']] for i in resp['collection']]
    labs=[i['label'] for i in resp['collection']]
    gids=[i['key'] for i in resp['collection']]
    select=xbmcgui.Dialog().select('Kategoria:', labsT)
    if select>-1:
        new_gid='%s|%s'%(gids[select],labs[select])
    else:
        new_gid=gid
    
    if new_gid!=gid:
        addon.setSetting('genre_'+t,new_gid)
        xbmc.executebuiltin('Container.Refresh()')

sortType={'newest':'Ostatnio dodane','title':'A-Z'}
        
def selectSortType(t):#helper
    sid=addon.getSetting('sort_'+t)
    sid=sid if sid!='' else 'newest'

    labs=[sortType[i] for i in sortType]
    sids=[i for i in sortType]
    select=xbmcgui.Dialog().select('Typ sortowania:', labs)
    if select>-1:
        new_sid=sids[select]
    else:
        new_sid=sid
    
    if new_sid!=sid:
        addon.setSetting('sort_'+t,new_sid)
        xbmc.executebuiltin('Container.Refresh()')

def contDetail(r,translat,ep=False): #helper
    title=r['title']
    desc=r['desc'] if 'desc' in r else ''    
    
    det=r['params']
    dur=det['duration'] if 'duration' in det else 0
    year=det['year'] if 'year' in det else 0
    mpaa=str(det['age']) if 'age' in det else ''
    if 'credits' in det:
        cast=[c['person'] for c in det['credits'] if c['role']=='Actor']
        dir=[c['person'] for c in det['credits'] if c['role']=='Director']
    else:
        cast=[]
        dir=[]
    
    genres=[translat[g['label']] for g in det['genres']] if 'genres' in det else []
    if desc=='':
        ' | '.join(genres)
    
    try:
        availTill=fromDateToStr(fromStrToDate(r['deals'][0]['end'],'%Y-%m-%dT%H:%M:%SZ'),'%Y-%m-%d %H:%M')
        availSinceDate=fromStrToDate(r['deals'][0]['start'],'%Y-%m-%dT%H:%M:%SZ')
        availSince=fromDateToStr(availSinceDate,'%Y-%m-%d %H:%M')
        now=datetime.datetime.now()
        if availSinceDate>now:
            desc='[B]Dostępny od[/B]: [COLOR=yellow]%s[/COLOR]\n%s'%(availSince,desc)
        else:
            desc='[B]Dostępny do[/B]: %s\n%s'%(availTill,desc)
    except:
        pass
    
    if ep:
        e='S%sE%s' %(det['seriesSeason'],str(det['seriesEpisode']))
        title='%s | %s'%(e,title)
    
    iL={'title':title,'plot':desc,'duration':dur,'year':year,'mpaa':mpaa,'cast':cast,'director':dir,'genre':genres}
    type=r['type']
    if type=='VOD':
        iL['mediatype']='movie'
    elif type=='VODSeries':
        iL['mediatype']='tvshow'
    
    if ep:
        iL['mediatype']='episode'
        iL['season']=int(det['seriesSeason'])
        iL['episode']=det['seriesEpisode']
        
    return iL
        

def addItem(r,tr,ep=False): #helper
    cid=r['id']
    iL=contDetail(r,tr,ep)
    title=iL['title']
    img=getImage(r['images'])
    if 'icon.png' not in img:
        img+='&w=464&h=261'
    type=r['type']
    
    if type=='VOD':
        isF=False
       
        availSinceDate=fromStrToDate(r['deals'][0]['start'],'%Y-%m-%dT%H:%M:%SZ')
        now=datetime.datetime.now()
        if availSinceDate>now:
            isP='false'
            url=build_url({'mode':'noPlay'})
        else:
            isP='true'
            url=build_url({'mode':'playVid','vid':cid})
        
    elif type=='VODSeries':
        isF=True
        isP='false'
        url=build_url({'mode':'seasList','sid':cid})
        
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
    
    cmItems=[
        ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.filmbox_plus?mode=favAdd&url='+quote(url)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&art='+quote(str(setArt))+')'),
        ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.filmbox_plus?mode=getDetails&cid='+cid+'&ct='+type+')')
    ]
    if type=='VOD' and not ep:
        cmItems.append(
            ('[B]Trailer[/B]','PlayMedia(plugin://plugin.video.filmbox_plus?mode=trailer&cid='+cid+')')
        )
   
    addItemList(url, title, setArt, 'video', iL, isF, isP, True, cmItems)


def contList(t,p=None):#
    translat=eval(openF(PATH_profile+'transl.txt'))
    
    genre=addon.getSetting('genre_'+t)
    genre=genre if genre!='' else 'All|sg.ui.genre.all'
    sort=addon.getSetting('sort_'+t)
    sort=sort if sort!='' else 'newest'

    if p==None:
        title='[B]Kategoria: [/B] [COLOR=cyan]%s[/COLOR]'%(translat[genre.split('|')[1]])
        img='DefaultGenres.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url=build_url({'mode':'selectGenre','type':t})
        addItemList(url, title, setArt, isF=False, isPla='false')
        
        title='[B]Sortowanie: [/B] [COLOR=cyan]%s[/COLOR]'%(sortType[sort])
        img='DefaultGenres.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url=build_url({'mode':'selectSortType','type':t})
        addItemList(url, title, setArt, isF=False, isPla='false')
        
    url=apiURL+'v1/assets'
    ct='noseries' if t=='movies' else 'series'
    queryParams=['videos',ct]
    if genre!='All|sg.ui.genre.all':
        queryParams.append('categoryb64')
        queryParams.append(base64.b64encode(genre.split('|')[0].encode()).decode())
    queryParams.append('owners')
    queryParams.append('filmboxpl')
    paramsURL={
        'query':','.join(queryParams),
        'limit':'100',
        'sort':sort
    }
    if p!=None:
        paramsURL['from']=p
    
    resp=req('get',url,heaGen(),p=paramsURL)
    if 'assets' in resp:
        for r in resp['assets']:
            addItem(r,translat)
            
    if 'nextAsset' in resp:
        if resp['nextAsset']!=None:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': fanart}
            url=build_url({'mode':'contList','type':t,'page':resp['nextAsset']})
            addItemList(url, '[COLOR=cyan][B]>>> następna strona[/B][/COLOR]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def getDetails(cid,t):
    url=apiURL+'v1/assets/'+cid
    resp=req('get',url,heaGen())
    
    translat=eval(openF(PATH_profile+'transl.txt'))
    det=contDetail(resp,translat)
    #print(det)
    plot='[B]%s[/B]\n'%(det['title'])
    ct='FILM' if t=='VOD' else 'SERIAL'
    plot+='[COLOR=yellow]%s[/COLOR]\n\n'%(ct)
    if det['year']!=0:
        plot+='[B]Rok prod.:[/B] %s\n'%(str(det['year']))
    if len(det['cast'])>0:
        plot+='[B]Gatunek:[/B] %s\n'%(', '.join(det['genre']))
    if len(det['cast'])>0:
        plot+='[B]Obsada:[/B] %s\n'%(', '.join(det['cast']))
    if len(det['director'])>0:
        plot+='[B]Reżyseria:[/B] %s\n'%(', '.join(det['director']))
    if det['duration']!=0:
        plot+='[B]Czas:[/B] %s min.\n'%(str(int(det['duration']/60)))
    
    plot+=det['plot']
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)
    
def seasList(sid):
    url=apiURL+'v1/collections/episodes?group=default&sort=default&asset='+sid
    resp=req('get',url,heaGen())
    for r in resp['collection']:
        cid=r['query']
        seasData=r['metadata']
        title=seasData['longTitle']
        desc=seasData['desc']
        img=getImage(seasData['images'])
        if 'icon.png' not in img:
            img+='&w=464&h=261'
        
        iL={'plot':desc}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url=build_url({'mode':'epList','cid':cid})
        addItemList(url, title, setArt,'video', iL)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def epList(cid,p):
    translat=eval(openF(PATH_profile+'transl.txt'))
    
    url=apiURL+'v1/assets'
    paramsURL={
        'query':cid,
        'sort':'seasonepisode',
        'limit':'50'
    }
    if p!=None:
        paramsURL['from']=p
    resp=req('get',url,heaGen(),p=paramsURL)
    if 'assets' in resp:
        for r in resp['assets']:
            addItem(r,translat,True)
        

    if 'nextAsset' in resp:
        if resp['nextAsset']!=None:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': fanart}
            url=build_url({'mode':'epList','cid':cid,'page':resp['nextAsset']})
            addItemList(url, '[COLOR=cyan][B]>>> następna strona[/B][/COLOR]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def searchRes(q,p):
    translat=eval(openF(PATH_profile+'transl.txt'))
    
    url=apiURL+'v1/search?query='+quote(q)
    '''
    if p!=None:
        url+='&from='+p
    '''
    resp=req('get',url,heaGen())
    if 'collection' in resp:
        data=[c for c in resp['collection'] if c['label']=='sg.ui.search.vod']
        if len(data)>0:
            if 'assets' in data[0]:
                for r in data[0]['assets']:
                    addItem(r,translat)
                    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def browser(c):
    url=apiURL+'v1/discovery/'+c
    resp=req('get',url,heaGen())
    if 'rows' in resp:
        for r in resp['rows']:
            if r['type']=='OnDemand':
                title=r['title']
                q=r['query']
                img='DefaultAddonVideo.png'
                
                setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': fanart}
                url=build_url({'mode':'brContList','q':q})
                addItemList(url, title, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def brContList(q,p):
    translat=eval(openF(PATH_profile+'transl.txt'))
    
    url=apiURL+'v1/assets'
    paramsURL={
        'query':q,
        'limit':'50'
    }
    if p!=None:
        paramsURL['from']=p
    resp=req('get',url,heaGen(),p=paramsURL)
    if 'assets' in resp:
        for r in resp['assets']:
            addItem(r,translat)
            
    if 'nextAsset' in resp:
        if resp['nextAsset']!=None:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': fanart}
            url=build_url({'mode':'brContList','q':q,'page':resp['nextAsset']})
            addItemList(url, '[COLOR=cyan][B]>>> następna strona[/B][/COLOR]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)


def auth_hea(data):
    def ct(x):
        y=x.replace('+','-').replace('/', '_')
        z=re.sub('[=]+?$','',y)
        return z

    def ct2(x):
        return x.replace('-','+').replace('_', '/')

    def hash_sha256(x):
        return base64.b64encode(sha256(x.encode('utf-8')).digest()).decode()
        
    def sign_hmac(key, to_sign):
        signed_hmac_sha256 = hmac.HMAC(key, to_sign.encode(), sha256)
        digest = signed_hmac_sha256.digest()
        return base64.b64encode(digest).decode()
        
    data_str=json.dumps(data)#.replace(' ','')
    #print(data_str)

    data_hash=hash_sha256(data_str)
    data_hash_cl=ct(data_hash)
    #print(data_hash_cl)

    u='https://flb.login.solocoo.tv/login'
    t=str(int(time.time()))#'1729722787' #10digit
    d=u+data_hash_cl+t
    #print(d)

    sec='OXh0-pIwu3gEXz1UiJtqLPscZQot3a0q'
    sec_cl=ct2(sec)
    #print(sec_cl)

    sign=ct(sign_hmac(base64.b64decode(sec_cl.encode()), d))
    #print(sign)

    return "Client key=web.NhFyz4KsZ54,time=%s,sig=%s"%(t,sign)

def logIn():#
    def er():
        xbmcgui.Dialog().notification('Filmbox+', 'Błąd logowania - szczegóły w logu', xbmcgui.NOTIFICATION_INFO)
    
    e=addon.getSetting('email')
    p=addon.getSetting('pass')
    if e!='' and p!='':
        provData=getProvision()
        
        if provData==None:
            xbmc.log('@@@Login error: no provisionData', level=xbmc.LOGINFO)
            er()
            return
        
        #LOGIN lev.1
        url='https://flb.login.solocoo.tv/login'
        data={
            "provisionData":provData,
            "deviceInfo":{
                "osVersion":"Windows 10",
                "deviceModel":"Firefox",
                "deviceType":"ConnectedTV", #PC
                "deviceSerial":addon.getSetting('d_id'),
                "deviceOem":"Firefox",
                "devicePrettyName":"Firefox 146.0",
                "appVersion":appVer,
                "language":"pl_PL",
                "country":"PL",
                "brand":"flb"
            }
        }
        h=heaGen()
        h['Authorization']=auth_hea(data)
        
        resp=requests.post(url,headers=h,json=data).json()
        if 'ticket' not in resp:
            xbmc.log('@@@Login error (no ticket): '+str(resp), level=xbmc.LOGINFO)
            er()
            return
        
        ticket=resp['ticket']

        #LOGIN lev.2
        data={
            "ticket":ticket,
            "userInput":{
                "username":e,
                "password":p
            }
        }
        h['Authorization']=auth_hea(data)
        resp=requests.post(url,headers=h,json=data).json()
        if 'ssoToken' not in resp:
            xbmc.log('@@@Login error (no ssoToken): '+str(resp), level=xbmc.LOGINFO)
            er()
            return
        
        ssoToken=resp['ssoToken']

        #Session
        resp=getSession(provData,ssoToken)
        if 'token' in resp:
            addon.setSetting('token',resp['token'])
            addon.setSetting('ssoToken',resp['ssoToken'])
            addon.setSetting('tokenExp',str(int(time.time()+30*60-1)))
            addon.setSetting('user_id',resp['userId'])
            addon.setSetting('logged','true')
        else:
            xbmc.log('@@@Login error (no token): '+str(resp), level=xbmc.LOGINFO)
            er()
        
    else:
        xbmcgui.Dialog().notification('Filmbox+', 'Uzupełnij e-mail i hasło w ustawieniach wtyczki.', xbmcgui.NOTIFICATION_INFO)
     
def logOut():#
    url='https://flblogin.solocoo.tv/logout'
    h=heaGen()
    del h['Content-Type']
    h['Authorization']='Bearer '+addon.getSetting('ssoToken')
    resp=req('post',url,h)
    #print(h)
    if 'logout' in resp and 'result' in resp:
        if resp['logout'] and resp['result']=='success':
            addon.setSetting('token','')
            addon.setSetting('ssoToken','')
            addon.setSetting('tokenExp','')
            addon.setSetting('user_id','')
            addon.setSetting('logged','false')
        else:
            xbmc.log('@@@LogOut error (2): '+str(resp), level=xbmc.LOGINFO)
    else:
        xbmc.log('@@@LogOut error (1): '+str(resp), level=xbmc.LOGINFO)
    
def para_logout():
    addon.setSetting('token','')
    addon.setSetting('ssoToken','')
    addon.setSetting('tokenExp','')
    addon.setSetting('user_id','')
    addon.setSetting('logged','false')
    
    xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox_plus/,replace)')
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
    
    
def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Filmbox+', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Filmbox+', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    
    url=apiURL+'v1/bouquet'
    resp=req('get',url,heaGen())
    for r in resp['channels']:
        tvData=r['assetInfo']
        if tvData['type']=='Channel':
            name=tvData['title']
            img=getImage(tvData['images'])
            cid=tvData['id']
    
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Filmbox+" ,%s\nplugin://plugin.video.filmbox_plus?mode=playTV&cid=%s\n' %(name,img,name,cid)
            
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('Filmbox+', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

#FAV
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=json.loads(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
        
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        if 'play' in j[0]:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        contMenu=True
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.filmbox_plus?mode=favDel&url='+quote(j[0])+')'),
        ]
        setArt=eval(j[3])
        iL=eval(j[2])
        addItemList(j[0], j[1], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,iL,img):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,iL,img])
        xbmcgui.Dialog().notification('Filmbox+', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Filmbox+', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

   
mode = params.get('mode', None)

if not mode:

    if addon.getSetting('d_id')=='' or addon.getSetting('d_id')==None:#
        addon.setSetting('d_id',"%s-%s-%s-%s-%s" %('w'+code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12)))
        

    transl()
    main_menu()
else:
    if mode=='logIn':
        logIn()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox_plus/,replace)')
            
    if mode=='logOut':
        logOut()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox_plus/,replace)')
    
    if mode=='movies' or mode=='series':
        contList(mode)
            
    if mode=='contList':
        type=params.get('type')
        page=params.get('page')
        contList(type,page)
    
    if mode=='selectGenre':
        type=params.get('type')
        selectGenre(type)
    
    if mode=='selectSortType':
        type=params.get('type')
        selectSortType(type)
    
    if mode=='seasList':
        sid=params.get('sid')
        seasList(sid)
        
    if mode=='epList':
        cid=params.get('cid')
        page=params.get('page')
        epList(cid,page)
        
    if mode=='getDetails':
        cid=params.get('cid')
        ct=params.get('ct')
        getDetails(cid,ct)
  
    if mode=='playVid':#
        vid=params.get('vid')
        playVid(vid)
        
    if mode=='trailer':
        cid=params.get('cid')
        playVid(cid,True)
        
    if mode=='tv':#
        tv()
        
    if mode=='playTV':#
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            playVid(cid)
        else:
            xbmcgui.Dialog().notification('Filmbox', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
    
    if mode=='epg':
        cid=params.get('cid')
        epg(cid)
    
    if mode=='search':   
        query = xbmcgui.Dialog().input('Szukaj:', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox_plus/?mode=searchRes&q='+query+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox_plus/,replace)')
    
    if mode=='searchRes':
        q=params.get('q')
        page=params.get('page')
        searchRes(q,page)
        
    if mode=='home':
        browser('Home')
        
    if mode=='brContList':
        q=params.get('q')
        page=params.get('page')
        brContList(q,page)
    
    if mode=='noPlay':
        pass
    
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('Filmbox+', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
    
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        iL=params.get('iL')
        a=params.get('art')
        favAdd(u,t,iL,a)
    