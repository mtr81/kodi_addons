# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import time,datetime
#import random
#import base64
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.moje_pr')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
PATH_img=PATH+'/resources/img/'
img_empty=PATH_img+'empty.png'
fanart=PATH_img+'fanart.jpg'
icon_main=PATH+'icon.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0'
baseurl='https://polskieradio.pl/'
hea={
    'User-Agent':UA,
    'Referer':baseurl
}
api_new='https://api-gateway.polskieradio.pl/v4/'
hea_new={
    'User-Agent':UA,
    'x-api-key':'74c6f5c6-0593-46f5-b128-b3f3ebf7ba8c'
}
api_pcast='https://prapi.polskieradio.pl/'#'https://apipodcasts.polskieradio.pl/api/'
baseurl_pcast='https://polskieradio.pl/'#'https://podcasty.polskieradio.pl/'
hea_pcast={
    'User-Agent':UA,
    'Origin':baseurl_pcast[:-1],
    'Referer':baseurl_pcast
}
api_pcast_img='https://cdn5.polskieradio.pl/cdn/dev/%s/img.%s'#'https://api.pr24.pl/thumbnails?url=https://cdn5.polskieradio.pl/cdn/dev/%s/img.png&bucket=pr1&w=256&q=75&fit=contain'

api_pcast_search='https://api.pr24.pl/search/'

api_player='https://apipr.polskieradio.pl/api/'
hea_player={
    'User-Agent':UA,
    'Accept':'application/json'
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(u,subt=None):
    import inputstreamhelper
    subActive=False
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+UA+'&Referer='+baseurl)#K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)

        if subt!=None:
            play_item.setSubtitles(subt)
            subActive=True

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
    if subActive==True:
        while not xbmc.Player().isPlaying():
            xbmc.sleep(100)
        xbmc.Player().showSubtitles(True)

def directPlayer(u,subt=None):
    subActive=False
    
    play_item = xbmcgui.ListItem(path=u)
    play_item.setProperty("IsPlayable", "true")
    

    if subt!=None:
        play_item.setSubtitles(subt)
        subActive=True
    
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
    if subActive==True:
        while not xbmc.Player().isPlaying():
            xbmc.sleep(100)
        xbmc.Player().showSubtitles(True)
    
def dateToStr(d,x='%Y-%m-%d'):
    return d.strftime(x)
    
def strToDate(s,f='%Y-%m-%dT%H:%M:%S'):
    return datetime.datetime(*(time.strptime(s,f)[0:6]))
    
def main_menu():
    items=[
        ['Stacje radiowe','radio','DefaultMusicSongs.png'],
        ['Podcasty','podcast','DefaultPlaylist.png'],
        ['Ulubione','favList','DefaultMusicRecentlyAdded.png']
        
    ]
    for i in items:
        setArt={'thumb': '', 'poster': icon_main, 'banner': '', 'icon': i[2], 'fanart': fanart}
        URL=build_url({'mode':i[1]})
        addItemList(URL, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)


channels={ 
    'Jedynka':{'epg_id':'1','epg_onn':'Jedynka','logo':'jedynka','stream':'https://stream11.polskieradio.pl/pr1/pr1.sdp/playlist.m3u8'},
    'Dwójka':{'epg_id':'2','epg_onn':'Dwójka','logo':'dwojka','stream':'https://stream12.polskieradio.pl/pr2/pr2.sdp/playlist.m3u8'},
    'Trójka':{'epg_id':'3','epg_onn':'Trójka','logo':'trojka','stream':'https://stream13.polskieradio.pl/pr3/pr3.sdp/playlist.m3u8'},
    'Czwórka':{'epg_id':'4','epg_onn':'Czwórka','logo':'czworka','stream':'https://stream14.polskieradio.pl/pr4/pr4.sdp/playlist.m3u8'},
    'Czwórka [VIDEO]':{'epg_id':'4','epg_onn':'Czwórka','logo':'czworka','stream':'https://stream14.polskieradio.pl/pr4_video/video_pr4.stream/playlist.m3u8'},
    'Polskie Radio 24':{'epg_id':'6','epg_onn':'Polskie Radio 24','logo':'pr24','stream':'https://stream15.polskieradio.pl/pr24/pr24.sdp/playlist.m3u8'},
    'Polskie Radio 24 [VIDEO]':{'epg_id':'6','epg_onn':'Polskie Radio 24','logo':'pr24','stream':'https://stream15.polskieradio.pl/pr24_video/video_pr24.stream/playlist.m3u8'},
    'Polskie Radio Chopin':{'epg_id':'12','epg_onn':'Polskie Radio Chopin','logo':'chopin','stream':'https://stream85.polskieradio.pl/live/rytm.sdp/playlist.m3u8'},
    'Polskie Radio Dzieciom':{'epg_id':'11','epg_onn':'Polskie Radio Dzieciom','logo':'dla_dzieci','stream':'https://stream85.polskieradio.pl/live/radio_dzieciom.sdp/playlist.m3u8'},
    'Polskie Radio Kierowców':{'epg_id':'','epg_onn':'','logo':'prk','stream':'https://stream10.polskieradio.pl/prk/rdk.sdp/playlist.m3u'},
    'Polskie Radio dla Zagranicy DAB+':{'epg_id':'7','epg_onn':'Polskie Radio dla Zagranicy','logo':'zagranica_dab','stream':'https://stream85.polskieradio.pl/pr5/pr5_dab.sdp/playlist.m3u8'},
    'Polskie Radio dla Zagranicy Wschód':{'epg_id':'9','epg_onn':'External Wschód','logo':'zagranica','stream':'https://stream85.polskieradio.pl/pr5/pr5_wsch.sdp/playlist.m3u8'},
    'Polskie Radio dla Zagranicy POLAND':{'epg_id':'5','epg_onn':'Radio Poland','logo':'zagranica_poland','stream':'https://stream85.polskieradio.pl/pr5/pr5.sdp/playlist.m3u8'},
    'Polskie Radio dla Ukrainy':{'epg_id':'','epg_onn':'Polskie Radio dla Ukrainy','logo':'dla_ukrainy','stream':'https://stream85.polskieradio.pl/radio_ukraina/ukraina.stream/playlist.m3u8'},
}

def radio():
    for c in channels:
        cd=channels[c]
        name=c
        sid=c
        img='%slogo_%s.png' %(PATH_img,cd['logo'])
        isVid='false' if 'VIDEO' not in name else 'true'
        
        plot='[I]Ramówka dostępna z poziomu menu kontekstowego.[/I]' if cd['epg_onn']!='' else ''
        
        iL={'title': name,'sorttitle': name,'plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url = build_url({'mode':'playStation','sid':sid,'vid':isVid})
        cmItems=[
            ('[B]Ramówka[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=getEPG&sid='+quote(str(cd['epg_onn']))+')'),
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favAdd&url='+quote(url)+'&title='+quote(name)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=station)')
        ]
        addItemList(url, name, setArt, 'video', iL, False, 'true', True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)
    
def getEPG(sid): 
    
    plot=''
    type=''
    date=datetime.datetime.now()
    if sid !=None:
        url='https://video.onnetwork.tv/livePR2.php'
        resp=requests.get(url,headers=hea_new).json()
        if sid in resp:
            for r in resp[sid]:
                t=strToDate(r['fullStartTime'])
                e=strToDate(r['fullEndTime'])
                if e>date:
                    plot+='[B]%s[/B] %s\n'%(r['pTime'],r['title'])
    
    if plot=='':
        plot='Brak informacji'
    dialog = xbmcgui.Dialog()
    dialog.textviewer(type, plot)   

def playStation(sid,vid):

    if sid not in channels:
        xbmcgui.Dialog().notification('MojePR', 'Brak stacji w bazie', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return
           
    stream_url=channels[sid]['stream']
    
    playerType=addon.getSetting('playerType')
    if playerType=='ISA':
        ISAplayer(stream_url)
    else:
        stream_url+='|User-Agent='+UA
        directPlayer(stream_url)   
    

def m3u_gen():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('MojePR', 'Ustaw nazwę pliku oraz katalog docelowy', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('MojePR', 'Generuję listę M3U', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    
    for c in channels:
        cd=channels[c]
        name=c
        sid=c
        img=PATH_img+cd['logo']+'.png'
        isVid='false' if 'VIDEO' not in name else 'true'
        isRadio='true' if isVid=='false' else 'false'
        
        data += '#EXTINF:0 tvg-id="%s" radio="%s" group-title="MojePR",%s\nplugin://plugin.audio.moje_pr?mode=playStation&sid=%s&vid=%s\n' % (name,isRadio,name,quote(name),isVid)
    
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('MojePR', 'Wygenerowano listę M3U.', xbmcgui.NOTIFICATION_INFO)

#PODCASTS

pdcBrands={
    'Podcasty oryginalne Polskiego Radia':'3c80f24e-17db-409a-aeac-20528422a821',
    'Jedynka':'3ee05eb1-0725-4536-aa22-a75597ad8322',
    'Dwójka':'cc119bfb-d4ef-4903-8a3b-0a786baf8650',
    'Trójka':'14fa3e0c-0e00-4fab-8d4f-e05764171165',
    'Czwórka':'3e40e475-a510-40cd-8317-fa31e2556b28',
    'Polskie Radio 24':'2658b259-b557-4d64-bb00-275c7ab377db',
    'Polskie Radio Dzieciom':'88c6cff2-26dd-4de8-9d0c-5de82d8a859a',
    'Polskie Radio Chopin':'75b4f281-c471-4164-a5e1-433b4aefb57f',
    'Studio Reportażu Polskiego Radia':'52905970-314f-4740-b881-7260ea071a31',
    'Radiowe Centrum Kultury Ludowej':'b782fd7a-16b2-4e3f-ba6e-b785b6221078',
    'Polskie Radio Audiobooki':'be286203-99fb-4398-b781-99de37f5d20c',
    'Teatr Polskiego Radia':'983067b7-2f76-4676-818c-8445b241d371',
    'Redakcja Archiwum Polskiego Radia':'97cb8d99-95a2-4a2d-b4e8-ab3e9ed14eb8',
    'Polskie Radio dla Zagranicy PL':'b2861c10-4044-42aa-980f-655c5dcd6ae2',
    'Polskie Radio dla Zagranicy RU':'18f15807-dbff-4dca-ab17-ed6cc394186c',
    'Polskie Radio dla Zagranicy BY':'feecbe02-5f09-4ea2-afec-988e375aee3a',
    'Polskie Radio dla Zagranicy DE':'66839adb-3ec0-4775-b1c7-581ad245928d',
    'Polskie Radio dla Zagranicy EN':'a3a4990b-ca14-4ecf-8872-45ea4c525a63',
    'Polskie Radio dla Ukrainy':'a447d44d-33f4-4571-a463-8bf45222f016',
}

pdcCategs=['Dla dzieci','Publicystyka','True Crime','Historia','Społeczeństwo','Audiobooki','Słuchowiska','Powieści radiowe','Muzyka','Kultura','Reportaże','Ekologia','Folk','International']

languages={
    'pl':'polski','en':'angielski','uk':'ukraiński','be':'białoruski','ru':'rosyjski','de':'niemiecki'
}
        
def podcast():
    items=[
        ['Kategorie','pcastCateg','DefaultGenre.png'],
        ['Anteny i redakcje','pcastAnt','DefaultPlaylist.png'],
        ['Najnowsze odcinki','pcastEp','DefaultYear.png'],
        ['Wyszukiwarka','pcastSearch','DefaultAddonsSearch.png']
    ]
    
    for i in items:
        img=i[2]
        isF=False if i[1] in ['pcastSearch'] else True
        
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img , 'fanart': fanart}
        URL=build_url({'mode':i[1]})
        addItemList(URL, i[0], setArt, isF=isF)
    xbmcplugin.endOfDirectory(addon_handle)
    
def pcastCateg():
    url=api_pcast+'categories'
    paramsURL={
        'siteId':'26cace88-b84a-422d-ba07-84eb3fa6bfb1'
    }
    resp=requests.get(url,headers=hea_pcast,params=paramsURL).json()
    
    categs=[['[B]Wszystkie[/B]','','Lista wszystkich podacastów']]
    categs_base=[[c['name'],c['id'],c['metaDescription']] for c in resp['data'] if c['name'] in pdcCategs]
    categs+=categs_base
   
    for c in categs:
        img='DefaultGenre.png'
        
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        iL={'plot':c[2]}
        URL=build_url({'mode':'pcastList','categ':c[1]})
        addItemList(URL, c[0], setArt, 'video', iL)
    xbmcplugin.endOfDirectory(addon_handle)

def pcastAnt():        
    for c in pdcBrands:
        img='DefaultGenre.png'
        
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        iL={'plot':c}
        URL=build_url({'mode':'pcastList','brand':pdcBrands[c]})
        addItemList(URL, c, setArt, 'video', iL)
    xbmcplugin.endOfDirectory(addon_handle)

  
def pcastList(c,b,p):
    podcastImg=openJSON(PATH+'resources/lib/podcastImg.json',True)
    
    url=api_pcast+'podcasts'
    page=1 if p==None else int(p)
    paramsURL={
        'pageSize':100,
        'pageNumber':page
    }
    if c!=None:
        paramsURL['categoryId']=c
        
    if b!=None:
        paramsURL['brandId']=b
    
    resp=requests.get(url,headers=hea_pcast,params=paramsURL).json()
    for r in resp['data']:
        pid=r['id']
        title=r['title']
        desc=r['description']
        lastEpDate=r['latestEpisodePublishedAt'].split('T')[0] if r['latestEpisodePublishedAt']!=None else '...'
        
        if r['mainImageId'] not in podcastImg:
            url_img=api_pcast_img %(r['mainImageId'],'png')
            resp_img=requests.head(url_img,headers=hea_pcast)
            if resp_img.status_code==200:
                podcastImg[r['mainImageId']]='png'
            else:
                url_img=api_pcast_img %(r['mainImageId'],'jpg')
                resp_img=requests.head(url_img,headers=hea_pcast)
                if resp_img.status_code==200:
                    podcastImg[r['mainImageId']]='jpg'
                else:
                    url_img=api_pcast_img %(r['mainImageId'],'jpeg')
                    resp_img=requests.head(url_img,headers=hea_pcast)
                    if resp_img.status_code==200:
                        podcastImg[r['mainImageId']]='jpeg'
                    else:
                        podcastImg[r['mainImageId']]=''
                        
        img=api_pcast_img %(r['mainImageId'],podcastImg[r['mainImageId']]) if podcastImg[r['mainImageId']] !='' else icon_main
        
        plot='[B]Ostatnia aktualizacja: [/B]%s\n\n'%(lastEpDate)
        plot+=desc
        
        iL={'title': title,'sorttitle': title,'plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url = build_url({'mode':'pcastEp','pid':pid,'page':'1'})
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favAdd&url='+quote(url)+'&title='+quote(title)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=podcast)')
        ]
        addItemList(url, title, setArt, 'video', iL, contMenu=True, cmItems=cmItems)
        
    if resp['totalPages']>page:
        categ=c if c!=None else ''
        brand=b if b!=None else ''
        img=icon_main
        
        iL={'plot': 'Kolejna strona'}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url = build_url({'mode':'pcastList','categ':categ,'brand':brand,'page':str(page+1)})
        addItemList(url, '[B][COLOR=cyan]>>> kolejna strona[/COLOR][/B]', setArt, 'video', iL)
    
    saveJSON(PATH+'resources/lib/podcastImg.json',podcastImg)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def pcastEp(pid,p):
    url=api_pcast+'podcast-episodes'
    page=1 if p==None else int(p)
    paramsURL={
        'pageSize':100,
        'pageNumber':page
    }
    if pid!=None:
        paramsURL['podcastId']=pid
    
    resp=requests.get(url,headers=hea_pcast,params=paramsURL).json()
    for r in resp['data']:
        eid=r['id']
        title=r['title']
        desc=r['description']
        desc=desc if desc!=None else '...'
        publDate=r['publishDate'].split('T')[0]
        img='DefaultMusicSongs.png'
        
        plot='[COLOR=cyan]%s[/COLOR]\n\n'%(publDate)
        plot+=desc
        
        iL={'title': title,'sorttitle': title,'plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url = build_url({'mode':'pcastPlay','eid':eid})
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favAdd&url='+quote(url)+'&title='+quote(title)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=podcast)'),
            ('[B]Info o podcaście[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=pcastInfo&pid='+r['podcastId']+')'),
        ]
        addItemList(url, title, setArt, 'video', iL, False, 'true', contMenu=True, cmItems=cmItems)
    
    if resp['totalPages']>page:
        PID=pid if pid!=None else ''
        img=icon_main
        
        iL={'plot': 'Kolejna strona'}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        url = build_url({'mode':'pcastEp','pid':PID,'page':str(page+1)})
        addItemList(url, '[B][COLOR=cyan]>>> kolejna strona[/COLOR][/B]', setArt, 'video', iL)
    
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def pcastInfo(pid):
    plot='Brak danych'
    
    url=api_pcast+'podcasts/'+pid
    resp=requests.get(url,headers=hea_pcast).json()
    if 'data' in resp:
        podcData=resp['data']
        title=podcData['title']
        desc=podcData['description']
        lng=podcData['language']
        try:
            lang=languages[lng]
        except:
            lang=lng
        
        plot='[COLOR=cyan]%s[/COLOR]\n'%(title)
        plot+='[B]Język:[/B] %s\n\n'%(lang)
        plot+=desc
        
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły podcastu', plot)
    

def pcastPlay(eid):
    url=api_pcast+'podcast-episodes/'+eid
    resp=requests.get(url,headers=hea_pcast).json()
    epData=resp['data']
    if epData['audioId']!=None or epData['videoId']!=None:
        if epData['audioId']!=None and epData['videoId']!=None:
            sources=['video','audio']
            streamsId=[epData['audioId'],epData['videoId']]
            select=xbmcgui.Dialog().select('Źródła', sources)
            if select>-1:
                streamId=streamsId[select]
                sourceType=sources[select]
            else:
                streamId=streamsId[1]
                sourceType=sources[1]
        else:
            streamId=epData['audioId'] if epData['audioId']!=None else epData['videoId']
            sourceType='audio' if epData['audioId']!=None else 'video'
            
        '''
        stream_url='https://cdn6.polskieradio.pl/cms/dev/audio/all/'+streamId+'/'
        if sourceType=='audio':
            stream_url+='audio.mp3'
        else:
            stream_url+='video.mp4' #do sprawdzenia !!!
        '''
        
        urlS='https://video.onnetwork.tv/videorec3.php?w=16632&l=0&e=%s_20562&onnsfonn=1'%(streamId)
        resp=requests.get(urlS,headers=hea_pcast).json()
        if 'url' in resp:
            stream_url=resp['url']

            sub=None
            if 'newsubs' in resp:
                if len(resp['newsubs'])>0:
                    sub=[resp['newsubs'][0]['url']]
            stream_url+'|User-Agent='+UA+'&Referer='+baseurl_pcast+'&Origin='+baseurl_pcast[:-1]
            directPlayer(stream_url,sub)
        else:
            xbmcgui.Dialog().notification('Moje PR', 'Brak źródeł (onn)', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            
    else:
        xbmcgui.Dialog().notification('Moje PR', 'Brak źródeł', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
def searchRes(query,page,ct):
    if ct==None:
        url=api_pcast_search+'?q='+query
        resp=requests.get(url,headers=hea_pcast).json()
        items=[
            ['Podcasty','podcasts'],
            ['Odcinki','episodes']
        ]
        
        for i in items:
            types={'podcasts':'series','episodes':'episodes'}
            count=resp[types[i[1]]]['count']
            if count>0:
                title='%s [I](%s)[/I]'%(i[0],str(count))
                img=icon_main
                
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
                URL=build_url({'mode':'searchRes','query':query,'ct':i[1],'page':'1'})
                addItemList(URL, title, setArt)
                
    
    elif ct=='episodes':
        limit=100
        offset=(int(page)-1)*100
        url=api_pcast_search+'episodes'
        paramsURL={
            'q':query,
            'limit':limit,
            'offset':offset
        }
        resp=requests.get(url,headers=hea_pcast,params=paramsURL).json()
        #print(paramsURL)
        #print(resp)
        for r in resp['items']:
            title=r['title']
            podcTitle=r['podcast_title']
            try:
                publDate=r['published_date'].split('T')[0]
            except:
                publDate='...'
            img='DefaultMusicSongs.png'
            
            plot='[COLOR=cyan]%s[/COLOR]\n\n'%(podcTitle)
            plot+='[B]Data publikacji: [/B]'+publDate
            
            iL={'title': title,'sorttitle': title,'plot': plot}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            url = build_url({'mode':'pcastPlayTitle','title':title})
            cmItems=[
                ('[B]Inne odcinki[/B]','Container.Update(plugin://plugin.audio.moje_pr?mode=pcastEp&pid='+r['podcast_id']+'&page=1)'),
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favAdd&url='+quote(url)+'&title='+quote(title)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=podcast)')
            ]
            addItemList(url, title, setArt, 'video', iL, False, 'true', contMenu=True, cmItems=cmItems)
            
        if resp['count']>offset+len(resp['items']):
            img=icon_main
            
            iL={'plot': 'Kolejna strona'}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            url = build_url({'mode':'searchRes','query':query,'ct':'episodes','page':str(int(page)+1)})
            addItemList(url, '[B][COLOR=cyan]>>> kolejna strona[/COLOR][/B]', setArt, 'video', iL)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        
    elif ct=='series':
        pass #TO DO
        
    xbmcplugin.endOfDirectory(addon_handle)

def pcastPlayTitle(t):
    url=api_pcast+'podcast-episodes'
    paramsURL={
        'title':t
    }
    resp=requests.get(url,headers=hea_pcast,params=paramsURL).json()
    if len(resp['data'])==1:
        eid=resp['data'][0]['id']
        pcastPlay(eid)
    else:
        xbmcgui.Dialog().notification('Moje PR', 'Nie znaleziono odcinka', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
#ULUBIONE KODI
def openJSON(u,arr=False):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=json.loads(cont)
    except:
        js=[] if not arr else {}
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    
    for j in js:
        if 'play' in j[0].lower():
            isFolder=False
            isPlayable='true'
        else:
            isFolder=True
            isPlayable='false'

        title=j[1]
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favDel&url='+quote(j[0])+')')
        ]
        if j[4]=='station':
            cmItems.append(('[B]Ramówka/Playlista[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=getEPG&sid='+quote(j[1])+')'))
            title='[COLOR=cyan]Radio: [/COLOR]%s'%(j[1])
        iL=eval(j[3])
        setArt=eval(j[2])
        url = j[0]
        addItemList(url, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,a,i,tp):
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,a,i,tp])
        xbmcgui.Dialog().notification('MojePR', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('MojePR', 'Stacja jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione2.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione1.json')
    xbmcgui.Dialog().notification('MojePR', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione2.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('MojePR', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)


mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='radio':
        radio()
        
    if mode=='podcast':
        podcast()
   
    if mode=='getEPG':
        sid=params.get('sid')
        getEPG(sid)
    
    if mode=='playStation':
        sid=params.get('sid')
        vid=params.get('vid')
        playStation(sid,vid)
        
    if mode=='m3u_gen':
        m3u_gen()
    
    if mode=='pcastCateg':
        pcastCateg()
    
    if mode=='pcastList':
        categ=params.get('categ')
        brand=params.get('brand')
        page=params.get('page')
        pcastList(categ,brand,page)
    
    if mode=='pcastEp':
        pid=params.get('pid')
        page=params.get('page')
        pcastEp(pid,page)
    
    if mode=='pcastInfo':
        pid=params.get('pid')
        pcastInfo(pid)
    
    if mode=='pcastPlay':
        eid=params.get('eid')
        pcastPlay(eid)
        
    if mode=='pcastPlayTitle':
        title=params.get('title')
        pcastPlayTitle(title)
        
    if mode=='pcastAnt':
        pcastAnt()
        
    if mode=='pcastSearch':
        query = xbmcgui.Dialog().input('Szukaj', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            xbmc.executebuiltin('Container.Update(plugin://plugin.audio.moje_pr/?mode=searchRes&query='+query+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.audio.moje_pr/,replace)')
    
    if mode=='searchRes':
        query=params.get('query')
        page=params.get('page')
        ct=params.get('ct')
        searchRes(query,page,ct)
    
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        a=params.get('setArt')
        i=params.get('iL')
        tp=params.get('type')
        favAdd(u,t,a,i,tp)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
