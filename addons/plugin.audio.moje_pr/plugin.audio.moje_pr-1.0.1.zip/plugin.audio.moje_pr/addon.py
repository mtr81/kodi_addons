# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import time
#import random
#import base64
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.moje_pr')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
icon_main=PATH+'icon.png'

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/116.0'
baseurl='https://moje.polskieradio.pl/'
hea={
    'User-Agent':UA,
    'Referer':baseurl
}
api_pcast='https://apipodcasts.polskieradio.pl/api/'
baseurl_pcast='https://podcasty.polskieradio.pl/'
hea_pcast={
    'User-Agent':UA,
    'Referer':baseurl_pcast
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(u):
    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        #play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+UA+'&Referer='+baseurl)#K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(u):
    play_item = xbmcgui.ListItem(path=u)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def main_menu():
    items=[
        ['Stacje radiowe','radio',icon_main],
        ['Podcasty','podcast',icon_main],
        ['Ulubione','favList',icon_main]
        
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': ''}
        URL=build_url({'mode':i[1]})
        addItemList(URL, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def radio():
    url='https://moje.polskieradio.pl/api/?channel=&key=d590cafd-31c0-4eef-b102-d88ee2341b1a'
    resp=requests.get(url,headers=hea).json()
    
    fURL=PATH_profile+'channels.json'
    saveJSON(fURL,resp)
    
    mainCategs=[
        ['Programy','stationList'],
        ['Słowo','stationList'],
        ['Muzyka','stationList'],
        ['KATEGORIE','subcategsList'],
    ]           
    
    for m in mainCategs:  
        MODE=m[1]
        if MODE=='stationList':
            URL=build_url({'mode':'stationList','mainCateg':m[0],'subCateg':''})
        elif  MODE=='subcategsList':
            URL=build_url({'mode':'subcategsList'})
        elif MODE=='favList':
            URL=build_url({'mode':'favList'})
                   
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': icon_main, 'fanart': ''}
        addItemList(URL, m[0], setArt)
  
    xbmcplugin.endOfDirectory(addon_handle)

def subcategsList():
    fURL=PATH_profile+'channels.json'
    chans=openJSON(fURL)['channel']

    subCategs=[]
    for r in chans:
        for rr in r['subcategories']:
            if rr['name'] not in subCategs:
                subCategs.append(rr['name'])
    for s in subCategs:  
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': icon_main, 'fanart': ''}
        url = build_url({'mode':'stationList','mainCateg':'','subCateg':s})
        addItemList(url, s, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def stationList(m,s):
    fURL=PATH_profile+'channels.json'
    chans=openJSON(fURL)['channel']

    if m!=None:
        stations= [c for c in chans if c['category']==m]
    else:
        stations=[]
        for c in chans:
            for sc in c['subcategories']:
                if sc['name']==s:
                    stations.append(c)
    
    for st in stations:
        stName=st['title']
        img=st['image']
        desc=st['description']
        plot=desc+'\n'
        plot+='[I]Ramówka dostępna z poziomu menu kontekstowego[/I]'
        sid=st['id']
        gsid=st['gsid']
        vid=st['isVideoChannel']
        if vid==True:
            isVid='true'
        else:
            isVid='false'
                
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        url = build_url({'mode':'playStation','sid':str(sid),'vid':isVid})
        cmItems=[
            ('[B]Ramówka/Playlista[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=getEPG&sid='+quote(str(gsid))+')'),
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favAdd&url='+quote(url)+'&title='+quote(stName)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=station)')
        ]
        addItemList(url, stName, setArt, 'video', iL, False, 'true', True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)

def getEPG(sid):
    plot=''
    type=''
    url='https://moje.polskieradio.pl/api/?mobilestationId='+sid+'&key=d590cafd-31c0-4eef-b102-d88ee2341b1a'
    print(url)
    resp=requests.get(url,headers=hea)
    if resp.status_code!=500:
        resp=resp.json()
        if resp['Playlist']==False:
            type='Ramówka'
        else:
            type='Playlista'
        if 'Songs' in resp:
            def sortFN(i):
                return i['ScheduleTime']
            resp['Songs'].sort(key=sortFN,reverse=False)
            for s in resp['Songs']:
                hour=s['ScheduleTime'].split('T')[-1].split(':')
                date=s['ScheduleTime'].split('T')[0]
                timeStart='[B]%s | %s:%s[/B]'%(date,hour[0],hour[1])
                if type=='Ramówka':
                    name=s['Artist']
                else:
                    name=s['Artist']+' - '+s['Title']
                plot+=timeStart+ ' '+name+'\n'
    if plot=='':
        plot='Brak informacji'
    dialog = xbmcgui.Dialog()
    dialog.textviewer(type, plot)   

def playStation(sid,vid):
    fURL=PATH_profile+'channels.json'
    chans=openJSON(fURL)['channel']

    station=[c for c in chans if c['id']==int(sid)]
    if vid=='false':
        streams=[st['link'] for st in station[0]['AlternateStationsStreams'] if st['name']=='iPhone']
        stream_url=streams[0].replace('http:','https:')
            
    else:
        streams=[st['link'] for st in station[0]['AlternateStationsStreams'] if st['name']=='iPhone']
        stream_url=streams[0].replace('http:','https:')
        print(stream_url)
        stream_url+='|User-Agent='+UA+'&Referer='+baseurl+'&Origin='+baseurl[:-1]
    
    directPlayer(stream_url)    
        
def podcast():
    items=[
        ['Kategorie','pcastCateg',icon_main],
        ['Anteny','pcastAnt',icon_main],
        ['Wszystkie','pcastAll',icon_main]
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': ''}
        URL=build_url({'mode':i[1]})
        addItemList(URL, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)
    
def pcastCateg():
    url=api_pcast+'Categories'
    resp=requests.get(url,headers=hea_pcast).json()
    categs=[[c['pl'],c['name'],'n'] for c in resp['items']]
    
    url=api_pcast+'categories/pr'
    resp=requests.get(url,headers=hea_pcast).json()
    categs+=[[c['name'],c['name'],'y'] for c in resp['items']]
    
    for c in categs:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''}
        URL=build_url({'mode':'pcastList','categ':c[1],'pr':c[2]})
        addItemList(URL, c[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def genPcastList(): #baza danych
    url=api_pcast+'Podcasts/?pageSize=100&page='
    p=1
    test=True
    data=[]
    while test:
        resp=requests.get(url+str(p),headers=hea_pcast).json()
        data+=resp['items']
        if len(data)==resp['count']:
            test=False
        else:
            p+=1

    fURL=PATH_profile+'podcasts.json'
    saveJSON(fURL,data)

def podcastData(d): #helper
    pid=str(d['id'])
    title=d['title']
    desc=d['description'] if 'description' in d else None
    st=d['radioStation'] if 'radioStation' in d else None
    count=d['itemCount'] if 'itemCount' in d else None
    date=d['lastItemUpdate'] if 'lastItemUpdate' in d else None
    img=d['image']['main']
            
    plot=''
    if st!=None or st!='':
        plot+='[B]Stacja: %s[/B]\n' %(st)
    if desc!=None or desc!='':
        plot+='[I]%s[/I]\n' %(desc)
    if count!=None or count!='':
        plot+='[B]Odcinki: %s[/B]\n' %(str(count))
    if date!=None or date!='':
        plot+='[B]aktualizacja: %s[/B]\n' %(date.split('T')[0])
               
    iL={'title': '','sorttitle': '','plot': plot}
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
    url = build_url({'mode':'pcastEp','pid':pid,'page':'1'})
    cmItems=[
        ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favAdd&url='+quote(url)+'&title='+quote(title)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=podcast)')
    ]
    addItemList(url, title, setArt, 'video', iL, contMenu=True, cmItems=cmItems)

def pcastListLoad(): #helper
    fURL=PATH_profile+'podcasts.json'
    data=openJSON(fURL)
    pcastSort=addon.getSetting('pcastSort')
    if pcastSort=='alfabetycznie': 
        def sortFN(i):
            return i['title']
        data.sort(key=sortFN,reverse=False)
        
    return data
  
def pcastList(c,pr):
    data=pcastListLoad()
    for d in data:
        if (pr=='n' and d['itunesCategory']==c) or (pr=='y' and d['prCategory']==c):
            podcastData(d)
    xbmcplugin.endOfDirectory(addon_handle)
    
def pcastEp(pid,page):
    count=10
    url=api_pcast+'Podcasts/%s/?pageSize=%s&page=%s'%(pid,str(count),page)
    resp=requests.get(url,headers=hea_pcast).json()
    for d in resp['items']:
        title=d['title']
        desc=d['description'] if 'description' in d else None
        dur=d['length'] if 'length' in d else None
        st=d['radioStation'] if 'radioStation' in d else None
        date=d['publishDate'] if 'publishDate' in d else None
        img=d['image']
        
        plot=''
        if st!=None or st!='':
            plot+='[B]Stacja: %s[/B]\n' %(st)
        if dur!=None or dur!='':
            plot+='[B]Długość: %s[/B] min.\n' %(str(int(dur/60)))    
        if date!=None or date!='':
            plot+='[B]Data publikacji: %s[/B]\n' %(date.split('T')[0])
        if desc!=None or desc!='':
            plot+='[I]%s[/I]\n' %(desc)
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        url = build_url({'mode':'pcastPlay','url':d['url']})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    if (int(page)-1)*count+len(resp['items'])<resp['itemCount']:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
        url = build_url({'mode':'pcastEp','pid':pid,'page':str(int(page)+1)})
        addItemList(url, '[COLOR=yellow][B]>>> następna strona[/B][/COLOR]', setArt, 'video')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def pcastPlay(u):
    stream_url=u+'|User-Agent='+UA+'&Referer='+baseurl_pcast+'&Origin='+baseurl_pcast[:-1]
    directPlayer(stream_url)
    
def pcastAnt():
    fURL=PATH_profile+'stations.json'
    js=openJSON(fURL)
    for s in js:
        img=baseurl_pcast[:-1]+s[1]
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''}
        URL=build_url({'mode':'pcastListSt','st':s[0]})
        addItemList(URL, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def pcastListSt(s):
    data=pcastListLoad()
    for d in data:
        if 'radioStation' in d:
            if d['radioStation']==s:
                podcastData(d)
    xbmcplugin.endOfDirectory(addon_handle)        

def pcastAll():
    data=pcastListLoad()
    for d in data:
        podcastData(d)
    xbmcplugin.endOfDirectory(addon_handle)    
 
#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=json.loads(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione1.json'
    js=openJSON(fURL)
    
    fURL=PATH_profile+'channels.json'
    chans=openJSON(fURL)['channel']

    for j in js:
        if 'play' in j[0]:
            isFolder=False
            isPlayable='true'
        else:
            isFolder=True
            isPlayable='false'

        title=j[1]
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favDel&url='+quote(j[0])+')')
        ]
        if j[4]=='station':
            sid=re.compile('sid=([^&]+?)&').findall(j[0])[0]
            fURL=PATH_profile+'channels.json'
            chans=openJSON(fURL)['channel']
            gsid=[str(c['gsid']) for c in chans if str(c['id'])==sid][0]
            cmItems.append(('[B]Ramówka/Playlista[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=getEPG&sid='+quote(gsid)+')'))
            title='[COLOR=yellow]Radio: [/COLOR]%s'%(j[1])
        iL=eval(j[3])
        setArt=eval(j[2])
        url = j[0]
        addItemList(url, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione1.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,a,i,tp):
    fURL=PATH_profile+'ulubione1.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,a,i,tp])
        xbmcgui.Dialog().notification('MojePR', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('MojePR', 'Stacja jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione1.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione1.json')
    xbmcgui.Dialog().notification('MojePR', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione1.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('MojePR', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)

def stList():#baza danych
    fURL=PATH_profile+'stations.json'
    js=openJSON(fURL)
    
    url='https://podcasty.polskieradio.pl'
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('Anteny</a')[1].split('<ul')[1].split('</ul>')[0].split('</li>')
    stations=[]
    for r in resp1:
        if 'img' in r and 'alt=' in r:
            img=re.compile('<img src=\"([^\"]+?)\"').findall(r)[0]
            name=re.compile('alt=\"([^\"]+?)\"').findall(r)[0]
            stations.append([name.encode('latin-1').decode('utf-8'),img])
    js=stations
    saveJSON(fURL,js)


mode = params.get('mode', None)

if not mode:
    dataUpdate=addon.getSetting('dataUpdate')
    now=time.time()
    if dataUpdate=='':
        stList()
        genPcastList()
        addon.setSetting('dataUpdate',str(now))
    else:
        if now>=float(dataUpdate)+6*60*60:
            stList()
            genPcastList()
            addon.setSetting('dataUpdate',str(now))
    main_menu()
else:
    if mode=='radio':
        radio()
        
    if mode=='podcast':
        podcast()
    
    if mode=='subcategsList':
        subcategsList()
        
    if mode=='stationList':
        m=params.get('mainCateg')
        s=params.get('subCateg')
        stationList(m,s)
        
    if mode=='getEPG':
        sid=params.get('sid')
        getEPG(sid)
    
    if mode=='playStation':
        sid=params.get('sid')
        vid=params.get('vid')
        playStation(sid,vid)
    
    if mode=='pcastCateg':
        pcastCateg()
    
    if mode=='pcastList':
        categ=params.get('categ')
        pr=params.get('pr')
        pcastList(categ,pr)
    
    if mode=='pcastEp':
        pid=params.get('pid')
        page=params.get('page')
        pcastEp(pid,page)
        
    if mode=='pcastPlay':
        url=params.get('url')
        pcastPlay(url)
        
    if mode=='pcastAnt':
        pcastAnt()
    
    if mode=='pcastListSt':
        st=params.get('st')
        pcastListSt(st)
        
    if mode=='pcastAll':
        pcastAll()
        
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        a=params.get('setArt')
        i=params.get('iL')
        tp=params.get('type')
        favAdd(u,t,a,i,tp)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
