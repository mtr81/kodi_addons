# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
#import re
#import base64
import json
#import random
#import time
#from resources.lib import jsunpack
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.moje_pr')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/108.0'
baseurl='https://moje.polskieradio.pl/'
hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def main_menu():
    url='https://moje.polskieradio.pl/api/?channel=&key=d590cafd-31c0-4eef-b102-d88ee2341b1a'
    resp=requests.get(url,headers=hea).json()
    addon.setSetting('json_data',str(resp))
    mainCategs=[
        ['Programy','stationList'],
        ['Słowo','stationList'],
        ['Muzyka','stationList'],
        ['KATEGORIE','subcategsList'],
        ['Ulubione','favList']
    ]           
    
    for m in mainCategs:  
        MODE=m[1]
        if MODE=='stationList':
            URL=build_url({'mode':'stationList','mainCateg':m[0],'subCateg':''})
        elif  MODE=='subcategsList':
            URL=build_url({'mode':'subcategsList'})
        elif MODE=='favList':
            URL=build_url({'mode':'favList'})
            
        li=xbmcgui.ListItem(m[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=URL, listitem=li, isFolder=True)
  
    xbmcplugin.endOfDirectory(addon_handle)

def subcategsList():
    chans=eval(addon.getSetting('json_data'))['channel']
    subCategs=[]
    for r in chans:
        for rr in r['subcategories']:
            if rr['name'] not in subCategs:
                subCategs.append(rr['name'])
    for s in subCategs:  
        li=xbmcgui.ListItem(s)
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
        url = build_url({'mode':'stationList','mainCateg':'','subCateg':s})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)   
    xbmcplugin.endOfDirectory(addon_handle)

def stationList(m,s):
    chans=eval(addon.getSetting('json_data'))['channel']
    if m!=None:
        stations= [c for c in chans if c['category']==m]
    else:
        stations=[]
        for c in chans:
            for sc in c['subcategories']:
                if sc['name']==s:
                    stations.append(c)
    
    for st in stations:
        stName=st['title']
        img=st['image']
        desc=st['description']
        plot=desc+'\n'
        plot+='[I]Ramówka dostępna z poziomu menu kontekstowego[/I]'
        sid=st['id']
        gsid=st['gsid']
        vid=st['isVideoChannel']
        if vid==True:
            isVid='true'
        else:
            isVid='false'
                
        li=xbmcgui.ListItem(stName)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': img, 'banner': img, 'icon': img, 'fanart': ''})
        url = build_url({'mode':'playStation','sid':str(sid),'vid':isVid})
        
        contMenu = []
        contMenu.append(('[B]Ramówka/Playlista[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=getEPG&sid='+quote(str(gsid))+')'))
        contMenu.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favAdd&sid='+quote(str(sid))+')'))
        li.addContextMenuItems(contMenu, replaceItems=False)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def getEPG(sid):
    plot=''
    type=''
    url='https://moje.polskieradio.pl/api/?mobilestationId='+sid+'&key=d590cafd-31c0-4eef-b102-d88ee2341b1a'
    print(url)
    resp=requests.get(url,headers=hea)
    if resp.status_code!=500:
        resp=resp.json()
        if resp['Playlist']==False:
            type='Ramówka'
        else:
            type='Playlista'
        if 'Songs' in resp:
            for s in resp['Songs']:
                hour=s['ScheduleTime'].split('T')[-1].split(':')
                timeStart='[B]'+hour[0]+':'+hour[1]+'[/B]'
                if type=='Ramówka':
                    name=s['Artist']
                else:
                    name=s['Artist']+' - '+s['Title']
                plot+=timeStart+ ' '+name+'\n'
    if plot=='':
        plot='Brak informacji'
    dialog = xbmcgui.Dialog()
    dialog.textviewer(type, plot)   

def playStation(sid,vid):
    chans=eval(addon.getSetting('json_data'))['channel']
    station=[c for c in chans if c['id']==int(sid)]
    if vid=='false':
        streams=[st['link'] for st in station[0]['AlternateStationsStreams'] if st['name']=='iPhone']
        stream_url=streams[0].replace('http:','https:')
            
    else:
        streams=[st['link'] for st in station[0]['AlternateStationsStreams'] if st['name']=='iPhone']
        stream_url=streams[0].replace('http:','https:')
        print(stream_url)
        stream_url+='|User-Agent='+UA+'&Referer='+baseurl+'&Origin='+baseurl[:-1]
    '''
    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)
        #play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                      
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    '''
        
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
   
#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    
    chans=eval(addon.getSetting('json_data'))['channel']
    for j in js:
        stations= [c for c in chans if c['id']==int(j)]
        st=stations[0]
        stName=st['title']
        img=st['image']
        desc=st['description']
        plot=desc+'\n'
        plot+='[I]Ramówka dostępna z poziomu menu kontekstowego[/I]'
        sid=st['id']
        gsid=st['gsid']
        vid=st['isVideoChannel']
        if vid==True:
            isVid='true'
        else:
            isVid='false'
                
        li=xbmcgui.ListItem(stName)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': img, 'banner': img, 'icon': img, 'fanart': ''})
        url = build_url({'mode':'playStation','sid':str(sid),'vid':isVid})
        
        contMenu = []
        contMenu.append(('[B]Ramówka/Playlista[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=getEPG&sid='+quote(str(gsid))+')'))
        contMenu.append(('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.moje_pr?mode=favDel&sid='+quote(str(sid))+')'))
        li.addContextMenuItems(contMenu, replaceItems=False)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(s):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j==s:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(s):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    if s in js:
        duplTest=True
    if not duplTest:
        js.append(s)
        xbmcgui.Dialog().notification('MyFreeMP3', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('MyFreeMP3', 'Stacja jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('MyFreeMP3', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('MyFreeMP3', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)


mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='subcategsList':
        subcategsList()
        
    if mode=='stationList':
        m=params.get('mainCateg')
        s=params.get('subCateg')
        stationList(m,s)
        
    if mode=='getEPG':
        sid=params.get('sid')
        getEPG(sid)
    
    if mode=='playStation':
        sid=params.get('sid')
        vid=params.get('vid')
        playStation(sid,vid)
        
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        s=params.get('sid')
        favDel(s)
        
    if mode=='favAdd':
        s=params.get('sid')
        favAdd(s)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
