# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
import urllib
from urllib.request import Request, urlopen
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.tbn')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
img_addon=PATH+'/icon.png'
fanart=PATH+'/resources/img/fanart.jpg'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

heaUA={'User-Agent':UA}

'''
channels={
    'tbn':['TBN Polska','784',img_path+'tbn.png','c',2],
}
'''
#vod tbn
urlTBNvod='https://tbngo.pl/api/'
baseurl='https://tbngo.pl/'
heaTBN={
    'User-Agent':UA,
    'Referer':baseurl,
    'Origin':baseurl[:-1]
    
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)
    
def ISAplayer(protocol,stream_url, playHea, isDRM=False, licURL=False):
    import inputstreamhelper
    
    PROTOCOL = protocol
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)                     
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)        
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', playHea)
        play_item.setProperty('inputstream.adaptive.manifest_headers', playHea)
        if isDRM:
            play_item.setProperty('inputstream.adaptive.license_type', DRM)
            play_item.setProperty('inputstream.adaptive.license_key', licURL)        
    
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(stream_url,heaP):
    stream_url+='|'+heaP
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
'''
def getS(c):
    s='eyd0Ym4nOidodHRwczovL3MtcGwtMDEubWVkaWF0b29sLnR2L3BsYXlvdXQvdGJuLWFici9pbmRleC5tcGQnfQ=='
    return eval(base64.b64decode(s).decode())[c]
'''    
def getTime(x):#WP
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    t_utc=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    t_loc=t_utc+diff+datetime.timedelta(seconds=1)
    return t_loc

def timeToStr(x,y):#WP
    return x.strftime(y)
    
def strToTime(x):#WP
    return datetime.datetime(*(time.strptime(x,'%Y-%m-%d')[0:6]))

def main_menu():
    items=[
        ['TBN Polska Na żywo','playLive',img_addon],
        #['Archiwum TV','calendar','DefaultTVShows.png'],
        ['VOD','vod','DefaultAddonVideo.png'],
    ]
    status=addon.getSetting('logged')
    if status=='true':
        items.append(['Wyloguj','logOut','DefaultUser.png'])
    else:
        items.append(['Zaloguj','logIn','DefaultUser.png'])
    
    for i in items:
        if i[1]=='playLive':
            try:
                epg=getEPG('784')
                    
            except:
                epg='Brak danych EPG'
            plot=epg
            isP='true'
            isF=False
        else:
            plot=''
            isP='false'
            isF=False if i[1] in ['logIn','logOut'] else True
        
        iL={'plot':plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': fanart}
        url=build_url({'mode':i[1]})
        addItemList(url, i[0], setArt, 'video', iL, isF, isP)
    xbmcplugin.endOfDirectory(addon_handle)


def getEPG(c): #WP
    today=datetime.datetime.now()
    yest=datetime.datetime.now()-datetime.timedelta(days=1)
    t=timeToStr(today,'%Y-%m-%d')
    y=timeToStr(yest,'%Y-%m-%d')
    progs=[]
    url='https://tv.wp.pl/api/v1/program/'+y+'/'+c
    resp=requests.get(url,headers=heaUA).json()
    progs=resp['data'][0]['entries']
    url='https://tv.wp.pl/api/v1/program/'+t+'/'+c
    resp=requests.get(url,headers=heaUA).json()
    progs+=resp['data'][0]['entries']
    epg=''
    for r in progs:
        if getTime(r['end'])>datetime.datetime.now():
            title=r['title']
            if 'episode_title' in r:
                title+=' - ' + r['episode_title']
            if 'genre' in r:
                title+=' [I]('+ r['genre']+')[/I]'
            ts=timeToStr(getTime(r['start']),'%H:%M')
            epg+='[B]%s[/B] %s\n'%(ts,title)
    
    return epg

def calendar():
    cuDays=2
    now=datetime.datetime.now()
    for i in range(0,cuDays+1):
        date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart':fanart}
        url=build_url({'mode':'programList','date':date})
        addItemList(url, date, setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def programList(d):
    epgID='784'
    cuTime=2*24*60*60
    
    t0=strToTime(d)-datetime.timedelta(days=1)
    d0=timeToStr(t0,'%Y-%m-%d')
    progs=[]
    url='https://tv.wp.pl/api/v1/program/'+d0+'/'+epgID
    h={
        'User-Agent':UA,
    }
    resp=requests.get(url,headers=h).json()
    progs=resp['data'][0]['entries']
    url='https://tv.wp.pl/api/v1/program/'+d+'/'+epgID
    resp=requests.get(url,headers=h).json()
    progs+=resp['data'][0]['entries']
    
    for r in progs:
        now=datetime.datetime.now()
        start=now-datetime.timedelta(seconds=cuTime)
        if getTime(r['start'])>start and getTime(r['start'])<now and timeToStr(getTime(r['start']),'%Y-%m-%d')==d:
            title=r['title']
            if 'episode_title' in r:
                title+=' - ' + r['episode_title']
            if 'genre' in r:
                title+=' [I]('+ r['genre']+')[/I]'
            ts=timeToStr(getTime(r['start']),'%H:%M')
            name='[B]%s[/B] %s\n'%(ts,title)
            tstart=str(int(getTime(r['start']).timestamp()))
            tend=str(int(getTime(r['end']).timestamp()))
            img=r['photo'][0]['file']
                        
            #iL={'title': title,'sorttitle': '','plot': descLong,'plotoutline':desc,'year':year,'duration':dur,'director':directors,'cast':actors,'mediatype':'movie'}
            iL={'title': title,'sorttitle': '','plot': ''}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            url=build_url({'mode':'playReplay','ts':tstart,'te':tend})
            addItemList(url, name, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos') 
    xbmcplugin.endOfDirectory(addon_handle)
    
def tbn(ts=None,te=None):
    url=baseurl+'get-live-hls'
    resp=requests.get(url,headers=heaTBN).json()
    if 'hls' in resp:
        s_url=resp['hls']
        heaPlay=urlencode(heaUA)
        ISAplayer('hls',s_url,heaPlay)
    else:
        xbmcgui.Dialog().notification('TBN GO', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    
def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('TBN', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('TBN', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'

    name='TBN Polska'
    img=img_addon
    cu=''#'c'
    cuTime='2'
    if cu=='c':
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" catchup="append" catchup-source="&s={utc:Y-m-dTH:M:S}&e={utcend:Y-m-dTH:M:S}" catchup-days="%s",%s\nplugin://plugin.video.tbn?mode=playLive\n' %(name,img,cuTime,name)
    else:
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s",%s\nplugin://plugin.video.tbn?mode=playLive\n' %(name,img,name)
    
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('TBN', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    

#tbn vod
def getCookies():
    if addon.getSetting('logged')=='true':
        c={
            'TOKEN':addon.getSetting('token')
        }
    else:
        c={}
        
    return c

def vod():
    url=urlTBNvod+'categories'
    resp=requests.get(url,headers=heaTBN,cookies=getCookies()).json()
    for r in resp:
        for rr in r:
            title=rr
            categ=rr
            
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultGenre.png', 'fanart':fanart}
            url=build_url({'mode':'vodList','categ':categ})
            addItemList(url, title, setArt)
            
    xbmcplugin.endOfDirectory(addon_handle)
    

def vodList(c):
    url='https://tbngo.pl/getVideos'
    resp=requests.get(url,headers=heaTBN,cookies=getCookies()).json()
    progs=[p for p in resp if c in p['category']]
    for p in progs:
        title=p['title']
        info=p['info']
        vid=p['_id']
        link=p['hlsUrl']
        img='https://tbngo.pl/uploads/'+p['filename']
        
        mediatype='movie'
        mod='playVOD'
        isF=False
        isP='true'
        URL=build_url({'mode':'playVOD','link':link})
        if 'episodes' in p:
            if len(p['episodes'])>0:
                mediatype='tvshow'
                mod='epList'
                isF=True
                isP='false'
                URL=build_url({'mode':'epList','vid':vid})
        
        iL={'mediatype':mediatype,'title':title,'plot':info}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        addItemList(URL, title, setArt, 'video', iL, isF, isP)

    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.setContent(addon_handle, 'videos')

def epList(vid):
    url='https://tbngo.pl/getVideos'
    resp=requests.get(url,headers=heaTBN,cookies=getCookies()).json()
    progs=[p for p in resp if p['_id']==vid]
    if len(progs)>0:
        prog=progs[0]
        
        title='odc. 1'
        epNo=1
        link=prog['hlsUrl']
        img='https://tbngo.pl/uploads/'+prog['filename']
        
        iL={'mediatype':'episode','title':title,'episode':epNo}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        URL=build_url({'mode':'playVOD','link':link})
        addItemList(URL, title, setArt, 'video', iL, False, 'true')
        
        for e in prog['episodes']:
            epNo=e['episodeNumber']
            title='Odc. %s'%(str(epNo))
            link=e['hls']
            img=e['thumbnail']
            URL=build_url({'mode':'playVOD','link':link})
            iL={'mediatype':'episode','title':title,'episode':epNo}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            addItemList(URL, title, setArt, 'video', iL, False, 'true')
            
    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.setContent(addon_handle, 'videos')

    
def playVOD(link):
    heaP=urlencode(heaTBN)
    ISAplayer('hls',link,heaP)
    

def logIn():
    l=addon.getSetting('email')
    p=addon.getSetting('password')
    if l!='' and p!='':
        url='https://tbngo.pl/login'
        data={
            'email':l,
            'password':p
        }
        resp=requests.post(url,headers=heaTBN,json=data).json()

        if 'token' in resp:
            addon.setSetting('token',resp['token'])
            addon.setSetting('logged','true')
        else:
           xbmcgui.Dialog().notification('TBN', 'Błędne dane logowania', xbmcgui.NOTIFICATION_INFO) 
        
    else:
        xbmcgui.Dialog().notification('TBN', 'Brak danych logowania (uzupełnij je w ustawieniach wtyczki)', xbmcgui.NOTIFICATION_INFO)

def logOut():
    url='https://tbngo.pl/logout'
    heaTBN.update({'Cookie':'TOKEN='+addon.getSetting('token')})
    resp=requests.post(url,headers=heaTBN)
    
    addon.setSetting('token','')
    addon.setSetting('logged','false')
    

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
        
    if mode=='playLive':
        s=params.get('s')
        e=params.get('e')
        if s!=None and e!=None:
            co=int(addon.getSetting('cuOffset2'))
            ts=str(int((datetime.datetime(*(time.strptime(s, "%Y-%m-%dT%H:%M:%S")[0:6]))+datetime.timedelta(hours=co)).timestamp()))
            te=str(int((datetime.datetime(*(time.strptime(e, "%Y-%m-%dT%H:%M:%S")[0:6]))+datetime.timedelta(hours=co)).timestamp()))
            tbn(ts,te)
        else:
            tbn()
            
    if mode=='calendar':
        calendar()
    
    if mode=='programList':
        date=params.get('date')
        programList(date)
        
    if mode=='playReplay':
        ts=params.get('ts')
        te=params.get('te')
        tbn(ts,te)
    
    if mode=='listM3U':
        listM3U()#
    
    #TBN vod
    if mode=='vod':
        vod()
    
    if mode=='vodList':
        categ=params.get('categ')
        vodList(categ)
    
    if mode=='epList':
        vid=params.get('vid')
        epList(vid)
    
    if mode=='playVOD':
        if addon.getSetting('logged')!='true':
            xbmcgui.Dialog().notification('TBN', 'Konieczne logowanie', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        else:
            link=params.get('link')
            playVOD(link)
        
    if mode=='logIn':
        logIn()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.tbn/,replace)')
            
    if mode=='logOut':
        logOut()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.tbn/,replace)')

        