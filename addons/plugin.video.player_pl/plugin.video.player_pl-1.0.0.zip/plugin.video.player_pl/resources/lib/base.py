# -*- coding: utf-8 -*-
#import os
#import sys

import xbmc
import xbmcgui#
import xbmcplugin#
import xbmcaddon
import xbmcvfs

import random
import requests

from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

class b:
    def __init__(self, base_url=None, addon_handle=None):
        self.base_url=base_url
        self.addon_handle=addon_handle
        self.UA='playerTV/2.2.2 (455) (Linux; Android 8.0.0; Build/sdk_google_atv_x86) net/sdk_google_atv_x86userdebug 8.0.0 OSR1.180418.025 6695156 testkeys'
        self.hea={
            'User-Agent':self.UA,
            #'Content-Type':'application/x-www-form-urlencoded',
            'accept-encoding':'gzip'
        }
        self.heaWeb={
             'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
        }
        self.platform='ANDROID_TV'
        self.baseurl='https://player.pl/'
        self.apiAuth='https://oauth.account.tvn.pl/'
        self.client_id='Player_TV_Android_28d3dcc063672068'
        
        
        self.addon=xbmcaddon.Addon(id='plugin.video.player_pl')
        self.PATH_profile=xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(self.PATH_profile):
            xbmcvfs.mkdir(self.PATH_profile)
            
    def build_url(self, query):
        return self.base_url + '?' + urlencode(query)

    def addItemList(self, url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
        li=xbmcgui.ListItem(name)
        li.setProperty("IsPlayable", isPla)
        if medType:
            li.setInfo(type=medType, infoLabels=infoLab)
        li.setArt(setArt) 
        if contMenu:
            li.addContextMenuItems(cmItems, replaceItems=False)
        xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=url, listitem=li, isFolder=isF)
    
    def code_gen(self,x):
        base='0123456789abcdef'
        code=''
        for i in range(0,x):
            code+=base[random.randint(0,15)]
        return code
        
    def heaGen(self):
        CorrelationID='androidTV_'+self.code_gen(8)+'-'+self.code_gen(4)+'-'+self.code_gen(4)+'-'+self.code_gen(4)+'-'+self.code_gen(12)
        hea=self.hea
        hea.update({
            'api-correlationid':CorrelationID,
            'api-deviceuid':self.addon.getSetting('device_uid'),
            'api-deviceinfo':'sdk_google_atv_x86;unknown;Android;8.0.0;Unknown;2.2.2 (455);',
        })

        if self.addon.getSetting('logged')=='true':
            hea.update({
                'api-authentication':self.addon.getSetting('access_token'),
                'api-profileuid':self.addon.getSetting('profile_uid'),
                'api-subscriberhash':self.addon.getSetting('user_hash'),
                'api-subscriberpub':self.addon.getSetting('user_pub')
            })
        
        return hea
        
    def cookiesGen(self):
        c={
            'konto_tvn_at':	self.addon.getSetting('konto_tvn'),
            'profile_uid':self.addon.getSetting('profile_uid'), 
            'samuid':self.addon.getSetting('profile_uid'),
            'uid':self.addon.getSetting('uid'),
            'subscriber_hash':self.addon.getSetting('user_hash'),
            'subscriber_pub':self.addon.getSetting('user_pub') 
        }
        return c
        
    def logIn(self):
        #code gen
        url=self.apiAuth+'tvn-reverse-onetime-code/create?platform='+self.platform
        data={
            'scope':'/pub-api/user/me',
            'client_id':self.client_id
        }
        resp=requests.post(url,headers=self.hea,data=data).json()
        if 'code' in resp:
            code=resp['code']
            ok=xbmcgui.Dialog().ok("Logowanie", 'Wprowadź kod [COLOR=yellow][B]'+code+'[/B][/COLOR] na stronie [B]https://player.pl/generuj-kod-tv[/B] a następnie naciśnij OK')
            if ok:
                #weryfikacja kodu
                url=self.apiAuth+'token?platform='+self.platform
                data={
                    'grant_type':'tvn_reverse_onetime_code',
                    'code':code,
                    'client_id':self.client_id
                }
                resp=requests.post(url,headers=self.hea,data=data).json()
                if 'access_token' in resp:
                    self.addon.setSetting('access_token',resp['access_token'])
                    self.addon.setSetting('refresh_token',resp['refresh_token'])
                    self.addon.setSetting('user_hash',resp['user_hash'])
                    self.addon.setSetting('user_pub',resp['user_pub'])
                    
                    #profil
                    url=self.baseurl+'playerapi/subscriber/login/token?4K=true&platform='+self.platform
                    data={
                        "agent": "sdk_google_atv_x86",
                        "agentVersion": self.UA,
                        "appVersion": "2.2.2 (455)",
                        "maker": "Unknown",
                        "os": "Android",
                        "osVersion": "8.0.0",
                        "token": self.addon.getSetting('access_token'),
                        "uid": self.addon.getSetting('device_uid')
                    }
                    cookies={
                        'uid':self.addon.getSetting('uid')
                    }
                    resp=requests.post(url,headers=self.heaGen(),json=data,cookies=cookies)
                    respj=resp.json()
                    if 'active' in respj:
                        
                        self.addon.setSetting('profile_uid',respj['profile']['externalUid'])
                        self.addon.setSetting('subscr',respj['status']['subscriptionModel'])
                        cooks=dict(resp.cookies)
                        self.addon.setSetting('konto_tvn',cooks['konto_tvn_at'])
                        
                        self.addon.setSetting('logged','true')
                        xbmcgui.Dialog().notification('Player.pl', 'Zalogowano', xbmcgui.NOTIFICATION_INFO)
                    else:
                        xbmcgui.Dialog().notification('Player.pl', 'Błąd logowania (profil)', xbmcgui.NOTIFICATION_INFO)
                        xbmcplugin.endOfDirectory(self.addon_handle, cacheToDisc=False)
                        xbmc.executebuiltin('Container.Update(plugin://plugin.video.player_pl/,replace)')
                    
                else:
                    xbmcgui.Dialog().notification('Player.pl', 'Błąd przy potwierdzeniu kodu', xbmcgui.NOTIFICATION_INFO)
                    xbmcplugin.endOfDirectory(self.addon_handle, cacheToDisc=False)
                    xbmc.executebuiltin('Container.Update(plugin://plugin.video.player_pl/,replace)')
        
        else:
            xbmcgui.Dialog().notification('Player.pl', 'Błąd przy generowaniu kodu', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(self.addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.player_pl/,replace)')
            
    def logOut(self):
        url=self.baseurl+'playerapi/subscriber/logout?platform='+self.platform
        data=''
        resp=requests.post(url,headers=self.heaGen(),data=data,cookies=self.cookiesGen())
        print(resp)
        
        self.addon.setSetting('access_token','')
        self.addon.setSetting('refresh_token','')
        self.addon.setSetting('user_hash','')
        self.addon.setSetting('user_pub','')
        self.addon.setSetting('profile_uid','')
        self.addon.setSetting('konto_tvn','')
        self.addon.setSetting('availUpdateTime','')
        self.addon.setSetting('logged','false')
        xbmcgui.Dialog().notification('Player.pl', 'Wylogowano', xbmcgui.NOTIFICATION_INFO)

    def paraLogOut(self):
        self.addon.setSetting('access_token','')
        self.addon.setSetting('refresh_token','')
        self.addon.setSetting('user_hash','')
        self.addon.setSetting('user_pub','')
        self.addon.setSetting('profile_uid','')
        self.addon.setSetting('konto_tvn','')
        self.addon.setSetting('availUpdateTime','')
        self.addon.setSetting('logged','false')
        self.xbmcgui.Dialog().notification('Player.pl', 'Sesja wygasła', xbmcgui.NOTIFICATION_INFO)
        self.xbmcplugin.endOfDirectory(self.addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.player_pl/,replace)')
        return

    def authCheck(self,r):
        if 'code' in r:
            if r['code']=='OAUTH_TOKEN_INVALID':
                #refresh_token
                xbmc.log('@@@Próba odświeżenia access_token', level=xbmc.LOGINFO)
                url=self.apiAuth+'token?platform='+self.platform
                data={
                    'grant_type':'refresh_token',
                    'refresh_token':self.addon.getSetting('refresh_token'),
                    'client_id':self.client_id
                }
                resp=requests.post(url,headers=self.hea,data=data).json()
                if 'access_token' in resp:
                    self.addon.setSetting('access_token',resp['access_token'])
                    self.addon.setSetting('refresh_token',resp['refresh_token'])
                    self.addon.setSetting('user_hash',resp['user_hash'])
                    self.addon.setSetting('user_pub',resp['user_pub'])
                    xbmc.log('@@@Odświeżono access_token', level=xbmc.LOGINFO)
                    return False
                else:
                    #refresh_token wygasł
                    xbmc.log('@@@refresh_token wygasł-->wylogowanie: '+str(resp), level=xbmc.LOGINFO)
                    self.paraLogOut()
            elif r['code']=='AUTHENTICATION_REQUIRED':
                self.paraLogOut()
            elif r['code']=='ITEM_NOT_PAID':
                return True
            else:
                xbmcgui.Dialog().notification('Player.pl', 'Błąd (authCheck): '+r['code'], xbmcgui.NOTIFICATION_INFO)
                return True
                
        else:
            return True
        
    