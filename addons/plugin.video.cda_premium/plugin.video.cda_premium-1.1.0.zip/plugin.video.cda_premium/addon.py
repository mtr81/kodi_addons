# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.cda_premium')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='http://smarttv.cda.pl/'
apiURL='https://api.cda.pl/'
authHea='Basic YTQ3NGQ0OWItZmQyOC00MmRhLTgwZDItOGFmNGM2NTMwODBkOkJEMmNEWnVSMGpxRHZWSGwwWjY0RWVHTVdQeFRQQzFGUVFhbGQ3bWRxWVZCVDJ4N0l6blhBN1FKUVQ3WXV0Sm0'

def heaGen(auth=True):
    HEA={
        'Accept':'application/vnd.cda.public+json',
        'Accept-Encoding':'gzip, deflate, br',
        'Referer':baseurl,
        'Origin':baseurl[:-1],
        'Connection':'keep-alive',
        'User-Agent':UA,
        'X-App-TV':'1',
        'X-App-Version':'1.1.69 build 1395',#'1.1.46 build 1233',
        'X-Device':'desktop',   
    }
    if auth:
        HEA.update({'Authorization':'Bearer '+addon.getSetting('access_token')})
    return HEA

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def directPlayer(stream_url,heaPlay):
    stream_url+='|'+urlencode(heaPlay)
    
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

    
    
def ISAplayer(protocol, stream_url, heaPlay, isDRM=False, lickey=False, drm_conf={}, sub=None, isLive=True ):
    import inputstreamhelper
    
    PROTOCOL = protocol
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)                     
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)        
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', heaPlay)
        play_item.setProperty('inputstream.adaptive.manifest_headers', heaPlay)
        if isLive:
            play_item.setProperty('ResumeTime', '43200')
            play_item.setProperty('TotalTime', '1')
        if isDRM:
            kodiVer=xbmc.getInfoLabel('System.BuildVersion')
            if int(kodiVer.split('.')[0])<22:
                play_item.setProperty('inputstream.adaptive.license_type', DRM)
                play_item.setProperty('inputstream.adaptive.license_key', lickey)
            else:
                play_item.setProperty("inputstream.adaptive.drm", json.dumps(drm_conf))
        if sub!=None:
            play_item.setSubtitles(sub)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def ISffmpegPlayer(protocol,stream_url,hea_pla):
        mimeTypes={'hls':'application/x-mpegURL','mpd':'application/xml+dash'}
        stream_url+='|'+urlencode(hea_pla)
        
        play_item = xbmcgui.ListItem(path=stream_url) 
        play_item.setMimeType(mimeTypes[protocol])
        play_item.setProperty('inputstream', 'inputstream.ffmpegdirect')
        play_item.setProperty('inputstream.ffmpegdirect.manifest_type', protocol)
        
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def encPass(x):
    import hashlib,hmac,base64,re
    
    msg=hashlib.md5(x.encode('utf-8')).hexdigest()
    key='s01m1Oer5IANoyBXQETzSOLWXgWs01m1Oer5bMg5xrTMMxRZ9Pi4fIPeFgIVRZ9PeXL8mPfXQETZGUAN5StRZ9P'
    b=hmac.new(key.encode(),msg=msg.encode(),digestmod=hashlib.sha256).digest()
    c=base64.b64encode(b).decode()
    d=c.replace('+','-').replace('/','_')
    e=re.sub('=+$','',d)
    return e

def logIn():
    Login=addon.getSetting('Login')
    Password=addon.getSetting('Password')
    if Login and Password:
        url=apiURL+'oauth/token?grant_type=password&login='+Login+'&password='+encPass(Password)
        hea=heaGen(False)
        hea.update({'Authorization':authHea})
        resp=requests.post(url,headers=hea).json()
        if 'access_token' in resp:
            addon.setSetting('access_token',resp['access_token'])
            addon.setSetting('refresh_token',resp['refresh_token'])
            exp=int(time.time())+86400
            addon.setSetting('tokenExp',str(exp))
            addon.setSetting('logged','true')
        
        else:
            xbmc.log('@@@Logowanie-błąd: '+str(resp), level=xbmc.LOGINFO)
            info=resp['error'] if 'error' in resp else 'nieokreślony'
            xbmcgui.Dialog().notification('CDA Premium', 'Błąd logowania: '+info, xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.cda_premium/,replace)')    
            
    else:
        xbmcgui.Dialog().notification('CDA Premium', 'Uzupełnij dane logowania w ustawieniach', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.cda_premium/,replace)')
     
def logOut():
    addon.setSetting('access_token','')
    addon.setSetting('refresh_token','')
    addon.setSetting('tokenExp','')
    addon.setSetting('logged','false')
    
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    xbmc.executebuiltin('Container.Update(plugin://plugin.video.cda_premium/,replace)')

def refreshToken():
    result=True
    if addon.getSetting('logged')=='true':
        if int(time.time())>=int(addon.getSetting('tokenExp')):
            url=apiURL+'oauth/token?grant_type=refresh_token&refresh_token='+addon.getSetting('refresh_token')
            hea=heaGen()
            hea['Authorization']=authHea
            resp=requests.post(url,headers=hea).json()
            if 'access_token' in resp:
                addon.setSetting('access_token',resp['access_token'])
                addon.setSetting('refresh_token',resp['refresh_token'])
                exp=int(time.time())+86400
                addon.setSetting('tokenExp',str(exp))
                xbmc.log('@@@Odświeżono access_token', level=xbmc.LOGINFO)        
            else:
                xbmc.log('@@@Refresh_token-błąd: '+str(resp), level=xbmc.LOGINFO)
                result=False 
            
    return result    
    
def userInfo():
    data=''
    if addon.getSetting('logged')=='true':
        url=apiURL+'user/me/premium'
        resp=requests.get(url,headers=heaGen()).json()
        data=''
        if 'status' in resp:
            resp=resp['status']
            data+='[B]Premium[/B]: %s\n'%(resp['premium'])
            if resp['premium']=='tak':
                data+='[B]Wygasa[/B]: %s\n'%(resp['wygasa'])
                data+='[B]TV[/B]: %s\n'%(resp['tv_access'])
        
    else:
        data='Niezalogowany'
        
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Status', data)    
   

def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':
        items=[
            ['TV','tv','DefaultTVShows.png'],
            ['Nagrania z TV','catchup','DefaultTVShows.png'],
            ['Filmy','movies','DefaultAddonVideo.png'],
            ['Seriale','series','DefaultAddonVideo.png'],
            ['Strona Główna','home','DefaultAddonVideo.png'],
            ['Wyszukiwarka','search','DefaultAddonsSearch.png'],
            ['Ulubione','favList','DefaultMusicRecentlyAdded.png'],
            ['Wyloguj','logOut','DefaultUser.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','DefaultUser.png']
        ]
    for i in items:
        setArt={'icon': i[2],'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)   

tv_packets={
    'free':['free'],
    'social':['free','social'],
    'start':['free','social','start'],
    'basic':['free','social','start','basic']
}

def accountStatus():
    data=[]
    if addon.getSetting('logged')=='true':
        url=apiURL+'user/me/premium'
        resp=requests.get(url,headers=heaGen()).json()
        data=''
        if 'status' in resp:
            isPremium=resp['status']['premium']
            tv=resp['status']['tv_access']
            tv='free' if tv=='false' else tv
            
            data=[isPremium,tv]
        
    return data
    
def tv():
    if refreshToken():
        url=apiURL+'tv/channels'
        resp=requests.get(url,headers=heaGen()).json()
        statusAcc=accountStatus()
        for r in resp['channels']:
            if r['access_type'] in tv_packets[statusAcc[1]]:
                if r['manifest_dash']!='':
                    name=r['title']
                    name=re.sub('\t', '',name)
                    cid=r['id']
                    img=r['logo_dark']
                    
                    try:
                        prog=r['program']['actual']
                        progInfo=''
                        pi=['genre','country','year']
                        for i in pi:
                            if prog[i]!='':
                                progInfo+=' | '+prog[i]
                        if progInfo.startswith(' |'):
                            progInfo=progInfo[3:]
                        epg='[B]%s - %s[/B] %s\n[I]%s[/I]\n\n%s'%(prog['start_time'],prog['end_time'],prog['title'],progInfo,prog['description'])
                        
                    except:
                        epg=''
                    
                    setArt={'poster':img,'thumb':img,'icon':img,'fanart':fanart}
                    iL={'plot':epg}
                    URL=build_url({'mode':'playTV','cid':cid})
                    addItemList(URL, name, setArt, 'video', iL, False, 'true')
        
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        logOut()
            
        
def playTV(cid):
    if refreshToken():
        url=apiURL+'tv/channels'
        resp=requests.get(url,headers=heaGen()).json()
        channel=[c for c in resp['channels'] if c['id']==cid]
        if len(channel)>0:
            chan=channel[0]
            if chan['manifest_dash']!='':
                stream_url=chan['manifest_dash']
                if chan['drm_widevine']!=None:
                    isDrm=True
                    licUrl=chan['drm_widevine']
                    heaLic={
                        'User-Agent':UA,
                        'Referer':baseurl,
                        #'Content-Type':'',
                        chan['drm_header_name']:chan['drm_header_value']
                    }
                    #K21
                    lickey='%s|%s|R{SSM}|'%(licUrl,urlencode(heaLic))
                    #K22
                    drm_config={
                        "com.widevine.alpha": {
                            "license": {
                                "server_url": licUrl,
                                "req_headers": urlencode(heaLic)
                            }
                        }
                    }
                    
                else:
                    isDrm=False
                    lickey=False
                    drm_config={}
                
                heaPlay={
                    'User-Agent':UA,
                    'Referer':baseurl
                }
                
                ISAplayer('mpd', stream_url, urlencode(heaPlay), isDrm, lickey, drm_config)
                
            else:
                xbmcgui.Dialog().notification('CDA Premium', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            
            
        else:
            xbmcgui.Dialog().notification('CDA Premium', 'Nie znaleziono kanału', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        logOut()

def catchup(p):
    if refreshToken():
        page='1' if p==None else p
        url=apiURL+'tv/catch-ups'
        urlParams={
            'count':'50',
            'page':page
        }
        resp=requests.get(url,headers=heaGen(),params=urlParams).json()
        for r in resp['data']:
            if 'tv_channel_url' in r:
                title=r['title']
                uid=r['tv_channel_url']
                img=r['tv_channel_logo']
                
                setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
                URL=build_url({'mode':'cuList','uid':uid})
                addItemList(URL, title, setArt)
            
        xbmcplugin.endOfDirectory(addon_handle)
                
    else:
        logOut()
        
def cuList(uid,p):
    if refreshToken():
        page='1' if p==None else p
        url=apiURL+'tv/channel/'+uid+'/catch-up'
        urlParams={
            'count':'50',
            'page':page
        }
        resp=requests.get(url,headers=heaGen(),params=urlParams).json()
        tvPacket=accountStatus()[1]
        for r in resp['catch_ups']:
            title,medType,iL=videoInfo(r,True)
            img=r['thumb']
            cuid=r['url']
            if r['channel']['access_type'] not in tv_packets[tvPacket]:
                isF=False
                isP='false'
                URL=build_url({'mode':'cuNotAvail'})
                title='[COLOR=gray]%s[/COLOR]'%(title)
            elif medType=='movie':
                isF=False
                isP='true'
                URL=build_url({'mode':'playCu','cuid':cuid})
            elif medType=='tvshow':
                isF=True
                isP='false'
                URL=build_url({'mode':'cuEpList','cuid':cuid})
                
            setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
            
            cmItems=[
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=cuDetails&cuid='+cuid+')'),
            ]
            
            addItemList(URL, title, setArt, 'video', iL, isF, isP, True, cmItems)
        
        if 'paginator' in resp:
            if int(page)!=resp['paginator']['total_pages']:
                next_page=str(int(page)+1)
                
                setArt={'icon':img_empty,'fanart':fanart}
                URL=build_url({'mode':'cuList','uid':uid,'page':next_page})
                addItemList(URL, '[B][COLOR=cyan]>>> następna strona[/COLOR][/B]', setArt)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle) 
    else:
        logOut()

def cuEpList(cuid):
    if refreshToken():
        url=apiURL+'tv/catch-up/'+cuid+'/episodes'
        resp=requests.get(url,headers=heaGen()).json()
        for r in resp['episodes']:
            title,medType,iL=videoInfo(r)
            img=r['thumb']
            vid=r['video']['id']
            
            setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
            URL=build_url({'mode':'playCu','cuid':cuid+'||'+vid})
            addItemList(URL, title, setArt, 'video', iL, False, 'true')
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)     
    else:
        logOut()
    

def movies():
    if refreshToken():
        setArt={'icon':'DefaultAddonVideo.png','fanart':fanart}
        #all
        URL=build_url({'mode':'contList','isS':'false'})
        addItemList(URL, '[B]Wszystkie[/B]', setArt)
        #popular
        URL=build_url({'mode':'contList','isS':'false','type':'popular'})
        addItemList(URL, '[B]Popularne[/B]', setArt)
        #categs
        url=apiURL+'video?type=premium&categories='
        resp=requests.get(url,headers=heaGen()).json()
        for r in resp['data']:
            categName=r['name']
            categID=r['id']
            count=r['video_count']
            
            plot='[B]Ilość: [/B]'+str(count)
            iL={'plot':plot}
            URL=build_url({'mode':'contList','isS':'false','categ':categID})
            addItemList(URL, categName, setArt, 'video', iL)
            
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        logOut()

contSort={
    "new": "nowo dodane",
    "views30": "popularne w ostatnich 30 dni",
    "views7": "popularne w ostatnich 7 dni",
    "views3": "popularne w ostatnich 3 dni",
    "views": "najczęściej oglądane",
    "alpha": "alfabetycznie",
    "best": "najlepiej oceniane na IMDb",
    "popular": "najcześciej oceniane na IMDb",
    "release":"data premiery kinowej"
}

def videoInfo(r,cuList=False): #helper
    title=r['title']
    medType='movie'
    mpaa=r['age_restriction'] if 'age_restriction' in r else ''
    dur=r['duration'] if 'duration' in r else 0
    if cuList:
        dur=dur*60
    if 'is_series' in r:
        if r['is_series']:
            medType='tvshow'
            title=r['folder_name'] if 'folder_name' in r else title
            dur=0
    rating=0
    if 'imdb' in r:
        if r['imdb']!=None:
            rating=float(r['imdb']['average'].replace('-','0'))
    desc=r['description'] if 'description' in r else title
    genres=r['categories'] if 'categories' in r else []
    if len(genres)==0 and 'genre' in r:
        if r['genre']!='':
            genres=[r['genre']]
    countries=r['production'] if 'production' in r else []
    
    if 'premium_free' in r:
        if r['premium_free']:
            desc+='\n\n[COLOR=cyan]Bezpłatny[/COLOR]'
    
    iL={'mediatype':medType,'title':title,'duration':dur,'mpaa':mpaa,'rating':rating,'plot':desc,'genre':genres,'country':countries}
    
    return title,medType,iL

def contDetails(vid,cu=False):
    if refreshToken():
        plot='Brak danych'
        if not cu:
            url=apiURL+'video/'+vid
        else:
            url=apiURL+'tv/catch-up/'+vid
        resp=requests.get(url,headers=heaGen()).json()
        cType='video' if not cu else 'catch_up'
        if cType in resp:
            vidData=resp[cType] if not cu else resp[cType]['video']
            title,medType,iL=videoInfo(vidData)
            plot='[COLOR=cyan][B]%s[/B][/COLOR]\n'%(title)
            if medType=='tvshow':
                plot+='[B]>>> SERIAL <<<[/B]\n'
            if len(iL['country'])>0:
                plot+='[B]Kraj: [/B]%s\n'%(', '.join(iL['country']))
            if len(iL['genre'])>0:
                plot+='[B]Gatunek: [/B]%s\n'%(', '.join(iL['genre']))
            if iL['mpaa']!='' and iL['mpaa']!=None:
                plot+='[B]Kat. wiekowa: [/B]%s\n'%(iL['mpaa'])
            if iL['rating']!=0:
                plot+='[B]Ocena (IMDB): [/B]%s\n'%(str(iL['rating']))    
            if iL['duration']!=0:
                plot+='[B]Długość: [/B]%s min.\n'%(str(int(iL['duration']/60)))
            if iL['plot']!='':
                plot+='\n%s'%(iL['plot'])
        
        dialog = xbmcgui.Dialog()
        dialog.textviewer('Szczegóły', plot)
        
    else:
        logOut()
    
def sortType(s):
    select=xbmcgui.Dialog().select('Typ sortowania', list(contSort.values()))
    if select>-1:
        sort=addon.getSetting('sort')
        if list(contSort)[select]!=sort:
            addon.setSetting('sort',list(contSort)[select])
            xbmc.executebuiltin('Container.Refresh')
        
def contList(c,t,s,p):
    if refreshToken():
        page='1' if p==None else p
        count=str(addon.getSetting('count')) #'100'
        type='premium' if t==None else 'premium_promoted'
        urlParams={
            'page':page,
            'count':count,
            'type':type
        }
        if s=='false':
            urlParams['series']='0'
        if c!=None:
            urlParams['category']=c
            
        statusAcc=accountStatus()
        if statusAcc[0]=='nie':
            urlParams['free']='1'
        
        #wybór sortowania
        sort=addon.getSetting('sort')
        sortLabel=contSort['new'] if sort=='' else contSort[sort]
        if p==None:
            setArt={'icon':'DefaultMusicPlaylists.png','fanart':fanart}
            URL=build_url({'mode':'sortType','sort':sort})
            addItemList(URL, '[B][COLOR=fuchsia]Sortowanie: [/COLOR][/B]'+sortLabel, setArt, isF=False)
        
        urlParams['sort']='new' if sort=='' else sort
        
        url=apiURL+'video'
        resp=requests.get(url,headers=heaGen(),params=urlParams).json()
        for r in resp['data']:
            vid=r['id']
            title,medType,iL=videoInfo(r)
            img=r['cover']
            
            setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
            if medType in ['movie','episode']:
                isF=False
                isP='true'
                URL=build_url({'mode':'playVid','vid':vid})
            else:
                isF=True
                isP='false'
                URL=build_url({'mode':'epList','vid':vid})
            
            cmItems=[
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=contDetails&vid='+vid+')'),
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+')'),
                ('[B]Podobne[/B]','Container.Update(plugin://plugin.video.cda_premium?mode=similarList&vid='+vid+')')
            ]
            
            addItemList(URL, title, setArt, 'video', iL, isF, isP, True, cmItems)
        
        if 'paginator' in resp:
            if int(page)!=resp['paginator']['total_pages'] and len(resp['data'])!=0:
                isS='' if s==None else s
                type='' if t==None else t
                next_page=str(int(page)+1)
                categ='' if c==None else c
                
                setArt={'icon':img_empty,'fanart':fanart}
                URL=build_url({'mode':'contList','isS':isS,'categ':categ,'type':type,'page':next_page})
                addItemList(URL, '[B][COLOR=cyan]>>> następna strona[/COLOR][/B]', setArt)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)   
    else:
        logOut()

def epList(vid):
    if refreshToken():
        url=apiURL+'video/'+vid+'/episodes'
        resp=requests.get(url,headers=heaGen()).json()
        if 'episodes' in resp:
            for r in resp['episodes']:
                eid=r['id']
                title,medType,iL=videoInfo(r)
                img=r['thumb']
                
                setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
                URL=build_url({'mode':'playVid','vid':eid})
                
                cmItems=[
                    ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=contDetails&vid='+eid+')')
                ]
                addItemList(URL, title, setArt, 'video', iL, False, 'true', True, cmItems)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)  
        
    else:
        logOut()

def similarList(vid,fid,p):
    if refreshToken():
        if p==None:
            url=apiURL+'video/'+vid
            resp=requests.get(url,headers=heaGen()).json()
            fid=resp['video']['folder_id']
            if fid==None:
                fid=resp['video']['id']
        
        page='1' if p==None else p
        count=addon.getSetting('count')
        urlParams={
            'count':str(count),
            'page':page
        }
        url=apiURL+'video/'+fid+'/similar'
        resp=requests.get(url,headers=heaGen(),params=urlParams).json()
        for r in resp['similar']:
            Vid=r['id']
            title,medType,iL=videoInfo(r)
            img=r['thumb']
            
            setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
            URL=build_url({'mode':'playVid','vid':Vid})
            
            cmItems=[
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=contDetails&vid='+Vid+')'),
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+'&search=1)'),
            ]
            
            addItemList(URL, title, setArt, 'video', iL, False, 'true', True, cmItems)
                
        if 'paginator' in resp:
            if int(page)!=resp['paginator']['total_pages']:
                next_page=str(int(page)+1)
                
                setArt={'icon':img_empty}
                URL=build_url({'mode':'similarList','fid':fid,'p':next_page})
                addItemList(URL, '[B][COLOR=cyan]>>> następna strona[/COLOR][/B]', setArt)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
        
    else:
        logOut()
        
    
def playVid(vid,cu=False):
    if refreshToken():
        if not cu:
            url=apiURL+'video/'+vid
            
        else: #catchup
            if '||' in vid: #episode
                cuid,evid=vid.split('||')
                url=apiURL+'tv/catch-up/'+cuid+'/'+evid
            else:
                url=apiURL+'tv/catch-up/'+vid
        
        h={
            'User-Agent':'pl.cda.tv 1.0 (version 1.2.41 build 12224; Android 8.0.0; Unknown sdk_google_atv_x86)',
            'Authorization':'Bearer '+addon.getSetting('access_token'),
            'Accept':'application/vnd.cda.public+json'
        }
            
        resp=requests.get(url,headers=h).json()
        if not cu:
            vidData=resp['video']
        else:
            vidData=resp['catch_up']['video']
        
        info=''
        stream_url=''
        if 'quality_adaptive' in vidData: #
            vd=vidData['quality_adaptive']
            manifest_type='manifest_vp9'if 'manifest_vp9' in vd else 'manifest'
            
            stream_url=vd[manifest_type]
            
            if stream_url==None:
                stream_url=vd['manifest_h264']
            
            heaPlay={
                'User-Agent':UA
            }
            
            if stream_url!=None:
                ISAplayer('mpd', stream_url, urlencode(heaPlay),isLive=False)
                #ISffmpegPlayer('mpd',stream_url,heaPlay)
            else:
                info='brak źródła'
            
        else:
            info='brak źródeł'
   
        
        if stream_url =='':            
            xbmcgui.Dialog().notification('CDA Premium', 'Błąd odtwarzania: '+info, xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        logOut()

def search(q,p):
    if refreshToken():
        #count='100' #str(addon.getSetting('count')) parametr nieaktywny - zawsze stronicowanie po 20 pozycji...
        page='1' if p==None else p
        url=apiURL+'video/search'
        urlParams={
            #'count':count,
            'sort':'best',
            'query':q,
            'page':page
        }
        resp=requests.get(url,headers=heaGen(),params=urlParams).json()
        for r in resp['data']:
            vid=r['id']
            title,medType,iL=videoInfo(r)
            img=r['thumb']
            
            setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
            URL=build_url({'mode':'playVid','vid':vid})            
            
            cmItems=[
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=contDetails&vid='+vid+')'),
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+'&search=1)')
            ]
            
            addItemList(URL, title, setArt, 'video', iL, False, 'true', True, cmItems)
            
        if 'paginator' in resp:
            if int(page)!=resp['paginator']['total_pages']:
                next_page=str(int(page)+1)
                
                setArt={'icon':img_empty}
                URL=build_url({'mode':'searchRes','q':q,'p':next_page})
                addItemList(URL, '[B][COLOR=cyan]>>> następna strona[/COLOR][/B]', setArt)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        logOut()

def home(p):
    if refreshToken():
        page='1' if p==None else p
        url=apiURL+'sections'
        urlParams={
            'count':'20',
            'page':page
        }
        resp=requests.get(url,headers=heaGen(),params=urlParams).json()
        if p==None:
            saveF(PATH_profile+'home.txt',str(resp['data']))
        else:
            data=eval(openF(PATH_profile+'home.txt'))
            saveF(PATH_profile+'home.txt',str(resp['data']+data))
        for r in resp['data']:
            title=r['title']
            if title!='Kontynuuj oglądanie':
                cid=str(r['id'])
                if 'categories' in r:
                    URL=build_url({'mode':'categs','cid':cid})
                else:
                    URL=build_url({'mode':'videoList','cid':cid})
                    
                setArt={'icon':'DefaultAddonVideo.png','fanart':fanart}
                addItemList(URL, title, setArt)
        
        if 'paginator' in resp:
            if int(page)!=resp['paginator']['total_pages']:
                next_page=str(int(page)+1)
                
                setArt={'icon':img_empty}
                URL=build_url({'mode':'home','page':next_page})
                addItemList(URL, '[B][COLOR=cyan]>>> następna strona[/COLOR][/B]', setArt)
            
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        logOut()

def categs(cid):
    data=eval(openF(PATH_profile+'home.txt'))
    cts=[d['categories'] for d in data if str(d['id'])==cid][0]
    for r in cts:
        title=r['title']
        img=r['thumb']
        categID=str(r['id'])
        
        setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
        URL=build_url({'mode':'contList','isS':'false','categ':categID})
        addItemList(URL, title, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)    
        
def videoList(cid):
    data=eval(openF(PATH_profile+'home.txt'))
    videos=[d['videos'] for d in data if d['id']==cid][0]
    for r in videos:
        vid=r['id']
        title,medType,iL=videoInfo(r)
        try:
            img=r['cover']
        except:
            img=r['thumb']
        
        setArt={'poster':img,'thumb':img,'banner':img,'icon':img,'fanart':fanart}
        URL=build_url({'mode':'playVid','vid':vid})            
        
        cmItems=[
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=contDetails&vid='+vid+')'),
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+'&search=1)')
        ]
        
        addItemList(URL, title, setArt, 'video', iL, False, 'true', True, cmItems)
        
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    
    
def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('CDA Premium', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('CDA Premium', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    
    url=apiURL+'tv/channels'
    resp=requests.get(url,headers=heaGen()).json()
    for r in resp['channels']:
        if r['manifest_dash']!='':
            name=r['title']
            name=re.sub('\t', '',name)
            cid=r['id']
            img=r['logo_dark']
    
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="CDA Premium" ,%s\nplugin://plugin.video.cda_premium?mode=playTV&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('CDA Premium', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
        
    else:
        xbmcgui.Dialog().notification('CDA Premium', 'Brak danych z serwera', xbmcgui.NOTIFICATION_INFO)

#FAV
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        if 'playVid' in j[0]:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True
        
        vid=dict(parse_qsl(j[0]))['vid']
        
        contMenu=True
        cmItems=[
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=contDetails&vid='+vid+')'),
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.cda_premium?mode=favDel&url='+quote(j[0])+')')
        ]
        setArt=eval(j[3])
        iL=eval(j[2])
        addItemList(j[0], j[1], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,iL,art,s):
    if s=='1': #weryfikacja czy rezultat wyszukiwania jest serialem
        if refreshToken():
            v=dict(parse_qsl(u))['vid']
            url=apiURL+'video/'+v
            resp=requests.get(url,headers=heaGen()).json()
            if resp['video']['is_series']:
                u=u.replace('playVid','epList')
        else:
            logOut()
            return
    
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,iL,art])
        xbmcgui.Dialog().notification('CDA Premium', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('CDA Premium', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)



mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='logIn':
        logIn()
        if addon.getSetting('logged')=='true':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.cda_premium/,replace)')
            
    if mode=='logOut':
        logOut()
  
    if mode=='tv':
        tv()
        
    if mode=='playTV':
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            playTV(cid)
        else:
            xbmcgui.Dialog().notification('CDA Premium', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
    
    if mode=='catchup':
        page=params.get('page')
        catchup(page)
    
    if mode=='cuList':
        uid=params.get('uid')
        page=params.get('page')
        cuList(uid,page)
        
    if mode=='cuEpList':
        cuid=params.get('cuid')
        cuEpList(cuid)
    
    if mode=='cuDetails':
        cuid=params.get('cuid')
        contDetails(cuid,True)    
    
    if mode=='playCu':
        if addon.getSetting('logged')=='true':
            cuid=params.get('cuid')
            playVid(cuid,True)
        else:
            xbmcgui.Dialog().notification('CDA Premium', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
    
    if mode=='cuNotAvail':
        xbmcgui.Dialog().notification('CDA Premium', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
    
    if mode=='movies':
        movies()
        
    if mode=='series':
        contList('43',None,None,None)
    
    if mode=='contList':
        categ=params.get('categ')
        type=params.get('type')
        isS=params.get('isS')
        page=params.get('page')
        contList(categ,type,isS,page)
    
    if mode=='sortType':
        s=params.get('sort')
        sortType(s)
    
    if mode=='epList':
        vid=params.get('vid')
        epList(vid)
        
    if mode=='similarList':
        page=params.get('p')
        vid=params.get('vid')
        fid=params.get('fid')
        similarList(vid,fid,page)
        
    if mode=='playVid':
        if addon.getSetting('logged')=='true':
            vid=params.get('vid')
            playVid(vid)
        else:
            xbmcgui.Dialog().notification('CDA Premium', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
    
    if mode=='contDetails':
        vid=params.get('vid')
        contDetails(vid)
    
    if mode=='search':   
        query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł:', type=xbmcgui.INPUT_ALPHANUM)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        if query:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.cda_premium/?mode=searchRes&q='+query+'&p=1)')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.cda_premium/,replace)')
    
    if mode=='searchRes':
        q=params.get('q')
        p=params.get('p')
        search(q,p)
        
    if mode=='home':
        page=params.get('page')
        home(page)
    
    if mode=='categs':
        cid=params.get('cid')
        categs(cid)
    
    if mode=='videoList':
        cid=params.get('cid')
        videoList(cid)
          
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            if refreshToken():
                listM3U()
            else:
                logOut()
        else:
            xbmcgui.Dialog().notification('CDA Premium', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)

    if mode=='userInfo':
        userInfo()
    
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        iL=params.get('iL')
        setart=params.get('setart')
        s=params.get('search')
        favAdd(u,t,iL,setart,s)
