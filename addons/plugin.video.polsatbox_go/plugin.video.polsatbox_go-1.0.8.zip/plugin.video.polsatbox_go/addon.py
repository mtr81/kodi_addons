# -*- coding: utf-8 -*-
import os
import sys

import urllib
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib3
import re
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

import string
import json
import time
import datetime

import base64
import hashlib
import hmac

from urllib.parse import urlencode, quote_plus, quote, parse_qsl
    
import random

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.polsatbox_go')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
img_addon='icon.png'
fanart=PATH+'/resources/img/tlo.jpg'

baseurl='https://polsatboxgo.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'
UA_post="pbg_pc_windows_firefox_html/2 (Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0)"
UA_play=" (Windows 10; widevine=true)"
userAgentData={
    "application": "firefox",
    "build": 2,
    "deviceType": "pc",
    "os": "windows",
    "osInfo": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0",
    "player": "html",
    "portal": "pbg"
}
userAgentData_play={
    "application": "firefox",
    "build": 2180100,
    "deviceType": "pc",
    "os": "windows",
    "player": "html",
    "portal": "pbg",
    "widevine": True
}
hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)
    
def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def get_sessionToken(sess_id,sess_kET,sess_key,t,e):
    r='%s|%s|%s|%s'%(sess_id,sess_kET,t,e)
    a=base64.b64decode(sess_key.replace('-','+').replace('_','/'))

    def sign_string(key, to_sign):
        signed_hmac_sha256 = hmac.HMAC(key, to_sign.encode(), hashlib.sha256)
        digest = signed_hmac_sha256.digest()
        return base64.b64encode(digest).decode()
            
    hash=sign_string(a,r).replace('+','-').replace('/','_')
    sessionToken=r+'|'+hash
    return sessionToken

mainCategs=[]
    
def main_menu():
    if addon.getSetting('logged')=='true':
        categs=getCategories()
        if categs==False: #
            return
        for c in categs:
            if c[1]=='category':
                mainCategs.append([c[0],c[2],'subCateg','DefaultAddonVideo.png'])
            elif c[1]=='tv_channels':
                mainCategs.append([c[0],'','tv','DefaultTVShows.png'])
            elif c[1]=='live_channels':
                mainCategs.append([c[0],'','live','DefaultTVShows.png'])
        mainCategs.append(['Ulubione','','favList','DefaultMusicRecentlyAdded.png'])
        mainCategs.append(['Wyszukiwarka','','search','DefaultAddonsSearch.png'])
        mainCategs.append(['Wyloguj','','logOut','DefaultUser.png'])
    else:
        mainCategs.append(['Zaloguj','','logIn','DefaultUser.png'])
    for s in mainCategs:
        isF=False if s[2] in ['search','logIn','logOut'] else True
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': s[3], 'fanart':fanart}
        url = build_url({'mode':s[2],'categ':s[1]})
        addItemList(url, s[0], setArt, isF=isF)
    xbmcplugin.endOfDirectory(addon_handle)

def logIn():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    usr = addon.getSetting('username')
    password = addon.getSetting('password')
    
    if usr and password:    
        data_js = {
            "id": 1,
            "jsonrpc": "2.0",
            "method": "login",
            "params": {
                "authData": {
                    "authProvider":"sso",
                    "deviceId": {
                        "type": "other",
                        "value": deviceid
                    },
                    "login": usr,
                    "password": password
                },
                "clientId": clientid,
                "deviceId": {
                    "type": "other",
                    "value": deviceid
                },
                "ua": UA_post,
                "userAgentData": userAgentData
            }
        }
        logMethod=addon.getSetting('logMethod')
        
        if logMethod=='inne dane':
            data_js['params']['authData'].pop("authProvider",None)
        
        resp = requests.post('https://b2c-www.redefine.pl/rpc/auth/login/', json=data_js, headers=hea).json()
        if 'error' in resp:
            if resp['error']['message']=='Not found error' or resp['error']['message']=='Unauthorized access':
                xbmcgui.Dialog().notification('PolsatBox Go', resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
            else:
                try:
                    xbmcgui.Dialog().notification('PolsatBox Go', '[B]Błąd logowania: [/B]'+ resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
                except:
                    xbmcgui.Dialog().notification('PolsatBox Go', 'Nieokreślony błąd logowania', xbmcgui.NOTIFICATION_INFO)

        elif 'result' in resp:
            addon.setSetting('sessId',resp['result']['session']['id'])
            addon.setSetting('sessKey',resp['result']['session']['key'])
            addon.setSetting('sessKeyExp',str(resp['result']['session']['keyExpirationTime']))
            addon.setSetting('sessUpdateTime',str(int(time.time())))
            addon.setSetting('logged','true')
            getClientContextToken()
            xbmcgui.Dialog().notification('PolsatBox Go', 'Zalogowano', xbmcgui.NOTIFICATION_INFO)
        else:
            pass
            
    else:
        xbmcgui.Dialog().notification('PolsatBox Go', 'Uzupełnij dane logowania w ustawieniach', xbmcgui.NOTIFICATION_INFO)

    
def logOut():
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'auth','logout')
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "logout",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp= requests.post('https://b2c-www.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        if resp['result']['status']==0:
            xbmc.log('@@@Wylogowanie systemowe', level=xbmc.LOGINFO)
    else:
        xbmc.log('@@@Błąd_logOut: '+str(resp), level=xbmc.LOGINFO)
        xbmc.log('@@@para-Logout', level=xbmc.LOGINFO)

    addon.setSetting('sessId','')
    addon.setSetting('sessKeyExp','')
    addon.setSetting('sessKey','')
    addon.setSetting('logged','false')
    addon.setSetting('sessUpdateTime','')
    addon.setSetting('ClientContextToken','')
    xbmcgui.Dialog().notification('PolsatBox Go', 'Wylogowano', xbmcgui.NOTIFICATION_INFO)

def error():
    xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go/?mode=start,replace)')
    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)

def getSettings():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    return clientid,deviceid,sessId,sessKeyExp,sessKey

def getSession(afterErr=False): #wywoływana raz /24h
    if addon.getSetting('logged')=='true': #nowa sesja
        sessUpdateTime=addon.getSetting('sessUpdateTime')
        sessUpdateTime=0 if sessUpdateTime=='' or sessUpdateTime==None else int(sessUpdateTime)
        now=int(time.time())
        if now-sessUpdateTime>=24*60*60 or afterErr:
            clientid=addon.getSetting('clientid')
            deviceid=addon.getSetting('deviceid')
            sessId=addon.getSetting('sessId')
            sessKeyExp=addon.getSetting('sessKeyExp')
            sessKey=addon.getSetting('sessKey')
            
            sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'auth','getSession')
            data_js={
                "id": 1,
                "jsonrpc": "2.0",
                "method": "getSession",
                "params": {
                    "authData": {
                        "sessionToken": sessToken
                    },
                    "clientId": clientid,
                    "deviceId": {
                        "type": "other",
                        "value": deviceid
                    },
                    "ua": UA_post,
                    "userAgentData": userAgentData
                }
            }
            resp= requests.post('https://b2c-www.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
            if 'result' in resp:
                addon.setSetting('sessId',resp['result']['session']['id'])
                addon.setSetting('sessKey',resp['result']['session']['key'])
                addon.setSetting('sessKeyExp',str(resp['result']['session']['keyExpirationTime']))
                addon.setSetting('sessUpdateTime',str(int(time.time())))
                getClientContextToken()
                xbmc.log('@@@Nowa sesja', level=xbmc.LOGINFO)
            else:#token wygasł
                xbmc.log('@@@token wygasł: '+str(resp), level=xbmc.LOGINFO)
                xbmc.log('@@@Nie można odświeżyć sesji-próba przelogowania (logowanie login/pass', level=xbmc.LOGINFO)
                addon.setSetting('sessId','')
                addon.setSetting('sessKeyExp','')
                addon.setSetting('sessKey','')
                addon.setSetting('sessUpdateTime','')
                addon.setSetting('ClientContextToken','')
                addon.setSetting('logged','false')
                #xbmcgui.Dialog().notification('PolsatBox Go', 'Przelogowanie: nie można odświeżyć sesji', xbmcgui.NOTIFICATION_INFO)
                logIn()

def getClientContextToken(): #2024-05-25
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'system','getClientContextToken')
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getClientContextToken",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    
    resp= requests.post('https://b2c-www.redefine.pl/rpc/system/', json=data_js, headers=hea).json()
    categs=[]
    if 'errors' not in resp and 'result' in resp:
        addon.setSetting('ClientContextToken',resp['result'])
    
def getCategories():
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getHomeMenu')
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getHomeMenu",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    
    resp= requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js, headers=hea).json()
    categs=[]
    if 'errors' not in resp and 'result' in resp:
        for r in resp['result']:
            if r['name']!='Moja lista':
                categs.append([r['name'],r['place']['type'],r['place']['value']])
        return categs
    else:
        xbmc.log('@@@Błąd_getCategories: '+str(resp), level=xbmc.LOGINFO)
        error()
        return False

def getImage(x):#
    def sortFN(i):
        return i['size']['width']
    x.sort(key=sortFN,reverse=True)
    img=x[0]['src'] if len(x)>0 else img_empty
    return img
    
def locTime(x):#
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    z=(y+diff+datetime.timedelta(seconds=1)).strftime('%Y-%m-%d %H:%M')
    return z

def getEPG(TV_list):#
    chansId=[r['id'] for r in TV_list['result']['results']]
    
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getChannelsCurrentProgram')
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getChannelsCurrentProgram",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "channelIds":chansId,
            "limit": 2,
            "offset": 0,
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        return resp['result']
    else:
        xbmc.log('@@@Błąd_getEPG: '+str(resp), level=xbmc.LOGINFO)
        error()
        return False

def plotEPG(data,c):#
    plot=''
    if c in data:
        for p in data[c]:
            title=p['title']
            genre=p['genre']
            startTime=locTime(p['startTime']).split(' ')[1]
            plot+='[B]%s[/B] %s'%(startTime,title)
            if genre!='':
                plot+=' - [I]%s[/I]\n'%(genre)
            else:
                plot+='\n'
    return plot

def getTVList(limit=200,offset=0):#
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getTvChannels')
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getTvChannels",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "filters": [],
            "limit": limit,
            "offset": offset,
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        return resp
    else:
        xbmc.log('@@@Błąd_getTVList: '+str(resp), level=xbmc.LOGINFO)
        error()
        return False

def setTvCateg():
    tv_categ=addon.getSetting('tv_categ')
    tv_categ='Wszystkie' if tv_categ=='' else tv_categ
        
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getTvChannelsFlatNavigation')
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getTvChannelsFlatNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "filters": [],
            "limit": 100,
            "offset": 0,
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        categs=['Wszystkie']
        categs+=[c['value'] for c in resp['result']['filterLists'][0]['filters']]
        select=xbmcgui.Dialog().select('Kategoria:', categs)
        if select>-1:
            new_tv_categ=categs[select]
        else:
            new_tv_categ=tv_categ
        
        if new_tv_categ!=tv_categ:
            addon.setSetting('tv_categ',new_tv_categ)
            xbmc.executebuiltin('Container.Refresh()')

        
    else:
        xbmc.log('@@@Błąd_getTVList: '+str(resp), level=xbmc.LOGINFO)
        error()
        return False

def tv():
    resp=getTVList()
    if resp==False:
        return
    chans=resp['result']['results']
    if len(resp['result']['results'])==200:
        resp2=getTVList(200,200)
        if resp2==False:
            return
        chans+=resp2['result']['results']
        
    EPG=getEPG(resp)
    if EPG==False:
        return
        
    #wybór kategorii
    tv_categ=addon.getSetting('tv_categ')
    tv_categ='Wszystkie' if tv_categ=='' else tv_categ
    
    img='DefaultGenre.png'
    title='[COLOR=cyan]Kategoria:[/COLOR] %s'%(tv_categ)
    setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
    url = build_url({'mode':'setTvCateg'})
    addItemList(url, title, setArt, isF=False)
    
    for r in chans:
        if tv_categ=='Wszystkie' or tv_categ in r['genres']:
            title=r['title']
            mediaid=r['id']
            cpid=str(r['cpid'])
            img=getImage(r['thumbnails'])
            plot=plotEPG(EPG,mediaid)
             
            setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
            iL={'title': title,'sorttitle': title,'plot': plot}
            url = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'tv'})
            addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)    

def live():
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getLiveChannelsWithTreeNavigation')
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getLiveChannelsWithTreeNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        for r in resp['result']['results']:
            cpid=str(r['cpid'])
            mediaid=r['id']
            title=r['title']
            img=getImage(r['thumbnails'])
            date=locTime(r['publicationDate'])
            plot='[B]Początek transmisji: [/B]'+date
            if r['published']==False:
                url = build_url({'mode':'playINFO','info':'Transmisja nie jest jeszcze prowadzona'})
                isPlayable='false'
            else:
                url = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'live'})
                isPlayable='true'
            
            setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
            iL={'title': '','sorttitle': '','plot': plot}
            addItemList(url, title, setArt, 'video', iL, False, isPlayable)
        xbmcplugin.endOfDirectory(addon_handle) 
    else:
        xbmc.log('@@@Błąd_live: '+str(resp), level=xbmc.LOGINFO)
        error()

def subCateg(categ):
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getCategoryWithFlatNavigation')
    
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getCategoryWithFlatNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(categ),
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        subcategs=[['[B]Wszystkie[/B]','']]
        s=[c['filters'] for c in resp['result']['flatNavigation']['filterLists'] if c['name']=='Gatunki']
        if len(s)==1:
            for ss in s[0]:
                subcategs.append([ss['name'],ss['value']])
        for sb in subcategs:
            setArt={'thumb': '', 'poster': '', 'banner': '','icon':'DefaultGenre.png','fanart':fanart}
            url = build_url({'mode':'contentList','categ':categ,'subcateg':sb[1],'page':'1'})
            addItemList(url, sb[0], setArt)
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_subCateg: '+str(resp), level=xbmc.LOGINFO)
        error()

def contData(resp):#
    for r in resp['result']['results']:
        if 'catchUpEntry' not in r:
            cid=str(r['id'])
            cpid=str(r['cpid'])
            genre=r['genres']#'/'.join(r['genres'])
            desc=r['description']
            img=getImage(r['thumbnails'])
            if 'mediaType' in r:
                title=r['title']
                age=str(r['ageGroup']) if 'ageGroup' in r else ''
                countries=r['countries'] if 'countries' in r else []
                dur=r['duration'] if 'duration' in r else 0
                mediaid=r['id']
                isPlayable='true'
                isFolder=False
                #URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
                
                if r['mediaType']=='movie':
                    originaltitle=r['originalTitle'] if 'originalTitle' in r else ''
                    year=r['releaseYear'] if 'releaseYear' in r else 0
                    infoLab={'title': title,'sorttitle': title,'mpaa':age,'genre':genre,'plot': desc,'year': year,'country': countries,'originaltitle':originaltitle,'duration':dur,'mediatype':'movie'}    
                    URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
                elif r['mediaType']=='vod': 
                    epNumber=r['episodeNumber'] if 'episodeNumber' in r else 0
                    try:
                        seasNumber=r['category']['seasonNumber']
                    except:
                        seasNumber=0
                    infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'country': countries,'season':seasNumber,'episode':epNumber,'duration':dur,'mediatype':'episode'}
                    URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
                elif r['mediaType']=='live':#dla search
                    date=locTime(r['publicationDate'])
                    plot='[COLOR=yellow]Transmisja na żywo[/COLOR]\n[B]Początek transmisji: [/B]'+date
                    infoLab={'title': '','sorttitle': '','plot': plot}
                    if r['published']==False:
                        URL = build_url({'mode':'playINFO','info':'Transmisja nie jest jeszcze prowadzona'})
                        isPlayable='false'
                    else:
                        URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'live'})
                        isPlayable='true'
                elif r['mediaType']=='tv':#dla search
                    plot='[COLOR=yellow]Kanał TV[/COLOR]\n'+desc
                    URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'tv'})
                    infoLab={'title': '','sorttitle': '','plot': plot}
                
            elif 'subCategoriesLabel' in r:
                title=r['name']
                isPlayable='false'
                isFolder=True
                if r['subCategoriesLabel']=='Serie':
                    mod='seasonList'#'contentList'   
                    URL= build_url({'mode':mod,'cid':cid})#build_url({'mode':mod,'categ':cid,'page':'1'})
                elif r['subCategoriesLabel']=='Sezony':
                    mod='seasonList' 
                    URL= build_url({'mode':mod,'cid':cid})
                infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'mediatype':'tvshow'}
            
            else:
                ct=r['reporting']['playerEvents']['contentItem']['type']
                title=r['name']
                if ct=='category':
                    isPlayable='false'
                    isFolder=True
                    URL=build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
                    infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'mediatype':'tvshow'}
                else:#do sprawdzenia i ewentualnej rozbudowy 
                    title='[COLOR=yellow]'+r['name']+'[/COLOR]'
                    isPlayable='false'
                    isFolder=False
                    URL=''
                    infolab={}

            cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.polsatbox_go?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&infoLab='+quote(str(infoLab))+'&img='+quote(img)+')')]
            setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
            addItemList(URL, title, setArt, 'video', infoLab, isFolder, isPlayable, True, cmItems)
    
def contentList(categ,subcateg,page,sortBy):
    count=min(200,int(addon.getSetting('count'))) #max ilość wyników zwracana przez serwer: 200
    start=(int(page)-1)*count
    
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getCategoryContentWithFlatNavigation')

    data_js={"catid":int(categ),"collection":{"default":True,"name":"Alfabetycznie","type": "sortedby","value":"13"},"filters":[],"limit":count,"offset":start}
    #data_js='{"catid":5024044,"collection":{"default":true,"name":"Alfabetycznie","type":"sortedby","value":"13"},"filters":[],"limit":40,"offset":0}'
    
    if subcateg !=None:
        data_js.update({"filters":[{"type": "genres","value": [subcateg]}]})
    sortList=addon.getSetting('sortList')
    if sortBy =='addDate' or sortList=='data dodania':#dla odcinków sortowanie wg daty dodania
        data_js['collection'].update({'name':'Data dodania','value':'12'})
    
    hea.update({
        'X-Auth-Data-Session-Id':sessId,
        'X-Auth-Data-Session-Token':sessToken,
        'X-Client-Context-Token':addon.getSetting('ClientContextToken'),
        'X-Client-Id':clientid,
        'X-Device-Id-Type':'other',
        'X-Device-Id-Value':deviceid,
        'X-User-Agent-Data-Application':userAgentData['application'],
        'X-User-Agent-Data-Build':str(userAgentData['build']),
        'X-User-Agent-Data-Device-Type':userAgentData['deviceType'],
        'X-User-Agent-Data-Os':userAgentData['os'],
        'X-User-Agent-Data-Os-Info':userAgentData['osInfo'],
        'X-User-Agent-Data-Player':userAgentData['player'],
        'X-User-Agent-Data-Portal':userAgentData['portal']   
    })
    urlParams={
        'id':'1',
        'method':'getCategoryContentWithFlatNavigation',
        'params':base64.b64encode(json.dumps(data_js).replace('True','true').encode()).decode()
    }
    resp = requests.get('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea,params=urlParams).json()
    if 'errors' not in resp and 'result' in resp:
        contData(resp)
        nextPage=False
                
        if int(page)*count<resp['result']['total']:
            nextPage=True
                    
        if nextPage:
            setArt={'thumb': '', 'poster': '', 'banner': '','icon':'','fanart':fanart}
            subcateg_='' if subcateg==None else subcateg
            sortBy_='' if sortBy==None else sortBy
            url = build_url({'mode':'contentList','categ':categ,'subcateg':subcateg_,'page':str(int(page)+1),'sortBy':sortBy_,'count':count})
            addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt, 'video')
        
        xbmcplugin.setContent(addon_handle, 'videos')
        if sortBy!=None and not nextPage and page=='1': #episodes
            xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_EPISODE)
        xbmcplugin.endOfDirectory(addon_handle)

    else:
        xbmc.log('@@@Błąd_contentList: '+str(resp), level=xbmc.LOGINFO)
        error()
    
def seasonList(cid):
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getSubCategories')
    
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getSubCategories",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(cid),
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        if len(resp['result'])<=1:
            contentList(cid,None,'1','addDate')#str(resp['result'][0]['id'])
        else:
            #wszystkie odcinki
            setArt={'thumb': '', 'poster': '', 'banner': '','icon':'DefaultAddonVideo.png','fanart':fanart}
            iL={'plot':'Wszystkie odcinki'}
            url = build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
            addItemList(url, '[B]Wszystkie odcinki[/B]', setArt, 'video', iL)
            #lista sezonów
            for r in resp['result']:
                cid=str(r['id'])
                name=r['name']
                desc=r['description']
                img=getImage(r['thumbnails'])
                seasNumb=r['seasonNumber'] if 'seasonNumber' in r else 0
                
                setArt={'thumb': img, 'poster': img, 'banner': img,'icon':'DefaultAddonVideo.png','fanart':fanart}
                iL={'title': name,'sorttitle': name,'plot': desc,'season':seasNumb,'mediatype':'season'}
                url = build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
                addItemList(url, name, setArt, 'video', iL)
            xbmcplugin.setContent(addon_handle, 'videos')
            xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_contentList: '+str(resp), level=xbmc.LOGINFO)
        error()        
    
def playCont(mediaid,cpid,type,s,e,c_dur):
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    #sprawdzenie dostępności
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','checkProductAccess')
    
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "checkProductAccess",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "product": {
                "id": mediaid,
                "subType": type,
                "type": "media"
            },
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c-www.redefine.pl/rpc/drm/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        if resp['result']['statusDescription']!='no access':
        
            #dane do odtwarzacza
            sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','prePlayData')
            
            data_js={
                "id": 1,
                "jsonrpc": "2.0",
                "method": "prePlayData",
                "params": {
                    "authData": {
                        "sessionToken": sessToken
                    },
                    "clientId": clientid,
                    "cpid": int(cpid),
                    "mediaId": mediaid,
                    "ua": UA_post+UA_play,
                    "userAgentData": userAgentData_play
                }
            }
            resp = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
            mediaSources=resp['result']["mediaItem"]['playback']['mediaSources']

            def sortFN(i):
                return int(i['quality'].replace('p',''))
            mediaSources.sort(key=sortFN,reverse=True)
            #odtwarzanie
            if 'widevine' in mediaSources[0]['authorizationServices']:
                isDRM=True
            elif 'pseudo' in mediaSources[0]['authorizationServices']:
                isDRM=False
            if mediaSources[0]['accessMethod']=='direct': #MP4
                player='direct'
            elif mediaSources[0]['accessMethod']=='dash':
                player='ISA'
                
            if isDRM==False:    
                sourceId=mediaSources[0]['id']
                clientid=addon.getSetting('clientid_player')
                deviceid=addon.getSetting('deviceid_player')
                
                sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','getPseudoLicense')
                
                data_js={
                    "id": 1,
                    "jsonrpc": "2.0",
                    "method": "getPseudoLicense",
                    "params": {
                        "authData": {
                            "sessionToken": sessToken
                        },
                        "clientId": clientid,
                        "cpid": int(cpid),
                        "deviceId": {
                            "type": "other",
                            "value": deviceid
                        },
                        "mediaId": mediaid,
                        "sourceId": sourceId,
                        "ua": "pbg_pc_windows_firefox_html/2180100",
                        "userAgentData": {
                            "application": "firefox",
                            "build": 2180100,
                            "deviceType": "pc",
                            "os": "windows",
                            "player": "html",
                            "portal": "pbg",
                            "widevine": True
                        }
                    }
                }
                resp = requests.post('https://b2c.redefine.pl/rpc/drm/', json=data_js,headers=hea).json()
                stream_url=resp['result']['url']+'|User-Agent='+UA+'&Referer='+baseurl
                
                
            if player=='ISA': #dash
                if isDRM: #DRM
                    keyId= mediaSources[0]['keyId']
                    stream_url=mediaSources[0]['url']
                    sourceId=mediaSources[0]['id']
                    
                    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','getWidevineLicense')
                    clientid=addon.getSetting('clientid_player')
                    deviceid=addon.getSetting('deviceid_player')
                    
                    licURL = 'https://b2c-www.redefine.pl/rpc/drm/'
                    heaLic={
                        'User-Agent':UA
                    }
                    
                    data_lic={
                        "id":1,
                        "jsonrpc":"2.0",
                        "method":"getWidevineLicense",
                        "params":{
                            "clientId":clientid,
                            "cpid":int(cpid),
                            "deviceId":{
                                "type":"other",
                                "value":deviceid
                            },
                            "keyId":keyId,
                            "mediaId":mediaid,
                            "object":"b{SSM}",
                            "sourceId":sourceId,
                            "ua":"pbg_pc_windows_firefox_html/2180100",
                            "authData":{
                                "sessionToken":sessToken
                            },
                            "userAgentData":{
                                "deviceType":"pc",
                                "application":"firefox",
                                "os":"windows",
                                "build":2180100,
                                "portal":"pbg",
                                "player":"html",
                                "widevine":True
                            }
                        }
                    }
                    lickey='%s|%s|%s|JBlicense'%(licURL,urlencode(heaLic),quote(json.dumps(data_lic)))
                    #K22
                    data_lic['params']['object']="{CHA-B64}"
                    drm_config={
                        'com.widevine.alpha': {
                            'license': {
                                'server_url':licURL,
                                'req_headers':urlencode(heaLic),
                                'req_data':base64.b64encode(json.dumps(data_lic).encode()).decode(),
                                'unwrapper':'json,base64',
                                'unwrapper_params': {'path_data': 'result/object/license'}
                            }
                        }
                    }
                
                import inputstreamhelper
                PROTOCOL = 'mpd'
                DRM = 'com.widevine.alpha'
                if isDRM:
                    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
                else:
                    is_helper = inputstreamhelper.Helper(PROTOCOL)
                if is_helper.check_inputstream():
                    play_item = xbmcgui.ListItem(path=stream_url)           
                    play_item.setMimeType('application/xml+dash')
                    play_item.setContentLookup(False)
                    play_item.setProperty('inputstream', is_helper.inputstream_addon)
                    play_item.setProperty("IsPlayable", "true")
                    play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                    if type=='tv':
                        play_item.setProperty('inputstream.adaptive.manifest_config','{\"timeshift_bufferlimit\":43200}')#K21
                    play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA) #K21
                    play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
                    if s!=None:
                        ts=datetime.datetime(*(time.strptime(s,'%Y%m%d_%H%M%S')[0:6])).timestamp()
                        te=datetime.datetime(*(time.strptime(e,'%Y%m%d_%H%M%S')[0:6])).timestamp()
                        now=int(time.time())
                        if te>now-int(c_dur):
                            offset=max(1,int(c_dur)-(now-int(ts)))
                            play_item.getVideoInfoTag().setResumePoint(offset,1)
                        else:
                            cut=str((int(int(c_dur)/3600)))
                            xbmcgui.Dialog().notification('PolsatBox Go - [LIVE]', 'Okres catch-up: %sH'%(cut), xbmcgui.NOTIFICATION_INFO)
                            
                    if isDRM:
                        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
                        if int(kodiVer.split('.')[0])<22:
                            play_item.setProperty('inputstream.adaptive.license_type', DRM)
                            play_item.setProperty('inputstream.adaptive.license_key', lickey)
                        else:
                            play_item.setProperty('inputstream.adaptive.drm', json.dumps(drm_config))
                            play_item.setProperty('inputstream.adaptive.config', '{"check_hdcp":"license"}')
                    
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
            
            elif player=='direct': #mp4
                play_item = xbmcgui.ListItem(path=stream_url)
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
        else:
            xbmcgui.Dialog().notification('PolsatBox Go', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        xbmc.log('@@@Błąd_playCont: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        error()


def search(q):
    clientid,deviceid,sessId,sessKeyExp,sessKey=getSettings()
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','searchContent')
    
    data_js={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "searchContent",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "limit": 50,
            "query": q,
            "ua": UA_post,
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c-www.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        contData(resp)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_playCont: '+str(resp), level=xbmc.LOGINFO)
        error()

def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('PolsatBox Go', 'Podaj nazwę pliku oraz katalog docelowy', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('PolsatBox Go', 'Generuję listę M3U', xbmcgui.NOTIFICATION_INFO)
    chans=getTVList()
    data = '#EXTM3U\n'
    for c in chans['result']['results']:
        chName=c['title']
        mediaid=c['id']
        cpid=str(c['cpid'])
        img=getImage(c['thumbnails'])
        t_dur=c['timeShiftingDuration']
        if t_dur>180:
            c_dur=str(t_dur)
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="PolsatBox Go" catchup="append" catchup-source="&s={utc:Ymd_HMS}&e={utcend:Ymd_HMS}" catchup-days="1" catchup-correction="0.0" ,%s\nplugin://plugin.video.polsatbox_go?mode=playTV&mediaid=%s&cpid=%s&type=tv&c_dur=%s\n' %(chName,img,chName,mediaid,cpid,c_dur)
        else:
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="PolsatBox Go" ,%s\nplugin://plugin.video.polsatbox_go?mode=playTV&mediaid=%s&cpid=%s&type=tv\n' %(chName,img,chName,mediaid,cpid)

    
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('PolsatBox Go', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        URL=j[0]
        if 'playCont' in URL:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        cmItems=[('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.polsatbox_go?mode=favDel&url='+quote(j[0])+')')]
        setArt={'thumb': j[3], 'poster': j[3], 'banner': j[3], 'icon': j[3], 'fanart':fanart}
        addItemList(URL, j[1], setArt, 'video', eval(j[2]), isFolder, isPlayable, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,l,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,l,i])
        xbmcgui.Dialog().notification('PolsatBox Go', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('PolsatBox Go', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('PolsatBox Go', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('PolsatBox Go', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)  


mode = params.get('mode', None)

if not mode:
    if addon.getSetting('deviceid')=='':
        def serialNumberGen():
            return '%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12))
        addon.setSetting('deviceid',serialNumberGen())
        addon.setSetting('clientid',serialNumberGen())
        addon.setSetting('deviceid_player',code_gen(32)+'_')
        addon.setSetting('clientid_player',serialNumberGen())       
    main_menu()

else:
    if mode=='start': #próba odświeżenia sesji po błędzie w resp
        getSession(True)        
        main_menu()
        
    if mode=='logIn':
        logIn()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go/,replace)')
    
    if mode=='logOut':
        logOut()
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go/,replace)')
    
    if mode=='tv':
        tv()
        
    if mode=='setTvCateg':
        setTvCateg()
        
    if mode=='live':
        live()
        
    if mode=='subCateg':
        c=params.get('categ')
        subCateg(c)
        
    if mode=='contentList':
        c=params.get('categ')
        sc=params.get('subcateg')
        p=params.get('page')
        o=params.get('sortBy')
        contentList(c,sc,p,o)
    
    if mode=='playCont':
        mediaid=params.get('mediaid')
        cpid=params.get('cpid')
        type=params.get('type')
        s=params.get('s')
        e=params.get('e')
        c_dur=params.get('c_dur')
        playCont(mediaid,cpid,type,s,e,c_dur)
    
    if mode=='playINFO':
        info=params.get('info')
        xbmcgui.Dialog().notification('PolsatBox Go', info, xbmcgui.NOTIFICATION_INFO)
        
    if mode=='seasonList':
        cid=params.get('cid')
        seasonList(cid)
    
    if mode=='search':
        qry=xbmcgui.Dialog().input(u'Szukaj:', type=xbmcgui.INPUT_ALPHANUM)
        if qry:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go/?mode=searchRes&q='+quote(qry)+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go/,replace)')
    
    if mode=='searchRes':
        q=params.get('q')
        search(q)
    
    if mode=='listM3U':
        listM3U()
    
    if mode=='playTV':
        getSession()
        if addon.getSetting('logged')=='true':
            mediaid=params.get('mediaid')
            cpid=params.get('cpid')
            type=params.get('type')
            s=params.get('s')
            e=params.get('e')
            c_dur=params.get('c_dur')
            playCont(mediaid,cpid,type,s,e,c_dur)
        else:
            xbmcgui.Dialog().notification('PolsatBox Go', 'Zaloguj się we wtyczce', xbmcgui.NOTIFICATION_INFO)
        
    #FAV
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        l=params.get('infoLab')
        i=params.get('img')
        favAdd(u,t,l,i)
        
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
      