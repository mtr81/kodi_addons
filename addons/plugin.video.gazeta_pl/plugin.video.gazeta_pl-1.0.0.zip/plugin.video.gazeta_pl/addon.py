# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from resources.lib.yt_live import play_yt, epgData

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.gazeta_pl')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

mode = addon.getSetting('mode')
baseurl=''
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

hea={
    'User-Agent':UA,
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def main_menu():
    items=[
        ['Programy','progs','DefaultAddonVideo.png'],
        ['Transmisje na żywo (YT)','live','DefaultTVShows.png']
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart':''}
        url = build_url({'mode':i[1]})
        if i[1]=='live':
            cm=True
            cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.gazeta_pl?mode=epg)')]
            plot='[B]Transmisje okazjonalne[/B]\n [I]Planowane transmisje dostępne z poziomu menu kontekstowego (szczegóły)[/I]'
            isFolder=False
            isPlayable='true'
        else:
            cm=False
            cmItems=[]
            plot=''
            isFolder=True
            isPlayable='false'
        iL={'plot':plot}
        addItemList(url, i[0], setArt, 'video', iL, isFolder, isPlayable, cm, cmItems)
    xbmcplugin.endOfDirectory(addon_handle)

    

def progs():
    items=[
        ['Poranna rozmowa','https://wiadomosci.gazeta.pl/poranna-rozmowa-gazeta-pl'],
        ['Studio biznes','https://next.gazeta.pl/studio-biznes'],
        #['Gwiazdy lat 90.','https://www.plotek.pl/gwiazdy-lat-90'],
        #['Oskarżam','https://wiadomosci.gazeta.pl/oskarzam-cykl-kryminalny-gazeta-pl'],
    ]
    
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultAddonVideo.png', 'fanart':''}
        url = build_url({'mode':'epList','link':i[1],'page':'1'})
        addItemList(url, i[0], setArt, 'video')

    xbmcplugin.endOfDirectory(addon_handle)
    
def epList(l,p):
    url=l if p=='1' else l+'/'+p
    resp=requests.get(url,headers=hea).text
    resp0=resp.split('<section class=\"body\"')[1].split('</section')[0]
    resp1=resp0.split('<li class=\"entry\"')
    items=[]
    for r in resp1:
        if 'article' in r and 'lead' in r:
            link,name=re.compile('<a href=\"([^\"]+?)\" title=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('<img[^=]+?src=\"([^\"]+?)\"').findall(r)[0]
            desc=r.split('\"lead\">')[1].split('</p>')[0].strip()
            
            iL={'plot':unescape(desc)}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
            url = build_url({'mode':'playVid','link':link})
            addItemList(url, unescape(name), setArt, 'video', iL, False, 'true')
    
    if '\"pagination\"' in resp:
        resp2=resp.split('\"pagination\"')[1]
        if 'rel=\"next\"' in resp2:
            next_page=str(int(p)+1)
            
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''}
            url = build_url({'mode':'epList','link':l,'page':next_page})
            addItemList(url, '[B][COLOR=yellow]>>> następna strona[/COLOR][/B]', setArt, 'video')
            
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def playVid(l):
    resp=requests.get(l,headers=hea).text
    if '\"video-head\"' in resp:
        resp1=resp.split('class=\"video-head\"')[1]
        embURL=re.compile('data-src=\"([^\"]+?)\"').findall(resp1)[0]
    elif '\"video_wrapper\"' in resp:
        resp1=resp.split('class=\"video_wrapper\"')[1]
        embURL=re.compile('src=\"([^\"]+?)\"').findall(resp1)[0]
    else: 
        resp1=None
    if resp1!=None:
        #print(embURL)
        hea.update({'Referer':l})
        resp_emb=requests.get(embURL,headers=hea).text
        ver=re.compile('\"version\":\"([^\"]+?)\"').findall(resp_emb)[0]
        mid=re.compile('\"mid\":\"([^\"]+?)\"').findall(resp_emb)[0]
        u=re.compile('_ONND_URL_EMBED = \'([^\']+?)\'').findall(resp_emb)[0]
        emb2URL=u+'/frame'+ver+'.php?mid='+mid
        resp_emb2=requests.get(emb2URL,headers=hea).text
        #print(resp_emb2)
        dataPlayer=re.compile('var playerVideos = (.*);}\n').findall(resp_emb2)[0]
        #print(dataPlayer)
        dataPlayerJSON=json.loads(dataPlayer)
        #print(dataPlayerJSON[0])
        stream_url=dataPlayerJSON[0]['url']
        sourceType=dataPlayerJSON[0]['sourcetype']
        print(stream_url)
        print(sourceType)#hls
        if sourceType=='hls':
            import inputstreamhelper
            PROTOCOL = 'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=stream_url)
                #play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA)
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)    
                
        else:
            stream_url+='|User-Agent='+UA+'&Referer='+l
            play_item = xbmcgui.ListItem(path=stream_url)
            play_item.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('gazeta.pl', 'Brak materiału video', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='progs':
        progs()
        
    if mode=='epList':
        link=params.get('link')
        page=params.get('page')
        epList(link,page)
        
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
    
    if mode=='live':
        play_yt('UCU8ueU3NrJdum0m94TJSdkw')
        
    if mode=='epg':
        epgData('UCU8ueU3NrJdum0m94TJSdkw')
