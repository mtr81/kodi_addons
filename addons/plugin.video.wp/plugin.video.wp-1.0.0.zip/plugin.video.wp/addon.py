# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
import datetime,time
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.wp')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

mode = addon.getSetting('mode')
baseurl='https://wideo.wp.pl/'
baseurl_money='https://money.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def main_menu():    
    sources=[
        ['Na żywo','live',''],
        ['Najnowsze','latest',''],
        #['Bieżące','categs','glonewsList'],
        ['Programy','items','programs'],
        ['Kategorie','items','categories'],
        ['SZUKAJ','search',''],
        ['Materiały video money.pl','money_pl','']
        #['ULUBIONE','favList','']
    ]
    for s in sources:
        li=xbmcgui.ListItem(s[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':s[1],'type':s[2],'page':'1'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)    
    xbmcplugin.endOfDirectory(addon_handle)

def live():
    cnt=addon.getSetting('epCount')
    url='https://wideo.wp.pl/wbe/api/v1/lives?limit='+str(cnt)
    resp=requests.get(url,headers=hea).json()
    for r in resp['content']:
        img=r['thumbnail']
        tStart=r['startDate']
        tEnd=r['stopDate']
        now=time.time()*1000
        if True:
        #if tEnd>now:
            title=r['title']
            if now>tStart and now<tEnd:
                title='[B][COLOR=yellow]TRWA [/COLOR][/B]'+r['title']
            if r['archiveAvailable']==True:
                title='[B]Archiwalna [/B]'+r['title']
            plot='[B]Rozpoczęcie: [/B]'+datetime.datetime.fromtimestamp(tStart/1000).strftime('%Y-%m-%d %H:%M')
            li=xbmcgui.ListItem(title)
            li.setProperty("IsPlayable", 'true')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': r['description']})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
            url = build_url({'mode':'playLive','link':r['path'],'tStart':str(tStart),'tEnd':str(tEnd)})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)    

def latest():
    url='https://wideo.wp.pl/tlit-2303867p'#bz???
    resp=requests.get(url,headers=hea).text
    jsonData=re.compile('__NEXT_DATA__ =([^;]+?);').findall(resp)
    if len(jsonData)>0:
        jD=json.loads(jsonData[0])
        print(jD['props']['initialAppState']['latest'])
        for i in jD['props']['initialAppState']['latest']:
            title=''
            if i['program']!=None:
                title='[B]'+i['program']['name']+'[/B] '+ i['title']
            else:
                title=i['title']
            img=i['previewUrl']
            mid=i['mid']
            li=xbmcgui.ListItem(title)
            li.setProperty("IsPlayable", 'true')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
            url = build_url({'mode':'playVid','mid':str(mid)})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def categs(t):
    resp=requests.get(baseurl,headers=hea).text
    jsonData=re.compile('__NEXT_DATA__ =([^;]+?);').findall(resp)
    if len(jsonData)>0:
        jD=json.loads(jsonData[0])
        for i in jD['props']['initialAppState']['homepage'][t]:
            title=''
            if 'name' in i:
                title=i['name']
            elif 'title' in i:
                title=i['title']
            img=''
            if 'image' in i:
                img=i['image']
            elif 'previewUrl' in i:
                img=i['previewUrl']
            li=xbmcgui.ListItem(title)
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
            if t=='glonewsList':
                url = build_url({'mode':'playVid','mid':str(i['mid'])})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def Items(t,p):
    cnt=addon.getSetting('epCount')
    offset=(int(p)-1)*int(cnt)
    url='https://wideo.wp.pl/wbe/api/v1/'+t+'?limit='+cnt+'&offset='+str(offset)
    resp=requests.get(url,headers=hea).json()
    for r in resp['content']:
        title=r['name']
        img=''
        if 'imageUrl' in r:
            img=r['imageUrl']
        plot=''
        if 'description' in r:
            plot=r['description']
        cid=r['id']
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':''})
        if t=='categories':
            url = build_url({'mode':'contentCategs','cid':str(r['id']),'page':'1'})
        elif t=='programs':
            url = build_url({'mode':'content','link':r['path'],'cid':str(r['id'])})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    totalCount=resp['totalElements']
    if int(p)*int(cnt)<totalCount:
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'items','type':t,'page':str(int(p)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def contentCategs(cid,p):
    cnt=addon.getSetting('epCount')
    offset=(int(p)-1)*int(cnt)
    url='https://wideo.wp.pl/graphql'
    data={
        "query": "query videoListForCategory($id: Int!, $limit: Int, $offset: Int) {\n  videoList(categoryId: $id, limit: $limit, offset: $offset) {\n    content {\n      id\n      title\n      previewUrl\n      duration\n      path\n      mid\n      program {\n        id\n        name\n      }\n      minimalAge\n      sex\n      violence\n      drugs\n      profanity\n      iabTags\n      drastic\n      advertEnabled\n    }\n    pagination {\n      count\n    }\n  }\n}\n",
        "variables": {
            "id": int(cid),
            "limit": int(cnt),
            "offset": offset
        }
    }
    resp=requests.post(url,json=data,headers=hea).json()
    for r in resp['data']['videoList']['content']:
        title=r['title']
        img=r['previewUrl']
        mid=r['mid']
        plot=''
        if 'duration' in r:
            dur=str(max(1,int(r['duration']/60)))+' min.'
            plot+='[B]Długość: [/B]'+dur
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playVid','mid':str(mid)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    
    totalCount=resp['data']['videoList']['pagination']['count']
    if int(p)*int(cnt)<totalCount:
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'contentCategs','cid':cid,'page':str(int(p)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def content(l,cid):
    resp=requests.get(baseurl[:-1]+l,headers=hea).text
    jsonData=re.compile('__NEXT_DATA__ =([^;]+?);').findall(resp)
    if len(jsonData)>0:
        jD=json.loads(jsonData[0])
        matID=jD['props']['initialAppState']['materialId']
        progData=jD['props']['initialAppState']['material'][matID]['programData']
        if 'seasons' in progData:
            for s in progData['seasons']:
                seasonNumber=str(s['season'])
                li=xbmcgui.ListItem('Sezon '+seasonNumber)
                li.setProperty("IsPlayable", 'false')
                li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
                li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart':''})
                url = build_url({'mode':'contentList','season':seasonNumber,'cid':cid,'page':'1'})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
                
        else:
            pass
           
    xbmcplugin.endOfDirectory(addon_handle)

   
def contentList(cid,s,p):
    cnt=addon.getSetting('epCount')
    offset=(int(p)-1)*int(cnt)
    hea.update({'Referer':baseurl})
    data={
        "query": "query ($id: Int!, $limit: Int, $offset: Int, $season: Int!) {\n  videoList(limit: $limit, offset: $offset, programId: $id, season: $season) {\n    content {\n      advertEnabled\n      canonicalUrl\n      drastic\n      duration\n      episode\n      iabTags\n      id\n      mid\n      minimalAge\n      sex\n      violence\n      drugs\n      profanity\n      path\n      previewUrl\n      productUrl\n      season\n      title\n    }\n    pagination {\n      count\n    }\n  }\n}\n",
        "variables": {
            "id": int(cid),
            "limit": int(cnt),
            "offset": offset,
            "season": int(s)
        }
    }
    url='https://wideo.wp.pl/graphql'
    resp=requests.post(url,json=data,headers=hea).json()
    for r in resp['data']['videoList']['content']:
        title=r['title']
        img=r['previewUrl']
        mid=r['mid']
        plot=''
        if 'season' in r:
            plot+='[B]Sezon: [/B]'+str(r['season'])+'\n'
        if 'episode' in r:
            plot+='[B]Odcinek: [/B]'+str(r['episode'])+'\n'
        if 'duration' in r:
            dur=str(max(1,int(r['duration']/60)))+' min.'
            plot+='[B]Długość: [/B]'+dur
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playVid','mid':str(mid)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    
    totalCount=resp['data']['videoList']['pagination']['count']
    if int(p)*int(cnt)<totalCount:
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'contentList','season':s,'cid':cid,'page':str(int(p)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
        
def playVid(mid):
    url='https://wideo.wp.pl/api/v2/embed/'+mid+'/secured'
    hea.update({'Referer':baseurl})
    resp=requests.get(url,headers=hea).json()
    url_stream=''
    for r in resp['clip']['url']:
        if 'hls' in r['type']:
            url_stream=r['url']+'|User-Agent='+UA+'&Referer='+baseurl
    if url_stream !='':
        import inputstreamhelper
        PROTOCOL = 'hls'
        is_helper = inputstreamhelper.Helper(PROTOCOL)
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=url_stream)
            #play_item.setMimeType('application/xml+dash')
            play_item.setContentLookup(False)
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
            play_item.setProperty("IsPlayable", "true")
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
            #play_item.setProperty('ResumeTime', '43200')
            #play_item.setProperty('TotalTime', '1')
            #play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
            #play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)#+'&Referer='+baseurl)
            play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('WP', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    
def playLive(l,ts,te):
    url_stream=''
    now=time.time()*1000
    if now>int(ts):# and now<int(te):
        ID=l.split('-')[-1].replace('l','')
        url='https://live.wpcdn.pl/api/v1/lives/'+ID
        hea.update({'Referer':baseurl})
        resp=requests.get(url,headers=hea).json()
        if now>int(te):#archiwalne
            if 'url' in resp:
                for r in resp['url']:
                    if 'hls' in r['type']:
                        url_stream=r['url'][0]+'|User-Agent='+UA+'&Referer='+baseurl
        else: #live
            channel=resp['channel']
            url1='https://pilot.wp.pl/api/v1/live/channel/'+str(channel)
            resp1=requests.get(url1,headers=hea).json()
            streams=resp1['data']['stream_channel']['streams']
            for s in streams:
                if 'hls' in s['type']:
                    url_stream=s['url'][0]+'|User-Agent='+UA+'&Referer='+baseurl
        if url_stream !='':
            import inputstreamhelper
            PROTOCOL = 'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                #play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
                #play_item.setProperty('ResumeTime', '43200')
                #play_item.setProperty('TotalTime', '1')
                #play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
                #play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)#+'&Referer='+baseurl)
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            xbmcgui.Dialog().notification('WP', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
    else:
        xbmcgui.Dialog().notification('WP', 'Transmisja nie jest jeszcze prowadzona', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def search(q,p):
    cnt=addon.getSetting('epCount')
    offset=(int(p)-1)*int(cnt)
    hea.update({'Referer':baseurl})
    data={
        "query": "query videoListForPhrase($phrase: String!, $limit: Int, $offset: Int) {\n  videoList(phrase: $phrase, limit: $limit, offset: $offset) {\n    content {\n      id\n      path\n      previewUrl\n      duration\n      title\n      mid\n      program {\n        id\n        name\n      }\n      minimalAge\n      sex\n      violence\n      drugs\n      profanity\n      iabTags\n      drastic\n      advertEnabled\n    }\n    pagination {\n      count\n    }\n  }\n}\n",
        "variables": {
            "limit": int(cnt),
            "offset": offset,
            "phrase": q
        }
    }
    url='https://wideo.wp.pl/graphql'
    resp=requests.post(url,json=data,headers=hea).json()
    for r in resp['data']['videoList']['content']:
        title=r['title']
        img=r['previewUrl']
        mid=r['mid']
        plot=''
        if 'duration' in r:
            dur=str(max(1,int(r['duration']/60)))+' min.'
            plot+='[B]Długość: [/B]'+dur
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playVid','mid':str(mid)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    
    totalCount=resp['data']['videoList']['pagination']['count']
    if int(p)*int(cnt)<totalCount:
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'searchNextPage','query':q,'page':str(int(p)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
        
def moneyList(p):
    hea.update({'Referer':baseurl_money})
    url='https://www.money.pl/wideo'
    if p!='1':
        url+='?strona='+p
    resp=requests.get(url,headers=hea).text
    jsonData=re.compile('window.__PRELOADED_MATERIAL__ = (.*)').findall(resp)[0]
    jD=json.loads(jsonData)
    k=list(jD['listing'].keys())
    for i in jD['listing'][k[0]]['entries']:
        title=i['node']['name']
        img=i['node']['image']['url']
        URL=i['node']['productUrl']
        plot=''
        if 'publishedFrom' in i['node']:
            plot+='[B]Data: [/B]'+ datetime.datetime.fromtimestamp(i['node']['publishedFrom']).strftime('%Y-%m-%d %H:%M')+'\n'
        if 'lead' in i['node']:
            plot+='[I]'+i['node']['lead']+'[/I]'
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playMoney','link':URL})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        
    if 'link rel=\"next' in resp:
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'moneyList','page':str(int(p)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    

def playMoney(l):
    hea.update({'Referer':baseurl_money})
    resp=requests.get(l,headers=hea).text
    dataPlayer=re.compile('data-player-wptv=\"([^\"]+?)\"').findall(resp)[0]
    mid=dataPlayer.split('-')[-1]
    playVid(mid)

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='items':
        t=params.get('type')
        p=params.get('page')
        Items(t,p)
        
    if mode=='categs':
        t=params.get('type')
        categs(t)
    
    if mode=='live':
        live()
    
    if mode=='latest':
        latest()
    
    if mode=='content':#programy - lista sezonów
        link=params.get('link')
        cid=params.get('cid')
        content(link,cid)
    
    if mode=='contentList':#programy - lista odcinków
        s=params.get('season')
        cid=params.get('cid')
        p=params.get('page')
        contentList(cid,s,p)
        
    if mode=='contentCategs':#kategorie - lista video
        cid=params.get('cid')
        p=params.get('page')
        contentCategs(cid,p)
    
    if mode=='playVid':
        mid=params.get('mid')
        playVid(mid)
        
    if mode=='playLive':
        link=baseurl[:-1]+params.get('link')
        ts=params.get('tStart')
        te=params.get('tEnd')
        playLive(link,ts,te)
        
    if mode=='search':
        query = xbmcgui.Dialog().input(u'Szukaj, Podaj frazę:', type=xbmcgui.INPUT_ALPHANUM)
        if query:
           search(query,'1')
        else:
            xbmcplugin.endOfDirectory(addon_handle)
        main_menu()
        
    if mode=='searchNextPage':
        q=params.get('query')
        p=params.get('page')
        search(q,p)
    
    #Money.pl
    if mode=='money_pl':
        moneyList('1')
    
    if mode=='moneyList':
        p=params.get('page')
        moneyList(p)
    
    if mode=='playMoney':
        link=params.get('link')
        playMoney(link)
    '''            
    #favorites
    if mode=='favList':
        favList('tvp_info')
        
    if mode=='favDel':
        cid=params.get('cid')
        favDel(cid)
        
    if mode=='favAdd':
        cid=params.get('cid')
        name=params.get('name')
        mod=params.get('mod')
        img=params.get('img')
        favAdd(cid,name,mod,img,'tvp_info')
    '''
    