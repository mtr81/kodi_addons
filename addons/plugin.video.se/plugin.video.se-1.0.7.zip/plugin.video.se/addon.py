# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
import datetime,time
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

from resources.lib.yt_live import play_yt, epgData


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.se')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

baseurl='https://wideo.se.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0'

hea={
    'User-Agent':UA,
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(stream_url):
    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA) #K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def strToDate(s):#2025-03-23T16:00:00+00:00
    d=datetime.datetime(*(time.strptime(s, '%Y-%m-%dT%H:%M:%S%z')[0:6]))
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    d=d-datetime.timedelta(seconds=offset)
    return d

def dateToStr(d):
    return d.strftime('%H:%M')

def main_menu():
    items=[
        ['Programy','progs','DefaultAddonVideo.png'],
        ['Transmisje na żywo (YT)','live','DefaultTVShows.png'],
        ['Kanały FAST','fast','DefaultTVShows.png']
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart':fanart}
        url = build_url({'mode':i[1]})
        if i[1]=='live':
            cm=True
            cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.se?mode=epg)')]
            plot='[B]Transmisje okazjonalne[/B]\n [I]Planowane transmisje dostępne z poziomu menu kontekstowego (szczegóły)[/I]'
            isFolder=False
            isPlayable='true'
        else:
            cm=False
            cmItems=[]
            plot=''
            isFolder=True
            isPlayable='false'
        iL={'plot':plot}
        addItemList(url, i[0], setArt, 'video', iL, isFolder, isPlayable, cm, cmItems)
    xbmcplugin.endOfDirectory(addon_handle)

def progs():
    resp=requests.get(baseurl,headers=hea).text
    resp1=resp.split('<section class=\"reccomends')[1].split('</section')[0].split('</a>')
    progs=[]
    for r in resp1:
        if 'reccomends__single-el' in r:
            name,img=re.compile('<img.*alt=\"([^\"]+?)\".*src=\"([^\"]+?)\"').findall(r)[0]
            link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
            progs.append([name,link,img])
    for p in progs:
        if 'youtube' not in p[1]:
            img=p[2]
            title=unescape(p[0])
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'episodes','link':p[1],'page':'1'})
            addItemList(url, title, setArt, 'video')

    xbmcplugin.endOfDirectory(addon_handle)

def episodes(l,p):
    if int(p)>=2:
        l+='?page='+p
    resp=requests.get(l,headers=hea).text
    resp1=resp.split('class=\"main-title-listing\"')[1].split('paginacja\"')[0].split('class=\"element__media\"')
    eps=[]
    for r in resp1:
        if 'element__content' in r:
            link,title=re.compile('<a href=\"([^\"]+?)\".*title=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('<img.*src=\"([^\"]+?)\"').findall(r)[0]
            try:
                r1=r.split('listing-lead')[1]
                desc=re.compile('<p>([^<]+?)</p>').findall(r1)[0]
                r2=r1.split('\"date\"')[1]
                date=re.compile('<p>([^<]+?)</p>').findall(r2)[0]
            except:
                desc=title
                date='...'
            eps.append([title,link,img,desc,date])
     
    for e in eps:
        img=e[2]
        title=unescape(e[0])
        plot='[B]Data publikacji: [/B]'+e[4].replace('dodano ','')+'\n'
        plot+='[I]'+unescape(e[3])+'[/I]'
                
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url = build_url({'mode':'playVid','link':e[1]})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    pag=re.compile('<a href=\"([^\"]+?)\" title="Następna">').findall(resp)
    if len(pag)>0:
        nextPage=pag[0].split('page=')[1]
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'episodes','link':l,'page':nextPage})
        addItemList(url, '[B][COLOR=yellow]>>> następna strona[/COLOR][/B]', setArt, 'video')
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    

chans={
    'se':'Super Express',
    'poradnikzdrowie':'Poradnik Zdrowie',
    'murator':'Murator',
    'eska':'Eska FAST',
    'eskarock':'ESKA Rock FAST',
    'vox':'Vox FAST',
    'himusic':'HiMusic',
    'hidance':'HiDance',
    'sayhi':'SayHi'
}

def fast():    
    for c in chans:
        img='DefaultTVShows.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        iL={'plot':'EPG dostępne z poziomu menu kontekstowego'}
        url = build_url({'mode':'playFast','cid':c})
        
        cmItems=[('[B]EPG[/B]','RunPlugin(plugin://plugin.video.se?mode=fast_epg&cid='+c+')')]
        
        addItemList(url, chans[c], setArt, 'video', iL, False, 'true', True, cmItems)
    
    img='DefaultFile.png'
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
    url = build_url({'mode':'m3uList'})
    addItemList(url, 'Generuj listę M3U', setArt, isF=False, isPla='false')
    
    xbmcplugin.endOfDirectory(addon_handle) 

def fast_epg(cid):
    epg='Brak danych'
    url='https://tv.'+cid+'.mediateka.pl/'
    resp=requests.get(url,headers=hea).text
    cID=re.compile('window.channelUid = \'([^\']+?)\'').findall(resp)
    if len(cID)>0:
        epg=''
        url='https://www.eska.pl/api/epg-channel/?channel_uid='+cID[0]
        resp=requests.get(url,headers=hea).json()
        now=datetime.datetime.now()
        for r in resp['program']:
            ts=strToDate(r['emission_start_date'])
            te=strToDate(r['emission_end_date'])
            if te>now:
                title=r['title']+' '
                if 'season' in r:
                    if r['season'] not in [None,'']:
                        title+='sez. %s '%(r['season'])
                if 'episode' in r:
                    if r['episode'] not in [None,'']:
                        title+='odc. %s'%(r['episode'])
                s=dateToStr(ts)
                epg+='[B]%s[/B] %s\n'%(s,title)
                
    dialog = xbmcgui.Dialog()
    dialog.textviewer('EPG', epg)
    
def playFast(cid):
    url='https://tv.'+cid+'.mediateka.pl/'
    resp=requests.get(url,headers=hea).text
    srcs=re.compile('\[YPlayer.stream.BASIC\]: \'([^\']+?)\'').findall(resp)
    if len(srcs)>0:
        ISAplayer(srcs[0])
    else:
        xbmcgui.Dialog().notification('SuperExpress video', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
def m3uList():
    path_m3u=xbmcgui.Dialog().browse(0, 'Katalog docelowy', '', '', enableMultiple = False)
    fileName='se_m3u.m3u'
    data = '#EXTM3U\n'
    
    for c in chans:
        cName=chans[c]
        cid=c
        
        data += '#EXTINF:0 tvg-id="%s" group-title="SuperExpress",%s\nplugin://plugin.video.se?mode=playFast&cid=%s\n' % (cName,cName,cid)
        
    f = xbmcvfs.File(path_m3u + fileName, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('SuperExpress', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
        
def playVid(l):
    resp=requests.get(l,headers=hea).text
    try:
        resp1=resp.split('<div id=\'video-player')[1].split('</div>')[0]
        if 'data-src' in resp1:
            stream_url=re.compile('data-src=\'([^\']+?)\'').findall(resp1)[0]
    except:
        stream_url=''

    print(stream_url)
    
    if stream_url !='':
        ISAplayer(stream_url)
    else:
        xbmcgui.Dialog().notification('SuperExpress video', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='progs':
        progs()
    
    if mode=='episodes':
        link=params.get('link')
        page=params.get('page')
        episodes(link,page)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
        
    if mode=='live':
        playerType=addon.getSetting('playerType')
        play_yt('UCJ33TxiuEEYWLZ4ahILb0zQ',playerType)
        
    if mode=='epg':
        epgData('UCJ33TxiuEEYWLZ4ahILb0zQ')
        
    if mode=='fast':
        fast()
        
    if mode=='playFast':
        cid=params.get('cid')
        playFast(cid)
        
    if mode=='fast_epg':
        cid=params.get('cid')
        fast_epg(cid)
    
    if mode=='m3uList':
        m3uList()
        