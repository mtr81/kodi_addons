# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

from resources.lib.yt_live import play_yt, epgData


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.se')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

mode = addon.getSetting('mode')
baseurl='https://wideo.se.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

hea={
    'User-Agent':UA,
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def main_menu():
    items=[
        ['Programy','progs','DefaultAddonVideo.png'],
        ['Transmisje na żywo (YT)','live','DefaultTVShows.png']
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart':''}
        url = build_url({'mode':i[1]})
        if i[1]=='live':
            cm=True
            cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.se?mode=epg)')]
            plot='[B]Transmisje okazjonalne[/B]\n [I]Planowane transmisje dostępne z poziomu menu kontekstowego (szczegóły)[/I]'
            isFolder=False
            isPlayable='true'
        else:
            cm=False
            cmItems=[]
            plot=''
            isFolder=True
            isPlayable='false'
        iL={'plot':plot}
        addItemList(url, i[0], setArt, 'video', iL, isFolder, isPlayable, cm, cmItems)
    xbmcplugin.endOfDirectory(addon_handle)

def progs():
    resp=requests.get(baseurl,headers=hea).text
    resp1=resp.split('<section class=\"reccomends')[1].split('</section')[0].split('</a>')
    progs=[]
    for r in resp1:
        if 'reccomends__single-el' in r:
            name,img=re.compile('<img.*alt=\"([^\"]+?)\".*src=\"([^\"]+?)\"').findall(r)[0]
            link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
            progs.append([name,link,img])
    for p in progs:
        img=p[2]
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
        url = build_url({'mode':'episodes','link':p[1],'page':'1'})
        addItemList(url, p[0], setArt, 'video')

    xbmcplugin.endOfDirectory(addon_handle)

def episodes(l,p):
    if int(p)>=2:
        l+='?page='+p
    resp=requests.get(l,headers=hea).text
    resp1=resp.split('class=\"main-title-listing\"')[1].split('paginacja\"')[0].split('class=\"element__media\"')
    eps=[]
    for r in resp1:
        if 'element__content' in r:
            link,title=re.compile('<a href=\"([^\"]+?)\".*title=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('<img.*src=\"([^\"]+?)\"').findall(r)[0]
            r1=r.split('listing-lead')[1]
            desc=re.compile('<p>([^<]+?)</p>').findall(r1)[0]
            r2=r1.split('\"date\"')[1]
            date=re.compile('<p>([^<]+?)</p>').findall(r2)[0]
            eps.append([title,link,img,desc,date])
     
    for e in eps:
        img=e[2]
        title=unescape(e[0])
        plot='[B]Data publikacji: [/B]'+e[4].replace('dodano ','')+'\n'
        plot+='[I]'+unescape(e[3])+'[/I]'
                
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':''}
        url = build_url({'mode':'playVid','link':e[1]})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    pag=re.compile('<a href=\"([^\"]+?)\" title="Następna">').findall(resp)
    if len(pag)>0:
        nextPage=pag[0].split('page=')[1]
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''}
        url = build_url({'mode':'episodes','link':l,'page':nextPage})
        addItemList(url, '[B][COLOR=yellow]>>> następna strona[/COLOR][/B]', setArt, 'video')
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    
    
def playVid(l):
    resp=requests.get(l,headers=hea).text
    resp1=resp.split('<div id=\'video-player')[1].split('</div>')[0]
    stream_url=''
    if 'data-src' in resp1:
        stream_url=re.compile('data-src=\'([^\']+?)\'').findall(resp1)[0]

    print(stream_url)
    
    if stream_url !='':
        import inputstreamhelper
        PROTOCOL = 'hls'
        is_helper = inputstreamhelper.Helper(PROTOCOL)
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=stream_url)
            #play_item.setMimeType('application/xml+dash')
            play_item.setContentLookup(False)
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
            play_item.setProperty("IsPlayable", "true")
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
            play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
            play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA) #K21
            play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('SuperExpress video', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='progs':
        progs()
    
    if mode=='episodes':
        link=params.get('link')
        page=params.get('page')
        episodes(link,page)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
        
    if mode=='live':
        play_yt('UCJ33TxiuEEYWLZ4ahILb0zQ')
        
    if mode=='epg':
        epgData('UCJ33TxiuEEYWLZ4ahILb0zQ')
        