# -*- coding: utf-8 -*-
import os
import sys

import urllib
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib3
import re

import string
import json
import time
import datetime

import base64
import hashlib
import hmac

from urllib.parse import urlencode, quote_plus, quote, parse_qsl
    
import random

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.elevens')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
img_addon=PATH+'/icon.png'
fanart=PATH+'/resources/img/tlo.jpg'

UA='eleven_tv_android_native_cpplayer/100400'
userAgentData={
    "application": "native",
    "build": 100400,
    "deviceType": "tv", #api Android TV
    "os": "android",
    "player": "cpplayer",
    "portal": "eleven",
    "widevine": True
}
def hea_rec(a,f): #2025-01-13
    contextToken=getContextToken()
    if contextToken!=False:    
        msg=getMsg()
        
        clientid=addon.getSetting('clientid')
        deviceid=addon.getSetting('deviceid')
        sessId=addon.getSetting('sessId')
        sessKeyExp=addon.getSetting('sessKeyExp')
        sessKey=addon.getSetting('sessKey')
       
        sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,a,f)
        
        h={
            'X-User-Agent-Data-Portal':userAgentData['portal'],
            'X-User-Agent-Data-Device-Type':userAgentData['deviceType'],
            'X-User-Agent-Data-Application':userAgentData['application'],
            'X-User-Agent-Data-Player':userAgentData['player'],
            'X-User-Agent-Data-Build':str(userAgentData['build']),
            'X-User-Agent-Data-Os':userAgentData['os'],
            'X-User-Agent-Data-Widevine':'true',
            'X-Device-Id-Type':'other',
            'X-Device-Id-Value':deviceid,
            'X-Client-Id':clientid,
            'X-Client-Context-Token':contextToken,
            'X-Message-Id':	msg['id'],
            'X-Message-Timestamp': msg['timestamp'],
            'X-Auth-Data-Session-Id':sessId,
            'X-Auth-Data-Session-Token':sessToken,
            'User-Agent':'okhttp/4.12.0'
        }
        return h

userAgentData_play=userAgentData
hea={
    'User-Agent':UA
}

def build_url(query):
    return base_url + '?' + urlencode(query)
    
def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def code_gen(x,nmb=False):
    base='0123456789abcdef' if not nmb else '0123456789'
    r=15 if not nmb else 9
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,r)]
    return code

def get_sessionToken(sess_id,sess_kET,sess_key,t,e):
    r='%s|%s|%s|%s'%(sess_id,sess_kET,t,e)
    a=base64.b64decode(sess_key.replace('-','+').replace('_','/'))

    def sign_string(key, to_sign):
        signed_hmac_sha256 = hmac.HMAC(key, to_sign.encode(), hashlib.sha256)
        digest = signed_hmac_sha256.digest()
        return base64.b64encode(digest).decode()
            
    hash=sign_string(a,r).replace('+','-').replace('/','_')
    sessionToken=r+'|'+hash
    return sessionToken

def getMsg():
    msg={
        'id':'',
        'timestamp':''
    }
    msg['id']='%s-%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12),code_gen(3,True))
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    now=datetime.datetime.now()
    msg['timestamp']=(now+datetime.timedelta(seconds=offset)).strftime('%Y-%m-%dT%H:%M:%SZ')
    return msg

def dateConv(d,f='%Y-%m-%d %H:%M',str=True): #2025-01-13
    #2025-01-20T22:00:00Z
    date=datetime.datetime(*(time.strptime(d,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    res=(date-datetime.timedelta(seconds=offset)).strftime(f) if str else date-datetime.timedelta(seconds=offset)
    return res
    
def main_menu():
    mainCategs=[]
    if addon.getSetting('logged')=='true':
        categs=getCategories()
        if categs==False: #
            return
        for c in categs:
            if c[1]=='category':
                mainCategs.append([c[0],c[2],'subCateg','DefaultAddonVideo.png'])
            elif c[1]=='tv_channels':
                mainCategs.append([c[0],'','tv','DefaultTVShows.png'])
                mainCategs.append(['Archiwum TV','','replay','DefaultYear.png'])
            elif c[1]=='live_channels':
                mainCategs.append([c[0],'','live','DefaultTVShows.png'])
        if len(categs)>0:
            mainCategs.append(['Wideo','5015552','contentList','DefaultAddonVideo.png'])
            mainCategs.append(['Ulubione','','favList','DefaultMusicRecentlyAdded.png'])
            mainCategs.append(['Wyszukiwarka','','search','DefaultAddonsSearch.png'])
        mainCategs.append(['Wyloguj','','logOut','DefaultUser.png'])
    else:
        mainCategs.append(['Zaloguj','','logIn','DefaultUser.png'])
    
    #strona gł
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultAddonVideo.png', 'fanart':fanart}
    url = build_url({'mode':'recomList','place':'homepage'})
    addItemList(url, 'Start', setArt)
    
    for s in mainCategs:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': s[3], 'fanart':fanart}
        url = build_url({'mode':s[2],'categ':s[1]})
        addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def logIn():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    usr = addon.getSetting('username')
    password = addon.getSetting('password')
    if usr and password:    
        data_js = {
            "id": int(code_gen(19,True)),
            "jsonrpc": "2.0",
            "method": "login",
            "params": {
                "authData": {
                    "authProvider":"native",
                    "deviceId": {
                        "name": "AndroidTV null",
                        "type": "other",
                        "value": deviceid
                    },
                    "login": usr,
                    "password": password
                },
                "clientId": clientid,
                "message": getMsg(),
                "userAgentData": userAgentData
            }
        }
        
        resp = requests.post('https://b2c.redefine.pl/rpc/auth/login/', json=data_js, headers=hea).json()
        if 'error' in resp:
            if resp['error']['message']=='Not found error' or resp['error']['message']=='Unauthorized access':
                xbmcgui.Dialog().notification('Eleven Sports', resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
            else:
                try:
                    xbmcgui.Dialog().notification('Eleven Sports', '[B]Błąd logowania: [/B]'+ resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
                except:
                    xbmcgui.Dialog().notification('Eleven Sports', 'Nieokreślony błąd logowania', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        elif 'result' in resp:
            addon.setSetting('sessId',resp['result']['session']['id'])
            addon.setSetting('sessKey',resp['result']['session']['key'])
            addon.setSetting('sessKeyExp',str(resp['result']['session']['keyExpirationTime']))
            addon.setSetting('sessUpdateTime',str(int(time.time())))
            addon.setSetting('logged','true')
            xbmcgui.Dialog().notification('Eleven Sports', 'Zalogowano', xbmcgui.NOTIFICATION_INFO)
        else:
            pass
            
    else:
        xbmcgui.Dialog().notification('Eleven Sports', 'Uzupełnij dane logowania w ustawieniach', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    
def logOut():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'auth','logout')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "logout",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp= requests.post('https://b2c.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        if resp['result']['status']==0:
            xbmc.log('@@@Wylogowanie systemowe', level=xbmc.LOGINFO)
    else:
        xbmc.log('@@@Błąd_logOut: '+str(resp), level=xbmc.LOGINFO)
        xbmc.log('@@@para-Logout', level=xbmc.LOGINFO)
        
    addon.setSetting('sessId','')
    addon.setSetting('sessKeyExp','')
    addon.setSetting('sessKey','')
    addon.setSetting('logged','false')
    addon.setSetting('sessUpdateTime','')
    xbmcgui.Dialog().notification('Eleven Sports', 'Wylogowano', xbmcgui.NOTIFICATION_INFO)

def getSession(afterErr=False): #wywoływana raz /24h
    if addon.getSetting('logged')=='true': #nowa sesja
        sessUpdateTime=addon.getSetting('sessUpdateTime')
        sessUpdateTime=0 if sessUpdateTime=='' or sessUpdateTime==None else int(sessUpdateTime)
        now=int(time.time())
        if now-sessUpdateTime>=24*60*60 or afterErr:
            clientid=addon.getSetting('clientid')
            deviceid=addon.getSetting('deviceid')
            sessId=addon.getSetting('sessId')
            sessKeyExp=addon.getSetting('sessKeyExp')
            sessKey=addon.getSetting('sessKey')
            
            sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'auth','getSession')
            data_js={
                "id": int(code_gen(19,True)),
                "jsonrpc": "2.0",
                "method": "getSession",
                "params": {
                    "authData": {
                        "sessionToken": sessToken
                    },
                    "clientId": clientid,
                    "deviceId": {
                        "type": "other",
                        "value": deviceid
                    },
                    "message": getMsg(),
                    "userAgentData": userAgentData
                }
            }
            resp= requests.post('https://b2c.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
            if 'result' in resp:
                addon.setSetting('sessId',resp['result']['session']['id'])
                addon.setSetting('sessKey',resp['result']['session']['key'])
                addon.setSetting('sessKeyExp',str(resp['result']['session']['keyExpirationTime']))
                addon.setSetting('sessUpdateTime',str(int(time.time())))
                xbmc.log('@@@Nowa sesja', level=xbmc.LOGINFO)
            else:#token wygasł
                addon.setSetting('sessId','')
                addon.setSetting('sessKeyExp','')
                addon.setSetting('sessKey','')
                addon.setSetting('sessUpdateTime','')
                addon.setSetting('logged','false')
                
                xbmc.log('@@@Nie można odświeżyć sesji-próba przelogowania (logowanie login/pass', level=xbmc.LOGINFO)
                xbmcgui.Dialog().notification('Eleven Sports', 'Przelogowanie: nie można odświeżyć sesji', xbmcgui.NOTIFICATION_INFO)
                logIn()
                
def getContextToken(): #2025-01-13
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'system','getClientContextToken')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getClientContextToken",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    
    resp= requests.post('https://b2c.redefine.pl/rpc/system/', json=data_js, headers=hea).json()
    categs=[]
    if 'errors' not in resp and 'result' in resp:
        return resp['result']
    else:
        xbmc.log('@@@Błąd_getContextToken: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')
        return False

def recomList(place): #2025-01-13
    data={"place":{"type":place,"value":""}}
    meth='getStaffRecommendationsLists'
    
    url='http://b2c.redefine.pl/rpc/navigation/'
    h=hea_rec('navigation',meth)
    paramsURL={
        'method':meth,
        'id':'1',
        'params':base64.b64encode(json.dumps(data).encode()).decode()
    }
    resp=requests.get(url,headers=h,params=paramsURL).json()
    if 'errors' not in resp and 'result' in resp:
        for r in resp['result']:
            cid=r['id']
            name=r['name']
            img='DefaultAddonVideo.png'
            plot=r['description']
            
            setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
            iL={'title': name,'sorttitle': name,'plot': plot}
            url = build_url({'mode':'recomListItems','place':'homepage','id':cid,'page':'1'})
            addItemList(url, name, setArt, 'video', iL)
            
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_recomList: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')
        return False

def recomListItems(place,id,page): #2025-01-13
    count=min(200,int(addon.getSetting('count')))
    start=(int(page)-1)*count
    
    data={"limit":count,"offset":start,"place":{"type":place,"value":""},"staffRecommendationsListId":id}
    meth='getStaffRecommendationsListItems'
    
    url='http://b2c.redefine.pl/rpc/navigation/'
    h=hea_rec('navigation',meth)
    paramsURL={
        'method':meth,
        'id':'1',
        'params':base64.b64encode(json.dumps(data).encode()).decode()
    }
    resp=requests.get(url,headers=h,params=paramsURL).json()
    if 'errors' not in resp and 'result' in resp:
        if 'results' in resp['result']:
            for r in resp['result']['results']:
                if 'object' in r:
                    addItem(r)
            
        nextPage=False
                
        if int(page)*count<resp['result']['total']:
            nextPage=True
 
        if nextPage:
            setArt={'thumb': '', 'poster': '', 'banner': '','icon':'','fanart':fanart}
            
            url = build_url({'mode':'recomListItems','place':place,'id':id,'page':str(int(page)+1)})
            addItemList(url, '[B][COLOR=cyan]>>> Następna strona[/COLOR][/B]', setArt, 'video')
        
        xbmcplugin.setContent(addon_handle, 'videos')
        
        '''
        if not nextPage and page=='1': #episodes
            xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_EPISODE)
        '''
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_recomListItems: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')
    
    xbmcplugin.endOfDirectory(addon_handle) 

def addItem(r): #2025-01-13
    data=r['object']
    title=data['title']
    IMG=getImage(data['thumbnails']) if 'thumbnails' in data else img_addon
    desc=data['description'] if 'description' in data else ''
    cpid=str(data['cpid'])
    mediaid=data['id'] if 'mediaType' in data else ''
    isF=False
    isP='true'
    
    type=r['type']
    if type not in ['url']:
        if type=='vod':
            name= title
            img=IMG
            countries=data['countries'] if 'countries' in data else []
            genre=data['genres'] if 'genres' in data else []
            dur=data['duration'] if 'duration' in data else 0
            
            plot=desc
            datePubl=dateConv(data['publicationDate']) if 'publicationDate' in data else ''
            if datePubl!='':
                plot='[COLOR=cyan]Data publikacji: [/COLOR]%s\n%s'%(datePubl,plot)
            dateAvail=dateConv(r['validTo']) if 'validTo' in r else ''
            if dateAvail!='':
                plot='[COLOR=cyan]Dostępne do: [/COLOR]%s\n%s'%(dateAvail,plot)
            
            infoLab={'title': name,'sorttitle': name,'genre':genre,'plot': plot,'country': countries,'duration':dur,'mediatype':'movie'}
            URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
      
        elif type=='channel':
            name=r['name'] if 'name' in r else title
            img=r['gallery'][0]['src'] if 'gallery' in r else IMG
            plot='[COLOR=cyan]%s[/COLOR]%s\n'%(title,desc)
            
            URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'tv'})
            infoLab={'title': name,'sorttitle': '','plot': plot}
            
        elif type=='tv_program':
            name=title
            now=datetime.datetime.now()
            s=dateConv(data['startTime'],'',False)
            e=dateConv(data['endTime'],'',False)
            if now>=s and now<=e:
                name='[COLOR=yellow][B][LIVE][/B][/COLOR] %s'%(title)
            
            img=r['gallery'][0]['src'] if 'gallery' in r else IMG
            mediaid=r['value']
            day=dateConv(data['startTime'],'%Y-%m-%d')
            ts=dateConv(data['startTime'],'%H:%M')
            te=dateConv(data['endTime'],'%H:%M')
            desc+='\n[B]%s[/B] | %s - %s'%(day,ts,te)
            
            URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'prog'})
            infoLab={'title': name,'sorttitle': name,'plot': desc}
            
        setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.elevens?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&infoLab='+quote(str(infoLab))+'&img='+quote(str(setArt))+')')]
        addItemList(URL, name, setArt, 'video', infoLab, isF, isP, True, cmItems)


def getCategories():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getHomeMenu')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getHomeMenu",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    
    resp= requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js, headers=hea).json()
    categs=[]
    if 'errors' not in resp and 'result' in resp:
        for r in resp['result']:
            if r['name'] not in ['Moja lista','Piłka nożna','HITY ELEVEN']:
                categs.append([r['name'],r['place']['type'],r['place']['value']])
        return categs
    else:
        xbmc.log('@@@Błąd_getCategories: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')
        return False

def getImage(x):#
    def sortFN(i):
        return i['size']['width']
    x.sort(key=sortFN,reverse=True)
    img=x[0]['src'] if len(x)>0 else img_empty
    return img
    
def locTime(x):#
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    z=(y+diff+datetime.timedelta(seconds=1)).strftime('%Y-%m-%d %H:%M')
    return z

def getEPG(TV_list):#
    chansId=[r['id'] for r in TV_list['result']['results']]
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getChannelsCurrentProgram')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getChannelsCurrentProgram",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "channelIds":chansId,
            "limit": 2,
            "offset": 0,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        return resp['result']
    else:
        xbmc.log('@@@Błąd_getEPG: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')
        return False

def plotEPG(data,c):#
    plot=''
    if c in data:
        for p in data[c]:
            title=p['title']
            genre=p['genre']
            startTime=locTime(p['startTime']).split(' ')[1]
            plot+='[B]%s[/B] %s - [I]%s[/I]\n'%(startTime,title,genre)
    return plot

def getTVList():#
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getTvChannels')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getTvChannels",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "filters": [],
            "limit": 200,
            "offset": 0,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        return resp
    else:
        xbmc.log('@@@Błąd_getTVList: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')
        return False

def tv(replay=False):
    resp=getTVList()
    if resp==False:
        return
    EPG=getEPG(resp)
    if EPG==False:
        return
    for r in resp['result']['results']:
        title=r['title']
        mediaid=r['id']
        cpid=str(r['cpid'])
        img=getImage(r['thumbnails'])
        if replay:
            plot=title
            url=build_url({'mode':'catchupList','mediaid':mediaid})
            isF=True
            isP='false'
        
        else:
            plot=plotEPG(EPG,mediaid)
            url=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'tv'})
            isF=False
            isP='true'
            
        setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
        iL={'title': title,'sorttitle': title,'plot': plot}
        addItemList(url, title, setArt, 'video', iL, isF, isP)
    
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)    

def catchupList(mediaid): #2025-01-13
    now=datetime.datetime.now()
    date=now.strftime('%Y-%m-%d')
    hour=int(datetime.datetime.now().strftime('%H'))
    if hour>12:
        ds=[date]
    else:
        yest=(now-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
        ds=[yest,date]
    epg=[]
    for d in ds:
        data={"channelIds":[mediaid],"date":d}
        meth='getChannelsProgram'
        
        url='http://b2c.redefine.pl/rpc/navigation/'
        h=hea_rec('navigation',meth)
        paramsURL={
            'method':meth,
            'id':'1',
            'params':base64.b64encode(json.dumps(data).encode()).decode()
        }
        resp=requests.get(url,headers=h,params=paramsURL).json()
        if 'errors' not in resp and 'result' in resp:
            epg+=resp['result'][mediaid]
    
    for e in epg:
        st=dateConv(e['startTime'],'',False)
        if st>=now-datetime.timedelta(hours=12) and st<=now:
            cpid=str(e['cpid'])
            id=e['id']
            title=e['title']
            desc=e['description']
            img=getImage(e['thumbnails'])
            ts=dateConv(e['startTime'],'%H:%M')
            te=dateConv(e['endTime'],'%H:%M')
            tit='[B]%s - %s[/B] %s'%(ts,te,title)
        
            iL={'title':title,'plot':desc}
            setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
            URL = build_url({'mode':'playCont','mediaid':id,'cpid':cpid,'type':'prog','ts':e['startTime']})
            addItemList(URL, tit, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    

def live():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getLiveChannelsWithTreeNavigation')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getLiveChannelsWithTreeNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        for r in resp['result']['results']:
            cpid=str(r['cpid'])
            mediaid=r['id']
            title=r['title']
            img=getImage(r['thumbnails'])
            date=locTime(r['publicationDate'])
            plot='[B]Początek transmisji: [/B]'+date
            if r['published']==False:
                url = build_url({'mode':'playINFO','info':'Transmisja nie jest jeszcze prowadzona'})
                isPlayable='false'
            else:
                url = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'live'})
                isPlayable='true'
            
            setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
            iL={'title': '','sorttitle': '','plot': plot}
            addItemList(url, title, setArt, 'video', iL, False, isPlayable)
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_live: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')

def subCateg(categ):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getCategoryWithFlatNavigation')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getCategoryWithFlatNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(categ),
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        subcategs=[['[B]Wszystkie[/B]','']]
        s=[c['filters'] for c in resp['result']['flatNavigation']['filterLists'] if c['name']=='Gatunki']
        if len(s)==1:
            for ss in s[0]:
                subcategs.append([ss['name'],ss['value']])
        for sb in subcategs:
            setArt={'thumb': '', 'poster': img_addon, 'banner': '','icon':'DefaultGenre.png','fanart':fanart}
            url = build_url({'mode':'contentList','categ':categ,'subcateg':sb[1],'page':'1'})
            addItemList(url, sb[0], setArt)
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_subCateg: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')

def contData(resp,object=False):#
    for r in resp['result']['results']:
        r=r['object'] if object else r
        cid=str(r['id'])
        cpid=str(r['cpid'])
        genre=r['genres'] if 'genres' in r else []
        desc=r['description']
        img=getImage(r['thumbnails'])
        if 'mediaType' in r:
            title=r['title']
            age=str(r['ageGroup']) if 'ageGroup' in r else ''
            countries=r['countries'] if 'countries' in r else []
            dur=r['duration'] if 'duration' in r else 0
            mediaid=r['id']
            isPlayable='true'
            isFolder=False
            #URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
            
            if r['mediaType']=='movie':
                originaltitle=r['originalTitle'] if 'originalTitle' in r else ''
                year=r['releaseYear'] if 'releaseYear' in r else 0
                infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'year': year,'country': countries,'originaltitle':originaltitle,'duration':dur,'mediatype':'movie'}    
                URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
            elif r['mediaType']=='vod': 
                plot=desc
                datePubl=dateConv(r['publicationDate']) if 'publicationDate' in r else ''
                if datePubl!='':
                    plot='[COLOR=cyan]Data publikacji: [/COLOR]%s\n%s'%(datePubl,plot)
                
                epNumber=r['episodeNumber'] if 'episodeNumber' in r else 0
                try:
                    seasNumber=r['category']['seasonNumber']
                except:
                    seasNumber=0
                infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': plot,'country': countries,'season':seasNumber,'episode':epNumber,'duration':dur,'mediatype':'episode'}
                URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
            elif r['mediaType']=='live':#dla search
                date=locTime(r['publicationDate'])
                plot='[COLOR=cyan]Transmisja na żywo[/COLOR]\n[B]Początek transmisji: [/B]'+date
                infoLab={'title': '','sorttitle': '','plot': plot}
                if r['published']==False:
                    URL = build_url({'mode':'playINFO','info':'Transmisja nie jest jeszcze prowadzona'})
                    isPlayable='false'
                else:
                    URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'live'})
                    isPlayable='true'
            elif r['mediaType']=='tv':#dla search
                plot='[COLOR=cyan]Kanał TV[/COLOR]\n'+desc
                URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'tv'})
                infoLab={'title': '','sorttitle': '','plot': plot}
            
        elif 'subCategoriesLabel' in r:
            title=r['name']
            isPlayable='false'
            isFolder=True
            if r['subCategoriesLabel']=='Serie':
                mod='seasonList'#'contentList'   
                URL= build_url({'mode':mod,'cid':cid})#build_url({'mode':mod,'categ':cid,'page':'1'})
            elif r['subCategoriesLabel']=='Sezony':
                mod='seasonList' 
                URL= build_url({'mode':mod,'cid':cid})
            infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'mediatype':'tvshow'}
        
        else:
            ct=r['reporting']['playerEvents']['contentItem']['type']
            title=r['name']
            if ct=='category':
                isPlayable='false'
                isFolder=True
                URL=build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
                infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'mediatype':'tvshow'}
            else:#do sprawdzenia i ewentualnej rozbudowy 
                title='[COLOR=cyan]'+r['name']+'[/COLOR]'
                isPlayable='false'
                isFolder=False
                URL=''
                infolab={}
        setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':fanart}
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.elevens?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&infoLab='+quote(str(infoLab))+'&img='+quote(str(setArt))+')')]
        addItemList(URL, title, setArt, 'video', infoLab, isFolder, isPlayable, True, cmItems)
    
def contentList(categ,subcateg,page,sortBy):
    count=min(200,int(addon.getSetting('count'))) #max ilość wyników zwracanych przez serwer: 200
    start=(int(page)-1)*count
    
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getCategoryContentWithFlatNavigation')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getCategoryContentWithFlatNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(categ),
            "clientId": clientid,
            "collection": {
                "default": True,
                "name": "Ostatnio dodane",
                "type": "sortedby",
                "value": "12"#13
            },
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "limit": count,
            "offset": start,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    if subcateg !=None:
        data_js['params'].update({"filters":[{"type": "genres","value": [subcateg]}]})
    sortList=addon.getSetting('sortList')
    '''
    if sortBy =='addDate' or sortList=='data dodania':#dla odcinków sortowanie wg daty dodania
        data_js['params']['collection'].update({'name':'Ostatnio dodane','value':'12'})
    '''
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        contData(resp)
        nextPage=False
                
        if int(page)*count<resp['result']['total']:
            nextPage=True
 
        if nextPage:
            setArt={'thumb': '', 'poster': '', 'banner': '','icon':'','fanart':fanart}
            subcateg_='' if subcateg==None else subcateg
            sortBy_='' if sortBy==None else sortBy    
            
            url = build_url({'mode':'contentList','categ':categ,'subcateg':subcateg_,'page':str(int(page)+1),'sortBy':sortBy_})#,'count':count
            addItemList(url, '[B][COLOR=cyan]>>> Następna strona[/COLOR][/B]', setArt, 'video')
        
        xbmcplugin.setContent(addon_handle, 'videos')
        
        if sortBy!=None and not nextPage and page=='1': #episodes
            xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_EPISODE)
        
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_contentList: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')

def seasonList(cid):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getSubCategories')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getSubCategories",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(cid),
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        if len(resp['result'])<=1:
            contentList(cid,None,'1','addDate')#str(resp['result'][0]['id'])
        else:
            #wszystkie odcinki
            setArt={'thumb': '', 'poster': '', 'banner': '','icon':'DefaultAddonVideo.png','fanart':fanart}
            iL={'plot':'Wszystkie odcinki'}
            url = build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
            addItemList(url, '[B]Wszystkie odcinki[/B]', setArt, 'video', iL)
            #lista sezonów
            for r in resp['result']:
                cid=str(r['id'])
                name=r['name']
                desc=r['description']
                img=getImage(r['thumbnails'])
                seasNumb=r['seasonNumber'] if 'seasonNumber' in r else 0
                
                setArt={'thumb': img, 'poster': img, 'banner': img,'icon':'OverlayUnwatched.png','fanart':fanart}
                iL={'title': name,'sorttitle': name,'plot': desc,'season':seasNumb,'mediatype':'season'}
                url = build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
                addItemList(url, name, setArt, 'video', iL)
            xbmcplugin.setContent(addon_handle, 'videos')
            xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_contentList: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')
            
    
def playCont(mediaid,cpid,type,ts):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    if type=='prog':
        sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getCatchUpEntryEpg')
        data_js={
            "id": int(code_gen(19,True)),
            "jsonrpc": "2.0",
            "method": "getCatchUpEntryEpg",
            "params": {
                "authData": {
                    "sessionToken": sessToken
                },
                "clientId": clientid,
                "deviceId": {
                    "name": "AndroidTV null",
                    "type": "other",
                    "value": deviceid
                },
                "epgId":mediaid,
                "message": getMsg(),
                "userAgentData": userAgentData
            }
        }
        resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
        #print(resp)
        if 'errors' not in resp and 'result' in resp:
            mediaid=resp['result']['id']
            cpid=str(resp['result']['cpid'])
        
        else:
            sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getTvChannelProgramItem')
            data_js={
                "id": int(code_gen(19,True)),
                "jsonrpc": "2.0",
                "method": "getTvChannelProgramItem",
                "params": {
                    "authData": {
                        "sessionToken": sessToken
                    },
                    "clientId": clientid,
                    "deviceId": {
                        "name": "AndroidTV null",
                        "type": "other",
                        "value": deviceid
                    },
                    "tvChannelProgramItemId":mediaid,
                    "message": getMsg(),
                    "userAgentData": userAgentData
                }
            }
            resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
            if 'errors' not in resp and 'result' in resp:
                chanData=resp['result']['channelIds'][0]
                mediaid=chanData['id']
                cpid=str(chanData['cpid'])
            else:
                xbmcgui.Dialog().notification('Eleven Sports', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                return
        
    #sprawdzenie dostępności
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','checkProductAccess')
    mediaid_ver=mediaid if type!='prog' else mediaid.split('_')[0]
    type_ver=type if type!='prog' else 'tv'
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "checkProductAccess",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "product": {
                "id": mediaid_ver,
                "subType": type_ver,
                "type": "media"
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/drm/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        if resp['result']['statusDescription']!='no access':
        
            #dane do odtwarzacza
            sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','prePlayData')
            
            data_js={
                "id": int(code_gen(19,True)),
                "jsonrpc": "2.0",
                "method": "prePlayData",
                "params": {
                    "authData": {
                        "sessionToken": sessToken
                    },
                    "clientId": clientid,
                    "cpid": int(cpid),
                    "mediaId": mediaid,
                    "message": getMsg(),
                    "userAgentData": userAgentData_play
                }
            }
            resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
            mediaSources=resp['result']["mediaItem"]['playback']['mediaSources']

            def sortFN(i):
                return int(i['quality'].replace('p',''))
            mediaSources.sort(key=sortFN,reverse=True)
            #odtwarzanie
            if 'widevine' in mediaSources[0]['authorizationServices']:
                isDRM=True
            elif 'pseudo' in mediaSources[0]['authorizationServices']:
                isDRM=False
            if mediaSources[0]['accessMethod']=='direct': #MP4
                player='direct'
            elif mediaSources[0]['accessMethod']=='dash':
                player='ISA'
                
            if isDRM==False:    
                sourceId=mediaSources[0]['id']
                clientid=addon.getSetting('clientid')#('clientid_player')
                deviceid=addon.getSetting('deviceid')#('deviceid_player')
                
                sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','getPseudoLicense')
                
                data_js={
                    "id": int(code_gen(19,True)),
                    "jsonrpc": "2.0",
                    "method": "getPseudoLicense",
                    "params": {
                        "authData": {
                            "sessionToken": sessToken
                        },
                        "clientId": clientid,
                        "cpid": int(cpid),
                        "deviceId": {
                            "name": "AndroidTV null",
                            "type": "other",
                            "value": deviceid
                        },
                        "mediaId": mediaid,
                        "sourceId": sourceId,
                        "message": getMsg(),
                        "userAgentData": userAgentData
                    }
                }
                resp = requests.post('https://b2c.redefine.pl/rpc/drm/', json=data_js,headers=hea).json()
                stream_url=resp['result']['url']+'|User-Agent='+UA
                
                
            if player=='ISA': #dash
                if isDRM: #DRM
                    keyId= mediaSources[0]['keyId']
                    stream_url=mediaSources[0]['url']
                    sourceId=mediaSources[0]['id']
                    
                    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','getWidevineLicense')
                    clientid=addon.getSetting('clientid')#('clientid_player')
                    deviceid=addon.getSetting('deviceid')#('deviceid_player')
                    msg=getMsg()
                    mid=msg['id']
                    mt=msg['timestamp']
                    
                    licURL = 'https://b2c.redefine.pl/rpc/drm/'
                    heaLic={
                        'User-Agent':UA
                    }
                                        
                    data_lic={
                        "id":code_gen(19,True),
                        "jsonrpc":"2.0",
                        "method":"getWidevineLicense",
                        "params":{
                            "clientId":clientid,
                            "cpid":int(cpid),
                            "deviceId":{
                                "name": "AndroidTV null",
                                "type":"other",
                                "value":deviceid
                            },
                            "keyId":keyId,
                            "mediaId":mediaid,
                            "object":"b{SSM}",
                            "sourceId":sourceId,
                            "message":{
                                "id":mid,
                                "timestamp":mt
                            },
                            "authData":{
                                "sessionToken":sessToken
                            },
                            "userAgentData":{
                                "deviceType":"tv",
                                "application":"native",
                                "os":"android",
                                "build":100400,
                                "portal":"eleven",
                                "player":"cpplayer",
                                "widevine":True
                            }
                        }
                    }
                    lickey='%s|%s|%s|JBlicense'%(licURL,urlencode(heaLic),quote(json.dumps(data_lic)))
                    #K22
                    data_lic['params']['object']="{CHA-B64}"
                    drm_config={
                        'com.widevine.alpha': {
                            'license': {
                                'server_url':licURL,
                                'req_headers':urlencode(heaLic),
                                'req_data':base64.b64encode(json.dumps(data_lic).encode()).decode(),
                                'unwrapper':'json,base64',
                                'unwrapper_params': {'path_data': 'result/object/license'}
                            }
                        }
                    }
                
                import inputstreamhelper
                PROTOCOL = 'mpd'
                DRM = 'com.widevine.alpha'
                if isDRM:
                    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
                else:
                    is_helper = inputstreamhelper.Helper(PROTOCOL)
                if is_helper.check_inputstream():
                    play_item = xbmcgui.ListItem(path=stream_url)           
                    play_item.setMimeType('application/xml+dash')
                    play_item.setContentLookup(False)
                    play_item.setProperty('inputstream', is_helper.inputstream_addon)
                    play_item.setProperty("IsPlayable", "true")
                    play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                    if type=='tv':
                        play_item.setProperty('inputstream.adaptive.manifest_config','{\"timeshift_bufferlimit\":43200}')#K21
                    if ts!=None:
                        now=datetime.datetime.now()
                        startTime=dateConv(ts,'',False)
                        dur=43200-(now-startTime).seconds
                        play_item.getVideoInfoTag().setResumePoint(dur,1)
                    play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA) #K21
                    play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
                    play_item.setProperty('inputstream.adaptive.license_flags', "persistent_storage")
                    if isDRM:
                        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
                        if int(kodiVer.split('.')[0])<22:
                            play_item.setProperty('inputstream.adaptive.license_type', DRM)
                            play_item.setProperty('inputstream.adaptive.license_key', lickey)
                        else:
                            play_item.setProperty("inputstream.adaptive.drm", json.dumps(drm_config))
                    
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
            
            elif player=='direct': #mp4
                play_item = xbmcgui.ListItem(path=stream_url)
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
        else:
            xbmcgui.Dialog().notification('Eleven Sports', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    else:
        xbmc.log('@@@Błąd_playCont: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')

def search(q):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','searchContent')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "searchContent",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "name": "AndroidTV null",
                "type": "other",
                "value": deviceid
            },
            "limit": 50,
            "query": q,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if 'errors' not in resp and 'result' in resp:
        contData(resp)
        
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmc.log('@@@Błąd_playCont: '+str(resp), level=xbmc.LOGINFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=start,replace)')

def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Eleven Sports', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Eleven Sports', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=getTVList()
    if chans==False:
        return
    data = '#EXTM3U\n'
    for c in chans['result']['results']:
        chName=c['title']
        mediaid=c['id']
        cpid=str(c['cpid'])
        img=getImage(c['thumbnails'])
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Eleven Sports" ,%s\nplugin://plugin.video.elevens?mode=playTV&mediaid=%s&cpid=%s&type=tv\n' %(chName,img,chName,mediaid,cpid)
    
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('Eleven Sports', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        URL=j[0]
        if 'playCont' in URL:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        cmItems=[('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.elevens?mode=favDel&url='+quote(j[0])+')')]
        setArt=eval(j[3])
        addItemList(URL, j[1], setArt, 'video', eval(j[2]), isFolder, isPlayable, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,l,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,l,i])
        xbmcgui.Dialog().notification('Eleven Sports', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Eleven Sports', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('Eleven Sports', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('Eleven Sports', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)  


mode = params.get('mode', None)

if not mode:
    if addon.getSetting('deviceid')=='':
        def serialNumberGen():
            return '%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12))
        addon.setSetting('deviceid',code_gen(16))
        addon.setSetting('clientid',serialNumberGen())
        addon.setSetting('deviceid_player',code_gen(32)+'_')
        addon.setSetting('clientid_player',serialNumberGen())
    #getSession()        
    main_menu()

else:
    if mode=='start': #próba odświeżenia sesji po błędzie w resp
        getSession(True)        
        main_menu()
    
    if mode=='logIn':
        logIn()
        if addon.getSetting('logged')=='true':
            #main_menu()
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/,replace)')
    
    if mode=='logOut':
        logOut()
        if addon.getSetting('logged')=='false':
            #main_menu()
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/,replace)')
    
    if mode=='tv':
        tv()
    
    if mode=='replay':
        tv(True)
    
    if mode=='live':
        live()
        
    if mode=='catchupList': #2025-01-13
        mediaid=params.get('mediaid')
        catchupList(mediaid)
        
    if mode=='subCateg':
        
        c=params.get('categ')
        subCateg(c)
            
    if mode=='recomList': #2025-01-13
        place=params.get('place')
        recomList(place)
    
    if mode=='recomListItems': #2025-01-13
        place=params.get('place')
        page=params.get('page')
        id=params.get('id')
        recomListItems(place,id,page)
    
    if mode=='contentList':
        c=params.get('categ')
        sc=params.get('subcateg')
        p=params.get('page')
        p='1' if p==None else p
        o=params.get('sortBy')
        contentList(c,sc,p,o)
    
    if mode=='playCont':
        mediaid=params.get('mediaid')
        cpid=params.get('cpid')
        type=params.get('type')
        ts=params.get('ts')
        playCont(mediaid,cpid,type,ts)
    
    if mode=='playINFO':
        info=params.get('info')
        xbmcgui.Dialog().notification('Eleven Sports', info, xbmcgui.NOTIFICATION_INFO)
        
    if mode=='seasonList':
        cid=params.get('cid')
        seasonList(cid)
    
    if mode=='search':
        qry=xbmcgui.Dialog().input(u'Szukaj:', type=xbmcgui.INPUT_ALPHANUM)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)#
        if qry:
            #search(qry)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/?mode=searchRes&q='+quote(qry)+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.elevens/,replace)')
            #main_menu()
    
    if mode=='searchRes':
        q=params.get('q')
        search(q)
    
    if mode=='listM3U':
        listM3U()
    
    if mode=='playTV':
        getSession()
        if addon.getSetting('logged')=='true':
            mediaid=params.get('mediaid')
            cpid=params.get('cpid')
            type=params.get('type')
            playCont(mediaid,cpid,type)
        else:
            xbmcgui.Dialog().notification('Eleven Sports', 'Zaloguj się we wtyczce', xbmcgui.NOTIFICATION_INFO)
        
    #FAV
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        l=params.get('infoLab')
        i=params.get('img')
        favAdd(u,t,l,i)
        
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
      