# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
#import json
#import random
import time
import datetime
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.megogo')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'
baseurl='https://megogo.net/'
hea={
    'referer':baseurl,
    'User-Agent':UA
}


def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF) 

def main_menu():
    sources=[
        ['LIVE TV','live','DefaultTVShows.png'],
        ['Replay TV','replay','DefaultTVShows.png'],
    ]
    for s in sources:
        setArt={'icon': s[2]}
        url = build_url({'mode':s[1],'page':'0'})       
        addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def channels():
    url=baseurl+'wb/epgModule_v1/tvChannelsGrouped?lang=pl'
    resp=requests.Session().get(url,headers=hea).json()
    cGroups=resp['data']['widgets']['epgModule_v1']['json']['channel_groups']
    chans=[c['objects'] for c in cGroups if c['type_name']=='Bezpłatna telewizja' ][0]
    return chans

def tvList(type):
    chans=channels()
    if type=='live':
        chanIDs=','.join([str(c['id']) for c in chans])
        epg=epgLive(chanIDs)
            
    for c in chans:
        img=c['image']['original']
        title=c['title']
        cid=str(c['id'])
        
        if type=='live':
            isFolder=False
            isPlayable='true'
            URL=build_url({'mode':'playSource','cid':str(c['id'])})
            show=True if c['vod_channel']==False else False
            plot=epg[cid]
            
        elif type=='replay':
            isFolder=True
            isPlayable='false'
            URL=build_url({'mode':'calendar','cid':str(c['id'])})
            show=True if c['is_dvr'] else False
            plot=''
                
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
        iL={'title': '','sorttitle': '','plot': plot}
        if show:
            addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable)
            
    xbmcplugin.endOfDirectory(addon_handle)

def calendar(cid):
    days=7
    now=datetime.datetime.now()
    for i in range(0,days+1):
        date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
       
        setArt={'icon': 'DefaultYear.png'}
        url=build_url({'mode':'programList','cid':cid,'date':date})
        addItemList(url, date, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def getEPG(cid,ts,te):
    url=baseurl+'wb/epgModule_v1/epg?channel_id='+cid+'&locale=pl&from='+ts+'&to='+te+'&lang=pl'
    resp=requests.Session().get(url,headers=hea).json()
    progs=resp['data']['widgets']['epgModule_v1']['json'][0]['programs']
    return progs
    
def epgLive(c):
    since=int(time.time())
    till=since+8*60*60
    url=baseurl+'wb/epgModule_v1/epg?channel_id='+c+'&locale=pl&from='+str(since)+'&to='+str(till)+'&lang=pl'
    resp=requests.Session().get(url,headers=hea).json()
    chans=resp['data']['widgets']['epgModule_v1']['json']
    epg={}
    for c in chans:
        cid=str(c['id'])
        e=''
        for p in c['programs']:
            title=p['title']
            since=datetime.datetime.fromtimestamp(p['start_timestamp']).strftime('%H:%M')
            e+='[B]%s[/B] %s\n'%(since,title)
        epg[cid]=e
    return epg
    
    
def programList(cid,d):
    now=time.time()
    ts=datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6])).timestamp()
    if ts<now-7*24*60*60:
        ts=now-7*24*60*60
    te=(datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6]))+datetime.timedelta(days=1)).timestamp()
    if te>now:
        te=now
    epg=getEPG(cid,str(int(ts)),str(int(te)))
    for e in epg:
        if 'virtual_object_id' in e:
            title=e['title']
            since=datetime.datetime.fromtimestamp(e['start_timestamp']).strftime('%H:%M')
            till=datetime.datetime.fromtimestamp(e['end_timestamp']).strftime('%H:%M')
            name='[B]%s - %s[/B] %s'%(since,till,title)
            desc=e['description'] if 'description' in e else ''
            try:
                img=e['pictures']['original']
            except:
                img=img_empty
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
            iL={'title': title,'sorttitle': title,'plot': desc}
            url=build_url({'mode':'playReplay','vid':e['virtual_object_id'],'cid':cid})
            addItemList(url, name, setArt, 'video', iL, isF=False, isPla='true')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def playSource(u,vid=None):
    if vid==None:
        url=baseurl+'wb/videoEmbed_v2/stream?lang=pl&obj_id='+cid+'&drm_type=modular'
    else:
        url=baseurl+'wb/videoEmbed_v2/streamVirtual?lang=pl&obj_id='+cid+'&virtual_id='+vid+'&drm_type=modular'
    
    resp=requests.Session().get(url, headers=hea).json()
    streamData=resp['data']['widgets']['videoEmbed_v2']['json']
    if addon.getSetting('manualSelectedBitrate')=='false':
        #stream_url=streamData['src'] #manifest combo
        bitrates=streamData['bitrates']
        def sortFN(i):
            return i['bitrate']
        bitrates.sort(key=sortFN,reverse=True)
        stream_url=bitrates[0]['src']
    else:
        srcsName=[b['name'] for b in streamData['bitrates']]
        srcs=[b['src'] for b in streamData['bitrates']]
        select = xbmcgui.Dialog().select('Źródła', srcsName)
        if select > -1:
            stream_url=srcs[select]
        else:
            stream_url=srcs[-1]
    '''
    if ts!=None:
        now=int(time.time())
        difTime=now-int(ts)
        stream_url=stream_url.replace('/type.live','/ts/'+str(difTime)+'/type.live')
    '''
    protocol=streamData['stream_type']
    protocols={'dash':'mpd','hls':'hls'}
    if 'license_server' not in streamData:
        isDRM=False
    else:
        isDRM=True
        licHEA={
            'User-Agent':UA,
            'content-type':''
        }
        licURL=streamData['license_server']+'|'+urlencode(licHEA)+'|R{SSM}|'
    
    import inputstreamhelper
    
    PROTOCOL = protocols[protocol]
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL,drm=DRM)
    
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)                     
        #play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)        
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+baseurl)
        if isDRM:
            play_item.setProperty('inputstream.adaptive.license_type', DRM)
            play_item.setProperty('inputstream.adaptive.license_key', licURL)        
    
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Megogo', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Megogo', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    data = '#EXTM3U\n'
    for c in chans:
        if c['vod_channel']==False:
            img=c['image']['original']
            chName=c['title']
            cid=str(c['id'])
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Megogo" ,%s\nplugin://plugin.video.megogo?mode=playSource&cid=%s\n' %(chName,img,chName,cid)
    
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('Megogo', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='live':
        tvList('live')
        
    if mode=='replay':
        tvList('replay')
        
    if mode=='calendar':
        cid=params.get('cid')
        calendar(cid)
        
    if mode=='programList':
        cid=params.get('cid')
        date=params.get('date')
        programList(cid,date)
        
    if mode=='playReplay':
        cid=params.get('cid')
        vid=params.get('vid')
        playSource(cid,vid)
    
    if mode=='playSource':
        cid=params.get('cid')
        playSource(cid)
    
    if mode=='listM3U':
        listM3U()