# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
#import random
import time
import datetime
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.megogo')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0'
baseurl='https://megogo.net/'
hea={
    'referer':baseurl,
    'User-Agent':UA
}


def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def main_menu():
    sources=[
        ['LIVE TV','liveTV','DefaultTVShows.png'],
        ['LIVE Radio','liveRadio','DefaultMusicSongs.png'],
        ['Replay TV','replay','DefaultYear.png'],
        ['VOD','vod','DefaultAddonVideo.png']
    ]
    for s in sources:
        setArt={'icon': s[2],'fanart':fanart}
        url = build_url({'mode':s[1],'page':'0'})       
        addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def channels():
    url=baseurl+'wb/epgModule_v1/tvChannelsGrouped?lang=pl'
    resp=requests.Session().get(url,headers=hea).json()
    cGroups=resp['data']['widgets']['epgModule_v1']['json']['channel_groups']
    chans=[]
    for g in cGroups:
        chans+=g['objects']
    ids=[]
    channels=[]
    for c in chans:
        if c['vod_channel']==False and c['is_available'] and c['id'] not in ids:
            channels.append(c)
            ids.append(c['id'])
    return channels
    
def tvList(type):
    chans=channels()
    if 'live' in type:
        chanIDs=','.join([str(c['id']) for c in chans])
        epg=epgLive(chanIDs)
            
    for c in chans:
        img=c['image']['original']
        title=c['title']
        cid=str(c['id'])
        
        if type=='liveRadio' or type=='liveTV':
            isFolder=False
            isPlayable='true'
            URL=build_url({'mode':'playSource','cid':str(c['id'])})
            if type=='liveRadio':
                show=True if c['vod_channel']==False and c['is_available'] and 40625 in c['genres'] else False
            elif type=='liveTV':
                show=True if c['vod_channel']==False and c['is_available'] and 40625 not in c['genres'] else False
            plot=epg[cid]
            
        elif type=='replay':
            isFolder=True
            isPlayable='false'
            URL=build_url({'mode':'calendar','cid':str(c['id'])})
            show=True if c['is_dvr'] and c['is_available'] else False
            plot=''
                
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
        iL={'title': title,'sorttitle': title,'plot': plot}
        if show:
            addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable)
    
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)

def calendar(cid):
    days=7
    now=datetime.datetime.now()
    for i in range(0,days+1):
        date=(now-datetime.timedelta(days=i*1)).strftime('%Y-%m-%d')
       
        setArt={'icon': 'DefaultYear.png','fanart':fanart}
        url=build_url({'mode':'programList','cid':cid,'date':date})
        addItemList(url, date, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def getEPG(cid,ts,te):
    url=baseurl+'wb/epgModule_v1/epg?channel_id='+cid+'&locale=pl&from='+ts+'&to='+te+'&lang=pl'
    resp=requests.Session().get(url,headers=hea).json()
    progs=resp['data']['widgets']['epgModule_v1']['json'][0]['programs']
    return progs
    
def epgLive(c):
    since=int(time.time())
    till=since+8*60*60
    url=baseurl+'wb/epgModule_v1/epg?channel_id='+c+'&locale=pl&from='+str(since)+'&to='+str(till)+'&lang=pl'
    resp=requests.Session().get(url,headers=hea).json()
    chans=resp['data']['widgets']['epgModule_v1']['json']
    epg={}
    for c in chans:
        cid=str(c['id'])
        e=''
        for p in c['programs']:
            title=p['title']
            since=datetime.datetime.fromtimestamp(p['start_timestamp']).strftime('%H:%M')
            e+='[B]%s[/B] %s\n'%(since,title)
        epg[cid]=e
    return epg
    
    
def programList(cid,d):
    now=time.time()
    ts=datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6])).timestamp()
    if ts<now-7*24*60*60:
        ts=now-7*24*60*60
    te=(datetime.datetime(*(time.strptime(d, "%Y-%m-%d")[0:6]))+datetime.timedelta(days=1)).timestamp()
    if te>now:
        te=now
    epg=getEPG(cid,str(int(ts)),str(int(te)))
    for e in epg:
        if 'virtual_object_id' in e:
            title=e['title']
            since=datetime.datetime.fromtimestamp(e['start_timestamp']).strftime('%H:%M')
            till=datetime.datetime.fromtimestamp(e['end_timestamp']).strftime('%H:%M')
            name='[B]%s - %s[/B] %s'%(since,till,title)
            desc=e['description'] if 'description' in e else ''
            try:
                img=e['pictures']['original']
            except:
                img=img_empty
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            iL={'title': title,'sorttitle': title,'plot': desc}
            url=build_url({'mode':'playReplay','vid':e['virtual_object_id'],'cid':cid})
            addItemList(url, name, setArt, 'video', iL, isF=False, isPla='true')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def playSource(u,vid=None,apiVer='v2'):
    x='videoEmbed_'+apiVer
    if vid==None:
        url=baseurl+'wb/'+x+'/stream?lang=pl&obj_id='+u+'&drm_type=modular'
    else:
        url=baseurl+'wb/'+x+'/streamVirtual?lang=pl&obj_id='+u+'&virtual_id='+vid+'&drm_type=modular'
    
    resp=requests.Session().get(url, headers=hea).json()
    streamData=resp['data']['widgets'][x]['json']
    if addon.getSetting('manualSelectedBitrate')=='false':
        #stream_url=streamData['src'] #manifest combo
        bitrates=streamData['bitrates']
        def sortFN(i):
            return i['bitrate']
        bitrates.sort(key=sortFN,reverse=True)
        stream_url=bitrates[0]['src']
        lic_url=bitrates[0]['license_server'] if 'license_server' in bitrates[0] else None
    else:
        srcsName=[b['name'] for b in streamData['bitrates']]
        srcs=[b['src'] for b in streamData['bitrates']]
        select = xbmcgui.Dialog().select('Źródła', srcsName)
        if select > -1:
            stream_url=srcs[select]
            if 'license_server' in streamData['bitrates'][select]:
                lic_url=streamData['bitrates'][select]['license_server']
            else:
                lic_url=None
        else:
            stream_url=srcs[-1]
            if 'license_server' in streamData['bitrates'][-1]:
                lic_url=streamData['bitrates'][-1]['license_server']
            else:
                lic_url=None
            
    if addon.getSetting('audVOD')=='wybór ręczny' and apiVer=='v3' and len(streamData['audio_tracks'])>0:
        audsName=[b['display_name'] for b in streamData['audio_tracks']]
        auds=[b['index'] for b in streamData['audio_tracks']]
        select = xbmcgui.Dialog().select('Ścieżka audio', audsName)
        if select > -1:
            audID=auds[select]
        else:
            audID=auds[-1]
        aud_def_ID=[b['index'] for b in streamData['audio_tracks'] if b['is_active']==True][0]
        stream_url=stream_url.replace('/a/%s/' %(aud_def_ID),'/a/%s/' %(audID))
    
    '''
    if ts!=None:
        now=int(time.time())
        difTime=now-int(ts)
        stream_url=stream_url.replace('/type.live','/ts/'+str(difTime)+'/type.live')
    '''
    protocol=streamData['stream_type']
    protocols={'dash':'mpd','hls':'hls'}
    if 'license_server' not in streamData:
        isDRM=False
    else:
        isDRM=True
        licHEA={
            'User-Agent':UA,
            'content-type':''
        }
        #licURL=streamData['license_server']+'|'+urlencode(licHEA)+'|R{SSM}|'
        #stream_url=streamData['src']
        licURL=lic_url+'|'+urlencode(licHEA)+'|R{SSM}|'
    
    if not isDRM and addon.getSetting('playerType')=='ffmpeg':
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
    
        import inputstreamhelper
        
        PROTOCOL = protocols[protocol]
        DRM = 'com.widevine.alpha'
        is_helper = inputstreamhelper.Helper(PROTOCOL,drm=DRM)
        
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=stream_url)                     
            play_item.setMimeType('application/xml+dash')
            play_item.setContentLookup(False)
            play_item.setProperty('inputstream', is_helper.inputstream_addon)        
            play_item.setProperty("IsPlayable", "true")
            play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
            play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl+'&Origin='+baseurl[:-1])
            play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+baseurl+'&Origin='+baseurl[:-1])
            if isDRM:
                play_item.setProperty('inputstream.adaptive.license_type', DRM)
                play_item.setProperty('inputstream.adaptive.license_key', licURL)        
        
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Megogo', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Megogo', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    data = '#EXTM3U\n'
    for c in chans:
        if c['vod_channel']==False:
            img=c['image']['original']
            chName=c['title']
            cid=str(c['id'])
            if c['is_dvr']:
                data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Megogo" catchup="append" catchup-source="&s={utc:Y-m-dTH:M:S}&e={utcend:Y-m-dTH:M:S}" catchup-days="7",%s\nplugin://plugin.video.megogo?mode=playSource&cid=%s\n' %(chName,img,chName,cid)
            else:
                data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Megogo" ,%s\nplugin://plugin.video.megogo?mode=playSource&cid=%s\n' %(chName,img,chName,cid)
    
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('Megogo', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

def playSourceSC(cid,s,e): #Simple Client catchup
    co=int(addon.getSetting('cuOffset'))
    ts=(datetime.datetime(*(time.strptime(s, "%Y-%m-%dT%H:%M:%S")[0:6]))+datetime.timedelta(hours=co-1)).timestamp()
    te=(datetime.datetime(*(time.strptime(e, "%Y-%m-%dT%H:%M:%S")[0:6]))+datetime.timedelta(hours=co+1)).timestamp()
    
    epg=getEPG(cid,str(int(ts)),str(int(te)))
    progs=[e['virtual_object_id'] for e in epg if 'virtual_object_id' in e and e['start_timestamp']==int(ts)]
    if len(progs)>0:
        playSource(cid,progs[0])
    else:
        xbmcgui.Dialog().notification('Megogo', 'Nie znaleziono programu', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
       
def vod():
    items=[
        ['Filmy','films'],
        ['Seriale','series'],
        ['Kreskówki','mult'],
        ['Programy','show'],
        ['Sport','sport'],
    ]
    for i in items:
        setArt={'icon': 'DefaultAddonVideo.png','fanart':fanart}
        url = build_url({'mode':'vodList','categ':i[1],'page':''})       
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)
        
def vodList(categ,page):
    url=baseurl+'pl/search-extended?category_id=%s&main_tab=filters&sort=add&vod_free=true' %(categ)
    if page!=None:
        url+='&pageToken='+page
    
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('videos-list\"')[1].split('\"pagination')[0]
    resp2=resp1.split('card videoItem')
    videos=[]
    for r in resp2:
        if 'title=' in r:
            title=re.compile('title=\"([^\"]+?)\"').findall(r)[0]
            vid=re.compile('data-obj-id=\"([^\"]+?)\"').findall(r)[0]
            link=re.compile('<a href=\"([^\"]+?)\"').findall(r)[0]
            try:
                year=re.compile('video-year\">([^<]+?)<').findall(r)[0]
            except:
                year='-'
            try:
                genre=re.compile('video-country\">([^<]+?)<').findall(r)[0]
            except:
                genre='-'
            img=re.compile('data-original=\"([^\"]+?)\"').findall(r)[0]
            videos.append([title,vid,link,year,genre,img])
    
    for v in videos:
        plot='[B]Kategoria: [/B]%s\n[B]Rok: [/B]%s' %(v[4],v[3])
        img=v[5]+'%20x2'
        
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        iL={'plot': plot}
        url=build_url({'mode':'vidDet','vid':v[1]})
        cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.megogo?mode=details&vid='+v[1]+'&categ='+categ+')')]
        addItemList(url, unescape(v[0]), setArt, 'video', iL, contMenu=True, cmItems=cmItems)
    
    if 'data-page-more=' in resp:
        p=re.compile('data-page-more=\"([^\"]+?)\"').findall(resp)[0]
        
        setArt={'icon': img_empty,'fanart':fanart}
        url=build_url({'mode':'vodList','categ':categ,'page':p})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def details(vid,categ):
    url=baseurl+'pl/pl?video_id='+vid+'&origin=/pl/search-extended?category_id='+categ+'&main_tab=filters&sort=add&vod_free=true&ajax=true&widget=widget_9'
    resp=requests.get(url,headers=hea).json()
    plot=''
    if resp['result']=='ok':
        plot=re.compile('video-description\">([^<]+?)<').findall(resp['data']['widgets']['widget_9']['html'])[0]
        
    url=baseurl+'wb/videoEmbed_v3/stream?lang=pl&obj_id='+vid+'&drm_type=modular'
    resp=requests.get(url,headers=hea).json()
    streamData=resp['data']['widgets']['videoEmbed_v3']['json']
    aud=[a['display_name'] for a in streamData['audio_tracks']]
    subt=[a['display_name'] for a in streamData['subtitles']]
    if len(aud)>0:
        plot+='\n[B]Audio: [/B]'+', '.join(aud)
    if len(aud)>0:
        plot+='\n[B]Napisy: [/B]'+', '.join(subt)
    
    if plot=='':
        plot='Brak danych'
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)
    
def vidDet(vid):
    url=baseurl+'pl/view/'+vid
    resp=requests.get(url,headers=hea).text
    
    jsonData=resp.split('application/ld+json\">')[1].split('</script')[0]
    jd=json.loads(jsonData)
    title=jd['name']
    titleOrig=jd['alternativeHeadline'] if 'alternativeHeadline' in jd else title
    img=jd['thumbnailUrl']
    desc=jd['description']
    genre=jd['genre']
    contentRating=jd['contentRating']
    dur=jd['duration'].replace('PT','').replace('H',' godz. ').replace('M',' min. ').replace('S',' sek. ') if 'duration' in jd else '-'
    
    if 'nav seasons-list' in resp:#SEZONY
        plot='[B]%s[/B]\n[I](%s)[/I]\n[B]gatunek: [/B]%s\n[B]kat. wiek: [/B]%s\n%s' %(title,titleOrig,genre,contentRating,cleanText(desc))
        img=re.compile('data-original=\"([^\"]+?)\"').findall(resp.split('videoView-poster')[1])[0]
        resp1=resp.split('nav seasons-list')[1].split('</ul>')[0].split('</li>')
        for r in resp1:
            if 'data-page-title' in r:
                title=re.compile('data-page-title=\"([^\"]+?)\"').findall(r)[0]
                link=re.compile('data-href=\"([^\"]+?)\"').findall(r)[0]
                
                setArt={'icon': img}
                iL={'plot':plot}
                url=build_url({'mode':'epList','link':link,'sid':vid})
                addItemList(url, title, setArt, 'video', iL)
            
    else: #VIDEO
        plot='[B]%s[/B]\n[I](%s)[/I]\n[B]gatunek: [/B]%s\n[B]kat. wiek: [/B]%s\n[B]czas: [/B]%s\n%s' %(title,titleOrig,genre,contentRating,dur,cleanText(desc))
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        iL={'plot': plot}
        url=build_url({'mode':'playVOD','vid':vid})
        addItemList(url, '>>> Oglądaj', setArt, 'video', iL, False, 'true')
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def epList(link,sid):
    url=baseurl+link[1:]
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('videos-content\"')[1].split('videoView-content')[0]
    resp2=resp1.split('\"card videoItem')
    for r in resp2:
        if 'data-page-title' in r:
            title=re.compile('data-page-title=\"([^\"]+?)\"').findall(r)[0]
            vid=re.compile('data-id=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('<img src=\"([^\"]+?)\"').findall(r)[0]
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            iL={'plot': title}
            url=build_url({'mode':'playVOD','vid':vid})
            addItemList(url, unescape(title), setArt, 'video', iL, False, 'true')
    
    if 'data-next-page=' in resp:
        p=re.compile('data-next-page=\"([^\"]+?)\"').findall(resp)[0]
        
        setArt={'icon': img_empty}
        url=build_url({'mode':'epList_next','seas_id':link.split('/')[-1],'ser_id':sid,'page':p})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def epList_next(ser,seas,page):
    url=baseurl+'pl/view/'+ser+'?page='+page+'&season_id='+seas+'&view_template=content&origin=/pl/view/'+ser+'&ajax=true&widget=widget_16'
    resp=requests.get(url,headers=hea).json()
    htmlData=resp['data']['widgets']['widget_16']['html']
    if resp['result']=='ok':
        epsds=htmlData.split('\"card videoItem')
        for e in epsds:
            if 'data-episode' in e:
                title=re.compile('data-page-title=\"([^\"]+?)\"').findall(e)[0]
                vid=re.compile('data-id=\"([^\"]+?)\"').findall(e)[0]
                img=re.compile('<img src=\"([^\"]+?)\"').findall(e)[0]
    
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
                iL={'plot': title}
                url=build_url({'mode':'playVOD','vid':vid})
                addItemList(url, unescape(title), setArt, 'video', iL, False, 'true')
    
    if 'data-next-page=' in htmlData:
        p=re.compile('data-next-page=\"([^\"]+?)\"').findall(htmlData)[0]
        
        setArt={'icon': img_empty}
        url=build_url({'mode':'epList_next','seas_id':seas,'ser_id':ser,'page':p})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def cleanText(x):
    a=[['<p>',''],['</p>','\n']]
    for aa in a:
        x=x.replace(aa[0],aa[1])
    return x

    
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='liveTV' or mode=='liveRadio' or mode=='replay':
        tvList(mode)
                
    if mode=='calendar':
        cid=params.get('cid')
        calendar(cid)
        
    if mode=='programList':
        cid=params.get('cid')
        date=params.get('date')
        programList(cid,date)
        
    if mode=='playReplay':
        cid=params.get('cid')
        vid=params.get('vid')
        playSource(cid,vid)
    
    if mode=='playSource':
        cid=params.get('cid')
        s=params.get('s')
        e=params.get('e')
        if s!=None and e!=None:
            playSourceSC(cid,s,e)
        else:
            playSource(cid)
    
    if mode=='listM3U':
        listM3U()
    
    if mode=='vod':
        vod()
        
    if mode=='vodList':
        categ=params.get('categ')
        page=params.get('page')
        vodList(categ,page)
        
    if mode=='details':
        categ=params.get('categ')
        vid=params.get('vid')
        details(vid,categ)
        
    if mode=='vidDet':
        vid=params.get('vid')
        vidDet(vid)
    
    if mode=='epList':
        link=params.get('link')
        sid=params.get('sid')
        epList(link,sid)
    
    if mode=='epList_next':
        ser=params.get('ser_id')
        seas=params.get('seas_id')
        page=params.get('page')
        epList_next(ser,seas,page)
    
    if mode=='playVOD':
        vid=params.get('vid')
        playSource(vid,None,'v3')   
        