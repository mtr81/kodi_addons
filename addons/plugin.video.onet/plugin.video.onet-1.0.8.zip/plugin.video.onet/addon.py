# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
import datetime,time
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from resources.lib.yt_live import play_yt, epgData

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.onet')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
    
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
img_addon=PATH+'/icon.png'

baseurl='https://video.onet.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

api_podc='https://app.audio.onet.pl/api/'
UA_podc='Dalvik/2.1.0 (Linux; U; Android 10; Android SDK built for x86_64 Build/QSR1.210802.001); Mobile RingPublishing Onet Audio/1.11.4'
hea_podc={
    'Accept':'application/json',
    'Accept-Encoding':'gzip',
    'User-Agent':UA_podc
}

def build_url(query):
    return base_url + '?' + urlencode(query)
    
def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def directPlayer(url_stream,heaPlay=None):
    if heaPlay!=None:
        url_stream+='|'+heaPlay
    play_item = xbmcgui.ListItem(path=url_stream)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def main_menu():    
    sources=[
        ['Programy (video)','items','progs','DefaultAddonVideo.png'],
        #['Najnowsze odcinki (video)','items','latest','DefaultAddonVideo.png'],
        ['Podcasty','audio','','DefaultMusicSongs.png'],
        ['Transmisje (YT: Onet News)','live','','DefaultTVShows.png'],
        ['Radio Onet','radio','','DefaultMusicSongs.png'],
    ]
    for s in sources:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': s[3], 'fanart':fanart}
        if s[1] in ['live','radio']:
            url=build_url({'mode':s[1]})
            isFolder=False
            isPlayable='true'
            if s[1]=='live':
                cm=True
                cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.onet?mode=epg)')]
                plot='[B]Transmisje okazjonalne[/B]\n [I]Planowane transmisje dostępne z poziomu menu kontekstowego (szczegóły)[/I]'
            elif s[1]=='radio':
                cm=False
                cmItems=[]
                plot='Radio ONET'
        else:
            url = build_url({'mode':s[1],'type':s[2]})
            isFolder=True
            isPlayable='false'
            cm=False
            cmItems=[]
            plot=s[0]
        iL={'plot':plot}
        addItemList(url, s[0], setArt, 'video', iL, isFolder, isPlayable, cm, cmItems)
    xbmcplugin.endOfDirectory(addon_handle)

def items(t):
    url='https://video.onet.pl'
    resp=requests.get(url,headers=hea).content
    resp=resp.decode('utf-8')
    if t=='progs':
        resp1=resp.split('\"programy-onetu\"')[1].split('ods-x-editorial-block')[0]
    elif t=='latest':
        pass
    resp2=resp1.split('data-lps-hide')
    items=[]
    titles=[]
    for r in resp2:
        if 'href' in r and 'ods-c-card-wrapper' in r:
            link=re.compile('<a href=\"([^\"]+?)\"').findall(r)[0]
            #link=link.replace('weglarczyk-o-serialach','o-serialach-weglarczyk-o-serialach')
            title=re.compile('data-lps-title>([^<]+?)<').findall(r)[0].strip()
            img=re.compile('<img.*src=\"([^\"]+?)\"').findall(r)[0]
            items.append([title,link,img])
            titles.append(title)
    if t=='progs':
        isPlayable='false'
        isFolder=True
    elif t=='latest':
        isPlayable='true'
        isFolder=False
    
    if t=='progs':
        resp11=resp.split('data-omp-event-category=\"navigation\"')[1].split('</nav')[0].split('</a>')
        for rr in resp11:
            if 'href' in rr:
                link,title=re.compile('<a href=\"([^\"]+?)\"[^>]+?>(.*)').findall(rr)[0]
                title=title.strip()
                if not link.startswith('http'):
                    link='https://video.onet.pl'+link
                    if link.endswith('/naczelni'):
                        link=link.replace('video.','wiadomosci.')
                if title not in titles:
                    items.append([title,link,img_addon])
    
    for p in items:        
        iL={'plot':unescape(p[0])}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': p[2], 'fanart':fanart}
        if t=='progs':
            url = build_url({'mode':'episodes','link':p[1],'page':'1'})
        elif t=='latest':
            url = build_url({'mode':'playVid','link':p[1]})
        addItemList(url, unescape(p[0]), setArt, 'video', iL, isFolder, isPlayable)
    if t=='latest':
        xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def episodes(l,p):
    if '/audio/' in l:
        url=l
        resp=requests.get(url,headers=hea).text
        tags=re.compile('\"phoenixTags\":\"([^\"]+?)\"').findall(resp)
        if len(tags)>0:
            limit=50
            offset=0 if p==None else (int(p)-1)*50
            url='https://mp-list-api.onet.pl/2.0/lists/?size=%s&from=%s&types=podcast&phoenixTags=%s&withMetadata=true'%(str(limit),str(offset),tags[0])
            resp=requests.get(url,headers=hea).json()
            if 'entries' in resp:
                for e in resp['entries']:
                    link=e['link']['href']
                    title=e['title']['text']
                    desc='[B]%s[/B]\n\n%s'%(e['published'].split('T')[0],e['summary']['text'])
                    img=e['image']['url']
                    
                    iL={'title': title,'sorttitle': '','plot': desc}
                    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
                    url = build_url({'mode':'playVid','link':link})
                    addItemList(url, title, setArt, 'video', iL, False, 'true')
            
            #paginacja
            total=resp['total']['value']
            if (offset+limit)<total:
                setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
                url = build_url({'mode':'episodes','link':l,'page':str(int(p)+1)})
                addItemList(url, '[COLOR=yellow]>>> Następna strona[/COLOR]', setArt, 'video')
            
            
    else:
        url=l+'?strona='+p if int(p)>=2 else l
        resp=requests.get(url,headers=hea).content
        resp=resp.decode('utf-8')

        resp1=resp.split('list-driver')[1].split('\"loadMore\"')[0]
        resp2=resp1.split('ods-c-card-wrapper')
        
        episodes=[]
        for r in resp2:
            if 'href' in r and 'data-lps-title' in r: 
                link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
                title=re.compile('data-lps-title>([^<]+?)<').findall(r)[0].strip()
                img=re.compile('<img[^<]+?src=\"([^\"]+?)\"').findall(r)[0]
                
                try: 
                    desc=re.compile('data-lps-lead>([^<]+?)<').findall(r)[0].strip()
                except:
                    desc=title
                episodes.append([title,link,img,desc])

        for e in episodes:
            img=e[2]
            if not img.startswith('http') and not img.startswith('plugin'):
                img='https:'+img
            title=cleanTxt(e[0])
            plot=''
            if e[3]!=None:
                plot=unescape(e[3])
                    
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
            url = build_url({'mode':'playVid','link':e[1]})
            addItemList(url, title, setArt, 'video', iL, False, 'true')

        if 'Pokaż więcej artykułów' in resp:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
            url = build_url({'mode':'episodes','link':l,'page':str(int(p)+1)})
            addItemList(url, '[COLOR=yellow]>>> Następna strona[/COLOR]', setArt, 'video')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    
    
def playVid(l):
    hea['Referer']=''
    resp=requests.get(l,headers=hea).text
    try:
        vID=re.compile('//video.embed.videos.ringpublishing.com/([^\"]+?)\"').findall(resp)[0]
    except:
        try:
            vID=re.compile('embed.videos.ringpublishing.com/([^\"]+?)\"').findall(resp)[0] 
        except:
            vID=re.compile('pulsembed.eu/p2em/([^/]+?)/\"').findall(resp)[0] 
    url='https://player-api.dreamlab.pl/?body[method]=get&body[id]='+vID+'&body[jsonrpc]=2.0&body[params][mvp_id]='+vID+'&body[params][version]=2.0&x-onet-app=player.front.onetapi.pl&content-type=application/jsonp'
    hea.update({'Referer':'https://pulsembed.eu/'})
    respEmb=requests.get(url,headers=hea).json()
    try:
        url_stream=respEmb['result']['formats']['video']['hls'][0]['url']
    except:
        try:
            vID=re.compile('embedUrl\":\"([^"]+?)\"').findall(resp)[0]
            vID=vID.split('v=')[-1]
            url_stream='plugin://plugin.video.youtube/play/?video_id='+vID
        except:
            url_stream=''
    if url_stream !='':
        playerType=addon.getSetting('playerType')
        if playerType=='ISA' and 'plugin.video.youtube' not in url_stream:
            import inputstreamhelper
            PROTOCOL = 'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer=https://pulsembed.eu/')
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer=https://pulsembed.eu/') #K21
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            hp='User-Agent='+UA+'&Referer=https://pulsembed.eu/' if 'plugin.video.youtube' not in url_stream else None
            directPlayer(url_stream,hp)
    else:
        
        
        xbmcgui.Dialog().notification('Onet', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

#AUDIO

def audio():
    items=[
        ['Podcasty','podc','DefaultAddonMusic.png'],
        ['Najnowsze odcinki','newest','DefaultYear.png'],
        ['Kolekcje','coll','DefaultMusicPlaylists.png'],
        ['Kategorie','categs','DefaultGenre.png'],
        ['Autorzy','auths','DefaultUser.png'],
        ['Publikatorzy','brands','DefaultUser.png'],
        ['Wyszukiwarka','search','DefaultAddonsSearch.png'],
    ]
    for i in items:
        setArt={'thumb': i[2], 'poster': i[2], 'banner': i[2], 'icon': i[2], 'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def getPage(d,u,p): #helper
    p=1 if p==None else int(p)
    if 'meta' in d:
        if 'last_page' in d['meta']:
            if d['meta']['last_page']>p:
                setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
                u.update({'page':str(p+1)})
                url = build_url(u)
                addItemList(url, '[B][COLOR=cyan]>>> Następna strona[/COLOR][/B]', setArt)

def addItem(r,t=None):
    show=True
    if 'type' in r:
        ct=r['type']
                
        if ct=='podcast':
            pid=str(r['id'])
            title=r['name']
            desc=r['short_description']
            updtTime=r['published_at'].split('T')[0]
            auths_ar=[a['name'] for a in r['authors']]
            auths=', '.join(auths_ar) if len(auths_ar)>0 else ''
            img=r['thumbnail']
            
            plot=''
            if auths!='':
                plot+='[B][COLOR=cyan]Autorzy: [/COLOR][/B] %s\n'%(auths)
            plot+='[B][COLOR=cyan]Aktualizacja: [/COLOR][/B] %s\n'%(updtTime)
            if desc!=None and desc!='':
                plot+=desc
            
            isF=True
            isP='false'
            URL=build_url({'mode':'epList','pid':pid})
            iL={'title':title,'plot':plot}
        
        elif ct in ['episode','article']:
            eid=str(r['id'])
            title=r['name']
            desc=r['short_description']
            updtTime=r['published_at'].split('T')[0]
            dur=r['duration']
            img=r['thumbnail']
            
            if ct=='episode':
                podcTitle=r['podcast']['name']
                plot='[B][COLOR=cyan]Podcast: [/COLOR][/B] %s\n'%(podcTitle)
            elif ct=='article':
                brand=r['brand']['name']
                plot='[B][COLOR=cyan]Podcast: [/COLOR][/B] %s\n'%(brand)
            plot+='[B][COLOR=cyan]Aktualizacja: [/COLOR][/B] %s\n'%(updtTime)
            if desc!=None and desc!='':
                plot+=desc
            
            isF=False
            isP='true'
            URL=build_url({'mode':'playPodc','eid':eid})
            iL={'title':title,'plot':plot,'duration':dur}
        
        elif ct=='brand':
            fid=str(r['id'])
            title=r['name']
            if 'thumbnail' in r:
                img=r['thumbnail']
            if 'avatar' in r:
                img=r['avatar']
            if 'logo' in r:
                img=r['logo']
            
            isF=True
            isP='false'
            URL=build_url({'mode':'podcList','f':t,'fid':fid})
            iL={'title':title,'plot':title}
            
        elif ct in ['podcasts','articles_and_episodes','episodes','authors','brands']: #lista kolekcji
            fid=str(r['id'])
            title=r['name'].replace(' - SECTION','')
            img='DefaultGenre.png'
            
            isF=True
            isP='false'
            URL=build_url({'mode':'podcList','f':t,'fid':fid})
            iL={'title':title,'plot':title}
            
        
        else:
            show=False
    else:    
        if t in ['authors','categories','brands']:
            fid=str(r['id'])
            title=r['name']
            if 'thumbnail' in r:
                img=r['thumbnail']
            if 'avatar' in r:
                img=r['avatar']
            if 'logo' in r:
                img=r['logo']
            
            isF=True
            isP='false'
            URL=build_url({'mode':'podcList','f':t,'fid':fid})
            iL={'title':title,'plot':title}
        else:
            show=False
        
    if show:
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        addItemList(URL, title, setArt, 'video', iL, isF, isP)
        
def podc(p):
    url=api_podc+'podcasts'
    if p!=None:
        url+='?page='+p
    resp=requests.get(url,headers=hea_podc).json()
    for r in resp['data']:
        addItem(r)
    u={'mode':'podc'}
    getPage(resp,u,p)    
    
    xbmcplugin.endOfDirectory(addon_handle)

def epList(pid,p):
    url=api_podc+'podcasts/'+pid+'/episodes'
    if p!=None:
        url+='?page='+p
    resp=requests.get(url,headers=hea_podc).json()
    for r in resp['data']:
        addItem(r)
    u={'mode':'epList','pid':pid}
    getPage(resp,u,p)    
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def newest(p):
    url=api_podc+'episodes'
    if p!=None:
        url+='?page='+p
    resp=requests.get(url,headers=hea_podc).json()
    for r in resp['data']:
        addItem(r)
    u={'mode':'newest'}
    getPage(resp,u,p)    
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def podcFiltr(t,p):
    l={'categs':'categories','auths':'authors','coll':'collections','brands':'brands'}
    url=api_podc+l[t]
    if p!=None:
        url+='?page='+p
    resp=requests.get(url,headers=hea_podc).json()
    for r in resp['data']:
        addItem(r,l[t])
        
    u={'mode':t}
    getPage(resp,u,p)
    
    xbmcplugin.endOfDirectory(addon_handle)

def podcList(f,fid):
    url=api_podc+f+'/'+fid
    resp=requests.get(url,headers=hea_podc).json()
    types={'categories':'podcasts','authors':'podcasts','brands':'articles','collections':'content'}
    for r in resp['data'][types[f]]:
        if f=='collections':
            if resp['data']['type']=='authors':
                addItem(r,'authors')
            else:
                addItem(r)
        else:
            addItem(r)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def playPodc(eid):
    url=api_podc+'episodes/'+eid
    resp=requests.get(url,headers=hea_podc).json()
    try:
        stream_url=resp['data']['file']
        hp='User-Agent='+UA_podc
        directPlayer(stream_url,hp)
    except:
        xbmcgui.Dialog().notification('ONET', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def searchResGen(d,t): #helper
    return d[t]
 
def search():
    qry=xbmcgui.Dialog().input('Szukaj (przynajmniej 3 znaki):', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        url=api_podc+'search'
        p={'query':qry}
        resp=requests.get(url,headers=hea_podc,params=p).json()
        saveF(PATH_profile+'search.txt',str(resp))
        
        s=[
            ['Podcasty'+' (%s)'%(len(searchResGen(resp,'podcasts'))),'podcasts'],
            ['Odcinki'+' (%s)'%(len(searchResGen(resp,'episodes'))),'episodes'],
            ['Autorzy'+' (%s)'%(len(searchResGen(resp,'authors'))),'authors'],
            ['Kolekcje'+' (%s)'%(len(searchResGen(resp,'collections'))),'collections'],
            ['Publikatorzy'+' (%s)'%(len(searchResGen(resp,'brands'))),'brands'],
        ]
        for ss in s:
            setArt={'thumb': '', 'poster': img_addon, 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
            url = build_url({'mode':'searchRes','cat':ss[1]})
            addItemList(url, ss[0], setArt)

        xbmcplugin.endOfDirectory(addon_handle)
    else:
        main_menu()

def searchRes(c):
    data=eval(openF(PATH_profile+'search.txt'))
    items=data[c]
    for i in items:
        addItem(i,c)
    
    if c=='episodes':
        xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
 

def radio():
    stream_url='https://stream4.nadaje.com:10023/radio'
    directPlayer(stream_url,'User-Agent='+UA)

def cleanTxt(x):
    r=['\n','\t','\r']
    for rr in r:
        x=x.replace(rr,'')
    x=unescape(x)
    return x

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='items':
        type=params.get('type')
        items(type)
    
    if mode=='episodes':
        link=params.get('link')
        page=params.get('page')
        episodes(link,page)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
    
    if mode=='live':
        playerType=addon.getSetting('playerType')
        play_yt('UC_vMDcmkuEvw0N-gaP35wTA',playerType)
        
    if mode=='epg':
        epgData('UC_vMDcmkuEvw0N-gaP35wTA')
        
    if mode=='radio':
        radio()
    
    if mode=='playAud':
        link=params.get('link')
        playAud(link)
    
    #podc
    if mode=='audio':
        audio()

    if mode in ['categs','auths','coll','brands']:
        page=params.get('page')
        podcFiltr(mode,page)
        
    if mode=='podcList':
        f=params.get('f')
        fid=params.get('fid')
        podcList(f,fid)
    
    if mode=='podc':
        page=params.get('page')
        podc(page)
    
    if mode=='newest':
        page=params.get('page')
        newest(page)
    
    if mode=='epList':
        pid=params.get('pid')
        page=params.get('page')
        epList(pid,page)
    
    if mode=='playPodc':
        eid=params.get('eid')
        playPodc(eid)
        
    if mode=='search':
        search()
    
    if mode=='searchRes':    
        cat=params.get('cat')
        searchRes(cat)