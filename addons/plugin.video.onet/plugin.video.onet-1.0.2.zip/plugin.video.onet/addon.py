# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
import datetime,time
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.onet')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

mode = addon.getSetting('mode')
baseurl='https://video.onet.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def main_menu():    
    sources=[
        ['Programy','items','progs'],
        ['Najnowsze odcinki','items','latest'],
        #['Najnowsze','latest',''],
        #['SZUKAJ','search','']
        #['ULUBIONE','favList','']
    ]
    for s in sources:
        li=xbmcgui.ListItem(s[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':s[1],'type':s[2]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)    
    xbmcplugin.endOfDirectory(addon_handle)

def items(t):
    url='https://video.onet.pl'
    resp=requests.get(url,headers=hea).text
    if t=='progs':
        resp1=resp.split('programs-list')[1].split('</section')[0]
    elif t=='latest':
        resp1=resp.split('recent-episodes')[1].split('</section')[0]
    resp2=resp1.split('layout-wrapper wrap-element-')
    items=[]
    titles=[]
    for r in resp2:
        if 'href' in r and 'data-original' in r:
            link,title=re.compile('<a href=\"([^\"]+?)\" title=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('data-original=\"([^\"]+?)\"').findall(r)[0]
            items.append([title,link,img])
            titles.append(title)
    if t=='progs':
        isPlayable='false'
        isFolder=True
    elif t=='latest':
        isPlayable='true'
        isFolder=False
    
    if t=='progs':
        resp11=resp.split('mainMenu')[1].split('</ul')[0].split('</li>')
        for rr in resp11:
            if 'href' in rr:
                rr=rr.replace('\n','')
                link,title=re.compile('<a href=\"([^\"]+?)\".*>(.*)</a').findall(rr)[0]
                title=re.sub('(\s\s+)','',title)
                if not link.startswith('http'):
                    link='https://video.onet.pl'+link
                if title not in titles:
                    items.append([title,link,''])
    
    for p in items:
        img=p[2]
        li=xbmcgui.ListItem(cleanText(p[0]))
        li.setProperty("IsPlayable", isPlayable)
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        if t=='progs':
            url = build_url({'mode':'episodes','link':p[1],'page':'1'})
        elif t=='latest':
            url = build_url({'mode':'playVid','link':p[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isFolder)
    if t=='latest':
        xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def episodes(l,p):
    if int(p)>=2:
        l+='?page='+p
    resp=requests.get(l,headers=hea).text
    resp1=resp.split('article-list-container')[1].split('</ul')[0]
    resp2=resp1.split('</li>')
    episodes=[]
    for r in resp2:
        if 'href' in r and 'data-original' in r:
            link,title=re.compile('href=\"([^\"]+?)\" title=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('data-original=\"([^\"]+?)\"').findall(r)[0]
            date=re.compile('datePublished\": \"([^\"]+?)\"').findall(r)[0].split('T')[0]
            try:
                title2=re.compile('headline\": \"([^\"]+?)\"').findall(r)[0]
            except:
                title2=''
            episodes.append([title,link,img,date,title2])
    for e in episodes:
        img=e[2]
        title=cleanText(e[0])
        plot='[B]Data: [/B]'+cleanText(e[3])+'\n'
        plot+='[I]'+e[4]+'[/I]'
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'playVid','link':e[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    
    
    if 'title=\"Pokaż więcej\"' in resp:
        li=xbmcgui.ListItem('[COLOR=yellow]>>> Następna strona[/COLOR]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'episodes','link':l,'page':str(int(p)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    
    
def playVid(l):
    #'https://www.onet.pl/video/programy/burza-po-decyzji-pis-w-sprawie-tvp-to-jest-kryminal/ytf7g6g,6c2ea0e6'
    resp=requests.get(l,headers=hea).text
    vID=re.compile('//video.embed.videos.ringpublishing.com/([^\"]+?)\"').findall(resp)[0]
    url='https://player-api.dreamlab.pl/?body[method]=get&body[id]='+vID+'&body[jsonrpc]=2.0&body[params][mvp_id]='+vID+'&body[params][version]=2.0&x-onet-app=player.front.onetapi.pl&content-type=application/jsonp'
    hea.update({'Referer':'https://pulsembed.eu/'})
    resp=requests.get(url,headers=hea).json()
    try:
        url_stream=resp['result']['formats']['video']['hls'][0]['url']+'|User-Agent='+UA+'&Referer=https://pulsembed.eu/'
    except:
        url_stream=''
    if url_stream !='':
        import inputstreamhelper
        PROTOCOL = 'hls'
        is_helper = inputstreamhelper.Helper(PROTOCOL)
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=url_stream)
            #play_item.setMimeType('application/xml+dash')
            play_item.setContentLookup(False)
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
            play_item.setProperty("IsPlayable", "true")
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
            #play_item.setProperty('ResumeTime', '43200')
            #play_item.setProperty('TotalTime', '1')
            #play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
            #play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)#+'&Referer='+baseurl)
            play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('Onet', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def cleanText(x):
    x1=x.replace('&quot;','\"')
    return x1

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='items':
        type=params.get('type')
        items(type)
    
    if mode=='episodes':
        link=params.get('link')
        page=params.get('page')
        episodes(link,page)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
    
    '''            
    #favorites
    if mode=='favList':
        favList('tvp_info')
        
    if mode=='favDel':
        cid=params.get('cid')
        favDel(cid)
        
    if mode=='favAdd':
        cid=params.get('cid')
        name=params.get('name')
        mod=params.get('mod')
        img=params.get('img')
        favAdd(cid,name,mod,img,'tvp_info')
    '''
    