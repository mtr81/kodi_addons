# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
#import random
import datetime,time
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from resources.lib.yt_live import play_yt, epgData

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.onet')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
    
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
img_addon=PATH+'/icon.png'

baseurl='https://video.onet.pl/'
base_podcast='https://podcastyonet.net.libsyn.com/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

heaP={
    'User-Agent':UA,
    'Referer':base_podcast
}

def build_url(query):
    return base_url + '?' + urlencode(query)
    
def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def directPlayer(url_stream,heaPlay=None):
    if heaPlay!=None:
        url_stream+='|'+heaPlay
    play_item = xbmcgui.ListItem(path=url_stream)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def main_menu():    
    sources=[
        ['Programy (video)','items','progs','DefaultAddonVideo.png'],
        #['Najnowsze odcinki (video)','items','latest','DefaultAddonVideo.png'],
        ['Podcasty','audio','','DefaultMusicSongs.png'],
        ['Transmisje (YT: Onet News)','live','','DefaultTVShows.png'],
        ['Radio Onet','radio','','DefaultMusicSongs.png'],
    ]
    for s in sources:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': s[3], 'fanart':fanart}
        if s[1] in ['live','radio']:
            url=build_url({'mode':s[1]})
            isFolder=False
            isPlayable='true'
            if s[1]=='live':
                cm=True
                cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.onet?mode=epg)')]
                plot='[B]Transmisje okazjonalne[/B]\n [I]Planowane transmisje dostępne z poziomu menu kontekstowego (szczegóły)[/I]'
            elif s[1]=='radio':
                cm=False
                cmItems=[]
                plot='Radio ONET'
        else:
            url = build_url({'mode':s[1],'type':s[2]})
            isFolder=True
            isPlayable='false'
            cm=False
            cmItems=[]
            plot=s[0]
        iL={'plot':plot}
        addItemList(url, s[0], setArt, 'video', iL, isFolder, isPlayable, cm, cmItems)
    xbmcplugin.endOfDirectory(addon_handle)

def items(t):
    url='https://video.onet.pl'
    resp=requests.get(url,headers=hea).text
    if t=='progs':
        resp1=resp.split('programs-list')[1].split('</section')[0]
    elif t=='latest':
        resp1=resp.split('recent-episodes')[1].split('</section')[0]
    resp2=resp1.split('layout-wrapper wrap-element-')
    items=[]
    titles=[]
    for r in resp2:
        if 'href' in r and 'data-original' in r:
            link,title=re.compile('<a href=\"([^\"]+?)\" title=\"([^\"]+?)\"').findall(r)[0]
            img=re.compile('data-original=\"([^\"]+?)\"').findall(r)[0]
            items.append([title,link,img])
            titles.append(title)
    if t=='progs':
        isPlayable='false'
        isFolder=True
    elif t=='latest':
        isPlayable='true'
        isFolder=False
    
    if t=='progs':
        resp11=resp.split('mainMenu')[1].split('</ul')[0].split('</li>')
        for rr in resp11:
            if 'href' in rr:
                rr=rr.replace('\n','')
                link,title=re.compile('<a href=\"([^\"]+?)\".*>(.*)</a').findall(rr)[0]
                title=re.sub('(\s\s+)','',title)
                if not link.startswith('http'):
                    link='https://video.onet.pl'+link
                if title not in titles:
                    items.append([title,link,img_addon])
    
    for p in items:        
        iL={'plot':unescape(p[0])}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': p[2], 'fanart':fanart}
        if t=='progs':
            url = build_url({'mode':'episodes','link':p[1],'page':'1'})
        elif t=='latest':
            url = build_url({'mode':'playVid','link':p[1]})
        addItemList(url, unescape(p[0]), setArt, 'video', iL, isFolder, isPlayable)
    if t=='latest':
        xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def episodes(l,p):
    nextPage=False
    url=l+'?page='+p+'&ajax=1' if int(p)>=2 else l
    resp=requests.get(url,headers=hea).text
    try:
        resp1=resp.split('article-list-container')[1].split('</ul')[0]
        resp2=resp1.split('</li>')
    except:
        try:
            resp1=resp.split('class=\"boxArticleList')[1].split('class=\"showMore\"')[0]
        except:
            resp1=resp
            nextPage=True
        resp2=resp1.split('itarticle')
    episodes=[]
    for r in resp2:
        if 'href' in r and 'data-original' in r: #and 'data-slot-position=' in r:
            link,title=re.compile('href=\"([^\"]+?)\" title=\"([^\"]+?)\"').findall(r)[0]
            try:
                img=re.compile('data-original=\"([^\"]+?)\"').findall(r)[0]
            except:
                img=img_addon
            try:
                date=re.compile('datePublished\": \"([^\"]+?)\"').findall(r)[0].split('T')[0]
            except:
                date=None
            try:
                title2=re.compile('headline\": \"([^\"]+?)\"').findall(r)[0]
            except:
                title2=''
            episodes.append([title,link,img,date,title2])
        elif 'href' in r and 'data-uuid=' in r:# and 'data-slot-position=' in r:
            link,title=re.compile('href=\"([^\"]+?)\" title=\"([^\"]+?)\"').findall(r)[0]
            try:
                img=re.compile('src=\"([^\"]+?)\"').findall(r)[-1]
            except:
                img=img_addon
            try:
                title2=re.compile('class=\"itemTitle\"[^>]+?>([^<]+?)<').findall(r)[0]
            except:
                title2=''
            episodes.append([title,link,img,None,title2])
    for e in episodes:
        img=e[2]
        if not img.startswith('http') and not img.startswith('plugin'):
            img='https:'+img
        title=cleanTxt(e[0])
        plot=''
        if e[3]!=None:
            plot='[B]Data: [/B]'+unescape(e[3])+'\n'
        plot+='[I]'+unescape(e[4])+'[/I]'
                
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        url = build_url({'mode':'playVid','link':e[1]})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    if 'title=\"Pokaż więcej\"' in resp or '>Pokaż więcej<' in resp or nextPage:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'episodes','link':l,'page':str(int(p)+1)})
        addItemList(url, '[COLOR=yellow]>>> Następna strona[/COLOR]', setArt, 'video')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)    
    
def playVid(l):
    hea['Referer']=''
    resp=requests.get(l,headers=hea).text
    try:
        vID=re.compile('//video.embed.videos.ringpublishing.com/([^\"]+?)\"').findall(resp)[0]
    except:
        vID=re.compile('embed.videos.ringpublishing.com/([^\"]+?)\"').findall(resp)[0]
    url='https://player-api.dreamlab.pl/?body[method]=get&body[id]='+vID+'&body[jsonrpc]=2.0&body[params][mvp_id]='+vID+'&body[params][version]=2.0&x-onet-app=player.front.onetapi.pl&content-type=application/jsonp'
    hea.update({'Referer':'https://pulsembed.eu/'})
    resp=requests.get(url,headers=hea).json()
    try:
        url_stream=resp['result']['formats']['video']['hls'][0]['url']
    except:
        url_stream=''
    if url_stream !='':
        playerType=addon.getSetting('playerType')
        if playerType=='ISA':
            import inputstreamhelper
            PROTOCOL = 'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer=https://pulsembed.eu/')
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer=https://pulsembed.eu/') #K21
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            hp='User-Agent='+UA+'&Referer=https://pulsembed.eu/'
            directPlayer(url_stream,hp)
    else:
        xbmcgui.Dialog().notification('Onet', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def audio():
    resp=requests.get(base_podcast,headers=heaP).text
    podcasts=resp.split('bread crumbs')[1].split('.container ')[0].split('</a>')
    for p in podcasts:
        if '<a' in p:
            title=re.compile('var>(.*)</var').findall(p)[0]
            link=re.compile('href=\"([^\"]+?)\"').findall(p)[0]
            img=re.compile('background:url\(\'([^\']+?)\'').findall(p)[0]
            plot=title
            
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'podcEp','link':link,'page':'1'})
            addItemList(url, title, setArt, 'video', iL)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def podcEp(l,p):
    tit=l.split('/')[-1]
    url=base_podcast+'show/'+tit+'/page/'+p+'/0/0/render-type/json'
    heaP.update({'Referer':base_podcast[:-1]+l})
    resp=requests.get(url,headers=heaP).json()
    for r in resp:
        title=r['item_title']
        img=r['image_url']
        img320=img+'?height=320'
        img512=img+'?height=512'
        plot=''
        if 'release_date' in r:
            plot='[B]Data publikacji:[/B] %s\n'%(r['release_date'])
        if 'item_body_clean' in r:
            plot+='%s\n'%(r['item_body_clean'])
        try:
            u=r['primary_content']['url']
        except:
            u=None
        if u!=None and r['premium_state']=='free':
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': img320, 'poster': '', 'banner': '', 'icon': img512, 'fanart':img}
            url = build_url({'mode':'playAud','link':u})
            addItemList(url, title, setArt, 'video', iL, False, 'true')
            
    if len(resp)>0:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
        url = build_url({'mode':'podcEp','link':l,'page':str(int(p)+1)})
        addItemList(url, '[COLOR=yellow]>>> Następna strona[/COLOR]', setArt, 'video')        
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def playAud(l):
    resp=requests.get(l,heaP).content
    fURL=PATH_profile+'file.mp3'
    with open(fURL, 'wb') as f:
        f.write(resp)
      
    directPlayer(fURL)

def radio():
    stream_url='https://stream4.nadaje.com:10023/radio'
    directPlayer(stream_url,'User-Agent='+UA)

def cleanTxt(x):
    r=['\n','\t','\r']
    for rr in r:
        x=x.replace(rr,'')
    x=unescape(x)
    return x

mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='items':
        type=params.get('type')
        items(type)
    
    if mode=='episodes':
        link=params.get('link')
        page=params.get('page')
        episodes(link,page)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
    
    if mode=='live':
        playerType=addon.getSetting('playerType')
        play_yt('UC_vMDcmkuEvw0N-gaP35wTA',playerType)
        
    if mode=='epg':
        epgData('UC_vMDcmkuEvw0N-gaP35wTA')
        
    if mode=='audio':
        audio()
    
    if mode=='podcEp':
        link=params.get('link')
        page=params.get('page')
        podcEp(link,page)
    
    if mode=='playAud':
        link=params.get('link')
        playAud(link)
        
    if mode=='radio':
        radio()
        