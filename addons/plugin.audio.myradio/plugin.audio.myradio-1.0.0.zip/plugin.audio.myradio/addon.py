# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import time
#import random
#import base64
from html import unescape
import datetime
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.myradio')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
imgPATH=PATH+'/resources/img/'
img_empty=imgPATH+'empty.png'
fanart=imgPATH+'fanart.jpg'
icon_main=PATH+'icon.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl=''
hea={
    'User-Agent':UA,
}


def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(u):
    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        play_item.setMimeType('application/x-mpegurl')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty('IsPlayable', 'true')
        play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+UA+'&Referer='+baseurl)#K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(u,hp):
    u+='|'+urlencode(hp)
    play_item = xbmcgui.ListItem(path=u)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)

def getTime():
    now=datetime.datetime.now()
    return now.strftime('%Y-%m-%d_%H')

countries={
    'Polska':'https://myradioonline.pl',
    'Deutschland':'https://myonlineradio.de',
    'United Kingdom':'https://ukradiolive.com',
    'Česká republika':'https://myonlineradio.cz',
    'France':'https://myradioendirect.fr',
    'Nederland':'https://myonlineradio.nl',
    'Ireland':'https://irishradiolive.com',
    'Magyarország':'https://myonlineradio.hu',
    'Italia':'https://myradioonline.it',
    'España':'https://myradioonline.es',
    'Slovensko':'https://myonlineradio.sk',
    'România':'https://myradioonline.ro',
    'Österreich':'https://myonlineradio.at',
    'México':'https://myradioenvivo.mx',
    'Argentina':'https://myradioenvivo.ar',
    'Chile':'https://myradioonline.cl',
    'Perú':'https://myradioenvivo.pe',
    'Columbia':'https://myradioenvivo.co',
}
   
def main_menu():
    ctr=addon.getSetting('country')
    ctr='Polska' if ctr=='' else ctr
    
    img='DefaultCountry.png'
    title='[B][COLOR=cyan]Kraj: [/COLOR][/B]%s'%(ctr)
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
    URL=build_url({'mode':'setCountry'})
    addItemList(URL, title, setArt, isF=False)
    
    items=[
        ['Stacje radiowe','radio','DefaultMusicSongs.png',True],
        ['Ulubione','favList','DefaultMusicRecentlyAdded.png',True],
        ['Lista M3U (ulubione)','m3uList','DefaultFile.png',False]
        
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': fanart}
        URL=build_url({'mode':i[1]})
        addItemList(URL, i[0], setArt, isF=i[3])
    xbmcplugin.endOfDirectory(addon_handle)

def setCountry():
    ctr=addon.getSetting('country')
    ctr='Polska' if ctr=='' else ctr
    labs=list(countries)
    
    select=xbmcgui.Dialog().select('Kraj:', labs)
    if select>-1:
        new_ctr=labs[select]
    else:
        new_ctr=ctr
    
    if new_ctr!=ctr:
        addon.setSetting('country',new_ctr)
        xbmc.executebuiltin('Container.Refresh()')

def getChannels(c): #helper
    ctr_domain=countries[c]
    
    url=ctr_domain+'/radio-api/get-radios-v2/app-auth/andr1439/9dcc7a63f7426ed590982a7ddfa5b56ad820818df50550428bdfa4db3fbbe498299231aedde1577c3ef6b43b7a66243eb5df62864e439e329a0dc2d712e43d29'

    hea={
        'referer':ctr_domain,
        'x-requested-with':'XMLHttpRequest',
        'user-agent':'okhttp/3.12.12 - hu.myonlineradio.radio.pl.myonlineradio.onlineradioapplication',
        'cookie':'s=1',
        'content-type':'application/x-www-form-urlencoded',
        'accept-encoding':'gzip'
    }
    data={
        'ver':'andr1439',
        'sec-key':'a_febe521d77cbd235bc27268789e8592bb9378cb47e4e5fd5dc89493578a64049ec2c8282eda9a80d720e656c8639ba7ea1d5bf8812b0a5a198373164acf35fd6',
        'time':getTime()#'2025-04-28_01'
    }
    resp=requests.get(url,headers=hea,data=data).json()
    
    return resp

def addItem(c,ctr): #helper
    cid=c['rid']
    name=c['r_name']
    titler=c['r_slogen']
    img_labs=[i for i in list(c['settings']) if 'play' in i]
    img=c['settings'][img_labs[-1]]
    plot='[COLOR=cyan]%s[/COLOR]\n%s'%(name,titler)
    
    
    iL={'plot':plot,'title':name}
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
    URL=build_url({'mode':'playRadio','country':ctr,'cid':cid})
    
    cmItems=[
        ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.myradio?mode=favAdd&url='+quote(URL)+'&title='+quote(name)+'&art='+quote(str(setArt))+'&iL='+quote(str(iL))+')')
    ]
    
    addItemList(URL, name, setArt, 'video', iL, False, 'true', True, cmItems)
    

def radioList(c):
    channels=getChannels(c)
    for r in channels['radios']:
        addItem(r,ctr)

    xbmcplugin.endOfDirectory(addon_handle)

def playRadio(c,cid):
    channels=getChannels(c)
    channel=[ch for ch in channels['radios'] if ch['rid']==cid]
    if len(channel)>0:
        streams=channel[0]['streamServers']
        sids=list(streams)
        labs=['%s (%s kbps)'%(streams[s]['rsu_name'],streams[s]['rsu_bandwidth']) for s in sids]
        select=xbmcgui.Dialog().select('Strumienie:', labs)
        if select>-1:
            stream_url=streams[sids[select]]['rsu_url']
        else:
            stream_url=streams[sids[0]]['rsu_url']
        
        hp={
            'User-Agent':UA,
            'Referer':countries[c]
        }
        directPlayer(stream_url,hp)
        
    else:
        xbmcgui.Dialog().notification('MyRadio', 'Brak radia w bazie', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())


def m3uList():
    path_m3u=xbmcgui.Dialog().browse(0, 'Katalog docelowy', '', '', enableMultiple = False)
    fileName='myradio_m3u.m3u'
    data = '#EXTM3U\n'
    
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    
    for j in js:
        cName=j[1]
        img=eval(j[2])['icon']
        data += '#EXTINF:0 tvg-id="%s" radio="true" tvg-logo="%s" group-title="MyRadio",%s\n%s\n' % (cName,img,cName,j[0])
        
    f = xbmcvfs.File(path_m3u + fileName, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('MyRadio', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

'''
def details(pid):
    url=podcAPI+'shows/'+pid
    resp=requests.get(url,headers=hea).json()
    desc=resp['response']['show']['description']
    lastEp=resp['response']['show']['last_episode_at']
    plot=desc+'\n\n'
    if lastEp!=None:
        plot+='[B]Ostatni odcinek: [/B]%s'%(lastEp)
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)
'''

#FAV
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    
    for j in js:
        if 'play' in j[0]:
            isFolder=False
            isPlayable='true'
        else:
            isFolder=True
            isPlayable='false'

        title=j[1]
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.myradio?mode=favDel&url='+quote(j[0])+')')
        ]
        
        iL=eval(j[3])
        setArt=eval(j[2])
        url = j[0]
        addItemList(url, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,a,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,a,i])
        xbmcgui.Dialog().notification('MyRadio', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('MyRadio', 'Element jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('MyRadio', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('MyRadio', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)



mode = params.get('mode', None)

if not mode:
    main_menu()

else:
    if mode=='setCountry':
        setCountry()
    
    if mode=='radio':
        ctr=addon.getSetting('country')
        ctr='Polska' if ctr=='' else ctr
        radioList(ctr)
    
    if mode=='playRadio':
        c=params.get('country')
        cid=params.get('cid')
        playRadio(c,cid)
    
    if mode=='m3uList':
        m3uList()
    
    #FAV   
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        a=params.get('art')
        i=params.get('iL')
        favAdd(u,t,a,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
    