# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import datetime
import time
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.playpuls')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
icon=PATH+'/icon.png'


#TV
baseurl_tv='http://puls.hbbtv.emitel.pl/'
UAtv='HbbTV/2.0 (+DRM;Samsung;SmartTV2024;T-HKM6DEUC-1490.3;;)'

api_tv='http://puls.hbbtv.emitel.pl/api/puls/'
img_tv='http://puls.hbbtv.emitel.pl/puls-img'

stations=[
    ['TV Puls','puls'],
    ['Puls 2','puls2']
]

heaTV={
    'User-Agent':UAtv,
    'Origin':baseurl_tv[:-1],
    'Referer':baseurl_tv
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def player(p,u,tv=False):
    mimeTypes={'hls':'application/vnd.apple.mpegurl','mpd':'application/dash+xml'}
    
    import inputstreamhelper
    PROTOCOL = p
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        play_item.setContentLookup(False)
        play_item.setMimeType(mimeTypes[PROTOCOL])
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UAtv+'&Referer='+baseurl_tv)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UAtv+'&Referer='+baseurl_tv)
        
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)    

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def dateToStr(d,f):
    return d.strftime(f) #'%Y-%m-%d %H:%M'
    
def strToDate(s,f='%Y-%m-%dT%H:%M:%S%z'):
    return datetime.datetime(*(time.strptime(s,f)[0:6]))
    

def main_menu():
    items=[
        ['TV na żywo','live','DefaultTVShows.png'],
        ['Archiwum TV','replay','DefaultYear.png'],
        ['PULS na życzenie','vod','DefaultAddonVideo.png']
    ]
    for i in items:
        img=i[2]
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def getEpg(sid):
    d_now=datetime.datetime.now()
    now=dateToStr(d_now,'%Y-%m-%d')
    h_now=d_now.hour
    if h_now<3:
        yest=dateToStr(d_now+datetime.timedelta(days=-1),'%Y-%m-%d')
        dates=[yest,now]
    elif h_now>12:
        tom=dateToStr(d_now+datetime.timedelta(days=1),'%Y-%m-%d')
        dates=[now,tom]
    else:
        dates=[now]
    
    epgData=[]
    for d in dates:
        url=api_tv+'getPrograms'
        paramsURL={
            'day':d,
            'channel':sid
        }
        resp=requests.get(url,headers=heaTV,params=paramsURL).json()
        epgData+=resp
    
    epg=''
    
    for n,e in enumerate(epgData):
        ds=strToDate(e['startTime'])
        te=epgData[n+1]['startTime'] if n<len(epgData)-1 else e['endTime']
        de=strToDate(te)
        if de>d_now and ds<=d_now+datetime.timedelta(hours=12):
            title=e['title']
            s=dateToStr(ds,'%H:%M')
            if 'episode' in e:
                title+=' - [I]serial[/I]'
                if 'PRODCOUNTRIES' in e['episode']:
                    title+=' (%s)'%(e['episode']['PRODCOUNTRIES'])
                if 'SEASON' in e['episode']:
                    title+=' S%s'%(e['episode']['SEASON'])
                if 'EPISODENR' in e['episode']:
                    title+=' E%s'%(e['episode']['EPISODENR'])
            elif 'movie' in e:
                title+=' - [I]film[/I]'
                if 'PRODCOUNTRIES' in e['movie']:
                    title+=' %s'%(e['movie']['PRODCOUNTRIES'])
                if 'PRODYEAR' in e['movie']:
                    title+=' (%s)'%(e['movie']['PRODYEAR'])
                    
            epg+='[B]%s[/B] %s\n'%(s,title)
            
    return epg
    
def tv(t):
    for s in stations:
        name=s[0]
        sid=s[1]
        img='DefaultTVShows.png' #docelowo ikona w resources/img
        
        if t=='live':
            url=build_url({'mode':'playtv','sid':sid})
            isF=False
            isP='true'
            try:
                plot=getEpg(sid)
            except:
                plot='[I]Błąd podczas wczytywaia danych EPG[/I]'
        else:
            url=build_url({'mode':'calendar','sid':sid})
            isF=True
            isP='false'
            plot=name
            
        iL={'plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        addItemList(url, name, setArt, 'video', iL, isF, isP)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def playtv(sid,pid=None,s=None,e=None):    
    if pid==None:
        d_now=datetime.datetime.now()
        yest=dateToStr(d_now+datetime.timedelta(days=-1),'%Y-%m-%d')
        url=api_tv+'getPrograms'
        paramsURL={
            'day':yest,
            'channel':sid
        }
        resp=requests.get(url,headers=heaTV,params=paramsURL).json()
        try:
            PID=resp[0]['id']
        except:
            PID=None
    else:
        PID=pid
    streamType=addon.getSetting('streamType')
    URL_PID='https://rr.cdn.emitel.pl/URL/puls2/hbbtv-%s/%s/index.%s'
    URL='https://edge08.cdn.emitel.pl/bpk-tv/%s/hbbtv-%s/index.%s'
    chans={'puls':'Puls_HD','puls2':'Puls2_HD'}
    if streamType=='HLS':
        if PID!=None:
            URL=URL_PID %('hls',PID,'m3u8')
            stream_url=requests.get(URL,headers=heaTV).text
        else:
            stream_url=URL %(chans[sid],'hls','m3u8')
        protocol='hls'
    elif  streamType=='DASH':   
        if PID!=None:
            URL=URL_PID %('dash',PID,'mpd')
            stream_url=requests.get(URL,headers=heaTV).text
        else:
            stream_url=URL %(chans[sid],'dash','mpd')
        protocol='mpd'
        
    playMeth=addon.getSetting('playMeth')
    if pid==None or playMeth=='ts':
        stream_url=stream_url.split('?')[0]
        if s!=None: #sc_cu
            ds=strToDate(s,'%Y-%m-%dT%H:%M:%S')
            de=strToDate(e,'%Y-%m-%dT%H:%M:%S')

            is_dst=time.daylight and time.localtime().tm_isdst
            cuOffset=time.altzone if is_dst else time.timezone
            
            dso=ds+datetime.timedelta(seconds=cuOffset)
            deo=de+datetime.timedelta(seconds=cuOffset)
            s_str=dateToStr(dso,'%Y%m%dT%H%M%S')
            e_str=dateToStr(deo,'%Y%m%dT%H%M%S')
            stream_url+='?begin=%s&end=%s'%(s_str,e_str)
    
    player(protocol,stream_url,True)    
    

def calendar(sid):
    period=int(addon.getSetting('archPeriod'))
    d_now=datetime.datetime.now()
    for r in range(0,period+1):
        date=dateToStr(d_now-datetime.timedelta(days=r),'%Y-%m-%d')
        img='DefaultYear.png'
        
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url=build_url({'mode':'progs','sid':sid,'date':date})
        addItemList(url, date, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def contDet(r,epg=True): #helper
    pid=r['id']
    title=r['title']
    if epg:
        ds=strToDate(r['startTime'])
        s=dateToStr(ds,'%H:%M')
        tit='[B]%s[/B] %s' %(s,title)
    else:
        tit=title
    mpaa=r['parentalRating'] if 'parentalRating' else ''
    mpaa=mpaa if mpaa!=None else ''
    mediatype='movie'
    iL={'title':title,'plot':'...','mpaa':mpaa,'mediatype':mediatype}
    img=icon
    if 'episode' in r or 'movie' in r:
        data=r['episode'] if 'episode' in r else r['movie']
        year=data['PRODYEAR'] if 'PRODYEAR' else 0
        year=int(year) if year!=None else 0
        countries=[data['PRODCOUNTRIES']] if 'PRODCOUNTRIES' in data else []
        genre=[data['GENRE']] if 'GENRE' in data else []
        dur=data['DURATION'] if 'DURATION' in data else 0
        dur=int(dur)*60 if dur!=None else 0
        cast=[]
        if 'CAST' in data:
            cast=data['CAST'].split(',') if data['CAST']!=None else []
        director=[]
        if 'DIRECTOR' in data:
            director=data['DIRECTOR'].split(',') if data['DIRECTOR']!=None else []
        origtitle=data['ORIGTITLE'] if 'ORIGTITLE' in data else ''
        
        plot=data['EPSYNOPSIS'] if 'EPSYNOPSIS' in data else ''
        plotoutline=data['SYNOPSIS'] if 'SYNOPSIS' in data else ''
        plot=plotoutline if plot=='' or plot==None else plot
        
        if 'episode' in r:
            season=data['SEASON'] if 'SEASON' in data else 0
            season=int(season) if season!=None else 0
            episode=data['EPISODENR'] if 'EPISODENR' in data else 0
            episode=int(episode) if episode!=None else 0
            mediatype='episode'
            if 'EPTITLE' in data:
                title+= ' - %s'%(data['EPTITLE'])
    
        iL={'title':title,'originaltitle':origtitle,'plot':plot,'plotoutline':plotoutline,'duration':dur,'year':year,'country':countries,'genre':genre,'cast':cast,'mpaa':mpaa,'mediatype':mediatype}
        if mediatype=='episode':
            iL['episode']=episode
            iL['season']=season
        if 'image' in data:
            if data['image'] not in [None,'']:
                img=img_tv+data['image']

    return pid,tit,iL,img
        
def progs(sid,date):
    url=api_tv+'getPrograms'
    paramsURL={
        'day':date,
        'channel':sid
    }
    resp=requests.get(url,headers=heaTV,params=paramsURL).json()
    d_now=datetime.datetime.now()
    for i,r in enumerate(resp):
        ds=strToDate(r['startTime'])
        de=strToDate(r['endTime'])
        period=int(addon.getSetting('archPeriod'))
        if de<d_now and ds>=d_now-datetime.timedelta(seconds=period*24*60*60):
            pid,tit,iL,img=contDet(r)
            
            ts=dateToStr(ds,'%Y-%m-%dT%H:%M:%S')
            if i+1>len(resp)-1:
                date_tom=dateToStr(strToDate(date,'%Y-%m-%d')+datetime.timedelta(days=1),'%Y-%m-%d')
                url2=api_tv+'getPrograms'
                paramsURL={
                    'day':date_tom,
                    'channel':sid
                }
                resp2=requests.get(url2,headers=heaTV,params=paramsURL).json()
                if len(resp2)>0:
                    ds1=strToDate(resp2[0]['startTime'])
                    te=dateToStr(ds1,'%Y-%m-%dT%H:%M:%S')
                else: #brak EPG na kolejny dzień
                    de_real=strToDate(r['realEndTime'])
                    te=dateToStr(de_real,'%Y-%m-%dT%H:%M:%S')
                
            else:
                ds1=strToDate(resp[i+1]['startTime'])
                te=dateToStr(ds1,'%Y-%m-%dT%H:%M:%S')
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            url=build_url({'mode':'playtv','sid':sid,'pid':pid,'s':ts,'e':te})
            addItemList(url, tit, setArt, 'video', iL, False, 'true')

    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def m3u_gen():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('PlayPuls', 'Ustaw nazwę pliku oraz katalog docelowy', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('PlayPuls', 'Generuję listę M3U', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'

    for s in stations:
        sid=s[1]
        name=s[0]
        archPeriod=addon.getSetting('archPeriod')
         
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="" group-title="Play Puls" catchup="append" catchup-source="&s={utc:Y-m-dTH:M:S}&e={utcend:Y-m-dTH:M:S}" catchup-days="%s",%s\nplugin://plugin.video.playpuls?mode=playtv&sid=%s\n' %(name,archPeriod,name,sid)


    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('PlayPuls', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)


def vod():
    for s in stations:
        img='DefaultTVShows.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url=build_url({'mode':'vodCategs','chan':s[1]})
        addItemList(url, s[0], setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def vodCategs(s):
    url=api_tv+'categories?channel='+s
    resp=requests.get(url,headers=heaTV).json()
    for r in resp:
        img='DefaultGenre.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url=build_url({'mode':'vodList','cid':r['id'],'chan':s})
        addItemList(url, r['name'], setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def addVodCont(r,chan): #helper
    type=r['type'] if 'type' in r else 'episode'
    data=r['item'] if type!='episode' else r
    
    if type=='season':
        sid=data['id']
        title=data['TITLE']
        origtitle=data['ORIGTITLE'] if 'ORIGTITLE' else ''
        year=data['PRODYEAR'] if 'PRODYEAR' else 0
        year=int(year) if year!=None else 0
        countries=[data['PRODCOUNTRIES']] if 'PRODCOUNTRIES' in data else []
        genre=[data['GENRE']] if 'GENRE' in data else []
        iL={'title':title,'originaltitle':origtitle,'genre':genre,'year':year,'country':countries,'mediatype':'tvshow'}
        try:
            seasNo=data['episodes'][0]['episode']['SEASON']
        except:
            seasNo=None
        tit=title if seasNo==None else '%s - sezon %s'%(title,seasNo)
        try:
            img=img_tv+data['image']
        except:
            img=icon
        
        URL=build_url({'mode':'epList','sid':sid,'chan':chan})
        isF=True
        isP='false'
    
    elif type=='single' and 'episode' in data: #odcinek na liście seriali -> sezon
        data=data['episode']
        
        sid=data['seasonId']
        title=data['TITLE']
        origtitle=data['ORIGTITLE'] if 'ORIGTITLE' else ''
        year=data['PRODYEAR'] if 'PRODYEAR' else 0
        year=int(year) if year!=None else 0
        countries=[data['PRODCOUNTRIES']] if 'PRODCOUNTRIES' in data else []
        genre=[data['GENRE']] if 'GENRE' in data else []
        iL={'title':title,'originaltitle':origtitle,'genre':genre,'year':year,'country':countries,'mediatype':'tvshow'}
        try:
            seasNo=data['SEASON']
        except:
            seasNo=None
        tit=title if seasNo==None else '%s - sezon %s'%(title,seasNo)
        try:
            img=img_tv+data['image']
        except:
            img=icon
        
        URL=build_url({'mode':'epList','sid':sid,'chan':chan})
        isF=True
        isP='false'
        
    elif type=='single' or type=='episode':
        pid,tit,iL,img=contDet(data,False)
        
        ds=strToDate(data['realStartTime'])
        ts=dateToStr(ds,'%Y-%m-%dT%H:%M:%S')
        de=strToDate(data['realEndTime']) 
        te=dateToStr(de,'%Y-%m-%dT%H:%M:%S')
        
        if 'season' in iL:
            seas=str(iL['season'])
            if seas!='0':
                tit+= '[I] Sezon %s[/I]' %(seas)
        if 'episode' in iL:
            ep=str(iL['episode'])
            if ep!='0':
                tit+= '[I] Odcinek %s[/I]' %(ep)
        
        URL=build_url({'mode':'playtv','sid':chan,'pid':pid,'s':ts,'e':te})
        isF=False
        isP='true'

    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
    addItemList(URL, tit, setArt, 'video', iL, isF, isP)    

def vodList(cid,chan):
    url=api_tv+'categoryItems/'+cid
    resp=requests.get(url,headers=heaTV).json()
    for r in resp:
        addVodCont(r,chan)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    

def epList(sid,chan):
    url=api_tv+'seasonEpisodes/'+sid+'?channel='+chan
    resp=requests.get(url,headers=heaTV).json()
    for r in resp:
        addVodCont(r,chan)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

    
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    
    if mode in ['live','replay']:
        tv(mode)
        
    if mode=='playtv':
        sid=params.get('sid')
        pid=params.get('pid')
        s=params.get('s')
        e=params.get('e')
        playtv(sid,pid,s,e)
        
    if mode=='calendar':
        sid=params.get('sid')
        calendar(sid)
        
    if mode=='progs':
        sid=params.get('sid')
        date=params.get('date')
        progs(sid,date)    
    
    if mode=='m3u_gen':
        m3u_gen()
        
        
    if mode=='vod':
        vod()
        
    if mode=='vodCategs':
        chan=params.get('chan')
        vodCategs(chan)
        
    if mode=='vodList':
        chan=params.get('chan')
        cid=params.get('cid')
        vodList(cid,chan)
        
    if mode=='epList':
        chan=params.get('chan')
        sid=params.get('sid')
        epList(sid,chan)