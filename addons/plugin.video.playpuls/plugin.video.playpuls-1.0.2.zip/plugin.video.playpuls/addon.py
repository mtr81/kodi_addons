# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import datetime
import time
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.playpuls')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
icon=PATH+'/icon.png'

baseurl='https://playpuls.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)
    

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def main_menu():
    items=[
        ['TV na żywo','live','DefaultTVShows.png'],
        ['Archiwum TV','replay','DefaultYear.png']
    ]
    for i in items:
        img=i[2]
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    
    url='https://playpuls.pl'
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('class=\"menu\"')[1].split('</ul>')[0]
    menu=re.compile('<a href=\"([^\"]+?)\">(.*)</a>').findall(resp1)
    for m in menu:       
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': icon, 'fanart':fanart}
        url = build_url({'mode':'contentList','link':m[0]})
        addItemList(url, m[1], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def contentList(l):
    url=baseurl[:-1]+l
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('<div id=\"layout\">')[1].split('<footer')[0]
    items=[]
    links=re.compile('<a href=\"([^\"]+?)\">').findall(resp1)
    names=re.compile('category-item-title\">([^<]+?)</p').findall(resp1)
    imgs=re.compile('img src=\"([^\"]+?)\"').findall(resp1)
    if len(links)==len(names) and len(links)==len(imgs):
        for i in range(0,len(links)):
            img=baseurl[:-1]+imgs[i]
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'sezonList','link':links[i],'img':img})
            addItemList(url, cleanText(names[i]), setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def sezonList(l,img):
    url=baseurl[:-1]+l
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('tvshow-episodes__list')[1].split('<footer')[0]
    resp2=resp1.split('\"tvshow__item\"')
    episodes=[]
    sezons=[]
    for r in resp2:
        if 'player-line' in r:
            link=re.compile('<a href=\"([^\"]+?)\">').findall(r)[0]
            IMG=re.compile('img src=\"([^\"]+?)\"').findall(r)[0]
            sezon=''
            if 'episode-season-number' in r:
                sezon=re.compile('episode-season-number\">([^<]+?)</p>').findall(r)[0]
            if sezon=='' and 'data-season=' in r:
                sezon=re.compile('data-season=\"([^\"]+?)\"').findall(r)[0]
            episode=''
            if 'episode-number' in r:
                episode=re.compile('episode-number\">([^<]+?)</p>').findall(r)[0]
            title=re.compile('episode-title\">([^<]+?)</p>').findall(r)[0]
            durat=re.compile('episode-time\".*>([^<]+?)</p>').findall(r)[0]
            desc=''
            if 'episode-description' in r:
                desc=re.compile('episode-description\">([^<]+?)</p>').findall(r)[0]
            episodes.append([link,sezon,episode,title,durat,desc,IMG])
            if sezon not in sezons:
                sezons.append(sezon)
    saveF(PATH_profile+'episodes.txt',str(episodes))
    for s in sezons:
        if s=='':
            name='Inne'
        else:
            name='sezon '+s

        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
        url = build_url({'mode':'episodeList','sezon':s})
        addItemList(url, name, setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def episodeList(s):        
    if s==None:
        s=''
    episodes=eval(openF(PATH_profile+'episodes.txt'))
    for e in episodes:
        if e[1]==s:
            plot=''
            if e[1]!='':
                plot+='[B]Sezon: [/B]'+str(e[1])+'\n'
            if e[2]!='':
                plot+='[B]Odcinek: [/B]'+str(e[2])+'\n'
            if e[4]!='':
                plot+='[B]Długość: [/B]'+str(e[4])+'\n'
            if e[5]!='':
                plot+='[B]Opis: [/B][I]'+cleanText(e[5])+'[/I]'
            img=baseurl[:-1]+e[6]
            
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'playVid','link':e[0]})
            addItemList(url, cleanText(e[3]), setArt, 'video', iL, False, 'true')
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def player(p,u,tv=False):
    mimeTypes={'hls':'application/vnd.apple.mpegurl','mpd':'application/dash+xml'}
    UA_p=UA if not tv else UAtv
    baseurl_p=baseurl if not tv else baseurl_tv
    
    import inputstreamhelper
    PROTOCOL = p
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        play_item.setContentLookup(False)
        play_item.setMimeType(mimeTypes[PROTOCOL])
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA_p+'&Referer='+baseurl_p)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA_p+'&Referer='+baseurl_p)
        
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def playVid(l):
    url=baseurl[:-1]+l
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('<video-js')[1].split('</video-js')[0]
    sources=re.compile('source src=\"([^\"]+?)\"').findall(resp1)
    protocol=''
    url_stream=''
    u_hls=[s for s in sources if '.m3u8' in s]
    u_mpd=[s for s in sources if '.mpd' in s]
    if len(u_mpd)>0:
        protocol='mpd'
        url_stream=u_mpd[0]
        player(protocol,url_stream)
    elif len(u_hls)>0:
        protocol='hls'
        url_stream=u_hls[0]
        player(protocol,url_stream)
    else:
        xbmcgui.Dialog().notification('Play Puls', 'Brak źródeł.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def cleanText(x):
    return unescape(x).replace('&nbsp;',' ')
    
#TV
baseurl_tv='http://puls.hbbtv.emitel.pl/'
UAtv='HbbTV/2.0 (+DRM;Samsung;SmartTV2024;T-HKM6DEUC-1490.3;;)'

api_tv='http://puls.hbbtv.emitel.pl/api/puls/'

stations=[
    ['TV Puls','puls'],
    ['Puls 2','puls2']
]

heaTV={
    'User-Agent':UAtv,
    'Origin':baseurl[:-1],
    'Referer':baseurl
}

def dateToStr(d,f):
    return d.strftime(f) #'%Y-%m-%d %H:%M'
    
def strToDate(s,f='%Y-%m-%dT%H:%M:%S%z'):
    return datetime.datetime(*(time.strptime(s,f)[0:6]))

def getEpg(sid):
    d_now=datetime.datetime.now()
    now=dateToStr(d_now,'%Y-%m-%d')
    h_now=d_now.hour
    if h_now<3:
        yest=dateToStr(d_now+datetime.timedelta(days=-1),'%Y-%m-%d')
        dates=[yest,now]
    elif h_now>12:
        tom=dateToStr(d_now+datetime.timedelta(days=1),'%Y-%m-%d')
        dates=[now,tom]
    else:
        dates=[now]
    
    epgData=[]
    for d in dates:
        url=api_tv+'getPrograms'
        paramsURL={
            'day':d,
            'channel':sid
        }
        resp=requests.get(url,headers=heaTV,params=paramsURL).json()
        epgData+=resp
    
    epg=''
    
    for e in epgData:
        ds=strToDate(e['startTime'])
        de=strToDate(e['endTime'])
        if de>d_now and ds<=d_now+datetime.timedelta(hours=12):
            title=e['title']
            s=dateToStr(ds,'%H:%M')
            if 'episode' in e:
                title+=' - [I]serial[/I]'
                if 'PRODCOUNTRIES' in e['episode']:
                    title+=' (%s)'%(e['episode']['PRODCOUNTRIES'])
                if 'SEASON' in e['episode']:
                    title+=' S%s'%(e['episode']['SEASON'])
                if 'EPISODENR' in e['episode']:
                    title+=' E%s'%(e['episode']['EPISODENR'])
            elif 'movie' in e:
                title+=' - [I]film[/I]'
                if 'PRODCOUNTRIES' in e['movie']:
                    title+=' %s'%(e['movie']['PRODCOUNTRIES'])
                if 'PRODYEAR' in e['movie']:
                    title+=' (%s)'%(e['movie']['PRODYEAR'])
                    
            epg+='[B]%s[/B] %s\n'%(s,title)
            
    return epg
    

def tv(t):
    for s in stations:
        name=s[0]
        sid=s[1]
        img='DefaultTVShows.png' #docelowo ikona w resources/img
        
        if t=='live':
            url=build_url({'mode':'playtv','sid':sid})
            isF=False
            isP='true'
            try:
                plot=getEpg(sid)
            except:
                plot='[I]Błąd podczas wczytywaia danych EPG[/I]'
        else:
            url=build_url({'mode':'calendar','sid':sid})
            isF=True
            isP='false'
            plot=name
            
        iL={'plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        addItemList(url, name, setArt, 'video', iL, isF, isP)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def playtv(sid,pid=None,s=None,e=None):    
    if pid==None:
        d_now=datetime.datetime.now()
        yest=dateToStr(d_now+datetime.timedelta(days=-1),'%Y-%m-%d')
        url=api_tv+'getPrograms'
        paramsURL={
            'day':yest,
            'channel':sid
        }
        resp=requests.get(url,headers=heaTV,params=paramsURL).json()
        PID=resp[0]['id']
    else:
        PID=pid
    streamType=addon.getSetting('streamType')
    if streamType=='HLS':
        URL='https://rr.cdn.emitel.pl/URL/puls2/hbbtv-hls/'+PID+'/index.m3u8'
        protocol='hls'
    elif  streamType=='DASH':   
        URL='https://rr.cdn.emitel.pl/URL/puls2/hbbtv-dash/'+PID+'/index.mpd'
        protocol='mpd'
        
    stream_url=requests.get(URL,headers=heaTV).text
    if pid==None:
        stream_url=stream_url.split('?')[0]
        if s!=None: #sc_cu
            ds=strToDate(s,'%Y-%m-%dT%H:%M:%S')
            de=strToDate(e,'%Y-%m-%dT%H:%M:%S')

            is_dst=time.daylight and time.localtime().tm_isdst
            cuOffset=time.altzone if is_dst else time.timezone
            
            dso=ds+datetime.timedelta(seconds=cuOffset)
            deo=de+datetime.timedelta(seconds=cuOffset)
            s_str=dateToStr(dso,'%Y%m%dT%H%M%S')
            e_str=dateToStr(deo,'%Y%m%dT%H%M%S')
            stream_url+='?begin=%s&end=%s'%(s_str,e_str)
    
    player(protocol,stream_url,True)    
    

def calendar(sid):
    period=int(addon.getSetting('archPeriod'))
    d_now=datetime.datetime.now()
    for r in range(0,period+1):
        date=dateToStr(d_now-datetime.timedelta(days=r),'%Y-%m-%d')
        img='DefaultYear.png'
        
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url=build_url({'mode':'progs','sid':sid,'date':date})
        addItemList(url, date, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)
        
def progs(sid,date):
    url=api_tv+'getPrograms'
    paramsURL={
        'day':date,
        'channel':sid
    }
    resp=requests.get(url,headers=heaTV,params=paramsURL).json()
    d_now=datetime.datetime.now()
    for r in resp:
        ds=strToDate(r['startTime'])
        de=strToDate(r['endTime'])
        period=int(addon.getSetting('archPeriod'))
        if de<d_now and ds>=d_now-datetime.timedelta(seconds=period*24*60*60):
            pid=r['id']
            title=r['title']
            s=dateToStr(ds,'%H:%M')
            tit='[B]%s[/B] %s' %(s,title)
            mpaa=r['parentalRating'] if 'parentalRating' else ''
            mpaa=mpaa if mpaa!=None else ''
            mediatype='movie'
            iL={'title':title,'plot':'...','mpaa':mpaa,'mediatype':mediatype}
            if 'episode' in r or 'movie' in r:
                data=r['episode'] if 'episode' in r else r['movie']
                year=data['PRODYEAR'] if 'PRODYEAR' else 0
                year=int(year) if year!=None else 0
                countries=[data['PRODCOUNTRIES']] if 'PRODCOUNTRIES' in data else []
                genre=[data['GENRE']] if 'GENRE' in data else []
                dur=data['DURATION'] if 'DURATION' in data else 0
                dur=int(dur)*60 if dur!=None else 0
                cast=[]
                if 'CAST' in data:
                    cast=data['CAST'].split(',') if data['CAST']!=None else []
                director=[]
                if 'DIRECTOR' in data:
                    director=data['DIRECTOR'].split(',') if data['DIRECTOR']!=None else []
                origtitle=data['ORIGTITLE'] if 'ORIGTITLE' in data else ''
                
                plot=data['EPSYNOPSIS'] if 'EPSYNOPSIS' in data else ''
                plotoutline=data['SYNOPSIS'] if 'SYNOPSIS' in data else ''
                plot=plotoutline if plot=='' else plot
                
                if 'episode' in r:
                    season=data['SEASON'] if 'SEASON' in data else 0
                    season=int(season) if season!=None else 0
                    episode=data['EPISODENR'] if 'EPISODENR' in data else 0
                    episode=int(episode) if episode!=None else 0
                    mediatype='episode'
                    if 'EPTITLE' in data:
                        title+= ' - %s'%(data['EPTITLE'])
            
                iL={'title':title,'originaltitle':origtitle,'plot':plot,'plotoutline':plotoutline,'duration':dur,'year':year,'country':countries,'genre':genre,'cast':cast,'mpaa':mpaa,'mediatype':mediatype}
                if mediatype=='episode':
                    iL['episode']=episode
                    iL['season']=season
            img=icon
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            url=build_url({'mode':'playtv','sid':sid,'pid':pid})
            addItemList(url, tit, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def m3u_gen():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('PlayPuls', 'Ustaw nazwę pliku oraz katalog docelowy', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('PlayPuls', 'Generuję listę M3U', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'

    for s in stations:
        sid=s[1]
        name=s[0]
        archPeriod=addon.getSetting('archPeriod')
         
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="" group-title="Play Puls" catchup="append" catchup-source="&s={utc:Y-m-dTH:M:S}&e={utcend:Y-m-dTH:M:S}" catchup-days="%s",%s\nplugin://plugin.video.playpuls?mode=playtv&sid=%s\n' %(name,archPeriod,name,sid)


    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('PlayPuls', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

    
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='contentList':
        link=params.get('link')
        contentList(link)
        
    if mode=='sezonList':
        link=params.get('link')
        img=params.get('img')
        sezonList(link,img)
    
    if mode=='episodeList':
        sez=params.get('sezon')
        episodeList(sez)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
    
    if mode in ['live','replay']:
        tv(mode)
        
    if mode=='playtv':
        sid=params.get('sid')
        pid=params.get('pid')
        s=params.get('s')
        e=params.get('e')
        playtv(sid,pid,s,e)
        
    if mode=='calendar':
        sid=params.get('sid')
        calendar(sid)
        
    if mode=='progs':
        sid=params.get('sid')
        date=params.get('date')
        progs(sid,date)    
    
    if mode=='m3u_gen':
        m3u_gen()
        