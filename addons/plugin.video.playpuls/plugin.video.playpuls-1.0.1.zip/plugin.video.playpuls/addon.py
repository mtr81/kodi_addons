# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.playpuls')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'
icon=PATH+'/icon.png'

baseurl='https://playpuls.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/113.0'

hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)
    

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def main_menu():
    url='https://playpuls.pl'
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('class=\"menu\"')[1].split('</ul>')[0]
    menu=re.compile('<a href=\"([^\"]+?)\">(.*)</a>').findall(resp1)
    for m in menu:       
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': icon, 'fanart':fanart}
        url = build_url({'mode':'contentList','link':m[0]})
        addItemList(url, m[1], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def contentList(l):
    url=baseurl[:-1]+l
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('<div id=\"layout\">')[1].split('<footer')[0]
    items=[]
    links=re.compile('<a href=\"([^\"]+?)\">').findall(resp1)
    names=re.compile('category-item-title\">([^<]+?)</p').findall(resp1)
    imgs=re.compile('img src=\"([^\"]+?)\"').findall(resp1)
    if len(links)==len(names) and len(links)==len(imgs):
        for i in range(0,len(links)):
            img=baseurl[:-1]+imgs[i]
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'sezonList','link':links[i],'img':img})
            addItemList(url, cleanText(names[i]), setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def sezonList(l,img):
    url=baseurl[:-1]+l
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('tvshow-episodes__list')[1].split('<footer')[0]
    resp2=resp1.split('\"tvshow__item\"')
    episodes=[]
    sezons=[]
    for r in resp2:
        if 'player-line' in r:
            link=re.compile('<a href=\"([^\"]+?)\">').findall(r)[0]
            IMG=re.compile('img src=\"([^\"]+?)\"').findall(r)[0]
            sezon=''
            if 'episode-season-number' in r:
                sezon=re.compile('episode-season-number\">([^<]+?)</p>').findall(r)[0]
            if sezon=='' and 'data-season=' in r:
                sezon=re.compile('data-season=\"([^\"]+?)\"').findall(r)[0]
            episode=''
            if 'episode-number' in r:
                episode=re.compile('episode-number\">([^<]+?)</p>').findall(r)[0]
            title=re.compile('episode-title\">([^<]+?)</p>').findall(r)[0]
            durat=re.compile('episode-time\".*>([^<]+?)</p>').findall(r)[0]
            desc=''
            if 'episode-description' in r:
                desc=re.compile('episode-description\">([^<]+?)</p>').findall(r)[0]
            episodes.append([link,sezon,episode,title,durat,desc,IMG])
            if sezon not in sezons:
                sezons.append(sezon)
    saveF(PATH_profile+'episodes.txt',str(episodes))
    for s in sezons:
        if s=='':
            name='Inne'
        else:
            name='sezon '+s

        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
        url = build_url({'mode':'episodeList','sezon':s})
        addItemList(url, name, setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def episodeList(s):        
    if s==None:
        s=''
    episodes=eval(openF(PATH_profile+'episodes.txt'))
    for e in episodes:
        if e[1]==s:
            plot=''
            if e[1]!='':
                plot+='[B]Sezon: [/B]'+str(e[1])+'\n'
            if e[2]!='':
                plot+='[B]Odcinek: [/B]'+str(e[2])+'\n'
            if e[4]!='':
                plot+='[B]Długość: [/B]'+str(e[4])+'\n'
            if e[5]!='':
                plot+='[B]Opis: [/B][I]'+cleanText(e[5])+'[/I]'
            img=baseurl[:-1]+e[6]
            
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':fanart}
            url = build_url({'mode':'playVid','link':e[0]})
            addItemList(url, cleanText(e[3]), setArt, 'video', iL, False, 'true')
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def player(p,u):
    import inputstreamhelper
    PROTOCOL = p
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        play_item.setContentLookup(False)
        play_item.setMimeType('application/xml+dash')
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
        
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def playVid(l):
    url=baseurl[:-1]+l
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('<video-js')[1].split('</video-js')[0]
    sources=re.compile('source src=\"([^\"]+?)\"').findall(resp1)
    protocol=''
    url_stream=''
    u_hls=[s for s in sources if '.m3u8' in s]
    u_mpd=[s for s in sources if '.mpd' in s]
    if len(u_mpd)>0:
        protocol='mpd'
        url_stream=u_mpd[0]
        player(protocol,url_stream)
    elif len(u_hls)>0:
        protocol='hls'
        url_stream=u_hls[0]
        player(protocol,url_stream)
    else:
        xbmcgui.Dialog().notification('Play Puls', 'Brak źródeł.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def cleanText(x):
    return unescape(x).replace('&nbsp;',' ')
    
mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='contentList':
        link=params.get('link')
        contentList(link)
        
    if mode=='sezonList':
        link=params.get('link')
        img=params.get('img')
        sezonList(link,img)
    
    if mode=='episodeList':
        sez=params.get('sezon')
        episodeList(sez)
    
    if mode=='playVid':
        link=params.get('link')
        playVid(link)
    