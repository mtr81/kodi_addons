# -*- coding: utf-8 -*-
import os
import sys

from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import datetime,time

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.vantagetv')
file_name = addon.getSetting('fname')
path_m3u = addon.getSetting('path_m3u')

PATH=addon.getAddonInfo('path')
img_addon=PATH+'/icon.png'
PATH_img=PATH+'/resources/img/'
fanart=PATH_img+'fanart.jpg'

baseurl='https://vantagetv.eu/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:151.0) Gecko/20100101 Firefox/151.0'

hea={
    'User-Agent':UA,
    'Referer':baseurl,
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(protocol,u,h):
    import inputstreamhelper
    PROTOCOL = protocol
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty("inputstream.adaptive.manifest_headers", h)
        play_item.setProperty("inputstream.adaptive.stream_headers", h)
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
      
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def directPlayer(u,h):
    url_stream=u+'|'+h
    play_item = xbmcgui.ListItem(path=url_stream)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)    

def strToDate(s,f):
    return datetime.datetime(*(time.strptime(s,f)[0:6]))
    
def dateToStr(d,f):
    return d.strftime(f)
    
def dateUtcToLoc(d):
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    return d+datetime.timedelta(seconds=-offset)

stations={
    'Vantage Music':'vmusic',
    'Vantage Dance':'vdance',
    'Vantage Rock':'vrock',
    'Vantage Classic':'vclassic'
}

def epgData():
    url=baseurl+'scheduleData.js'
    resp=requests.get(url,headers=hea).content
    resp=resp.decode('utf-8')
    epg=re.compile(r'scheduleData = ([^;]+);').findall(resp)[0]
    epg=json.loads(epg)
    
    return epg
    
def epgChannel(e,c,d):
    epg=''
    
    now=datetime.datetime.now()
    
    d1=strToDate(d,'%Y-%m-%d')
    d0=d1-datetime.timedelta(days=1)
    d2=d1+datetime.timedelta(days=1)
    d0_str=dateToStr(d0,'%Y-%m-%d')
    d2_str=dateToStr(d2,'%Y-%m-%d')
    
    ds=[d0_str,d,d2_str]
    
    for dd in ds:
        for p in e[c][dd]:
            ts_utc=p['timesUtc'][0]
            
            s_utc='%sT%s'%(dd,ts_utc)
            d_utc=strToDate(s_utc,'%Y-%m-%dT%H:%M')
            d_loc=dateUtcToLoc(d_utc)
            
            d_loc_end=d_loc+datetime.timedelta(seconds=p['duration']*60)
            
            if now<d_loc_end:
            
                ts_loc=dateToStr(d_loc,'%H:%M')
                
                name=p['show']
                desc=p['description']
                
                epg+='[COLOR=cyan]%s[/COLOR] [B]%s[/B]\n -[I]%s[/I]\n'%(ts_loc,name,desc)
        
    return epg

def channelsData(): #helper
    url=baseurl+'data.php'
    resp=requests.get(url,headers=hea).json()
    
    return resp

def channels_gen():
    channels=channelsData()
    try:
        epg=epgData()
    except:
        epg=None
    
    for c in channels['streams']:
        cid=c['id']
        name=c['name']
        img=PATH_img+stations[name]+'.png'#c['thumbnail']
        
        d=dateToStr(datetime.datetime.now(),'%Y-%m-%d')
        epgC=name
        if epg!=None:
            try:
                epgC=epgChannel(epg,stations[name],d)
            except:
                pass
        
        iL={'title': name,'plot':epgC}
        setArt={'thumb':img,'poster':img,'banner':img,'icon':img,'fanart':fanart}
        url=build_url({'mode':'play','channel':cid})
        addItemList(url, name, setArt, 'video', iL, False, 'true')

    xbmcplugin.endOfDirectory(addon_handle)

     
def play(chId):
    stream_url=''
    
    channels=channelsData()
    cData=[c for c in channels['streams'] if c['id']==chId]
    if len(cData)>0:
        cData=cData[0]
        stream_url=cData['url']
        
    if stream_url!='':
        playerType=addon.getSetting('playerType')
        if playerType=='ISA':
            ISAplayer('hls',stream_url,urlencode(hea))
        else:
            directPlayer(stream_url,urlencode(hea))
        
def generate_m3u():
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Vantage TV', 'Ustaw nazwe pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Vantage TV', 'Generuję listę M3U', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    channels=channelsData()
    for c in channels['streams']:
        channelId = c['id']
        channelName = c['name']
        channelImg=PATH_img+stations[channelName]+'.png'
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Vantage TV",%s\nplugin://plugin.video.vantagetv?mode=play&channel=%s\n' % (channelName,channelImg,channelName,channelId)

    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('Vantage TV', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)


mode = params.get('mode', None)

if not mode:
    channels_gen()

elif mode == 'play':
    channel_id = params.get('channel')
    play(channel_id)

elif mode == 'BUILD_M3U':
    generate_m3u()
        