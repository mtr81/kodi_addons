# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.rmfon')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
addon_icon=PATH+'icon.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:132.0) Gecko/20100101 Firefox/132.0'
baseurl='https://beta.rmfon.pl/'
apiURL='https://api.rmfon.pl/'
hea={
    'User-Agent':UA,
    'Referer':baseurl,
    'Origin':baseurl[:-1]
}

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list
                    'artist':'setArtist',
                    'comment':'setComment',
                    'album':'setAlbum'
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def directPlayer(stream_url,hea=True):
    heaPlay={
        'User-Agent':UA,
        'Referer':baseurl,
        'Origin':baseurl[:-1],
    }
    if hea:
        hp='&'.join([k+'='+heaPlay[k] for k in heaPlay])
        stream_url+='|'+hp
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def cleanText(x):
    r=unescape(x) if x!=None else ''
    return r

def main_menu():
    menu=[
        ['Katalog stacji radiowych','radio','','DefaultMusicSongs.png'],
        ['Stacje radiowe','sections','stations','DefaultMusicSongs.png'],
        ['Podcasty','sections','podcasts','DefaultPlaylist.png'],
        ['Z anteny RMF24','vt','','DefaultPlaylist.png'],
        ['Strona główna','sections','homepage','DefaultTags.png'],
        ['Szukaj','search','','DefaultAddonsSearch.png'],
        ['Ulubione','fav','','DefaultMusicRecentlyAdded.png'],
    ]
    for m in menu:
        setArt={'icon': m[3], 'fanart': ''}
        url = build_url({'mode':m[1],'categ':m[2]})
        addItemList(url, m[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def sections(c):
    q='1' if c!='homepage' else '3'
    url=apiURL+c+'/sections?v-'+q+'='
    resp=requests.get(url,headers=hea).json()
    saveF(PATH_profile+'sections.txt',str(resp))
    for r in resp:
        name=cleanText(r['name'])
        slug=r['slug']
        
        setArt={'icon': 'DefaultGenre.png', 'fanart': ''}
        url = build_url({'mode':'sectionItems','slug':slug})
        addItemList(url, name, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)
    
def addItem(i,t='section',podcName=None):#helper
    type=i['type'] if t=='section' else t
    det=i['details'] if t=='section' else i
    id=str(det['id'])
    title=cleanText(det['name']) if type=='station' else cleanText(det['title'])
    img=det['img'] if 'img' in det else addon_icon
    desc=cleanText(det['description'])
    desc='' if desc==None else desc
    descShort=cleanText(i['short']) if 'short' in i else ''
    publDate=det['publication_datetime'] if 'publication_datetime' in det else '...'
    podcTitle=cleanText(det['podcast']['title']) if 'podcast' in det else '...'
    if type=='episode' and podcName!=None:
        podcTitle=podcName
    dur=det['duration'] if 'duration' in det else 0
    auth=cleanText(det['author_name']) if 'author_name' in det else '...'
    speaker=cleanText(det['speaker']) if 'speaker' in det else '...'
    recDate=det['recorded_at'] if 'recorded_at' in det else '...'
    
    plot=''
    if type=='episode':
        '''
        plot+='[COLOR=cyan][B]PODCAST: [/B][/COLOR]%s\n'%(podcTitle)
        plot+='[B]publikacja: [/B]%s\n'%(publDate)
        '''
        
        #comment+='[COLOR=cyan][B]PODCAST: [/B][/COLOR]%s\n'%(podcTitle)
        comment='[B]publikacja: [/B]%s\n'%(publDate)
        comment+=desc
        
        speaker=''
        desc=podcTitle
        
    elif type=='station':
        if t=='section':
            plot+='[COLOR=yellow][B]Stacja radiowa[/B][/COLOR]\n'
        if descShort!='':
            plot+='[B]%s[/B]\n'%(descShort)
    elif type=='podcast':
        if t=='section':
            plot+='[COLOR=yellow][B]Podcast[/B][/COLOR]\n'
        plot+='[B]autor: [/B]%s\n'%(auth)
    elif type=='vt':
        '''
        plot+='[B]prowadzący: [/B]%s\n'%(speaker)
        plot+='[B]data: [/B]%s\n'%(recDate)
        '''
        comment='[B]data: [/B]%s\n'%(recDate)
    plot+=desc
    
    if type!='vt' and type!='episode':
        iL={'title':title,'plot':plot}
    else:
        iL={'title':title,'artist':speaker,'comment':comment,'album':desc,'mediatype':'song'}
    print(iL)
    contType='video' if type!='vt' and type!='episode' else 'music'
    if type=='station':
        url = build_url({'mode':'playStation','sid':id})
        isF=False
        isP='true'
        
    elif type=='podcast':
        url = build_url({'mode':'epList','pid':id})
        isF=True
        isP='false'
        
    elif type=='episode' or type=='vt':
        iL['duration']=dur
        pid=str(det['podcast_id']) if type=='episode' else 'vt'
        url = build_url({'mode':'playPodcast','pid':pid,'eid':id})
        isF=False
        isP='true'

    setArt={'thumb': img, 'banner': img, 'poster': img,'icon': img, 'fanart': ''}
    
    cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.rmfon?mode=favAdd&name='+quote(title)+'&url='+quote(url)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type='+quote(type)+')')]
    
    addItemList(url, title, setArt, contType, iL, isF, isP, True, cmItems)    
    
def sectionItems(s):
    sections=eval(openF(PATH_profile+'sections.txt'))
    section=[ss for ss in sections if ss['slug']==s]
    if len(section)>0:
        items=section[0]['elements']
        for i in items:
            addItem(i)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

stTypes=['Wszystkie','Tradycyjne','Kanały muzyczne']

def setStType(): #helper
    stType=addon.getSetting('stType')
    st=stType if stType!='' else 'Wszystkie'
    
    select=xbmcgui.Dialog().select('Rodzaj:', stTypes)
    if select>-1:
        new_st=stTypes[select]
    else:
        new_st=st
    
    if new_st!=st:
        addon.setSetting('stType',new_st)
        xbmc.executebuiltin('Container.Refresh()')

def radio():
    stType=addon.getSetting('stType')
    st=stType if stType!='' else 'Wszystkie'
    
    #Filtr:rodzaj stacji
    tit='[COLOR=cyan][B]Rodzaj stacji: [/B][/COLOR]%s'%(st)
    setArt={'icon': 'DefaultGenre.png', 'fanart': ''}
    url = build_url({'mode':'setStType'})
    addItemList(url, tit, setArt, isF=False)
    
    url=apiURL+'stations'
    resp=requests.get(url,headers=hea).json()
    if st=='Wszystkie':
        stations=resp
    else:
        isAir=1 if st=='Tradycyjne' else 0
        stations=[s for s in resp if s['air']==isAir]
        
    for r in stations:
        addItem(r,'station')
        
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)

def vt(p):
    page='1' if p==None else p
    url=apiURL+'rmf24/voicetracks'
    if page!='1':
        url+='?page='+page
    resp=requests.get(url,headers=hea).json()
    if 'voicetracks' in resp:
        for r in resp['voicetracks']:
            addItem(r,'vt')
    
        if 'pagination' in resp:
            if resp['pagination']['lastPage']>int(page):
                setArt={'icon':img_empty, 'fanart': ''}
                url = build_url({'mode':'vt','page':str(int(page)+1)})
                addItemList(url, '[COLOR=cyan][B]>>> następna strona[/B][/COLOR]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'songs')
    xbmcplugin.endOfDirectory(addon_handle)

def epList(pid,p):
    page='1' if p==None else p
    url=apiURL+'podcasts/'+pid+'/episodes?page='+page
    resp=requests.get(url,headers=hea).json()
    if 'episodes' in resp:
        podcName=cleanText(resp['podcast']['title'])
        for r in resp['episodes']:
            addItem(r,'episode',podcName)
    
        if 'pagination' in resp:
            if resp['pagination']['lastPage']>int(page):
                setArt={'icon':img_empty, 'fanart': ''}
                url = build_url({'mode':'epList','page':str(int(page)+1)})
                addItemList(url, '[COLOR=cyan][B]>>> następna strona[/B][/COLOR]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'songs')
    xbmcplugin.endOfDirectory(addon_handle)
    
def playStation(sid):
    url=apiURL+'stations/'+sid+'/streams'
    resp=requests.get(url,headers=hea).json()
    
    codecType=addon.getSetting('codecType')
    try:
        if codecType=='AAC':
            stream_url=resp['playlist']['item'][0]
        elif codecType=='MP3':
            stream_url=resp['playlistMp3']['item_mp3'][0]
            
        directPlayer(stream_url)
    except:
        xbmcgui.Dialog().notification('RMF ON', 'Stream niedostępny', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
def playPodcast(pid,eid):
    url=apiURL+'podcasts/'+pid+'/episodes/'+eid if pid!='vt' else apiURL+'rmf24/voicetracks/'+eid
    resp=requests.get(url,headers=hea).json()
    src=''
    if 'filename' in resp:
        if resp['filename']!='' and resp['filename']!=None:
            src=resp['filename']
    
    if src!='':
        #directPlayer(src)
        '''pobranie pliku'''        
        resp=requests.get(src,headers=hea).content
        fURL=PATH_profile+'file.mp3'
        with open(fURL, 'wb') as f:
            f.write(resp)
        directPlayer(fURL,False)
        
    else:
        xbmcgui.Dialog().notification('RMF ON', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())


def searchCategs(q):
    url=apiURL+'search?q='+quote(q)
    resp=requests.get(url,headers=hea).json()
    saveF(PATH_profile+'searchRes.txt',str(resp))
    
    items=[
        ['Stacje','stations','DefaultMusicSongs.png'],
        ['Podcasty','podcasts','DefaultPlaylist.png'],
        ['Odcinki','podcast_episodes','DefaultTags.png'],
        ['Informacje RMF24','voicetracks_rmf24','DefaultTags.png'],
    ]
    
    for i in items:
        if i[1] in resp:
            cnt=len(resp[i[1]])
            if cnt>0:
                setArt={'icon':i[2], 'fanart': ''}
                url = build_url({'mode':'searchRes','type':i[1]})
                addItemList(url, '%s [I](%s)[/I]'%(i[0],str(cnt)), setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)
    
def searchRes(t):
    res=eval(openF(PATH_profile+'searchRes.txt'))
    for i in res[t]:
        if t=='stations':
            addItem(i,'station')
        elif t=='podcasts':
            addItem(i,'podcast')
        elif t=='podcast_episodes':
            addItem(i,'episode')
        elif t=='voicetracks_rmf24':
            addItem(i,'vt')
            
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)

def fav():
    items=[
        ['Stacje','station','DefaultMusicSongs.png'],
        ['Podcasty','podcast','DefaultPlaylist.png'],
        ['Odcinki','episode','DefaultTags.png'],
        ['Dźwięki','vt','DefaultTags.png'],
    ]
    for i in items:
        setArt={'icon':i[2], 'fanart': ''}
        url = build_url({'mode':'favList','type':i[1]})
        addItemList(url, i[0], setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)    
    
def favList(t):
    fURL=PATH_profile+'ulubione3.json'
    js=openJSON(fURL)
    for j in js:
        if j[0]==t:
            title=j[1]
            URL=j[2]
            iL=eval(j[4])
            setArt=eval(j[3])
            contType='music' if t=='podcast' or t=='episode' else 'video'
            
            if 'playStation' in URL or 'playPodcast' in URL:
                isPlayable='true'
                isFolder=False
            else:
                isPlayable='false'
                isFolder=True

            cmItems=[('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.rmfon?mode=favDel&url='+quote(URL)+')')]
            
            addItemList(URL, title, setArt, contType, iL, isFolder, isPlayable, True, cmItems)
    
    ct='videos' if t!='episode' and t!='vt' else 'songs'
    
    xbmcplugin.setContent(addon_handle, ct)
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(l):
    fURL=PATH_profile+'ulubione3.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[2]==l:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(t,n,u,a,i):#
    fURL=PATH_profile+'ulubione3.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[2]==u:
            duplTest=True
    if not duplTest:
        js.append([t,n,u,a,i])

        xbmcgui.Dialog().notification('RMF ON', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('RMF ON', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione3.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('RMF ON', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione3.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('RMF ON', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)



mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='sections':
        categ=params.get('categ')
        sections(categ) 
    
    if mode=='sectionItems':
        slug=params.get('slug')
        sectionItems(slug) 
    
    if mode=='epList':
        pid=params.get('pid')
        page=params.get('page')
        epList(pid,page)
        
    if mode=='playStation':
        sid=params.get('sid')
        playStation(sid)
        
    if mode=='playPodcast':
        pid=params.get('pid')
        eid=params.get('eid')
        playPodcast(pid,eid)
    
    if mode=='setStType':
        setStType()
    
    if mode=='radio':
        radio()
        
    if mode=='vt':
        page=params.get('page')
        vt(page)
        
    if mode=='search':
        query = xbmcgui.Dialog().input('Szukana fraza:', type=xbmcgui.INPUT_ALPHANUM)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        if query:
            xbmc.executebuiltin('Container.Update(plugin://plugin.audio.rmfon/?mode=searchCategs&q='+query+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.audio.rmfon/,replace)')
    
    if mode=='searchCategs':
        q=params.get('q')
        searchCategs(q)
    
    if mode=='searchRes':
        type=params.get('type')
        searchRes(type)
    
    #FAV    
    if mode=='fav':
        fav()
        
    if mode=='favList':
        type=params.get('type')
        favList(type)
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        t=params.get('type')
        n=params.get('name')
        u=params.get('url')
        a=params.get('setArt')
        i=params.get('iL')
        favAdd(t,n,u,a,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
