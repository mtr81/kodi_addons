# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
import json
#import random
#import time
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.rmfon')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0'
baseurl='https://www.rmfon.pl/'
hea={
    'User-Agent':UA,
    'Referer':baseurl,
    'Origin':baseurl[:-1],
    'X-Requested-With':'XMLHttpRequest'
}

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def main_menu():
    menu=[
        ['Stacje radiowe','radio','DefaultMusicSongs.png'],
        ['Podcasty','podcast','DefaultPlaylist.png'],
    ]
    for m in menu:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': m[2], 'fanart': ''}
        url = build_url({'mode':m[1]})
        addItemList(url, m[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def radio():
    menuR=[
        ['Lista stacji','stationList','DefaultMusicSongs.png'],
        ['Stacje wg kategorii','stationCategs','DefaultMusicSongs.png'],
        ['Wyszukiwarka kanałów','stationSearch','DefaultAddonsSearch.png'],
        ['ULUBIONE','favList','DefaultMusicRecentlyAdded.png']
    ]
    for m in menuR:        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': m[2], 'fanart': ''}
        url = build_url({'mode':m[1],'type':'radio'})
        addItemList(url, m[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def stationList(c=None):
    url='https://www.rmfon.pl/xml/stations.txt'#https://www.rmfon.pl/json/stations.php
    resp=requests.get(url,headers=hea).text
    stations=[]
    stID=re.compile('id=\"([^\"]+?)\"').findall(resp)
    stName=re.compile('\tname=\"([^\"]+?)\"').findall(resp)
    if len(stID)==len(stName):
        for i in range(0,len(stID)):
            stations.append([stID[i],stName[i]])
    if c!=None:
        stByCateg=eval(openF(PATH_profile+'stationCategs.txt'))[c]
    for s in stations:
        if c==None or (c!=None and int(s[0]) in stByCateg):
            name=cleanText(s[1])
            
            iL={'plot':name}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultMusicSongs.png', 'fanart': ''}
            url = build_url({'mode':'playStation','sid':str(s[0])})
            
            cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.rmfon?mode=favAdd&name='+quote(cleanText(s[1]))+'&url='+quote(url)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=radio)')]
            
            addItemList(url, name, setArt, 'video', iL, False, 'true', True, cmItems)
            
    xbmcplugin.endOfDirectory(addon_handle)

def stationCategs():
    url='https://www.rmfon.pl'
    resp=requests.get(url,headers=hea).text
    resp1=resp.split('category-checkbox-container')[1].split('radio-list')[0]
    categsBase=re.compile('data-list=\"([^\"]+?)\">([^<]+?)</div').findall(resp1)
    categ={}
    for c in categsBase:
        categ[c[1]]=eval(c[0])
    saveF(PATH_profile+'stationCategs.txt',str(categ))
    categories=list(categ.keys())
    for cc in categories:    
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultMusicGenres.png', 'fanart': ''}
        url = build_url({'mode':'stationList','categ':cc})
        addItemList(url, cc, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)
        
def stationSearchRes(query):
    url='https://www.rmfon.pl/szukaj?q='+quote_plus(query)
    resp=requests.get(url,headers=hea).json()
    for s in resp['stations']:
        name=s['name']
        
        iL={'plot':name}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultMusicSongs.png', 'fanart': ''}
        url = build_url({'mode':'playStation','sid':str(s['id'])})
        
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.rmfon?mode=favAdd&name='+quote(s['name'])+'&url='+quote(url)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=radio)')]
        
        addItemList(url, name, setArt, 'video', iL, False, 'true', True, cmItems)
            
    xbmcplugin.endOfDirectory(addon_handle)

def playStation(sid):
    url_stream=''
    url='https://www.rmfon.pl/stacje/flash_aac_'+sid+'.xml.txt'
    resp=requests.get(url,headers=hea).text
    streams=re.compile('>([^<]+?)</item>').findall(resp)
    if len(streams)>0:
        url_stream=streams[0]+'|Referer='+baseurl+'&User-Agent='+UA
        
        play_item = xbmcgui.ListItem(path=url_stream)
        play_item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('RMF ON', 'Stream niedostępny', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
             
def podcast():
    menuP=[
        ['Lista podcastów','podcastList','DefaultPlaylist.png'],
        ['Podcasty wg kategorii','podcastCategs','DefaultPlaylist.png'],
        ['Najnowsze','podcastNewest','DefaultPlaylist.png'],
        ['ULUBIONE','favList','DefaultMusicRecentlyAdded.png']
        #['Wyszukiwarka podcastów','podcastSearch','']    
    ]
    for m in menuP:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': m[2], 'fanart': ''}
        url = build_url({'mode':m[1],'type':'podcast'})
        addItemList(url, m[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def podcastList(c=None):
    url='https://www.rmfon.pl/json/podcasts.php'
    resp=requests.get(url,headers=hea).json()
    for p in resp['podcasts']:
        if c==None or (c!=None and c in p['categories']):
            img=p['img']
            title=cleanText(p['title'])
            pid=p['id']
            desc=p['description']
            podcastURL=p['url']
            
            iL={'title': '','sorttitle': '','plot': desc}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''}
            url = build_url({'mode':'podcastEpisodes','URL':podcastURL,'page':'1'})
            
            cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.rmfon?mode=favAdd&name='+quote(title)+'&url='+quote(url)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+'&type=podcast)')]
            
            addItemList(url, title, setArt, 'video', iL, contMenu=True, cmItems=cmItems)
            
    xbmcplugin.endOfDirectory(addon_handle)
        
def podcastEpisodes(u,p):      
    count=int(addon.getSetting('count'))
    offset=(int(p)-1)*count
    totalCount=0
    if p=='1':
        resp=requests.get(u,headers=hea).text
        #print(resp)
        episodesAll=[]
        items=resp.split('</item>')
        #print(items)
        for i in items:
            if '<link>' in i:
                title=re.compile('<title>(.*)</title>').findall(i)[-1]
                if 'CDATA' in title:
                    title=re.compile('CDATA\[([^\]]+?)\]').findall(title)[0]
                urlStream=re.compile('<enclosure url=\"([^\"]+?)\"').findall(i)[-1]
                try:
                    dur=re.compile('duration>(.*)<').findall(i)[-1]
                except:
                    dur=''
                publTime=re.compile('<pubDate>(.*)<').findall(i)[-1]
                try:
                    desc=re.compile('<description>(.*)</description').findall(i)[-1]
                except:
                    desc=''
                episodesAll.append([title,urlStream,dur,publTime,desc])
        #print(episodes)
        saveF(PATH_profile+'podcEpi.txt',str(episodesAll))
    else:
        episodesAll=eval(openF(PATH_profile+'podcEpi.txt'))
    
    totalCount=len(episodesAll)            
    episodes=[]
    for i in range(offset,min(offset+count,totalCount)):
        episodes.append(episodesAll[i])
    for e in episodes:
        plot='[B]Data publikacji: [/B]'+e[3]+'\n'
        if e[2]!='':
            plot+='[B]Czas trwania: [/B]'+e[2]+'\n'
        if e[4]!='':
            plot=='[B]Opis: [/B]'+cleanText(e[4])
        title=cleanText(e[0])
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon':'DefaultPlaylist.png' , 'fanart': ''}
        url = build_url({'mode':'playPodcast','URL':e[1]})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
        
        
    if offset+2*count<=totalCount:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
        url = build_url({'mode':'podcastEpisodes','URL':u,'page':str(int(p)+1)})
        addItemList(url, '[B][COLOR=yellow]>>> następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def playPodcast(u):
    url_stream=u+'|Referer='+baseurl+'&User-Agent='+UA
        
    play_item = xbmcgui.ListItem(path=url_stream)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def podcastNewest():
    url='https://www.rmfon.pl/json/podcast-newest.php'
    resp=requests.get(url,headers=hea).json()
    for p in resp:
        title='[B]'+cleanText(p['title']) + '[/B] - ' +cleanText(p['t'])
        plot=''
        if 'd' in p:
            plot+='[B]Data publikacji: [/B]'+p['d']+'\n'
        if 'dur' in p:
            plot+='[B]Czas trwania: [/B]'+p['dur']+'\n'
        if 'desc' in p:
            plot+='[B]Opis: [/B]'+cleanText(p['desc'])
        podcastURL=p['url']
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon':'DefaultPlaylist.png' , 'fanart': ''}
        url = build_url({'mode':'playPodcast','URL':podcastURL})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
        
def podcastCategs():
    url='https://www.rmfon.pl/json/podcasts.php'
    resp=requests.get(url,headers=hea).json()
    categs=list(resp['categories'].keys())
    for c in categs:
        title=c+' [I]('+str(resp['categories'][c])+')[/I]'
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultPlaylist.png', 'fanart': ''}
        url = build_url({'mode':'podcastList','categ':c})
        addItemList(url, title, setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def cleanText(x):
    x1=x.replace('&nbsp;',' ')
    x2=x1.replace('&amp;','&')
    x3=x2.replace('&quot;','\"')
    return x3

  
#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList(t):
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    for j in js:
        if j[0]==t:
            title=j[1]
            URL=j[2]
            iL=eval(j[4])
            setArt=eval(j[3])
            
            if 'playStation' in URL or 'playPodcast' in URL:
                isPlayable='true'
                isFolder=False
            else:
                isPlayable='false'
                isFolder=True

            cmItems=[('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.rmfon?mode=favDel&url='+quote(URL)+')')]
            
            addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
    
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(l,s):
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[3]==l or j[2]==s:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(t,n,u,a,i):#
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[2]==u:
            duplTest=True
    if not duplTest:
        js.append([t,n,u,a,i])

        xbmcgui.Dialog().notification('RMF ON', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('RMF ON', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione2.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('RMF ON', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione2.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('RMF ON', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)


mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='radio':
        radio()
    
    if mode=='podcast':
        podcast()
    
    if mode=='stationList':
        c=params.get('categ')
        stationList(c)
        
    if mode=='stationCategs':
        stationCategs()
        
    if mode=='stationSearch':
        query = xbmcgui.Dialog().input('Podaj nazwę:', type=xbmcgui.INPUT_ALPHANUM)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        if query:
            xbmc.executebuiltin('Container.Update(plugin://plugin.audio.rmfon/?mode=stationSearchRes&q='+query+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.audio.rmfon/,replace)')
    
    if mode=='stationSearchRes':
        q=params.get('q')
        stationSearchRes(q)
        
    if mode=='playStation':
        s=params.get('sid')
        playStation(s)
    
    if mode=='podcastList':
        c=params.get('categ')
        podcastList(c)
        
    if mode=='podcastCategs':
        podcastCategs()
    
    if mode=='podcastEpisodes':
        URL=params.get('URL')
        page=params.get('page')
        podcastEpisodes(URL,page)
    
    if mode=='playPodcast':
        URL=params.get('URL')
        playPodcast(URL)
    
    if mode=='podcastNewest':
        podcastNewest()
    

    #FAV    
    if mode=='favList':
        type=params.get('type')
        favList(type)
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        t=params.get('type')
        n=params.get('name')
        u=params.get('url')
        a=params.get('setArt')
        i=params.get('iL')
        favAdd(t,n,u,a,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
