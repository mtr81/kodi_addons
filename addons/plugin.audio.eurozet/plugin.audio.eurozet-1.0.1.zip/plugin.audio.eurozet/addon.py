# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
import json
#import random
import datetime
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.eurozet')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/images/empty.png'
img_logo=PATH+'/resources/images/'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0'
baseurl='https://player.chillizet.pl/'
apiURL='https://player.chillizet.pl/api/'

def hea(x):
    bu='https://player.%s..pl/' %(x)
    hea={
        'User-Agent':UA,
        'Referer':bu,
        'Origin':bu[:-1],
    }
    return hea
    
stations={'radiozet':'Radio ZET','antyradio':'ANTYRADIO','meloradio':'Meloradio','chillizet':'Chillizet'}

def build_url(query):
    return base_url + '?' + urlencode(query)
    
def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def main_menu():
    menu=[
        ['Radio ZET','radiozet','DefaultMusicSongs.png'],
        ['ANTYRADIO','antyradio','DefaultMusicSongs.png'],
        ['Meloradio','meloradio','DefaultMusicSongs.png'],
        ['Chillizet','chillizet','DefaultMusicSongs.png'],
        ['ULUBIONE','fav','DefaultMusicRecentlyAdded.png'],
    ]
    for m in menu:   
        if m[1]!='fav':
            url=build_url({'mode':'menu','station':m[1]})
            img=img_logo+m[1]+'.png'
        else:
            url=build_url({'mode':'fav'})
            img=m[2]
        setArt={'thumb': '', 'poster': img, 'banner': '', 'icon': m[2], 'fanart': ''}
        addItemList(url, m[0], setArt)
            
    xbmcplugin.endOfDirectory(addon_handle)

def fav():
    menu=[
        ['Kanały muzyczne','stations','DefaultMusicSongs.png'],
        ['Podcasty','podcasts','DefaultPlaylist.png'],
        ['Grupy podcastów','podcastsGroup','DefaultPlaylist.png']
    ]
    for m in menu:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': m[2], 'fanart': ''}
        url = build_url({'mode':'favList','favType':m[1]})
        addItemList(url, m[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def menu(s):
    menu=[
        [stations[s]+'[I] na żywo[/I]','playLive','true',False,'DefaultMusicSongs.png'],
        ['Kanały muzyczne','stationList','false',True,'DefaultMusicSongs.png'],
        ['Podcasty','podcast','false',True,'DefaultPlaylist.png']
    ]
    for m in menu:       
        iL={'title': '','sorttitle': '','plot': stations[s]}
        img=img_logo+s+'.png' if m[1]=='playLive' else m[4]
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': m[4], 'fanart': ''}
        url = build_url({'mode':m[1],'station':s})
        addItemList(url, m[0], setArt, 'video', iL, m[3], m[2])
        
    xbmcplugin.endOfDirectory(addon_handle)
    
def playLive(s,l):
    if l==None:
        url=apiURL+'stations/(station)/'+s
        resp=requests.get(url,headers=hea(s)).json()
        stream_url=resp['player']['stream']
    else:
         stream_url=l
    
    stream_url+='|User-Agent='+UA+'&Referer=https://player.'+s+'.pl/'
    
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def stationList(s):
    url=apiURL+'channels/getChannels/(station)/'+s
    resp=requests.get(url,headers=hea(s)).json()
    for c in resp:
        title=c['title']
        desc=c['desc']
        link=c['player']['stream']
        node=c['node_id']
        img=img_logo+s+'.png'
        if c['image']!=None:
            img=c['image']['original']
                
        iL={'title': '','sorttitle': '','plot': desc}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''}
        url = build_url({'mode':'playLive','station':s,'link':link})
        
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.eurozet?mode=favAdd&type=station&url='+quote(url)+'&title='+quote(title)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+')')]
        
        addItemList(url, title, setArt, 'video', iL, False, 'true', True, cmItems)
            
    xbmcplugin.endOfDirectory(addon_handle)

def podcast(s):
    menu=[
        ['Najnowsze','podcastList','Newest'],
        ['Podcasty wg tematów', 'podcastCateg','Topic'],
        ['Podcasty wg programów', 'podcastCateg','Program'],
        ['Podcasty wg prowadzących', 'podcastCateg','Presenter']
    ]
    for m in menu:
        iL={'title': '','sorttitle': '','plot': stations[s]}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultPlaylist.png', 'fanart': ''}
        if m[1]=='podcastList':
            url = build_url({'mode':m[1],'type':m[2],'station':s,})
        else:
            url = build_url({'mode':m[1],'categ':m[2],'station':s,})
        addItemList(url, m[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def podcastCateg(s,c):
    url=apiURL+'podcasts/get'+c+'List/(station)/'+s
    resp=requests.get(url,headers=hea(s)).json()
    for r in resp:
        if c=='Program':
            title=r['title']+' [I]('+r['podcast_count']+')[/I]'
            nid=r['node_id']
            img=r['image']['square']
            plot=''
            if 'airtime' in r:
                if r['airtime']!=None and r['airtime']!='':
                    plot+='[B]Czas emisji: [/B]'+r['airtime']+'\n'
            if 'presenters' in r:
                if r['presenters']!=None:
                    plot+='[B]Prowadzący: [/B]'
                    for p in r['presenters']:
                        plot+=p['title']+' '
                    plot+='\n'
            if 'body' in r:
                plot+='[B]Opis: [/B]'+r['body']+'\n'
            if 'desc' in r:
                if r['desc']!='':
                    plot+=r['desc']+'\n'
        
        elif c=='Topic':
            title=r['title']+' [I]('+r['podcast_count']+')[/I]'
            nid=r['node_id']
            img='OverlayUnwatched.png'
            plot=''
            
        elif c=='Presenter':
            title=r['title']+' [I]('+r['podcast_count']+')[/I]'
            nid=r['node_id']
            img=r['image']['square']
            plot='' 
            if 'body' in r:
                plot+='[B]Opis: [/B]'+r['body']+'\n'
            if 'desc' in r:
                if r['desc']!='':
                    plot+=r['desc']+'\n'
        
        plot=plot.replace('<p>','').replace('</p>','')
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        url = build_url({'mode':'podcastList','type':'categ','categ':c,'station':s,'nid':nid,'page':'0'})
        
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.eurozet?mode=favAdd&type=podcastGroup&url='+quote(url)+'&title='+quote(title)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+')')]
        
        addItemList(url, title, setArt, infoLab=iL, contMenu=True, cmItems=cmItems)
    
    xbmcplugin.endOfDirectory(addon_handle)

def getPodcastData(r): #helper
    title=r['title']
    node=r['node_id']
    try:
        img=r['program']['image']['square']
    except:
        try:
            img=r['presenter'][0]['image']['square']
        except:
            img=img_empty
    plot=''
    if 'program' in r:
        if r['program']!=None:
            if 'title' in r['program']:
                plot+='[B]Program: [/B]'+r['program']['title']+'\n'
    if 'presenter' in r:
        plot+='[B]Prowadzący: [/B]'
        for i in r['presenter']:
            plot+=i['title']+' '
        plot+='\n'    
    if 'typology' in r:
        if r['typology']!=None:
            plot+='[B]Temat: [/B]'+r['typology']['name']+'\n'
    if 'published_date' in r:
        date=datetime.datetime.fromtimestamp(r['published_date']).strftime('%Y-%m-%d %H:%M')
        plot+='[B]Data publikacji: [/B]'+date+'\n'
    if 'player' in r:
        plot+='[B]Czas trwania: [/B]'+str(int(r['player']['duration']/60))+' min.'
    link=r['player']['stream']
    
    return title,plot,img,link,node

def podcastList(s,t,c,n,p):
    url=''
    if t=='categ':
        url=apiURL+'podcasts/getPodcastListBy'+c+'/(node)/'+n+'/(station)/'+s+'/(offset)/'+p
    elif t=='Newest':
        url=apiURL+'podcasts/getNewestPodcasts/(station)/'+s
    resp=requests.get(url,headers=hea(s)).json()
    for r in resp['data']:
        title,plot,img,link,node=getPodcastData(r)
                
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        url = build_url({'mode':'playLive','link':link,'station':s})
        
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.eurozet?mode=favAdd&type=podcast&url='+quote(url)+'&title='+quote(title)+'&setArt='+quote(str(setArt))+'&iL='+quote(str(iL))+')')]
        
        addItemList(url, title, setArt, 'video', iL, False, 'true', True, cmItems)
    
    if 'info' in resp:
        if resp['info']['number_of_podcasts']>(int(p)+1)*100:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
            url = build_url({'mode':'podcastList','type':t,'categ':c,'station':s,'nid':n,'page':str(int(p)+1)})
            addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList(fType):
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    types={'podcasts':'podcast','stations':'station','podcastsGroup':'podcastGroup'}
    for j in js:
        if j[0]==types[fType]:
            url=j[1]
            title=j[2]
            setArt=eval(j[3])
            iL=eval(j[4])
            
            if 'playLive' in url:
                isF=False
                isP='true'
            else:
                isF=True
                isP='false'
            
            cmItems=[('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.eurozet?mode=favDel&url='+quote(j[1])+')')]
            
            addItemList(url, title, setArt, 'video', iL, isF, isP, True, cmItems)
                            
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[1]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(type,u,t,a,i):#
    fURL=PATH_profile+'ulubione2.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[1]==u:
            duplTest=True
    if not duplTest:
        js.append([type,u,t,a,i])
        xbmcgui.Dialog().notification('Eurozet Radio', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Eurozet Radio', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione2.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('Eurozet Radio', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione2.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('Eurozet Radio', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)


mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='menu':
        s=params.get('station')
        menu(s)
    
    if mode=='stationList':
        s=params.get('station')
        stationList(s)
    
    if mode=='playLive':
        s=params.get('station')
        l=params.get('link')
        playLive(s,l)
    
    if mode=='podcast':
        s=params.get('station')
        podcast(s)
    
    if mode=='podcastCateg':
        s=params.get('station')
        c=params.get('categ')
        podcastCateg(s,c) 
        
    if mode=='podcastList':
        s=params.get('station')
        t=params.get('type')
        c=params.get('categ')
        n=params.get('nid')
        p=params.get('page')
        podcastList(s,t,c,n,p)
    
    
    #FAV    
    if mode=='fav':
        fav()
    
    if mode=='favList':
        fType=params.get('favType')
        favList(fType)
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        type=params.get('type')
        u=params.get('url')
        t=params.get('title')
        a=params.get('setArt')
        i=params.get('iL')
        favAdd(type,u,t,a,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
    