# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.35mm')
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/img/empty.png'
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0'
baseurl='https://35mm.online/'
apiURL='https://cms.35mm.online/umbraco/api/'

hea={
    'User-Agent':UA,
    'Referer':baseurl,
    'Accept':'application/json, text/plain, */*',
    'Accept-Language':'pl,en-US;q=0.7,en;q=0.3',
    'Accept-Encoding':'gzip, deflate, br',
    'Connection':'keep-alive',
    'Origin':baseurl[:-1],
    'x-language':'pl-pl'
}

hea_play={
    'User-Agent':UA,
    'Referer':baseurl,
}

sort={'A-Z':'0','Z-A':'1','od najstarszych':'2','od najnowszych':'3'}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getVideoMusicTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def main_menu():
    url=apiURL+'content/'
    hea.update({'x-origin-url':'https://35mm.online/'})
    resp=requests.get(url,headers=hea).json()
    for r in resp['compositions']['menu']['mainLinks']:
        img='DefaultAddonVideo.png'
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''}
        url = build_url({'mode':'collectionList','link':r['url']}) #'mode':'contList'
        addItemList(url, r['name'], setArt, 'video')
    
    menu=[
        ['Wyszukiwarka','search','DefaultAddonsSearch.png'],
        ['Ulubione','favList','DefaultMusicRecentlyAdded.png'],
    ]
    for m in menu:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': m[2], 'fanart': ''}
        url = build_url({'mode':m[1]})
        addItemList(url, m[0], setArt, 'video')
    
    xbmcplugin.endOfDirectory(addon_handle)

def collectionList(link):
    url=apiURL+'content/'
    hea.update({'x-origin-url':baseurl[:-1]+link})
    resp=requests.get(url,headers=hea).json()
    if 'listView' in resp['content']:
        if resp['content']['listView'] !=None:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultAddonVideo.png', 'fanart': ''}
            url = build_url({'mode':'contList','link':link})
            addItemList(url, '[B]Wszystkie materiały[/B]', setArt, 'video')
    
    items=resp['content']['items']
    #zapis do pliku 
    fURL=PATH_profile+'collections.json'
    js=openJSON(fURL)
    js=items
    saveJSON(fURL,js)
        
    #titles=[]
    for ii,i in enumerate(items):
        if i['alias']!='banner' and 'items' in i['value']:
            if len(i['value']['items'])>0:
                title=i['value']['header'] if 'header' in i['value'] else i['value']['title']
                desc=i['value']['description']
                plot=desc if desc !=None else ''
                iL={'plot':desc}
                setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultAddonVideo.png', 'fanart': ''}
                url = build_url({'mode':'collItemList','cid':str(ii)})
                addItemList(url, title, setArt, 'video', iL)
           
    xbmcplugin.endOfDirectory(addon_handle)
                
def collItemList(cid):
    fURL=PATH_profile+'collections.json'
    js=openJSON(fURL)
    coll=js[int(cid)]
    if 'value' in coll:
        listGen(coll['value']['items'])
    else:
        listGen(coll)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle) 

def searchParams(filters,y): #fn_helper
    def elemToStr(z):
        a=[]
        for zz in z:
            a.append(str(zz))
        return a
    fType=[v['type'] for v in filters if v['field']==y][0]
    try:
        vals=[v['value']['value'] for v in filters if v['field']==y][0]
        return '%s.%s=%s' %(y,str(fType),','.join(elemToStr(vals)))
    except:
        vals=[v['value'] for v in filters if v['field']==y][0]
        return '%s.%s=%s' %(y,str(fType),vals)

def listGen(a): #fn_helper
    for r in a:
        test=True
        if 'alias' in r:
            test=False if r['alias'] in ['textElement','aditionalMaterialGallery'] else True
        if test:
            if 'value' in r:
                r=r['value']
            
            title=r['title']
            if 'subtitle' in r:
                subtitle=r['subtitle']
                year=int(subtitle.split(' | ')[1]) if subtitle else 0
                country=[subtitle.split(' | ')[0]] if subtitle else []
            else:
                year=int(r['year']) if 'year' in r else 0
                country=[r['country']] if 'country' in r else []
            desc=r['description']
            dur=r['duration']
            try:
                img=r['image']['url']
            except:
                img=PATH+'/icon.png'
            if img==None:
                img=PATH+'/icon.png'
            atdId=r['atdId']
            if r['showOnBox']!=None:
                directors=r['showOnBox']['persons'] if r['showOnBox']['roleName']=='Reżyseria' else []
            else:
                directors=[]

            
            iL={'title': title,'sorttitle': title,'genre':[],'plot': desc,'year': year,'country': country,'duration':dur,'director':directors,'mediatype':''}    
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
            if atdId!=0:#r['watch']=='Odtwarzaj' and 
                url = build_url({'mode':'playVid','vid':str(atdId)})
                isPlayable='true'
                isFolder=False
                cm=True
                iL.update({'mediatype':'movie'})
                ct='video'
            elif atdId==0:
                if r['type']=='Playlist':
                    url=build_url({'mode':'playList','link':r['url']})
                elif r['type']=='Category':
                    url=build_url({'mode':'collectionList','link':r['url']})
                else:
                    url = build_url({'mode':'epList','link':r['url']})
                    iL.update({'mediatype':'tvshow'})
                isPlayable='false'
                isFolder=True
                cm=True
                ct=False
            else:
                url = build_url({'mode':'noMode'})
                isPlayable='false'
                isFolder=False
                cm=False
                ct=False

            cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.35mm?mode=favAdd&url='+quote(url)+'&title='+quote(title)+'&iL='+quote(str(iL))+'&img='+quote(img)+')')] if cm else []
            
            addItemList(url, title, setArt, ct, iL, isFolder, isPlayable, cm, cmItems)
    
    return

def epList(link):
    url=apiURL+'content/'
    hea.update({'x-origin-url':baseurl[:-1]+link})
    resp=requests.get(url,headers=hea).json()
    if resp['content']['isSeries']:
        for s in resp['content']['seasonsModel']['seasons']:
            listGen(s['episodes'])
            
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def playList(link):
    url=apiURL+'content/'
    hea.update({'x-origin-url':baseurl[:-1]+link})
    resp=requests.get(url,headers=hea).json()
    listGen(resp['content']['items'])
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def contList(link,page):
    url=apiURL+'content/'
    hea.update({'x-origin-url':baseurl[:-1]+link})
    resp=requests.get(url,headers=hea).json()
    filters=resp['content']['listView']['filters']      
    if page==None:
        page='1'
    sortType=addon.getSetting('sortType')
    
    if link.endswith('fonoteka/dzwieki') or link.endswith('fonoteka/muzyka'):
        url_srch=apiURL+'search?page='+page+'&limit=48&'+searchParams(filters,'fonotekaCategory')+'&'+searchParams(filters,'__productionYear')
    elif link.endswith('fonoteka'):
        url_srch=apiURL+'search?page='+page+'&limit=48&'+searchParams(filters,'fonotekaMain')+'&'+searchParams(filters,'__productionYear')
    else:
        url_srch=apiURL+'search?page='+page+'&limit=48&'+searchParams(filters,'parentID')+'&'+searchParams(filters,'__productionYear')
    if sortType!='Domyślne':
        url_srch+='&sort_field.5='+sort[sortType]
    
    hea.update({'x-origin-url':baseurl[:-1]+link+'?'+url_srch.split('?')[-1]})
    resp=requests.get(url_srch,headers=hea).json()
    listGen(resp['records'])
        
    if resp['pageNumber']<resp['pageCount']:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
        url = build_url({'mode':'contList','link':link,'page':str(resp['pageNumber']+1)})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle) 

def playVid(vid):
    url=apiURL+'products/'+vid+'/videos/playlist?platform=BROWSER&videoType=MOVIE'
    resp=requests.get(url,headers=hea_play).json()
    if 'drm' in resp:
        isDRM=True
        licURL=resp['drm']['WIDEVINE']['src']
        licHEA=hea_play
        licKey='%s|%s|%s|%s' %(licURL,urlencode(licHEA),'R{SSM}','')
    else:
        isDRM=False

    stream_url=resp['sources']['DASH'][0]['src']
    if stream_url.startswith('//'):
        stream_url='https:'+stream_url
        
    if 'subtitles' in resp:
        subt=['https://'+s['url'] for s in resp['subtitles']]
    else:
        subt=[]
    
    import inputstreamhelper
    PROTOCOL = 'mpd'
    DRM = 'com.widevine.alpha'
    if isDRM:
        is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    else:
        is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)           
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA) #K21
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
        if isDRM:
            play_item.setProperty('inputstream.adaptive.license_type', DRM)
            play_item.setProperty('inputstream.adaptive.license_key', licKey)
        play_item.setSubtitles(subt)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def search():
    query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł:', type=xbmcgui.INPUT_ALPHANUM)
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    if query:
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.35mm/?mode=searchRes&query='+quote(query)+'&page=1)')
    else:
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.35mm/,replace)')

def searchRes(q,p,sp):
    if sp==None:
        sp=''
    if p=='1':
        url=apiURL+'content/'
        hea.update({'x-origin-url':baseurl+'search?searchPhrase.3='+quote(q)})
        resp=requests.get(url,headers=hea).json()
        filters=resp['content']['filters']
        searchRange=['Wszystkie kategorie','Wybrane kategorie']
        select_0 = xbmcgui.Dialog().select('Zakres przeszukiwania', searchRange)
        if select_0==1:
            categsAr=[f['value'] for f in filters if f['field']=='search_tag' ][0]
            categsKey=[k['key'] for k in categsAr]
            categsVal=[k['value'] for k in categsAr]
            select = xbmcgui.Dialog().multiselect('Wybierz kategorie', categsVal)
            if select !=None:
                categsChoose=[categsKey[i] for i in select]
                categs='&search_tag.2='+','.join(categsChoose)
            else:
                categs=''
        else:
            categs=''
        search_params='&limit=48'+'&__NodeTypeAlias.2=asset,series'+'&'+searchParams(filters,'__productionYear')+'&searchPhrase.3='+quote(q)+categs
        sortType=addon.getSetting('sortType')
        if sortType!='Domyślne':
            search_params+='&sort_field.5='+sort[sortType]
    else:
        search_params=sp
    url_srch=apiURL+'search?'
    url_srch+='page='+p+search_params
    hea.update({'x-origin-url':baseurl+'search?'+'page='+p+search_params})
    resp=requests.get(url_srch,headers=hea).json()
    listGen(resp['records'])
    
    if resp['pageNumber']<resp['pageCount']:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
        url = build_url({'mode':'searchRes','query':q,'page':str(resp['pageNumber']+1),'params':search_params})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle) 
    

###
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=json.loads(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
        
#FAV        
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        if 'playVid' in j[0]:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        contMenu=True
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.35mm?mode=favDel&url='+quote(j[0])+')'),
        ]
        setArt={'thumb': j[3], 'poster': j[3], 'banner': j[3], 'icon': j[3], 'fanart':''}
        iL=eval(j[2])
        addItemList(j[0], j[1], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,iL,img):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,iL,img])
        xbmcgui.Dialog().notification('35mm.online', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('35mm.online', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def expFav(File):
    from shutil import copy2, copyfile
    fURL=PATH_profile+File+'.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    copyfile(fURL, targetPATH+File+'.json')
    xbmcgui.Dialog().notification('35mm.online', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav(File):
    from shutil import copy2,copyfile
    fURL=PATH_profile+File+'.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)

mode = params.get('mode', None)

if not mode:
    main_menu()

else:
    if mode=='collectionList':
        link=params.get('link')
        collectionList(link)
    
    if mode=='collItemList':
        cid=params.get('cid')
        collItemList(cid)
    
    if mode=='contList':
        link=params.get('link')
        page=params.get('page')
        contList(link,page)
        
    if mode=='epList':
        link=params.get('link')
        epList(link)
    
    if mode=='playList':
        link=params.get('link')
        playList(link)
    
    if mode=='playVid':
        vid=params.get('vid')
        playVid(vid)
    
    if mode=='noMode':
        pass
        
    if mode=='search':
        search()
    
    if mode=='searchRes':
        page=params.get('page')
        query=params.get('query')
        params=params.get('params')
        searchRes(query,page,params)
        
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        iL=params.get('iL')
        img=params.get('img')
        favAdd(u,t,iL,img)

    if mode=='expFav':
        expFav('ulubione')
        
    if mode=='impFav':
        impFav('ulubione')
        