# -*- coding: utf-8 -*-
import os
import sys

import urllib
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import urllib3
import re

import string
import json
import time
import datetime

import base64
import hashlib
import hmac

from urllib.parse import urlencode, quote_plus, quote, parse_qsl
    
import random

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.polsatbox_go_atv')
file_name = addon.getSetting('fname')
path_m3u = addon.getSetting('path_m3u')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
img_addon=PATH+'/icon.png'


UA='pbg_tv_android_native_cpplayer/21001'
userAgentData={
    "application": "native",
    "build": 21001,
    "deviceType": "tv", #api Android TV
    "os": "android",
    "player": "cpplayer",
    "portal": "pbg",
    "widevine": True
}
userAgentData_play=userAgentData
hea={
    'User-Agent':UA
}

def build_url(query):
    return base_url + '?' + urlencode(query)
    
def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt)
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def code_gen(x,nmb=False):
    base='0123456789abcdef' if not nmb else '0123456789'
    r=15 if not nmb else 9
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,r)]
    return code

def get_sessionToken(sess_id,sess_kET,sess_key,t,e):
    r='%s|%s|%s|%s'%(sess_id,sess_kET,t,e)
    a=base64.b64decode(sess_key.replace('-','+').replace('_','/'))

    def sign_string(key, to_sign):
        signed_hmac_sha256 = hmac.HMAC(key, to_sign.encode(), hashlib.sha256)
        digest = signed_hmac_sha256.digest()
        return base64.b64encode(digest).decode()
            
    hash=sign_string(a,r).replace('+','-').replace('/','_')
    sessionToken=r+'|'+hash
    return sessionToken

def getMsg():
    msg={
        'id':'',
        'timestamp':''
    }
    msg['id']='%s-%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12),code_gen(3,True))
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    now=datetime.datetime.now()
    msg['timestamp']=(now+datetime.timedelta(seconds=offset)).strftime('%Y-%m-%dT%H:%M:%SZ')
    return msg

    
def main_menu():
    mainCategs=[]
    if addon.getSetting('logged')=='true':
        categs=getCategories()
        for c in categs:
            if c[1]=='category':
                mainCategs.append([c[0],c[2],'subCateg','DefaultAddonVideo.png'])
            elif c[1]=='tv_channels':
                mainCategs.append([c[0],'','tv','DefaultTVShows.png'])
            elif c[1]=='live_channels':
                mainCategs.append([c[0],'','live','DefaultTVShows.png'])
        if len(categs)>0:
            mainCategs.append(['Ulubione','','favList','DefaultMusicRecentlyAdded.png'])
            mainCategs.append(['Wyszukiwarka','','search','DefaultAddonsSearch.png'])
        mainCategs.append(['Wyloguj','','logOut','DefaultUser.png'])
    else:
        mainCategs.append(['Zaloguj','','logIn','DefaultUser.png'])
    for s in mainCategs:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': s[3], 'fanart':''}
        url = build_url({'mode':s[2],'categ':s[1]})
        addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def logIn():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    usr = addon.getSetting('username')
    password = addon.getSetting('password')
    logMethod=addon.getSetting('logMethod')
    if logMethod=='inne dane' or logMethod=='iPolsat Box':
        if usr and password:    
            data_js = {
                "id": int(code_gen(19,True)),
                "jsonrpc": "2.0",
                "method": "login",
                "params": {
                    "authData": {
                        "authProvider":"sso",
                        "deviceId": {
                            "type": "other",
                            "value": deviceid
                        },
                        "login": usr,
                        "password": password
                    },
                    "clientId": clientid,
                    "message": getMsg(),
                    "userAgentData": userAgentData
                }
            }
            #logMethod=addon.getSetting('logMethod')
            
            if logMethod=='inne dane':
                data_js['params']['authData']["authProvider"]='native'
            
            resp = requests.post('https://b2c.redefine.pl/rpc/auth/login/', json=data_js, headers=hea).json()
            if 'error' in resp:
                if resp['error']['message']=='Not found error' or resp['error']['message']=='Unauthorized access':
                    xbmcgui.Dialog().notification('PolsatBox Go', resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
                else:
                    try:
                        xbmcgui.Dialog().notification('PolsatBox Go', '[B]Błąd logowania: [/B]'+ resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
                    except:
                        xbmcgui.Dialog().notification('PolsatBox Go', 'Nieokreślony błąd logowania', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            elif 'result' in resp:
                addon.setSetting('sessId',resp['result']['session']['id'])
                addon.setSetting('sessKey',resp['result']['session']['key'])
                addon.setSetting('sessKeyExp',str(resp['result']['session']['keyExpirationTime']))
                addon.setSetting('sessUpdateTime',str(int(time.time())))
                addon.setSetting('logged','true')
                xbmcgui.Dialog().notification('PolsatBox Go', 'Zalogowano', xbmcgui.NOTIFICATION_INFO)
            else:
                pass
                
        else:
            xbmcgui.Dialog().notification('PolsatBox Go', 'Uzupełnij dane logowania w ustawieniach', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    elif logMethod=='kodem':
        #wygenerowanie kodu
        data_js = {
            "id": int(code_gen(19,True)),
            "jsonrpc": "2.0",
            "method": "requestLogin",
            "params": {
                "clientId": clientid,
                "message": getMsg(),
                "userAgentData": userAgentData
            }
        }
        resp = requests.post('https://b2c.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
        if  'error' not in resp:
            code=resp['result']['acceptanceData']['code']
            url=resp['result']['acceptanceData']['url']
            loginRequestId=resp['result']['loginRequestId']
            ok=xbmcgui.Dialog().ok("Logowanie", 'Wprowadź kod [COLOR=yellow][B]'+code+'[/B][/COLOR] na stronie [B]'+url+'[/B] a następnie naciśnij OK')
            if ok:
                #weryfikacja kodu
                data_js = {
                    "id": int(code_gen(19,True)),
                    "jsonrpc": "2.0",
                    "method": "getLoginRequestStatus",
                    "params": {
                        "clientId": clientid,
                        "loginRequestId": loginRequestId,
                        "message": getMsg(),
                        "userAgentData": userAgentData
                    }
                }
                resp = requests.post('https://b2c.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
                if 'error' not in resp:
                    if 'authToken' in resp['result']['authData']:
                        authToken=resp['result']['authData']['authToken']
                        #logowanie
                        data_js = {
                            "id": int(code_gen(19,True)),
                            "jsonrpc": "2.0",
                            "method": "login",
                            "params": {
                                "authData": {
                                    "authProvider": "native",
                                    "authToken": authToken,
                                    "deviceId": {
                                        "type": "other",
                                        "value": deviceid
                                    }
                                },
                                "clientId": clientid,
                                "message": getMsg(),
                                "userAgentData": userAgentData
                            }
                        }
                        resp = requests.post('https://b2c.redefine.pl/rpc/auth/login/', json=data_js, headers=hea).json()
                        if 'error' not in resp:
                            addon.setSetting('sessId',resp['result']['session']['id'])
                            addon.setSetting('sessKey',resp['result']['session']['key'])
                            addon.setSetting('sessKeyExp',str(resp['result']['session']['keyExpirationTime']))
                            addon.setSetting('sessUpdateTime',str(int(time.time())))
                            addon.setSetting('logged','true')
                            addon.setSetting('isCodeLogged','true')
                            xbmcgui.Dialog().notification('PolsatBox Go', 'Zalogowano', xbmcgui.NOTIFICATION_INFO)
                        
                        else:
                            xbmcgui.Dialog().notification('PolsatBox Go', '[B]Błąd logowania (K4): [/B]'+ resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
                            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                    else:
                            xbmcgui.Dialog().notification('PolsatBox Go', '[B]Błąd logowania (K3): [/B]Nie przepisano kodu', xbmcgui.NOTIFICATION_INFO)
                            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                    
                else:
                    xbmcgui.Dialog().notification('PolsatBox Go', '[B]Błąd logowania (K2): [/B]'+ resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
                    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            else:
                xbmcgui.Dialog().notification('PolsatBox Go', 'Brak potwierdzenia wprowadzenia kodu', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        else:
            xbmcgui.Dialog().notification('PolsatBox Go', '[B]Błąd logowania (K1): [/B]'+ resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
    else:
        xbmcgui.Dialog().notification('PolsatBox Go', 'Wybierz sposób logowania w ustawieniach', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
def logOut():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'auth','logout')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "logout",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp= requests.post('https://b2c.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
    if resp['result']['status']==0:
        addon.setSetting('sessId','')
        addon.setSetting('sessKeyExp','')
        addon.setSetting('sessKey','')
        addon.setSetting('logged','false')
        addon.setSetting('isCodeLogged','')
        addon.setSetting('sessUpdateTime','')
        xbmcgui.Dialog().notification('PolsatBox Go', 'Wylogowano', xbmcgui.NOTIFICATION_INFO)

def getSession(): #wywoływana raz /24h
    if addon.getSetting('logged')=='true': #nowa sesja
        sessUpdateTime=addon.getSetting('sessUpdateTime')
        sessUpdateTime=0 if sessUpdateTime=='' or sessUpdateTime==None else int(sessUpdateTime)
        now=int(time.time())
        if now-sessUpdateTime>=24*60*60:
            clientid=addon.getSetting('clientid')
            deviceid=addon.getSetting('deviceid')
            sessId=addon.getSetting('sessId')
            sessKeyExp=addon.getSetting('sessKeyExp')
            sessKey=addon.getSetting('sessKey')
            
            sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'auth','getSession')
            data_js={
                "id": int(code_gen(19,True)),
                "jsonrpc": "2.0",
                "method": "getSession",
                "params": {
                    "authData": {
                        "sessionToken": sessToken
                    },
                    "clientId": clientid,
                    "deviceId": {
                        "type": "other",
                        "value": deviceid
                    },
                    "message": getMsg(),
                    "userAgentData": userAgentData
                }
            }
            resp= requests.post('https://b2c.redefine.pl/rpc/auth/', json=data_js, headers=hea).json()
            if 'result' in resp:
                addon.setSetting('sessId',resp['result']['session']['id'])
                addon.setSetting('sessKey',resp['result']['session']['key'])
                addon.setSetting('sessKeyExp',str(resp['result']['session']['keyExpirationTime']))
                addon.setSetting('sessUpdateTime',str(int(time.time())))
                #xbmcgui.Dialog().notification('PolsatBox Go', 'nowa sesja', xbmcgui.NOTIFICATION_INFO)
            else:#token wygasł
                #xbmcgui.Dialog().notification('PolsatBox Go', 'Błąd w odświeżeniu sesji', xbmcgui.NOTIFICATION_INFO)
                addon.setSetting('sessId','')
                addon.setSetting('sessKeyExp','')
                addon.setSetting('sessKey','')
                addon.setSetting('sessUpdateTime','')
                addon.setSetting('logged','false')
                if addon.getSetting('isCodeLogged')!='true':
                    logIn()
                else:
                    addon.setSetting('isCodeLogged','')
                    xbmcgui.Dialog().notification('PolsatBox Go', 'Wylogowano - nie można odświeżyć sesji', xbmcgui.NOTIFICATION_INFO)
                    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
def getCategories():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getHomeMenu')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getHomeMenu",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    
    resp= requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js, headers=hea).json()
    categs=[]
    if 'errors' not in resp and 'result' in resp:
        for r in resp['result']:
            if r['name']!='Moja lista':
                categs.append([r['name'],r['place']['type'],r['place']['value']])
    else:
        xbmc.log('@@@Błąd_menu: '+str(resp), level=xbmc.LOGINFO)
        xbmcgui.Dialog().notification('PolsatBox Go', '[B]Błąd: [/B]'+resp['error']['data']['userMessage'], xbmcgui.NOTIFICATION_INFO)
    return categs

def getImage(x):#
    def sortFN(i):
        return i['size']['width']
    x.sort(key=sortFN,reverse=True)
    img=x[0]['src'] if len(x)>0 else img_empty
    return img
    
def locTime(x):#
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    z=(y+diff+datetime.timedelta(seconds=1)).strftime('%Y-%m-%d %H:%M')
    return z

def getEPG(TV_list):#
    chansId=[r['id'] for r in TV_list['result']['results']]
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getChannelsCurrentProgram')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getChannelsCurrentProgram",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "channelIds":chansId,
            "limit": 2,
            "offset": 0,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    return resp['result']

def plotEPG(data,c):#
    plot=''
    if c in data:
        for p in data[c]:
            title=p['title']
            genre=p['genre']
            startTime=locTime(p['startTime']).split(' ')[1]
            plot+='[B]%s[/B] %s - [I]%s[/I]\n'%(startTime,title,genre)
    return plot

def getTVList():#
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getTvChannels')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getTvChannels",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "filters": [],
            "limit": 200,
            "offset": 0,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    return resp

def tv():
    resp=getTVList()
    EPG=getEPG(resp)
    for r in resp['result']['results']:
        title=r['title']
        mediaid=r['id']
        cpid=str(r['cpid'])
        img=getImage(r['thumbnails'])
        plot=plotEPG(EPG,mediaid)
         
        setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':''}
        iL={'title': '','sorttitle': '','plot': plot}
        url = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'tv'})
        addItemList(url, title, setArt, 'video', iL, False, 'true')
    xbmcplugin.endOfDirectory(addon_handle)    

def live():
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getLiveChannelsWithTreeNavigation')
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getLiveChannelsWithTreeNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    for r in resp['result']['results']:
        cpid=str(r['cpid'])
        mediaid=r['id']
        title=r['title']
        img=getImage(r['thumbnails'])
        date=locTime(r['publicationDate'])
        plot='[B]Początek transmisji: [/B]'+date
        if r['published']==False:
            url = build_url({'mode':'playINFO','info':'Transmisja nie jest jeszcze prowadzona'})
            isPlayable='false'
        else:
            url = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'live'})
            isPlayable='true'
        
        setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':''}
        iL={'title': '','sorttitle': '','plot': plot}
        addItemList(url, title, setArt, 'video', iL, False, isPlayable)
    xbmcplugin.endOfDirectory(addon_handle) 

def subCateg(categ):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getCategoryWithFlatNavigation')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getCategoryWithFlatNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(categ),
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    subcategs=[['[B]Wszystkie[/B]','']]
    s=[c['filters'] for c in resp['result']['flatNavigation']['filterLists'] if c['name']=='Gatunki']
    if len(s)==1:
        for ss in s[0]:
            subcategs.append([ss['name'],ss['value']])
    for sb in subcategs:
        setArt={'thumb': '', 'poster': img_addon, 'banner': '','icon':'OverlayUnwatched.png','fanart':''}
        url = build_url({'mode':'contentList','categ':categ,'subcateg':sb[1],'page':'1'})
        addItemList(url, sb[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def contData(resp):#
    for r in resp['result']['results']:
        cid=str(r['id'])
        cpid=str(r['cpid'])
        genre='/'.join(r['genres'])
        desc=r['description']
        img=getImage(r['thumbnails'])
        if 'mediaType' in r:
            title=r['title']
            age=str(r['ageGroup']) if 'ageGroup' in r else None
            if age !=None:
                desc+='\n[B]Kat. wiekowa:[/B] '+age
            countries=r['countries'] if 'countries' in r else None
            dur=r['duration'] if 'duration' in r else None
            mediaid=r['id']
            isPlayable='true'
            isFolder=False
            #URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
            
            if r['mediaType']=='movie':
                originaltitle=r['originalTitle'] if 'originalTitle' in r else None
                year=r['releaseYear'] if 'releaseYear' in r else None
                infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'year': year,'country': countries,'originaltitle':originaltitle,'duration':dur,'mediatype':'movie'}    
                URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
            elif r['mediaType']=='vod': 
                epNumber=r['episodeNumber'] if 'episodeNumber' in r else None
                infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'country': countries,'episode':epNumber,'duration':dur,'mediatype':'episode'}
                URL=build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'vod'})
            elif r['mediaType']=='live':#dla search
                date=locTime(r['publicationDate'])
                plot='[COLOR=yellow]Transmisja na żywo[/COLOR]\n[B]Początek transmisji: [/B]'+date
                infoLab={'title': '','sorttitle': '','plot': plot}
                if r['published']==False:
                    URL = build_url({'mode':'playINFO','info':'Transmisja nie jest jeszcze prowadzona'})
                    isPlayable='false'
                else:
                    URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'live'})
                    isPlayable='true'
            elif r['mediaType']=='tv':#dla search
                plot='[COLOR=yellow]Kanał TV[/COLOR]\n'+desc
                URL = build_url({'mode':'playCont','mediaid':mediaid,'cpid':cpid,'type':'tv'})
                infoLab={'title': '','sorttitle': '','plot': plot}
            
        elif 'subCategoriesLabel' in r:
            title=r['name']
            isPlayable='false'
            isFolder=True
            if r['subCategoriesLabel']=='Serie':
                mod='seasonList'#'contentList'   
                URL= build_url({'mode':mod,'cid':cid})#build_url({'mode':mod,'categ':cid,'page':'1'})
            elif r['subCategoriesLabel']=='Sezony':
                mod='seasonList' 
                URL= build_url({'mode':mod,'cid':cid})
            infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'mediatype':'tvshow'}
        
        else:
            ct=r['reporting']['playerEvents']['contentItem']['type']
            title=r['name']
            if ct=='category':
                isPlayable='false'
                isFolder=True
                URL=build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
                infoLab={'title': title,'sorttitle': title,'genre':genre,'plot': desc,'mediatype':'tvshow'}
            else:#do sprawdzenia i ewentualnej rozbudowy 
                title='[COLOR=yellow]'+r['name']+'[/COLOR]'
                isPlayable='false'
                isFolder=False
                URL=''
                infolab={}
        setArt={'thumb': img, 'poster': img, 'banner': img,'icon':img,'fanart':''}
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.polsatbox_go_atv?mode=favAdd&url='+quote(URL)+'&title='+quote(title)+'&infoLab='+quote(str(infoLab))+'&img='+quote(str(setArt))+')')]
        addItemList(URL, title, setArt, 'video', infoLab, isFolder, isPlayable, True, cmItems)
    
def contentList(categ,subcateg,page,sortBy):
    count=int(addon.getSetting('count'))
    start=(int(page)-1)*count
    
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getCategoryContentWithFlatNavigation')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getCategoryContentWithFlatNavigation",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(categ),
            "clientId": clientid,
            "collection": {
                "default": True,
                "name": "Alfabetycznie", #TO DO: możliwość wyboru sortowania -> alfabetycznie / ostatnio dodane [oprócz odcinków - one zawsze od ostatnio dodanego]
                "type": "sortedby",
                "value": "13"
            },
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "limit": count,
            "offset": start,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    if subcateg !=None:
        data_js['params'].update({"filters":[{"type": "genres","value": [subcateg]}]})
    if sortBy =='addDate':#dla odcinków sortowanie wg daty dodania
        data_js['params']['collection'].update({'name':'Data dodania','value':'12'})
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    contData(resp)
    if int(page)*count<resp['result']['total']:
        setArt={'thumb': '', 'poster': '', 'banner': '','icon':'','fanart':''}
        if subcateg==None:
            subcateg=''
        url = build_url({'mode':'contentList','categ':categ,'subcateg':subcateg,'page':str(int(page)+1),'sortBy':sortBy})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt, 'video')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def seasonList(cid):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','getSubCategories')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "getSubCategories",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "catid": int(cid),
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    if len(resp['result'])<=1:
        contentList(cid,None,'1','addDate')#str(resp['result'][0]['id'])
    else:
        #wszystkie odcinki
        setArt={'thumb': '', 'poster': '', 'banner': '','icon':'','fanart':''}
        url = build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
        addItemList(url, '[B]Wszystkie odcinki[/B]', setArt, 'video')
        #lista sezonów
        for r in resp['result']:
            cid=str(r['id'])
            name=r['name']
            desc=r['description']
            img=getImage(r['thumbnails'])
            seasNumb=r['seasonNumber'] if 'seasonNumber' in r else None
            
            setArt={'thumb': img, 'poster': img, 'banner': img,'icon':'OverlayUnwatched.png','fanart':''}
            iL={'title': name,'sorttitle': name,'plot': desc,'season':seasNumb,'mediatype':'season'}
            url = build_url({'mode':'contentList','categ':cid,'subcateg':'','page':'1','sortBy':'addDate'})
            addItemList(url, name, setArt, 'video', iL)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
            
    
def playCont(mediaid,cpid,type):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    #sprawdzenie dostępności
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','checkProductAccess')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "checkProductAccess",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "product": {
                "id": mediaid,
                "subType": type,
                "type": "media"
            },
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/drm/', json=data_js,headers=hea).json()
    if resp['result']['statusDescription']!='no access':
    
        #dane do odtwarzacza
        sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','prePlayData')
        
        data_js={
            "id": int(code_gen(19,True)),
            "jsonrpc": "2.0",
            "method": "prePlayData",
            "params": {
                "authData": {
                    "sessionToken": sessToken
                },
                "clientId": clientid,
                "cpid": int(cpid),
                "mediaId": mediaid,
                "message": getMsg(),
                "userAgentData": userAgentData_play
            }
        }
        resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
        mediaSources=resp['result']["mediaItem"]['playback']['mediaSources']

        def sortFN(i):
            return int(i['quality'].replace('p',''))
        mediaSources.sort(key=sortFN,reverse=True)
        #odtwarzanie
        if 'widevine' in mediaSources[0]['authorizationServices']:
            isDRM=True
        elif 'pseudo' in mediaSources[0]['authorizationServices']:
            isDRM=False
        if mediaSources[0]['accessMethod']=='direct': #MP4
            player='direct'
        elif mediaSources[0]['accessMethod']=='dash':
            player='ISA'
            
        if isDRM==False:    
            sourceId=mediaSources[0]['id']
            clientid=addon.getSetting('clientid')#('clientid_player')
            deviceid=addon.getSetting('deviceid')#('deviceid_player')
            
            sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','getPseudoLicense')
            
            data_js={
                "id": int(code_gen(19,True)),
                "jsonrpc": "2.0",
                "method": "getPseudoLicense",
                "params": {
                    "authData": {
                        "sessionToken": sessToken
                    },
                    "clientId": clientid,
                    "cpid": int(cpid),
                    "deviceId": {
                        "type": "other",
                        "value": deviceid
                    },
                    "mediaId": mediaid,
                    "sourceId": sourceId,
                    "message": getMsg(),
                    "userAgentData": userAgentData
                }
            }
            resp = requests.post('https://b2c.redefine.pl/rpc/drm/', json=data_js,headers=hea).json()
            stream_url=resp['result']['url']+'|User-Agent='+UA
            
            
        if player=='ISA': #dash
            if isDRM: #DRM
                keyId= mediaSources[0]['keyId']
                stream_url=mediaSources[0]['url']
                sourceId=mediaSources[0]['id']
                
                sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'drm','getWidevineLicense')
                clientid=addon.getSetting('clientid')#('clientid_player')
                deviceid=addon.getSetting('deviceid')#('deviceid_player')
                msg=getMsg()
                mid=msg['id']
                mt=msg['timestamp']
                data_lic=quote('{"id":"'+code_gen(19,True)+'","jsonrpc":"2.0","method":"getWidevineLicense","params":{"clientId":"'+clientid+'","cpid":'+cpid+',"deviceId":{"type":"other","value":"'+deviceid+'"},"keyId":"'+keyId+'","mediaId":"'+mediaid+'","object":"b{SSM}","sourceId":"'+sourceId+'","message":{"id":"'+mid+'","timestamp":"'+mt+'"},"authData":{"sessionToken":"'+sessToken+'"},"userAgentData":{"deviceType":"tv","application":"native","os":"android","build":21001,"portal":"pbg","player":"cpplayer","widevine":true}}}')
                licURL = 'https://b2c.redefine.pl/rpc/drm/'
            
            import inputstreamhelper
            PROTOCOL = 'mpd'
            DRM = 'com.widevine.alpha'
            if isDRM:
                is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
            else:
                is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=stream_url)           
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA) #K21
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
                play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                play_item.setProperty('inputstream.adaptive.license_flags', "persistent_storage")
                if isDRM:
                    play_item.setProperty('inputstream.adaptive.license_type', DRM)
                    play_item.setProperty('inputstream.adaptive.license_key', licURL+'||'+data_lic+'|JBlicense')
                
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
        elif player=='direct': #mp4
            play_item = xbmcgui.ListItem(path=stream_url)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
    else:
        xbmcgui.Dialog().notification('PolsatBox Go', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def search(q):
    clientid=addon.getSetting('clientid')
    deviceid=addon.getSetting('deviceid')
    sessId=addon.getSetting('sessId')
    sessKeyExp=addon.getSetting('sessKeyExp')
    sessKey=addon.getSetting('sessKey')
    
    sessToken=get_sessionToken(sessId,sessKeyExp,sessKey,'navigation','searchContent')
    
    data_js={
        "id": int(code_gen(19,True)),
        "jsonrpc": "2.0",
        "method": "searchContent",
        "params": {
            "authData": {
                "sessionToken": sessToken
            },
            "clientId": clientid,
            "deviceId": {
                "type": "other",
                "value": deviceid
            },
            "limit": 50,
            "query": q,
            "message": getMsg(),
            "userAgentData": userAgentData
        }
    }
    resp = requests.post('https://b2c.redefine.pl/rpc/navigation/', json=data_js,headers=hea).json()
    contData(resp)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def listM3U():
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('PolsatBox Go', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('PolsatBox Go', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=getTVList()
    data = '#EXTM3U\n'
    for c in chans['result']['results']:
        chName=c['title']
        mediaid=c['id']
        cpid=str(c['cpid'])
        img=getImage(c['thumbnails'])
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="PolsatBox Go" ,%s\nplugin://plugin.video.polsatbox_go_atv?mode=playTV&mediaid=%s&cpid=%s&type=tv\n' %(chName,img,chName,mediaid,cpid)
    
    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('PolsatBox Go', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)

#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        URL=j[0]
        if 'playCont' in URL:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        cmItems=[('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.polsatbox_go_atv?mode=favDel&url='+quote(j[0])+')')]
        setArt=eval(j[3])
        addItemList(URL, j[1], setArt, 'video', eval(j[2]), isFolder, isPlayable, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,l,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,l,i])
        xbmcgui.Dialog().notification('PolsatBox Go', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('PolsatBox Go', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('PolsatBox Go', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('PolsatBox Go', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)  


mode = params.get('mode', None)

if not mode:
    if addon.getSetting('deviceid')=='':
        def serialNumberGen():
            return '%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12))
        addon.setSetting('deviceid',code_gen(16))
        addon.setSetting('clientid',serialNumberGen())
        addon.setSetting('deviceid_player',code_gen(32)+'_')
        addon.setSetting('clientid_player',serialNumberGen())
    getSession()        
    main_menu()

else:
    if mode=='logIn':
        logIn()
        if addon.getSetting('logged')=='true':
            #main_menu()
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go_atv/,replace)')
    
    if mode=='logOut':
        logOut()
        if addon.getSetting('logged')=='false':
            #main_menu()
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go_atv/,replace)')
    
    if mode=='tv':
        tv()
        
    if mode=='live':
        live()
        
    if mode=='subCateg':
        c=params.get('categ')
        subCateg(c)
        
    if mode=='contentList':
        c=params.get('categ')
        sc=params.get('subcateg')
        p=params.get('page')
        o=params.get('sortBy')
        contentList(c,sc,p,o)
    
    if mode=='playCont':
        mediaid=params.get('mediaid')
        cpid=params.get('cpid')
        type=params.get('type')
        playCont(mediaid,cpid,type)
    
    if mode=='playINFO':
        info=params.get('info')
        xbmcgui.Dialog().notification('PolsatBox Go', info, xbmcgui.NOTIFICATION_INFO)
        
    if mode=='seasonList':
        cid=params.get('cid')
        seasonList(cid)
    
    if mode=='search':
        qry=xbmcgui.Dialog().input(u'Szukaj:', type=xbmcgui.INPUT_ALPHANUM)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)#
        if qry:
            #search(qry)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go_atv/?mode=searchRes&q='+quote(qry)+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.polsatbox_go_atv/,replace)')
            #main_menu()
    
    if mode=='searchRes':
        q=params.get('q')
        search(q)
    
    if mode=='listM3U':
        listM3U()
    
    if mode=='playTV':
        getSession()
        if addon.getSetting('logged')=='true':
            mediaid=params.get('mediaid')
            cpid=params.get('cpid')
            type=params.get('type')
            playCont(mediaid,cpid,type)
        else:
            xbmcgui.Dialog().notification('PolsatBox Go', 'Zaloguj się we wtyczce', xbmcgui.NOTIFICATION_INFO)
        
    #FAV
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        l=params.get('infoLab')
        i=params.get('img')
        favAdd(u,t,l,i)
        
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
      