# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import random
import time
import datetime
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.red_tv')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
img_path=PATH+'/resources/img/'
img_addon=PATH+'icon.png'
fanart=''

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/111.0'
baseurl='https://www.redgo.film/'
apiURL='https://api.redcarpet.blueonline.tv/'
deviceType='BROWSER'
system='tvonline'
lng='pl'

def hea():
    HEA={
        'referer':baseurl,
        'User-Agent':UA,
        'API-Device':'Firefox; 111; Windows; 10; Windows; 10;',
        'API-DeviceUID':addon.getSetting('DeviceUid'),
        'Origin':baseurl[:-1]
    }
    return HEA
    
def getParams():
    p={
        'platform':deviceType,
        'system':system,
        'language':lng
    }
    return p

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def strToDate(x):
    d=datetime.datetime(*(time.strptime(x,'%Y-%m-%d %H:%M:%S')[0:6]))
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    dlok=d-datetime.timedelta(seconds=offset)
    return dlok

def main_menu():
    items=[
        ['TV','tvList','DefaultTVShows.png'],
        ['Free VOD','vod','DefaultAddonVideo.png']
    ]
    for i in items:
        setArt={'icon':i[2]}
        url=build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def getEPG():
    epg={}
    now=datetime.datetime.now()
    since=(now-datetime.timedelta(hours=4)).strftime('%Y%m%d%H0000')
    till=(now+datetime.timedelta(hours=12)).strftime('%Y%m%d%H0000')
    
    url=apiURL+'epg'
    par=getParams()
    par['startDate']=since
    par['endDate']=till
    
    resp=requests.Session().get(url,headers=hea(),params=par).json()
    print(resp)
    for r in resp:
        progs=[]
        for p in r['programs']:
            te=p['till']
            if strToDate(te)>now and p['uuid']!='NO_PROGRAM':
                title=p['title']
                category=p['category'] if 'category' in p else ''
                country=p['country'] if 'country' in p else ''
                ts=strToDate(p['since']).strftime('%H:%M')
                prog='[B]%s[/B] %s'%(ts,title)
                if category !='':
                    prog+=' -'+category
                if country !='':
                    prog+=' [I](%s)[/I]'%(country)
                progs.append(prog)
        epg[r['channel_uuid']]=progs
    
    return epg
               
def channels():
    url=apiURL+'products/channel'
    par=getParams()
    par['limit']='300'
    par['offset']='0'
    resp=requests.Session().get(url,headers=hea(),params=par).json()
    chans=[]
    for c in resp['data']:
        chName=c['title']
        cid=c['uuid']

        if 'Carpet' in chName:
            img=img_path+'red_carpet.png'
        elif 'Top' in chName:
            img=img_path+'red_top.png'
        else:
            img=PATH+'icon.png'
        avail=True#
        if avail:
            chans.append([chName,cid,img])
    
    return chans
        
def tvList():
    chans=channels()
    #print(chans)
    try:
        epg=getEPG()
    except:
        epg={}
    for c in chans:
        img=c[2]
        name=c[0]
        cid=c[1]
        if cid in epg:
            plot='\n'.join(epg[cid])
        else:
            plot=name
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
        iL={'title': name,'sorttitle': name,'plot': plot}
        url=build_url({'mode':'playSource','cid':cid})
        addItemList(url, name, setArt, 'video', iL, isF=False, isPla='true')
    xbmcplugin.endOfDirectory(addon_handle)
    
def playSource(c,t):
    delVidSess()
    
    url=apiURL+'player/product/'+c+'/configuration'
    par=getParams()
    par['type']=t
    
    resp=requests.Session().get(url,headers=hea(),params=par).json()
    if 'errorCode' in resp:
        xbmcgui.Dialog().notification('RED TV', resp['message'], xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        vidSess=resp['videoSession']['videoSessionId']
        addon.setSetting('vidSess',vidSess)
        
        url=apiURL+'player/product/'+c+'/playlist'
        playPar={
            'type':t,
            'videoSessionId':vidSess
        }
        resp=requests.Session().get(url,headers=hea(),params=playPar).json()
        try:
            stream_url=resp['sources']['DASH'][0]['src']
            licURL=resp['drm']['WIDEVINE']
            heaLic={
                'User-Agent':UA,
                'Referer':baseurl
            }
            lic='%s|%s|%s|'%(licURL,urlencode(heaLic),'R{SSM}')
        except:
            stream_url=None
        print(stream_url)
        
        if stream_url!=None:
            import inputstreamhelper
            PROTOCOL = 'mpd'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=stream_url)
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA)
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA)
                play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                play_item.setProperty('inputstream.adaptive.license_key',lic)
                              
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
        else:
            xbmcgui.Dialog().notification('RED TV', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
def delVidSess():
    vidSess=addon.getSetting('vidSess')
    if vidSess!='':
        url=apiURL+'player/videosession/'+vidSess
        par=getParams()
        del par['language']
        resp=requests.Session().delete(url,headers=hea(),params=par).json()
        xbmc.log('@@@Delete video sess: '+str(resp), level=xbmc.LOGINFO)
        

def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('RED TV', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('RED TV', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    if chans !=False:
        data = '#EXTM3U\n'
        for c in chans:
            name=c[0]
            img=c[2]
            cid=c[1]
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="RED TV" ,%s\nplugin://plugin.video.red_tv?mode=playSource&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('RED TV', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('RED TV', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)
   

def vod():
    url=apiURL+'sections/page/MAIN_WEB'
    resp=requests.Session().get(url,headers=hea(),params=getParams()).json()
    for r in resp:
        if int(r['id']) not in [9,47,44,23,7,16,4]:
            sid=r['id']
            title=r['label']
            
            setArt={'poster':img_addon,'icon':'DefaultAddonVideo.png'}
            url=build_url({'mode':'vodList','sid':sid})
            addItemList(url, title, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)        
    
def vodList(s,p):
    limit=100
    offset=0 if p==None else (int(p)-1)*100
    
    url=apiURL+'sections/'+sid+'/content'
    par=getParams()
    par['offset']=str(offset)
    par['limit']=str(limit)
    resp=requests.Session().get(url,headers=hea(),params=par).json()
    for r in resp['data']:
        if r['in_free_packet']:
            vid=r['uuid']
            title=r['title']
            desc=r['short_desc']
            mpaa=r['rating']
            try:
                img=r['images']['poster'][0]['url']
            except:
                img=img_addon
            genres=[]
            if 'genres' in r:
                if r['genres']!=None:
                    genres=[g['name'] for g in r['genres']]
            
            iL={'title':title, 'plot':desc, 'mpaa':mpaa, 'genre':genres, 'mediatype':'video'}
            setArt={'poster':img,'thumb':img,'banner':img,'icon':img}
            url=build_url({'mode':'playVOD','vid':vid})
            addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    if len(resp['data'])==limit:
        setArt={'icon':img_empty}
        url=build_url({'mode':'vodList','sid':s,'page':str(int(p)+1)})
        addItemList(url,'[COLOR=yellow][B]>>> następna strona[/B][/COLOR]')
            
    xbmcplugin.setContent(addon_handle, 'videos') 
    xbmcplugin.endOfDirectory(addon_handle)


   
mode = params.get('mode', None)

if not mode:
    if addon.getSetting('DeviceUid')=='' or addon.getSetting('DeviceUid')==None:
        addon.setSetting('DeviceUid','%s-%s-%s-%s-%s'%(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12)))
    main_menu()
else:
    if mode=='tvList':
        tvList()
    
    if mode=='playSource':
        cid=params.get('cid')
        playSource(cid,'channel')
    
    if mode=='listM3U':
        listM3U()#
        
    if mode=='vod':
        vod()
        
    if mode=='vodList':
        sid=params.get('sid')
        page=params.get('page')
        vodList(sid,page)
        
    if mode=='playVOD':
        vid=params.get('vid')
        playSource(vid,'vod')
                