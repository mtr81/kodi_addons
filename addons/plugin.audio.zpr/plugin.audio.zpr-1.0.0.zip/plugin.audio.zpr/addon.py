# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import time
#import random
#import base64
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.zpr')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
imgPATH=PATH+'/resources/img/'
icon_main=PATH+'icon.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl=''
hea={
    'User-Agent':UA,
}
heaA={
    'user-agent':'Radio ESKA 4.7.0/Android',
    'accept-encoding':'gzip'
}
podcAPI='https://api.spreaker.com/v2/'

stations=['eskarock','voxfm','eska2','eska']
stGroup={
    11:['eska','ESKA',''],
    16:['eskarock','ESKA Rock'],
    18:['voxfm','VOX FM',''],
    6:['eska2','ESKA2'],
    21:['plus','Radio Plus'],
    59:['plus','Radio Plus'],
    26:['vibefm','vibe fm'],
    0:['inne','Inne']
}
imgSt={
    'voxfm':'https://cdn.music.smcloud.net/t/cover/d7a6833c-766d-48dc-b642-bd0dd11ea5ba_VOX_WRH_500x500_500x500.jpg',
    'eska':'https://cdn.music.smcloud.net/t/cover/602854b3-a955-4737-9588-ea963676f73c_ESKA_radio_500x500_500x500.jpg',
    'eskarock':'https://cdn.files.smcloud.net/t/eska-rock-200x200.png',
    'eska2':'https://dwa.eska.pl/media/dwa.eska/desktop/images/ESKA2-plug.jpg',
    'plus':'https://cdn.radios.smcloud.net/t/plugs/Plus_500x500_rg-m6xH-PnQb-dUF8_500x500.jpg',
    'vibefm':'https://www.vibefm.pl/media/vibefm/desktop/images/vibefm-plug-icon2023.jpg',
    'inne':icon_main
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(u):
    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        #play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+UA+'&Referer='+baseurl)#K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(u):
    play_item = xbmcgui.ListItem(path=u)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)


def getData(): #base
    channels=[]
    for s in stations:
        url='https://player.'+s+'.pl/' if s!='eska2' else 'https://player2.eska.pl/'
        resp=requests.get(url,headers=hea).text
        resp1=resp.split('\"player__dedicated_streams\"')[1].split('\"gl_plugin listing\"')[0].split('</a>')
        
        for r in resp1:
            if 'stream-title' in r:
                sid=re.compile('/station/([^/]+?)/now_playing').findall(r)[0]
                img=re.compile('src=\"([^"]+?)\"').findall(r)[0]
                stName=re.compile('<span>([^<]+?)</span>').findall(r)[0]
                channels.append([stName,sid,s,0,img])
        
    def checkSt(sts,sid):
        res=[i for i,s in enumerate(sts) if s[1]==sid]
        result=False if len(res)==0 else True
        return result

    stIDs=list(stGroup.keys())
    url='https://player.eskarock.pl/api/mobile/stations/'
    resp=requests.get(url,headers=hea).json()

    for r in resp:
        sid=str(r['station_id'])
        gid=r['station_group_id']
        if checkSt(channels,sid):
            si=res=[i for i,s in enumerate(channels) if s[1]==sid][0]
            channels[si][3]=gid
        else:
            stName=r['name']
            img=''
            if gid in list(stGroup.keys()):
                gName=stGroup[gid][0]
            else:
                gName=stGroup[0][0]
            channels.append([stName,sid,gName,gid,img])
    
    fURL=PATH_profile+'channels.json'
    saveJSON(fURL,channels)

def plusStreams(): #base
    url='https://radioplus.pl'
    resp=requests.get(url,headers=hea).text
    data=re.compile('var radioConfig = ({[^;]+?});').findall(resp)[0]
    channels={}
    jdata=json.loads(data)
    for s in list(jdata['cities'].keys()):
        streamData=jdata['cities'][s]['stream']
        channels[streamData['station_group_id']]=streamData['stream_url']
    
    fURL=PATH_profile+'plus_streams.json'
    saveJSON(fURL,channels)
    
def main_menu():
    items=[
        ['Stacje radiowe','radio','DefaultMusicSongs.png'],
        ['Podcasty','podcast','DefaultPlaylist.png'],
        ['Ulubione','favList','DefaultMusicRecentlyAdded.png']
        
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': ''}
        URL=build_url({'mode':i[1]})
        addItemList(URL, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def radio():
    stIDs=list(stGroup.keys())
    groups={}
    for i in stIDs:
        if stGroup[i][0] not in list(groups.keys()):
            groups[stGroup[i][0]]=stGroup[i][1]
    
    for g in list(groups.keys()):
        img=imgSt[g] if g in imgSt else 'DefaultMusicSongs.png'
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''}
        URL=build_url({'mode':'radioList','gr':g})
        addItemList(URL, groups[g], setArt)
  
    xbmcplugin.endOfDirectory(addon_handle)

def radioList(g,i=None):
    api={'eska':'2000','eskarock':'5000','eska2':'1000','voxfm':'3000','plus':'4000','vibefm':'6490'}
    apiURL='https://www.eska.pl/api/mobile/packages/by_station_group/'
    fURL=PATH_profile+'channels.json'
    channels=openJSON(fURL)
    isInt=False
    if g in list(api.keys()):
        resp=requests.get(apiURL+api[g]+'/',headers=heaA).json()
        for r in resp['stations']:
            if 'items' in r:
                resp['stations']+=r['items']
        sIds=[]
        for r in resp['stations']:
            if (i==None and r['order']<100) or (i!=None and r['order']>=100):
                #if r['stream']!='':# jeśli puste pole stream to dla Plusów alternatywne strumienie (od EZ)
                sid=str(r['station_id'])
                if sid not in sIds:
                    sIds.append(sid)
                    stName=r['name']
                    if 'logo' in r:
                        img=r['logo']
                    else:
                        img='DefaultMusicSongs.png'
                    
                    iL={'plot':stName}
                    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
                    URL=build_url({'mode':'playRadio','sid':sid})
                    
                    cmItems=[
                        ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.zpr?mode=favAdd&url='+quote(URL)+'&title='+quote(stName)+'&art='+quote(str(setArt))+'&iL='+quote(str(iL))+')'),
                    ]
                    
                    addItemList(URL, stName, setArt, 'video', iL, False, 'true', True, cmItems)
                    
            else:
                if i==None:
                    isInt=True
        
    else:
        for c in channels:
            if c[2]==g and ((i==None and c[3]!=1) or (i!=None and c[3]==1)):
                stName=c[0]
                sid=c[1]
                if c[4]!='':
                    img=c[4]
                else:
                    img='DefaultMusicSongs.png'
                    
                if sid=='7990': #Z WAMI FM
                    stName='Z Wami FM'
                    img=imgPATH+'zwami.png'
                
                iL={'plot':stName}
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
                URL=build_url({'mode':'playRadio','sid':sid})
                
                cmItems=[
                    ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.zpr?mode=favAdd&url='+quote(URL)+'&title='+quote(stName)+'&art='+quote(str(setArt))+'&iL='+quote(str(iL))+')'),
                ]
                    
                addItemList(URL, stName, setArt, 'video', iL, False, 'true', True, cmItems)
                
            else:
                if i==None:
                    isInt=True
    
    if isInt:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultMusicSongs.png', 'fanart': ''}
        URL=build_url({'mode':'radioList','gr':g,'muz':'true'})
        addItemList(URL, '[B]Stacje tematyczne[/B]', setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)        

    
def playRadio(sid):
    fURL=PATH_profile+'plus_streams.json'
    plusChans=openJSON(fURL)
    if sid in list(plusChans.keys()):
        stream_url=plusChans[sid]
    else:
        stream_url='https://radio.stream.smcdn.pl/timeradio-p/'+sid+'-1.aac/playlist.m3u8'
    stream_url+='|User-Agent='+UA
    directPlayer(stream_url)

def podcast():
    items=[
        ['[B]Wszystkie[/B]','',''],
        ['ESKA','123456789','eska'],
        ['ESKA Rock','3','eskarock'],
        ['VOX FM','4','voxfm'],
        ['ESKA2','6','eska2'],
        ['vibe fm','6490','vibefm']
    ]
    for i in items:
        img=imgSt[i[2]] if i[2] in imgSt else icon_main
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''}
        URL=build_url({'mode':'podcastList','st':i[1]})
        addItemList(URL, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def podcastList(s):
    
    def addPodc(t,i,d,f):
        iL={'plot':d}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': f, 'fanart': ''}
        URL=build_url({'mode':'epList','pid':i})
        
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.audio.zpr?mode=favAdd&url='+quote(URL)+'&title='+quote(t)+'&art='+quote(str(setArt))+'&iL='+quote(str(iL))+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.audio.zpr?mode=details&pid='+i+')')
        ]
        
        addItemList(URL, t, setArt, 'video', infoLab=iL,contMenu=True,cmItems=cmItems)
     
    if s==None:
        url=podcAPI+'users/13275755/shows?limit=100'
        resp=requests.get(url,headers=hea).json()
        for r in resp['response']['items']:
            title=r['title']
            pid=r['show_id']
            img=r['image_original_url']
            lastEp=r['last_episode_at']
            desc=''
            if lastEp!=None:
                desc+='[B]Najnowszy odc.: [/B]%s'%(lastEp)
            
            addPodc(title,str(pid),desc,img)
    else:
        url='https://www.eska.pl/api/mobile/'+s+'/'
        resp=requests.get(url,headers=heaA).json()
        for r in resp:
            title=r['name']
            pid=r['spreaker_show_id']
            desc=r['description']
            img='DefaultMusicSongs.png'
            
            addPodc(title,str(pid),desc,img)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def epList(pid,p):
    limit=50
    url=podcAPI+'shows/'+pid+'/episodes?'
    if p==None:
        url+='limit='+str(limit)
    else:
        url+=p
    resp=requests.get(url,headers=hea).json()
    for r in resp['response']['items']:
        eid=str(r['episode_id'])
        title=r['title']
        date=r['published_at']
        dur=int(r['duration']/60000)
        desc='[B]Data: [/B]%s\n'%(date)
        desc+='[B]Długość: [/B]%s min.\n'%(str(dur))
        img=r['image_url']
        img2=r['image_original_url']
        
        iL={'plot':desc}
        setArt={'thumb': img2, 'poster': img2, 'banner': img, 'icon': img, 'fanart': ''}
        URL=build_url({'mode':'playPodc','eid':eid})
        addItemList(URL, title, setArt, 'video', iL, False, 'true')
    
    if resp['response']['next_url']!=None:
        next_page=resp['response']['next_url'].split('?')[-1]
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
        URL=build_url({'mode':'epList','pid':pid,'page':next_page})
        addItemList(URL, '[B][COLOR]>>> Następna strona[/COLOR][/B]', setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)    

def playPodc(eid):
    url=podcAPI+'episodes/'+eid
    resp=requests.get(url,headers=hea).json()
    stream_url=resp['response']['episode']['playback_url']
    stream_url+='|User-Agent='+UA
    directPlayer(stream_url)

def details(pid):
    url=podcAPI+'shows/'+pid
    resp=requests.get(url,headers=hea).json()
    desc=resp['response']['show']['description']
    lastEp=resp['response']['show']['last_episode_at']
    plot=desc+'\n\n'
    if lastEp!=None:
        plot+='[B]Ostatni odcinek: [/B]%s'%(lastEp)
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)

#FAV
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    
    for j in js:
        if 'play' in j[0]:
            isFolder=False
            isPlayable='true'
        else:
            isFolder=True
            isPlayable='false'

        title=j[1]
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.audio.zpr?mode=favDel&url='+quote(j[0])+')')
        ]
        if 'epList' in j[0]:
            pid=dict(parse_qsl(j[0]))['pid']
            cmItems.append(('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.audio.zpr?mode=details&pid='+pid+')'))
        
        iL=eval(j[3])
        setArt=eval(j[2])
        url = j[0]
        addItemList(url, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,a,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,a,i])
        xbmcgui.Dialog().notification('ZPR Radio', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('ZPR Radio', 'Element jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('ZPR Radio', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('ZPR Radio', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)



mode = params.get('mode', None)

if not mode:
    updateTime=addon.getSetting('updateTime')
    now=int(time.time())
    if updateTime=='' or (updateTime!='' and now-int(updateTime)>6*60*60):
        getData()
        plusStreams()
        addon.setSetting('updateTime',str(now))
    main_menu()
else:
    if mode=='radio':
        radio()
    
    if mode=='radioList':
        gr=params.get('gr')
        muz=params.get('muz')
        radioList(gr,muz)
    
    if mode=='playRadio':
        sid=params.get('sid')
        playRadio(sid)
        
    if mode=='podcast':
        podcast()
        
    if mode=='podcastList':
        st=params.get('st')
        podcastList(st)
        
    if mode=='epList':
        pid=params.get('pid')
        page=params.get('page')
        epList(pid,page)
        
    if mode=='playPodc':
        eid=params.get('eid')
        playPodc(eid)
    
    if mode=='details':
        pid=params.get('pid')
        details(pid)
        
    
    #FAV   
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        a=params.get('art')
        i=params.get('iL')
        favAdd(u,t,a,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
    