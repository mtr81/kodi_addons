# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.filmbox')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
fanart=''

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='https://app.filmbox.com/'
apiURL='https://api.filmbox.com/api/'

url_params={
    'd_type':'web', #androidtv
    'region':'pl',
    'locale':'pl-PL',
    'country_code':'pl'
}

heaATV={
    'User-Agent':'okhttp/4.2.1',
    'Origin':baseurl,
    'Referer':baseurl,
    'accept-encoding':'gzip',
    'content-type':'application/json; charset=utf-8'
}

def heaGen():
    HEA={
        'Referer':baseurl,
        'Origin':baseurl[:-1],
        'User-Agent':UA,
        'Content-Type':'application/json',
        'Authorization':addon.getSetting('access_token')
    }
    return HEA

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt)
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def directPlayer(stream_url):
    heaPlay={
        'User-Agent':UA,
        'Referer':baseurl,
        'Origin':baseurl[:-1],
    }
    hp=x='&'.join([k+'='+heaPlay[k] for k in heaPlay])
    stream_url+='|'+hp
    play_item = xbmcgui.ListItem(path=stream_url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def ISAplayer(protocol,stream_url, isDRM=False, licURL=False):
    heaPlay={
        'User-Agent':UA,
        'Referer':baseurl,
        'Origin':baseurl[:-1],
    }
    hp=x='&'.join([k+'='+heaPlay[k] for k in heaPlay])
    import inputstreamhelper
    
    PROTOCOL = protocol
    DRM = 'com.widevine.alpha'
    is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
    
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)                     
        #play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)        
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
        play_item.setProperty('inputstream.adaptive.stream_headers', hp)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hp)
        if isDRM:
            play_item.setProperty('inputstream.adaptive.license_type', DRM)
            play_item.setProperty('inputstream.adaptive.license_key', licURL)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':
        items=[
            ['Filmy','movies','DefaultAddonVideo.png'],
            ['Seriale','series','DefaultAddonVideo.png'],
            ['TV','tv','DefaultTVShows.png'],
            ['Wyszukiwarka','search','DefaultAddonsSearch.png'],
            ['Moja lista','wishlist','DefaultTags.png'],
            ['Kontynuuj oglądanie','continue','DefaultInProgressShows.png'],
            ['Wyloguj','logOut','DefaultUser.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','DefaultUser.png']
        ]
    for i in items:
        setArt={'icon': i[2]}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)   
    
def categs(t):
    url=apiURL+'v3/assets/category/'+t+'/contents'
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    for r in resp['data']:
        title=r['title'].replace('Genre','Gatunki').replace('Curation','Kolekcje').replace('My List','Moja lista').replace('Continue Watching','Kontynuuj oglądanie').replace('Baner','Promowane')
        key=r['key']
        slug=r['slug']
        cat=r['category_slug']
        component=r['component']
        if component=='':
            component='undefined'
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultAddonVideo.png', 'fanart': ''}
        url=build_url({'mode':'contList','key':key,'slug':slug,'component':component,'cat':cat,'page':'1'})
        addItemList(url, title, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)

def itemList(r,t=None): #utils
    if r['is_svod']==1:
        title=r['title']
        img='https://filmboxassets.tv2zcdn.com/images/'+r['poster_image']
               
        year=r['publish_time'] if 'year' in r else None
        desc=r['description'] if 'description' in r else None
        cast=r['cast'] if 'cast' in r else None
        director=r['director'] if 'director' in r else None
        dur=r['duration_min'] if 'duration_min' in r else None
        genre=r['tags'] if 'tags' in r else None           
            
        if r['is_series']==0: #film
            c_type='video'
            slug=r['content_slug']
            iL={'title': title,'sorttitle': title,'plot': desc,'year':year,'genre':genre,'duration':dur,'director':director,'cast':[cast],'mediatype':'movie'}
            URL=build_url({'mode':'playVid','slug':slug})
            isFolder=False
            isPlayable='true'
        elif r['is_series']==1 and t=='continue': #odcinek (tylko dla katalogu Kontynuuj...)
            c_type='series'
            slug=r['content_slug']
            iL={'title': title,'sorttitle': title,'plot': desc,'year':year,'genre':genre,'duration':dur,'director':director,'cast':[cast],'mediatype':'episode'}
            URL=build_url({'mode':'playVid','slug':slug})
            isFolder=False
            isPlayable='true'
        elif r['is_series']==1 : #serial
            c_type='series'
            slug=r['series_slug']
            iL={'title': title,'sorttitle': title,'plot': desc,'year':year,'genre':genre,'director':director,'cast':[cast],'mediatype':'tvshow'}
            URL=build_url({'mode':'seasonList','slug':slug})
            isFolder=True
            isPlayable='false'
            
        if 'watched_duration' in r and t=='continue':
            pathFile='plugin://plugin.video.filmbox/?mode=playVid&slug='+slug
            timePlay=r['watched_duration']
            totalTime=r['duration_min']*60
            request={
                "jsonrpc": "2.0", 
                "method": "Files.SetFileDetails", 
                "params": {
                    "file": pathFile, 
                    "media": "video", 
                    "resume": {
                        "position":timePlay, 
                        "total": totalTime
                    }
                },
                "id":"1"
            }
            results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        
        synchr=addon.getSetting('synchKontOgl')
        if t=='continue' and synchr=='true':
            continue_id=r['continue_id'] if 'continue_id' in r else None
            if continue_id !=None:
                cmItems=[
                    ('[B]Usuń z Kontynuuj oglądanie[/B]','RunPlugin(plugin://plugin.video.filmbox?mode=delWatching&continue_id='+continue_id+')')
                ]
            else:
                cmItems=[]
        elif t=='wishlist' and synchr=='true':
            cont_id=r['content_id']
            cmItems=[
                ('[B]Usuń z Mojej listy[/B]','RunPlugin(plugin://plugin.video.filmbox?mode=delMyList&cont_id='+cont_id+'&c_type='+c_type+')')
            ]
        elif synchr=='true':
            cont_id=r['content_id']
            cmItems=[
                ('[B]Dodaj do Mojej listy[/B]','RunPlugin(plugin://plugin.video.filmbox?mode=addMyList&cont_id='+cont_id+'&c_type='+c_type+')')
            ]
        else:
            cmItems=[]
        
        setArt={'thumb': img ,'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)

def contList(k,s,c,cat,p):
    count=20 #ustawienia !
    if s=='continue': #kontynuuj oglądanie (w kategoriach)
        url_params.update({
            'category':cat,
            'skip':str((int(p)-1)*count),#paginacja
            'take':count#
        })
        url=apiURL+'v2/persona/continue/watching'
        #resp=requests.get(url,headers=heaGen(),params=url_params).json()
        resp=req('get',url,heaGen(),url_params)
        if resp==None:
            return
        for r in resp['data']['list']:
            itemList(r,'continue')
    elif s=='wishlist': #moja lista (w kategoriach)
        url_params.update({
            'category':cat,
            'skip':str((int(p)-1)*count),#paginacja
            'take':count#
        })
        url=apiURL+'v2/persona/content/persona'
        #resp=requests.get(url,headers=heaGen(),params=url_params).json()
        resp=req('get',url,heaGen(),url_params)
        if resp==None:
            return
        data=[d for d in resp['data'] if d['key']==s][0]
        for r in data['list']:
            itemList(r,'wishlist')
    elif s=='banner':
        url=apiURL+'v3/assets/category/'+cat+'/contents'
        resp=requests.get(url,headers=heaGen(),params=url_params).json()
        data=[d for d in resp['data'] if d['key']==s][0]
        for r in data['list']:
            itemList(r)
    else:
        url_params.update({
            'key':k,
            'component':c,
            'skip':str((int(p)-1)*count),#paginacja
            'take':count#
        })
        url=apiURL+'v3/assets/seeall/'+s
        resp=requests.get(url,headers=heaGen(),params=url_params).json()
        for r in resp['data']['contents']:
            if 'component' not in r: #filmy/seriale
                itemList(r)
  
            else: #kolekcje
                title=r['title']
                key=r['key']
                slug=r['slug']
                component=r['component']
                if component=='':
                    component='undefined'
                img='https://filmboxassets.tv2zcdn.com/images/'+r['banner_medium']    
                   
                URL=build_url({'mode':'contList','key':key,'slug':slug,'component':component,'page':'1'})    
                isFolder=True
                isPlayable='false'
                iL={'plot':title}
            
                setArt={'thumb': img ,'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
                addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable)
    
    if s!='banner':
        pd=['count','list'] if s=='continue' or s=='wishlist' else ['total_count','contents']
        pData=resp['data'] if s!='wishlist' else data
        if pData[pd[0]]>(int(p)-1)*count+len(pData[pd[1]]):
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
            url=build_url({'mode':'contList','key':k,'slug':s,'component':c,'page':str(int(p)+1)})
            addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def seasonList(s):
    url=apiURL+'v2/assets/contents/series/'+s
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    for r in resp['data']['seasons']:
        title=r['season_title']
        slug=r['season_slug']
        
        iL={'plot':title}
        URL=build_url({'mode':'episodeList','slug':slug})
        setArt={}
        addItemList(URL, title, setArt, 'video', iL)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def episodeList(s):
    url=apiURL+'v2/assets/content/season/'+s
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    for r in resp['data']['content']:
        title=r['title']
        slug=r['content_slug']
        img='https://filmboxassets.tv2zcdn.com/images/'+r['poster_image']
                    
        year=r['publish_time'] if 'year' in r else None
        desc=r['description'] if 'description' in r else None
        cast=r['cast'] if 'cast' in r else None
        director=r['director'] if 'director' in r else None
        dur=r['duration_min'] if 'duration_min' in r else None
        genre=r['tags'] if 'tags' in r else None
        
        iL={'title': title,'sorttitle': title,'plot': desc,'year':year,'genre':genre,'duration':dur,'director':director,'cast':[cast],'mediatype':'episode'}
        URL=build_url({'mode':'playVid','slug':slug})
        setArt={'thumb': img ,'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        addItemList(URL, title, setArt, 'video', iL, False, 'true')
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def playVid(s):
    url_params.update({
        'streaming_type':'dash',
        'supports_drm':'1',
    })
    url=apiURL+'v2/persona/content/video/'+s
    #resp=requests.get(url,headers=heaGen(),params=url_params).json()
    resp=req('get',url,heaGen(),url_params,f=False)
    if resp==None:
        return
    if 'data' in resp:
        stream_url=resp['data']['playback_url']#dash_playback_url
        if resp['data']['is_drm']==1:
            licURL=resp['data']['la_widevine_url']
            heaLic={
                'Referer':baseurl,
                'Origin':baseurl[:-1],
                'Content-Type':'application/octet-stream',
                'User-Agent':UA
            }
            lickey='%s|%s|R{SSM}|'%(licURL,urlencode(heaLic),)
            ISAplayer('mpd',stream_url, True, lickey)
        else:
            ISAplayer('mpd',stream_url)
    else:
        xbmcgui.Dialog().notification('Filmbox', 'Brak dostępu', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def tv():
    url=apiURL+'v2/assets/livechannels'
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    for r in resp['data']['livechannels']:
        name=r['title']
        slug=r['slug']
        img='https://filmboxassets.tv2zcdn.com/images/'+r['icon']
        cid=r['feed_id']
        
        cmItems=[('[B]EPG[/B]','RunPlugin(plugin://plugin.video.filmbox?mode=epg&cid='+cid+')')]
        
        iL={'plot':r['description']}
        URL=build_url({'mode':'playTV','slug':slug})
        setArt={'thumb': img ,'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        addItemList(URL, name, setArt, 'video', iL, False, 'true', True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)
    
def playTV(s):
    url=apiURL+'v2/persona/livechannels/'+s
    url_params.update({'u_id':addon.getSetting('user_id')})
    #resp=requests.get(url,headers=heaGen(),params=url_params).json()
    resp=req('get',url,heaGen(),url_params,f=False)
    if resp==None:
        return
    stream_url=resp['data']['livechannel']['hls_playback_url']
    ISAplayer('hls',stream_url)
    
def epg(cid):
    plot=''
    date=datetime.datetime.now().strftime('%Y-%m-%d')
    url='https://filmboxassets.tv2zcdn.com/epg/'+cid+'_'+date+'.json'
    hea=heaGen()
    hea.pop('Authorization', None)
    resp=requests.get(url,headers=hea).json()
    now=int(time.time())
    for r in resp['programs']:
        if r['end_date']/1000>now:
            title=r['title']
            ts=datetime.datetime.fromtimestamp(r['start_date']/1000).astimezone().strftime('%H:%M')
            te=datetime.datetime.fromtimestamp(r['end_date']/1000).astimezone().strftime('%H:%M')
            plot+='[B]%s - %s[/B] %s\n'%(ts,te,title)
            
    dialog = xbmcgui.Dialog()
    dialog.textviewer('EPG', plot)

def search(q,p):
    count=20 #ustawienia !
    url_params.update({
        'keyword':q,
        'facelift':'1',
        'skip':str((int(p)-1)*count),#paginacja
        'take':count#
    })
    url=apiURL+'v2/assets/search'
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    items=[i for i in resp['data']['contents'] if i['key']=='video']
    if len(items)!=0:
        for r in items[0]['list']:
            itemList(r)

        if items[0]['count']>(int(p)-1)*count+len(items[0]['list']):
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
            url=build_url({'mode':'searchRes','q':q,'p':str(int(p)+1)})
            addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        xbmcplugin.endOfDirectory(addon_handle)

def logIn():
    def getCode():
        url=apiURL+'v2/persona/device/atvcode'
        data={
            "brand": "google",
            "campaign": "0.2.57",
            "country_code": "pl",
            "d_id": addon.getSetting('d_id'),
            "d_type": "androidtv",
            "locale": "pl-PL",
            "medium": "tv-app-sales-funnel",
            "model": "sdk_google_atv_x86",
            "region": "pl",
            "source": "androidtv",
            "unique_device_id": addon.getSetting('udi'),
            "user_device_info": {
                "displayHeight": 1080,
                "displayWidth": 1920,
                "manufacturer": "google",
                "model": "sdk_google_atv_x86",
                "osVersion": "8.0.0",
                "version": "0.2.57"
            }
        }
        resp=requests.post(url,headers=heaATV,json=data).json()
        return resp
    
    code=getCode()
    if code['message']=='Device Login Code has been generated':
        ok=xbmcgui.Dialog().ok("Logowanie", 'Wprowadź kod [COLOR=yellow][B]'+code['data']['mcode']+'[/B][/COLOR] na stronie [B]https://app.filmbox.com/pl/account/activate-tv[/B] a następnie naciśnij OK')
        if ok:
            codeResp=getCode()
            if 'access_token' in codeResp['data']:
                addon.setSetting('access_token','Bearer '+codeResp['data']['access_token'])
                addon.setSetting('refresh_token',codeResp['data']['refresh_token'])
                addon.setSetting('user_id',codeResp['data']['user_id'])
                addon.setSetting('token_time',str(int(time.time())))
                addon.setSetting('logged','true')
            else:
                xbmcgui.Dialog().notification('Filmbox', 'Błąd przy generowaniu kodu', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
                xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/,replace)')
    
    else:    
        xbmcgui.Dialog().notification('Filmbox', 'Błąd przy przepisywaniu kodu', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/,replace)')
 
def logOut():
    d_id=addon.getSetting('d_id')
    url=apiURL+'v2/persona/logout/devices/'+d_id+'?d_type=androidtv&region=pl&locale=pl-PL&country_code=pl'
    heaATV.update({'Authorization':addon.getSetting('access_token')})
    resp=requests.get(url,headers=heaATV).json()

    if resp['message']=='Wylogowano pomyślnie!':
        addon.setSetting('access_token','')
        addon.setSetting('refresh_token','')
        addon.setSetting('user_id','')
        addon.setSetting('token_time','')
        addon.setSetting('logged','false')
    else:
        xbmcgui.Dialog().notification('Filmbox', 'Nie wylogowano', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/,replace)')
    

def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('Filmbox', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('Filmbox', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    url=apiURL+'v2/assets/livechannels'
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    for r in resp['data']['livechannels']:
        name=r['title']
        slug=r['slug']
        img='https://filmboxassets.tv2zcdn.com/images/'+r['icon']

        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="Filmbox" ,%s\nplugin://plugin.video.filmbox?mode=playTV&slug=%s\n' %(name,img,name,slug)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('Filmbox', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
        
def myList(t,p):
    p='1' if p==None else p
    count=12 #ustawienia !
    url_params.update({
        'skip':str((int(p)-1)*count),#paginacja
        'take':count#
    })
    url=apiURL+'v2/persona/content/persona'
    #resp=requests.get(url,headers=heaGen(),params=url_params).json()
    resp=req('get',url,heaGen(),url_params)
    if resp==None:
        return
    data=[d for d in resp['data'] if d['key']==t][0]
    for r in data['list']:
        itemList(r,t)
        
    if data['count']>len(data['list'])+(int(p)-1)*count:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
        url=build_url({'mode':t,'page':str(int(p)+1)})
        addItemList(url, '[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]', setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def delWatching(i):
    url=apiURL+'v2/persona/continue/watching/remove'
    data={
        "continue_id": i,
        "country_code": "pl",
        "d_type": "web",
        "locale": "pl-PL",
        "region": "pl"
    }
    #resp=requests.post(url,headers=heaGen(),json=data).json()
    resp=req('post',url,heaGen(),url_params,data,f=None)
    if resp==None:
        return
    xbmc.executebuiltin('Container.Refresh()')
    
def delMyList(i,t):
    url=apiURL+'v2/persona/wishlist/%s/%s'%(t,i)
    url_params.update({'u_id':addon.getSetting('user_id')})
    #resp=requests.delete(url,headers=heaGen(),params=url_params)
    resp=req('delete',url,heaGen(),url_params,f=None)
    if resp==None:
        return
    xbmc.executebuiltin('Container.Refresh()')

def addMyList(i,t):
    url=apiURL+'v2/persona/wishlist'
    data={
        "content_id": i,
        "content_type": t,
        "country_code": "pl",
        "d_type": "web",
        "locale": "pl-PL",
        "region": "pl"
    }
    #resp=requests.post(url,headers=heaGen(),json=data).json()
    resp=req('post',url,heaGen(),url_params,data,None)
    if resp==None:
        return
    if resp['status_code']==200:
        xbmcgui.Dialog().notification('Filmbox', 'Dodano do Mojej Listy', xbmcgui.NOTIFICATION_INFO)
###
def checkStatus():
    res=True
    code=0
    url=apiURL+'v2/persona/content/persona'
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    if resp['status_code']!=200:
        res=False
        code=resp['error']['code']
        
    return res,code

def pluginLogout():
    addon.setSetting('access_token','')
    addon.setSetting('refresh_token','')
    addon.setSetting('user_id','')
    addon.setSetting('token_time','')
    addon.setSetting('logged','false')

def refreshToken():
    result=False#
    url=apiURL+'v2/auth/refresh/token'
    url_params.update({
        'd_id':addon.getSetting('d_id')
    })
    hea=heaGen()
    hea.update({'Authorization':addon.getSetting('refresh_token')})
    resp=requests.get(url,headers=hea,params=url_params).json()
    if resp['status_code']==200:
        if 'data' in resp: 
            addon.setSetting('access_token',resp['data']['access_token'])
            addon.setSetting('refresh_token',resp['data']['refresh_token'])
            xbmcgui.Dialog().notification('Filmbox', 'Odświeżono token', xbmcgui.NOTIFICATION_INFO)#
            xbmc.log('@@@odświeżono token', level=xbmc.LOGINFO)
            result=True#
        else:
            xbmc.log('@@@brak tokenów', level=xbmc.LOGINFO)
    else:
        if 'error' in resp:
            if resp['error']['code']==1003: #wygasł token odświeżania --> wylogowanie we wtyczce
                pluginLogout()
                xbmcgui.Dialog().notification('Filmbox', 'Wylogowano (wygasł refresh_token)', xbmcgui.NOTIFICATION_INFO)
                xbmc.log('@@@wygasł token odświeżania >>> wylogowanie we wtyczce', level=xbmc.LOGINFO)
        else:
            xbmcgui.Dialog().notification('Filmbox', 'Błąd przy odświeżeniu tokena', xbmcgui.NOTIFICATION_INFO)
    
    return result#

def req(t,u,h,p={},d={},f=True): # do play, mojej listy, kontynuacji
    def getAction(f): 
        if f:
            xbmcplugin.endOfDirectory(addon_handle)
        if f==None:
            pass
        else:
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    def getReq(t,u,h,p,d):
        if t=='get':
            resp=requests.get(u,headers=h,params=p).json()
        elif t=='post':
            resp=requests.post(u,headers=h,params=p,json=d).json()
        elif t=='delete':
            resp=requests.delete(u,headers=h,params=p).json()
        return resp
    
    r=getReq(t,u,h,p,d)
    if 'status_code' in r:
        if r['status_code']!=200:
            if 'error' in r:
                erCode=r['error']['code']
                if erCode==1002: #wygasł access_token
                    xbmc.log('@@@wygasł access_token', level=xbmc.LOGINFO)
                    if refreshToken():# gdy odświeżono token
                        r=getReq(t,u,heaGen(),p,d)
                        return r
                    else:
                        getAction(f)
                        return None
                elif erCode==4004 or erCode==4005: #wylogowano w innym serwisie ---> wylogowanie we wtyczce
                    xbmc.log('@@@wylogowano z poziomu innego urządzenia >>> wylogowanie we wtyczce', level=xbmc.LOGINFO)
                    pluginLogout()
                    getAction(f)
                    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
                    xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/,replace)')
                    return None
                else:
                    xbmc.log('@@@Błąd:'+str(erCode), level=xbmc.LOGINFO)
                    return None
            else:
                getAction(f)
                return None
        else:
            return r
    else:
        getAction(f)
        return None
        
    
mode = params.get('mode', None)

if not mode:

    if addon.getSetting('d_id')=='' or addon.getSetting('d_id')==None:#
        addon.setSetting('d_id',"%s-%s-%s-%s-%s" %(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12)))
        addon.setSetting('udi',"%s-%s-%s-%s-%s" %(code_gen(8),code_gen(4),code_gen(4),code_gen(4),code_gen(12)))

    if addon.getSetting('logged')=='true':
        isLogged,erCode=checkStatus()
        if isLogged:
            main_menu()
        else:
            if erCode==1002: #nieważny access_token
                xbmc.log('@@@nieważny access_token', level=xbmc.LOGINFO)
                refreshToken()
            elif erCode==4004 or erCode==4005: #wylogowano w innym serwisie ---> wylogowanie we wtyczce
                xbmc.log('@@@wylogowano z poziomu innego urządzenia >>> wylogowanie we wtyczce', level=xbmc.LOGINFO)
                pluginLogout()
            else:
                xbmc.log('@@@Błąd:'+str(erCode), level=xbmc.LOGINFO)
            main_menu()
    else:
        main_menu()
else:
    if mode=='logIn':
        logIn()
        if addon.getSetting('logged')=='true':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/,replace)')
            
    if mode=='logOut':
        logOut()
        if addon.getSetting('logged')=='false':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/,replace)')
    
    if mode=='movies' or mode=='series':
        categs(mode)
            
    if mode=='contList':
        key=params.get('key')
        slug=params.get('slug')
        component=params.get('component')
        page=params.get('page')
        cat=params.get('cat')
        contList(key,slug,component,cat,page)
        
    if mode=='seasonList':
        slug=params.get('slug')
        seasonList(slug)
        
    if mode=='episodeList':
        slug=params.get('slug')
        episodeList(slug)
        
    if mode=='playVid':
        slug=params.get('slug')
        playVid(slug)
        
    if mode=='tv':
        tv()
        
    if mode=='playTV':
        if addon.getSetting('logged')=='true':
            slug=params.get('slug')
            playTV(slug)
        else:
            xbmcgui.Dialog().notification('Filmbox', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
        
    if mode=='epg':
        cid=params.get('cid')
        epg(cid)
    
    if mode=='search':   
        query = xbmcgui.Dialog().input(u'Szukaj, Podaj tytuł:', type=xbmcgui.INPUT_ALPHANUM)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        if query:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/?mode=searchRes&q='+query+'&p=1)')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.filmbox/,replace)')
    
    if mode=='searchRes':
        q=params.get('q')
        p=params.get('p')
        search(q,p)
               
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('Filmbox', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
            
    if mode=='wishlist' or mode=='continue':
        p=params.get('page')
        myList(mode,p)
        
    if mode=='delWatching':
        c=params.get('continue_id')
        delWatching(c)
        
    if mode=='delMyList':
        c=params.get('cont_id')
        t=params.get('c_type')
        delMyList(c,t)
        
    if mode=='addMyList':
        c=params.get('cont_id')
        t=params.get('c_type')
        addMyList(c,t)
    