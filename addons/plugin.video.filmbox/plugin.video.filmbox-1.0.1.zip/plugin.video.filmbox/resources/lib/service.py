# -*- coding: utf-8 -*-

from xbmc import Monitor, Player, getInfoLabel
import xbmc
import time, datetime
import random
import json
import xbmcaddon
import requests
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

addon = xbmcaddon.Addon(id='plugin.video.filmbox')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='https://app.filmbox.com/'
apiURL='https://api.filmbox.com/api/'

url_params={
    'd_type':'web', #androidtv
    'region':'pl',
    'locale':'pl-PL',
    'country_code':'pl'
}
    
def heaGen():
    HEA={
        'Referer':baseurl,
        'Origin':baseurl[:-1],
        'User-Agent':UA,
        'Content-Type':'application/json',
        'Authorization':addon.getSetting('access_token')
    }
    return HEA

def getVidIDs(s):
    url=apiURL+'v2/persona/content/video/'+s
    url_params.update({
        'streaming-type':'dash',
        'supports_drm':'1'
    })
    resp=requests.get(url,headers=heaGen(),params=url_params).json()
    continue_id=resp['data']['continue_id'] if 'continue_id' in resp['data'] else None
    content_id=resp['data']['content_id']
    a={
        'continue_id':continue_id,
        'content_id': content_id 
    }
    return a

class BackgroundService(Monitor):
    """ Background service code """

    def __init__(self):
        Monitor.__init__(self)
        self._player = PlayerMonitor()

    def run(self):
        """ Background loop for maintenance tasks """

        while not self.abortRequested():

            # Stop when abort requested
            if self.waitForAbort(10):
                break


class PlayerMonitor(Player):
    """ A custom Player object to check subtitles """
    
    def __init__(self):
        """ Initialises a custom Player object """
        self.__listen = False

        self.__path = None
        self.__timeplay =0
        self.__totalTime=0
        Player.__init__(self)
        
    def markWatchStatus():
        pass
        
    def onPlayBackStarted(self):  
        """ Will be called when Kodi player starts """
        self.__path = getInfoLabel('Player.FilenameAndPath')
        
        if not self.__path.startswith('plugin://plugin.video.filmbox/?mode=playVid'):
            self.__listen = False
            return
        xbmc.log('start odtwarzania', level=xbmc.LOGINFO)    
        self.__listen = True
                
        while self.__listen and self.isPlaying():
            if self.isPlaying():
                self.__timeplay=self.getTime()
                self.__totalTime=self.getTotalTime()
            time.sleep(2)
        
    def onPlayBackEnded(self):  
        """ Will be called when [Kodi] stops playing a file """
        if not self.__listen:
            return
        xbmc.log('koniec odtwarzaniax', level=xbmc.LOGINFO)
        if addon.getSetting('logged')=='true' and addon.getSetting('synchKontOgl')=='true':
            slug=dict(parse_qsl(self.__path.split('?')[-1]))['slug']
            #usunięcie z kontynuuj
            continue_id=getVidIDs(slug)['continue_id']
            if continue_id != None:
                url=apiURL+'v2/persona/continue/watching/remove'
                data={
                    "continue_id": continue_id,
                    "country_code": "pl",
                    "d_type": "web",
                    "locale": "pl-PL",
                    "region": "pl"
                }
                resp=requests.post(url,headers=heaGen(),json=data).json()
                try:
                    xbmc.log('@@@'+str(resp['message']), level=xbmc.LOGINFO)
                except:
                    xbmc.log('@@@Nie usunięto video z kontynuacji', level=xbmc.LOGINFO)
            
            #status
            if 'playVid' in self.__path:
                pathFile='plugin://plugin.video.filmbox/?mode=playVid&slug='+slug
                totalTime=int(self.__totalTime)
                now=int(time.time())
                lastplayed=datetime.datetime.fromtimestamp(now).strftime('%Y-%m-%d %H:%M:%S')
                request={
                        "jsonrpc": "2.0", 
                        "method": "Files.SetFileDetails", 
                        "params": {
                            "file": pathFile, 
                            "media": "video", 
                            "playcount": 1,
                            "lastplayed":lastplayed,
                            "resume": {
                                "position":0, 
                                "total": 0
                            }
                        },
                        "id":"1"
                }
                results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                print(results)
                
                xbmc.executebuiltin('Container.Refresh()')
                
            req={"jsonrpc": "2.0", "params": {"media": "video","file": pathFile, "properties": ["resume","playcount"]}, "method": "Files.GetFileDetails", "id": "1"}
            results = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
            print(results)
            
              
            
    def onPlayBackStopped(self):  
        """ Will be called when [user] stops Kodi playing a file """
        if not self.__listen:
            return
        xbmc.log('@@@Odtwarzanie przerwane - STOP', level=xbmc.LOGINFO)
        if addon.getSetting('logged')=='true' and addon.getSetting('synchKontOgl')=='true':
            slug=dict(parse_qsl(self.__path.split('?')[-1]))['slug']
            timePlay=int(self.__timeplay)
            totalTime=int(self.__totalTime)
            url=apiURL+'v2/persona/continue/watching'
            data={
                "content_id": getVidIDs(slug)['content_id'],
                "country_code": "pl",
                "d_type": "web",
                "locale": "pl-PL",
                "preferred_language": "pl",#
                "preferred_subtitle": "pl",#
                "region": "pl",
                "u_id": addon.getSetting('user_id'),
                "w_time": timePlay
            }
            resp=requests.post(url,headers=heaGen(),json=data).json()
            try:
                xbmc.log('@@@'+str(resp['message']), level=xbmc.LOGINFO)
            except:
                xbmc.log('@@@Błąd przesyłania danych o kontynuacji na serwer', level=xbmc.LOGINFO)
            

            #status
            pathFile='plugin://plugin.video.filmbox/?mode=playVid&slug='+slug
            if totalTime>0 and 'playVid' in self.__path:
                request={
                    "jsonrpc": "2.0", 
                    "method": "Files.SetFileDetails", 
                    "params": {
                        "file": pathFile, 
                        "media": "video", 
                        "resume": {
                            "position":timePlay, 
                            "total": totalTime
                        }
                    },
                    "id":"1"
                }
                results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                
                xbmc.executebuiltin('Container.Refresh()') 
            
            req={"jsonrpc": "2.0", "params": {"media": "video","file": pathFile, "properties": ["resume","playcount"]}, "method": "Files.GetFileDetails", "id": "1"}
            results = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
            print(results)
                
def run():
    """ Run the BackgroundService """
    BackgroundService().run()
