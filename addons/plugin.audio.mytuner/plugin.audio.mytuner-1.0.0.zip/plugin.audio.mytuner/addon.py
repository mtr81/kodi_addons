# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import time
import datetime
from html import unescape
#import random
import base64
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from Cryptodome.Cipher import AES
import string

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.mytuner')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
img_empty=PATH+'/resources/empty.png'
imgPATH=PATH+'/resources/img/'
icon_main=PATH+'icon.png'

mode = addon.getSetting('mode')
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='https://mytuner-radio.com/'
hea={
    'User-Agent':UA,
    'Referer':baseurl
}

def cleanTXT(x):
    y=re.compile('(&#x[a-fA-F0-9]+?;)').findall(x)
    for yy in y:
        x=x.replace(yy,chr(int(yy[2:-1].replace('x',''),16)))
    x=re.sub(re.compile('<.*?>'),'',x)
    return x

def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(u):
    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        #play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+UA+'&Referer='+baseurl)#K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(u,heaP=None):
    if heaP!=None:
        u+='|'+heaP
    play_item = xbmcgui.ListItem(path=u)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def getCountry():
    country=addon.getSetting('country')
    if country=='' or country==None:
        country='Poland'
        addon.setSetting('country','Poland')
    return country
        
def getCountryToUrl():
    try:
        fURL=PATH_profile+'countries.json'
        js=openJSON(fURL)
        return js[addon.getSetting('country')]
    except:
        return 'poland'

       
def main_menu():
    addon.setSetting('genre','All')
    items=[
        ['Country: [B]%s[/B]'%(getCountry()),'country','DefaultCountry.png'],#DefaultAddonLanguage.png
        ['Radio stations','radio','DefaultMusicSongs.png'],
        ['Podcasts','podcast','DefaultPlaylist.png'],
        ['Search','search','DefaultAddonsSearch.png'],
        ['My list','favList','DefaultMusicRecentlyAdded.png']
        
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': ''}
        URL=build_url({'mode':i[1]})
        if i[1]=='country':
            addItemList(URL, i[0], setArt, isF=False)
        else:
            addItemList(URL, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def country():
    now=int(time.time())
    baseDate=addon.getSetting('baseDate')
    if baseDate==None or baseDate=='':
        loadData=True
    else:
        if now-int(baseDate)>24*60*60:
            loadData=True
        else:
            loadData=False
    
    if loadData:
        resp=requests.get(baseurl,headers=hea).text
        cNames=re.compile('var country_names = ([^;]+?);').findall(resp)[0]
        cN=json.loads(cNames)
        cLabels=re.compile('var country_labels = ([^;]+?);').findall(resp)[0]
        cL=json.loads(cLabels)
        countries={}
        for i,c in enumerate(cN):
            countries[c]=cL[i]
        
        fURL=PATH_profile+'countries.json'
        saveJSON(fURL,countries)
        addon.setSetting('baseDate',str(now))
    
    fURL=PATH_profile+'countries.json'
    js=openJSON(fURL)
            
    select=xbmcgui.Dialog().select('Choose a country:', list(js.keys()))
    if select>-1:
        addon.setSetting('country',list(js.keys())[select])
        xbmc.executebuiltin('Container.Refresh()')
    
def genreList(u,t): #helper
    gs={}
    resp=requests.get(u,headers=hea).text
    type='genres_div' if t=='radio' else 'states_div'
    resp1=resp.split(type)[1].split('</div')[0].split('</a>')
    for r in resp1:
        if 'href=' in r:
            name=re.compile('ellipsize\">([^<]+?)</span').findall(r)[0]
            label=re.compile('href=\"([^<]+?)\"').findall(r)[0]
            gs[unescape(name)]=label.strip()
    return gs
            
def genre(u,t):
    genList=genreList(u,t)
    select=xbmcgui.Dialog().select('Choose genre:', list(genList.keys()))
    if select>-1:
        addon.setSetting('genre',list(genList.keys())[select])
        xbmc.executebuiltin('Container.Refresh()')
    

def itemList(t,p=None):    
    genre=addon.getSetting('genre')
    url='%s%s/country/%s-stations'%(baseurl,t,getCountryToUrl()) if t=='radio' else '%s%s/country/top-%s'%(baseurl,t,getCountryToUrl())
    
    #Filtr: genre (tylko pierwsza strona)
    if p==None:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultGenre.png', 'fanart': ''}
        URL=build_url({'mode':'genre','u':url,'t':t})
        addItemList(URL, 'Genre: [B]%s[/B]'%(genre), setArt, isF=False)
            
    genList=genreList(url,t)
    url=baseurl+genList[genre][1:]
    if p!=None:
        url+='?page='+p
    p=p if p!=None else '1'
    print(url)
    
    resp=requests.get(url,headers=hea).text
    ct='radio-list' if t=='radio' else 'podcast-list'
    resp1=resp.split(ct)[1].split('</ul')[0].split('</li')
    for r in resp1:
        if 'href=' in r and ('data-src' in r or 'src' in r):
            try:
                img=re.compile('data-src=\"([^"]+?)\"').findall(r)[0]
            except:
                img=re.compile('img src=\"([^"]+?)\"').findall(r)[0]
            name=re.compile('alt=\"([^"]+?)\"').findall(r)[0]
            name=cleanTXT(name)
            link=re.compile('href=\"([^"]+?)\"').findall(r)[0]
            if t=='podcast':
                img=img.replace(img.split('/')[-1],'500x500bb.jpg')
                data=re.compile('ellipsize\">([^<]+?)</span').findall(r)
                plot=cleanTXT('\n'.join(data))
                URL=build_url({'mode':'epList','link':link})
                isF=True
                isP='false'
            else:
                plot=name
                URL=build_url({'mode':'playSource','link':link})   
                isF=False
                isP='true'                
            
            iL={'plot':plot}
            setArt={'thumb': img, 'poster': img, 'banner': '', 'icon': img, 'fanart': ''}
            
            cmItems=[('[B]Add to My list[/B]','RunPlugin(plugin://plugin.audio.mytuner?mode=favAdd&url='+quote(URL)+'&title='+quote(name)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+')')]
            
            addItemList(URL, name, setArt, 'video', iL, isF, isP, True, cmItems)
    
    if '?page='+str(int(p)+1) in resp:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart': ''}
        URL=build_url({'mode':'itemList','cont':t,'page':str(int(p)+1)})
        addItemList(URL, '[B]>>> Next page[/B]', setArt)
        
    xbmcplugin.endOfDirectory(addon_handle)

def urlDec(c,i,t):
    def genk(s):
        h = ""
        j = 0
        for i in range(0,32): 
            h += "" + hex(ord(s[j]))[2:]
            j+=1
            if j >= len(s): 
                j=0
            
        return h
    C=base64.b64decode(c)#[:-11]
    K=bytes.fromhex(genk(t))
    I=bytes.fromhex(i)
    
    obj = AES.new(K, AES.MODE_CFB, I, segment_size=128)
    return obj.decrypt(C).decode()
    
    
def playSource(l):
    url=baseurl+l[1:]
    resp=requests.get(url,headers=hea).text
    streams=re.compile('formatPlaylist\(([^;]+?)\);').findall(resp)
    streamsAr=json.loads(streams[0])
    selectStream=addon.getSetting('selectStream')
    if selectStream !='true':
        stream=streamsAr[0]
    else:
        select=xbmcgui.Dialog().select('Sources', [s['type'] for s in streamsAr])
        if select>-1:
            stream=streamsAr[select]
        else:
            stream=streamsAr[0]
    
    stream_url_enc=stream['cipher']
    iv=stream['iv']
    t=re.compile('data-timestamp=\"([^"]+?)\"').findall(resp)[0]
    stream_url=urlDec(stream_url_enc,iv,t)
    su=''.join([str(c) for c in stream_url if c in string.printable]).strip()
    
    directPlayer(su,'User-Agent='+UA)
    
def epList(l):
    url=baseurl+l[1:]
    resp=requests.get(url,headers=hea).text
    '''
    resp1=resp.split('\"application/ld+json\"')[1].split('</script')[0]
    podcData=json.loads(resp1)
    
    genre=podcData['genre'] if 'genre' in podcData else None
    pName=podcData['name'] if 'name' in podcData else None
    
    plot=''
    if pName!=None:
        plot+='[B]%s[/B]\n'%(pName)
    if genre!=None:
        plot+='[I]%s[/I]\n'%(genre)
        
    
    for p in podcData['episodes']:
        name=p['name']
        date=p['datePublished']
        img=p['thumbnailUrl']
        
        plot+='[B]Data: [/B]%s\n'%(date)
        
        iL={'plot':plot}
        setArt={'thumb': img, 'poster': img, 'banner': '', 'icon': img, 'fanart': ''}
        URL=build_url({'mode':'playPodc','link':link}) 
        addItemList(URL, name, setArt, 'video', iL, False, 'true')
    '''
    resp1=resp.split('podcast-episodes-list')[1].split('</ul')[0].split('<ul')[1].split('</li>')
    for r in resp1:
        if 'data-url' in r:
            img=re.compile('<img src=\"([^"]+?)\"').findall(r)[0]
            img=img.replace(img.split('/')[-1],'500x500bb.jpg')
            name=re.compile('name\">([^<]+?)</div').findall(r)[0]
            date=re.compile('date\">([^<]+?)</div').findall(r)[0]
            link=re.compile('data-url=\"([^"]+?)\"').findall(r)[0]
            
            plot='%s'%(date)
            
            iL={'plot':plot}
            setArt={'thumb': img, 'poster': img, 'banner': '', 'icon': img, 'fanart': ''}
            URL=build_url({'mode':'playPodc','link':link}) 
            addItemList(URL, unescape(name), setArt, 'video', iL, False, 'true')
    
    xbmcplugin.endOfDirectory(addon_handle)
    
    
def search():
    qry=xbmcgui.Dialog().input(u'Search:', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        url=baseurl+'search/?q='+quote_plus(qry)
        resp=requests.get(url,headers=hea).text
        results={'radio':[],'podcast':[]}
        resp1=resp.split('radio-list')
        if len(resp1)>2:
            resp1[1]=resp1[1].replace('</ul','')+resp1[2]
        resp2=resp1[1].split('</ul')[0].split('</li')
        for r in resp2:
            if 'ellipsize' in r:
                try:
                    img=re.compile('data-src=\"([^"]+?)\"').findall(r)[0]
                except:
                    img=re.compile('img src=\"([^"]+?)\"').findall(r)[0]
                name=re.compile('alt=\"([^"]+?)\"').findall(r)[0]
                link=re.compile('href=\"([^"]+?)\"').findall(r)[0]
                if '/radio/' in link:
                    results['radio'].append([name,link,img])
                elif '/podcast/':
                    results['podcast'].append([name,link,img])
        
        fURL=PATH_profile+'searchResults.json'
        saveJSON(fURL,results)
        
    items=[
        ['Radio (%s)'%(len(results['radio'])) ,'radio','DefaultMusicSongs.png'],
        ['Podcasty (%s)'%(len(results['podcast'])),'podcast','DefaultMusicSongs.png'],
    ]
    for i in items:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': i[2], 'fanart': ''}
        URL=build_url({'mode':'searchList','cont':i[1]})
        addItemList(URL, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def searchList(t):
    fURL=PATH_profile+'searchResults.json'
    js=openJSON(fURL)
    for i in js[t]:
        name=unescape(i[0])
        img=i[2]
        if t=='podcast':

            mod='epList'
            isF=True
            isP='false'
        else:
            mod='playSource'
            isF=False
            isP='true'                
        
        URL=build_url({'mode':mod,'link':i[1]})
        iL={'plot':name}
        setArt={'thumb': img, 'poster': img, 'banner': '', 'icon': img, 'fanart': ''}
        
        cmItems=[('[B]Add to My list[/B]','RunPlugin(plugin://plugin.audio.mytuner?mode=favAdd&url='+quote(URL)+'&title='+quote(name)+'&iL='+quote(str(iL))+'&setart='+quote(str(setArt))+')')]
        
        addItemList(URL, name, setArt, 'video', iL, isF, isP, True, cmItems)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
    
    
 
#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=json.loads(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
  
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    
    for j in js:
        if '=play' in j[0]:
            isFolder=False
            isPlayable='true'
        else:
            isFolder=True
            isPlayable='false'

        title=j[1]
        cmItems=[
            ('[B]Remove from My list[/B]','RunPlugin(plugin://plugin.audio.mytuner?mode=favDel&url='+quote(j[0])+')')
        ]
        
        iL=eval(j[2])
        setArt=eval(j[3])
        if isFolder:
            plot='[COLOR=yellow]Podcast[/COLOR]\n'
        else:
            plot='[COLOR=yellow]Radio[/COLOR]\n'
        iL={'plot':plot}    
        url = j[0]
        addItemList(url, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
        
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,i,a):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,i,a])
        xbmcgui.Dialog().notification('myTuner', 'Added to My List', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('myTuner', 'Item is already on My list', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Choose folder', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('myTuner', 'File saved', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Choose file', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('myTuner', 'File saved', xbmcgui.NOTIFICATION_INFO)




mode = params.get('mode', None)

if not mode:
    main_menu()
else:
    if mode=='country':
        country()
        
    if mode=='genre':
        u=params.get('u')
        t=params.get('t')
        genre(u,t)
    
    if mode=='radio' or mode=='podcast':
        itemList(mode)
    
    if mode=='itemList':
        cont=params.get('cont')
        page=params.get('page')
        itemList(cont,page)
    
    if mode=='playSource':
        link=params.get('link')
        playSource(link)
            
    if mode=='epList':
        link=params.get('link')
        epList(link)
    
    if mode=='playPodc':
        link=params.get('link')
        directPlayer(link,'User-Agent='+UA)
    
    if mode=='search':
        search()
    
    if mode=='searchList':
        cont=params.get('cont')
        searchList(cont)
        
    #FAV    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        i=params.get('iL')
        a=params.get('setart')
        favAdd(u,t,i,a)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()

    