# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import unicodedata
import json
import random
import math
#import time
#from resources.lib import jsunpack
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.polsatgo_hbb')
PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'

mode = addon.getSetting('mode')
baseurl='http://hbbmux4.teleaudio.pl/'
reqURLnav='https://b2c-www.redefine.pl/rpc/navigation/'
reqURLdrm='https://b2c-www.redefine.pl/rpc/drm/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0'
ua="pg_tv_hbbtv_other_html/1 (HbbTV/1.2.1 (+DRM;Samsung;SmartTV2015;T-HKM6DEUC-1490.3;;) HybridTvViewer)"
osInfo="HbbTV/1.2.1 (+DRM;Samsung;SmartTV2015;T-HKM6DEUC-1490.3;;) HybridTvViewer"

jsonData='''
{
	"id": 1,
	"jsonrpc": "2.0",
	"method": %s,
	"params": {
		"catid": %d,
		"clientId": %s,
		"limit": 1000,
		"offset": 0,
		"place": {
			"type": "homepage",
			"value": ""
		},
		"staffRecommendationsListId": "599",
		"ua": %s,
		"userAgentData": {
			"application": "other",
			"build": 1,
			"deviceType": "tv",
			"os": "hbbtv",
			"osInfo": %s,
			"player": "html",
			"portal": "pg",
			"widevine": False
		}
	}
}
'''
hea={
    'User-Agent':UA,
    'Referer':baseurl,
    'Content-Type':'Content-Type: application/json;charset=UTF-8'
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def getClientId():
    def code_gen(x):
        base='0123456789abcdef'
        code=''
        for i in range(0,x):
            code+=base[random.randint(0,15)]
        return code
    addon.setSetting('clientId',code_gen(8)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(12))
    addon.setSetting('deviceId',code_gen(32))

def main_menu():
    sources=[
        ['REKOMENDACJE','','rekom'],
        ['SERIALE','5024024','contList'],
        ['PROGRAMY','5024073','contList'],
        ['SPORT','5024074','contList'],
        ['.:ULUBIONE:.','','favList']
    ]
    for s in sources:
        mode=s[2]
        li=xbmcgui.ListItem(s[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':mode,'catid':s[1],'init':'yes','page':'1'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def rekom():
    jd={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getStaffRecommendationsLists",
        "params": {
            "clientId": addon.getSetting('clientId'),
            "place": {
                "type": "homepage",
                "value": ""
            },
            "ua": "www_iplatv/12345 (Mozilla/5.0 Windows NT 10.0; Win64; x64 AppleWebKit/537.36 KHTML, like Gecko Chrome/83.0.4103.61 Safari/537.36)",
            "userAgentData": {
                "application": "other",
                "build": 1,
                "deviceType": "tv",
                "os": "hbbtv",
                "osInfo": osInfo,
                "player": "html",
                "portal": "pg",
                "widevine": False
            }
        }
    }
    resp=requests.post(reqURLnav,json=jd,headers=hea).json()
    for r in resp['result']:
        if 'hbbtv' in r['description']:
            id=r['id']
            name=r['name']
            
            li=xbmcgui.ListItem(name)
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
            url = build_url({'mode':'rekomList','rid':id})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def rekomList(rid):
    jd={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getStaffRecommendationsListItems",
        "params": {
            "clientId": addon.getSetting('clientId'),
            "limit": 50,
            "place": {
                "type": "homepage",
                "value": ""
            },
            "staffRecommendationsListId": rid,
            "ua": ua,
            "userAgentData": {
                "application": "other",
                "build": 1,
                "deviceType": "tv",
                "os": "hbbtv",
                "osInfo": osInfo,
                "player": "html",
                "portal": "pg",
                "widevine": False
            }
        }
    }
    resp=requests.post(reqURLnav,json=jd,headers=hea).json()
    for r in resp['result']['results']:
        r=r['object']
        if 'mediaType' in r:
            if r['mediaType']=='vod':
                epList(r,True)
                #r=r['category']
        else:
            cid=r['id']
            name=r['name']
            categ=''
            mod=''
            if 'subCategoriesLabel' not in r:
                if len(r['categoryPath'])==4:
                    mod='episodeList'
                elif len(r['categoryPath'])==3:
                    mod='sezonList'
            else:
                categ=r['subCategoriesLabel']           
            desc=r['description']
            img=''
            for i in r['thumbnails']:
                if i['size']['width']>700:
                    img=i['src']
                    break

            if categ=='Sezony':
                mod='sezonList'
            if categ=='Serie':
                mod='episodeList'
                                        
            li=xbmcgui.ListItem(name)
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': desc})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
            url = build_url({'mode':mod,'catid':cid,'init':'yes','page':'1'})
            
            contMenu = []
            contMenu.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.polsatgo_hbb?mode=favAdd&cid='+str(cid)+'&name='+quote(name)+'&mod='+mod+')'))
            li.addContextMenuItems(contMenu, replaceItems=False)
            
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def contList(catid,pg,init):
    cnt=25
    p=int(pg)
    if init=='yes':
        jd=eval(jsonData %('\"getCategoryContentWithFlatNavigation\"',int(catid),'\"'+addon.getSetting('clientId')+'\"','\"'+ua+'\"','\"'+osInfo+'\"'))
        jd['params'].update({"collection": {"type": "sortedBy","value": "13"}})
        resp=requests.post(reqURLnav,json=jd,headers=hea).json()
        addon.setSetting('contJSON',str(resp))
        
    resp=eval(addon.getSetting('contJSON'))
    total=len(resp['result']['results'])
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        r=resp['result']['results'][i]
        print(r)
        cid=r['id']
        name=r['name']
        categ=r['subCategoriesLabel']
        desc=r['description']
        img=''
        for i in r['thumbnails']:
            if i['size']['width']>700:
                img=i['src']
                break
        
        mod=''
        if categ=='Sezony':
            mod='sezonList'
        if categ=='Serie':
            mod='episodeList'
        
                
        li=xbmcgui.ListItem(name)
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': desc})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':mod,'catid':cid,'init':'yes','page':'1'})
        
        contMenu = []
        contMenu.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.polsatgo_hbb?mode=favAdd&cid='+str(cid)+'&name='+quote(name)+'&mod='+mod+')'))
        li.addContextMenuItems(contMenu, replaceItems=False)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    if p<math.ceil(total/cnt):
        li=xbmcgui.ListItem('[B]>>> Następna strona[/B]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'contList','init':'no','catid':catid,'page':str(p+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)
    
def sezonList(ctid):
    jd=eval(jsonData %('\"getSubCategories\"',int(catid),'\"'+addon.getSetting('clientId')+'\"','\"'+ua+'\"','\"'+osInfo+'\"'))
    resp=requests.post(reqURLnav,json=jd,headers=hea).json()
    if len(resp['result'])==0:
        episodeList(ctid,'1','yes')
    else:
        for r in resp['result']:
            cid=r['id']
            name=r['name']
            desc=r['description']
            img=''
            for i in r['thumbnails']:
                if i['size']['width']>700:
                    img=i['src']
                    break
            
            li=xbmcgui.ListItem(name)
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': desc})
            li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
            url = build_url({'mode':'episodeList','catid':cid,'init':'yes','page':'1'})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(addon_handle)
    
def episodeList(catid,pg,init):
    cnt=25
    p=int(pg)
    if init=='yes':       
        jd=eval(jsonData %('\"getCategoryContentWithFlatNavigation\"',int(catid),'\"'+addon.getSetting('clientId')+'\"','\"'+ua+'\"','\"'+osInfo+'\"'))
        resp=requests.post(reqURLnav,json=jd,headers=hea).json()
        addon.setSetting('episodeJSON',str(resp))
        
    resp=eval(addon.getSetting('episodeJSON'))
    total=len(resp['result']['results'])
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        r=resp['result']['results'][i]
        epList(r,False)
        '''
        cid=r['category']['id']
        mediaId=r['id']
        name=''
        plot=''
        if 'seasonNumber' in r:
            plot+='[B]Sezon:[/B] '+str(r['seasonNumber']) +'\n'
        if 'episodeNumber' in r:
            plot+='[B]Odcinek:[/B] '+str(r['episodeNumber'])+'\n'
            name='Odcinek '+str(r['episodeNumber'])
        if 'duration' in r:
            plot+='[B]Długość:[/B] '+str(int(r['duration']/60))+' min.'+'\n'
        if 'ageGroup' in r:
            plot+='[B]Wiek:[/B] '+str(r['ageGroup'])+'\n'
        if 'description'  in r: 
            plot+='[B]Opis:[/B][I] '+str(r['description'])+'[/I]\n'
        
        img=''
        for i in r['thumbnails']:
            if i['size']['width']>700:
                img=i['src']
                break
        
        if name=='':
            name=r['title']
        
        li=xbmcgui.ListItem(name)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
        url = build_url({'mode':'getSources','catid':cid,'mediaId':mediaId})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
        '''
    if p<math.ceil(total/cnt):
        li=xbmcgui.ListItem('[B]>>> Następna strona[/B]')
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''})
        url = build_url({'mode':'episodeList','init':'no','catid':catid,'page':str(p+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def epList(r,t):
    cid=r['category']['id']
    mediaId=r['id']
    name=''
    plot=''
    if 'seasonNumber' in r:
        plot+='[B]Sezon:[/B] '+str(r['seasonNumber']) +'\n'
    if 'episodeNumber' in r:
        plot+='[B]Odcinek:[/B] '+str(r['episodeNumber'])+'\n'
        name='Odcinek '+str(r['episodeNumber'])
    if 'duration' in r:
        plot+='[B]Długość:[/B] '+str(int(r['duration']/60))+' min.'+'\n'
    if 'ageGroup' in r:
        plot+='[B]Wiek:[/B] '+str(r['ageGroup'])+'\n'
    if 'description'  in r: 
        plot+='[B]Opis:[/B][I] '+str(r['description'])+'[/I]\n'
       
    img=''
    for i in r['thumbnails']:
        if i['size']['width']>500:
            img=i['src']
            break
        
    if name=='' or t:
        name=r['title']
    
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", 'true')
    li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': plot})
    li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img})
    url = build_url({'mode':'getSources','catid':cid,'mediaId':mediaId})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(addon_handle, 'videos')
    

def getSources(catid,mediaId):
    jd={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "prePlayData",
        "params": {
            "catid": int(catid),
            "clientId": addon.getSetting('clientId'),
            "cpid": 1,
            "mediaId": mediaId,
            "staffRecommendationsListId": "344",
            "ua": "www_iplatv_html5/12345 (Windows 10; widevine=false)",
            "userAgentData": {
                "application": "other",
                "build": 1,
                "deviceType": "tv",
                "os": "hbbtv",
                "osInfo": osInfo,
                "player": "html",
                "portal": "pg",
                "widevine": False
            }
        }
    }
    resp=requests.post(reqURLnav,json=jd,headers=hea).json()
    q_symb=[]
    q_link=[]
    for r in resp['result']['mediaItem']['playback']['mediaSources']:
        q_symb.append(r['quality'])
        q_link.append(r['id'])
    
    sourceId=''
    select = xbmcgui.Dialog().select('Źródła', q_symb)
    if select > -1:
        sourceId=q_link[select]
        playVid(mediaId,sourceId)
    else:
        quit()
    return

def playVid(mId,sId):
    jd={
        "id": 1,
        "jsonrpc": "2.0",
        "method": "getPseudoLicense",
        "params": {
            "clientId": addon.getSetting('clientId'),
            "cpid": 1,
            "deviceId": {
                "type": "other",
                "value": addon.getSetting('deviceId')
            },
            "mediaId": mId,
            "sourceId": sId,
            "staffRecommendationsListId": "344",
            "ua": "ipla_pc_windows_chrome_html/1 (Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36)",
            "userAgentData": {
                "application": "other",
                "build": 1,
                "deviceType": "tv",
                "os": "hbbtv",
                "osInfo": osInfo,
                "player": "html",
                "portal": "pg",
                "widevine": False
            }
        }
    }
    resp=requests.post(reqURLdrm,json=jd,headers=hea).json()
    stream_url=resp['result']['url']+'|User-Agent='+UA+'&Referer='+baseurl
    
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

#ULUBIONE
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        li=xbmcgui.ListItem(j[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''})
        url = build_url({'mode':j[2],'catid':j[1],'init':'yes','page':'1'})
        
        contMenu = []
        contMenu.append(('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.polsatgo_hbb?mode=favDel&cid='+j[1]+')'))
        li.addContextMenuItems(contMenu, replaceItems=False)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[1]==c:
            print('XXX')
            del js[i]
    print(js)
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(c,n,m):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[1]==c:
            duplTest=True
    if not duplTest:
        js.append([n,c,m])
        xbmcgui.Dialog().notification('Polsat Go', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('Polsat Go', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)


mode = params.get('mode', None)

if not mode:
    if addon.getSetting('clientId')=='' or addon.getSetting('deviceId')=='':
        getClientId()
    main_menu()
else:
    if mode=='rekom':
        rekom()
        
    if mode=='rekomList':
        rid=params.get('rid')
        rekomList(rid)
        
    if mode=='contList':
        catid=params.get('catid')
        pg=params.get('page')
        init=params.get('init')
        contList(catid,pg,init)
    
    if mode=='sezonList':
        catid=params.get('catid')
        sezonList(catid)
    
    if mode=='episodeList':
        catid=params.get('catid')
        pg=params.get('page')
        init=params.get('init')
        episodeList(catid,pg,init)
        
    if mode=='getSources':
        catid=params.get('catid')
        mediaId=params.get('mediaId')
        getSources(catid,mediaId)
    
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        cid=params.get('cid')
        favDel(cid)
        
    if mode=='favAdd':
        cid=params.get('cid')
        name=params.get('name')
        mod=params.get('mod')
        favAdd(cid,name,mod)
