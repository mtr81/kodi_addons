# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
#import base64
#import unicodedata
import json
import random
import math
import datetime
import time
#from resources.lib import jsunpack
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from ttml2ssa import Ttml2SsaAddon

from resources.lib.base import b

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
base=b(base_url,addon_handle)

params = dict(parse_qsl(sys.argv[2][1:]))
addon = base.addon
PATH=addon.getAddonInfo('path')
PATH_profile=base.PATH_profile
img_empty=PATH+'/resources/empty.png'
fanart=PATH+'/resources/images/fanart.jpg'
img_path=PATH+'/resources/images/'

mode = addon.getSetting('mode')
baseurl='https://apps.vod.tvp.pl/'
platform='SMART_TV'#ANDROID

mainCategs=[        
    ['TELEWIZJA','','tvpgo','tvp_go.png'],
    ['Transmisje TVP SPORT','','tvp_sport','tvp_sport.png'],
    ['Programy TVP INFO','','tvp_info','tvp_info.png'],
    ['Programy TVP3 (Regiony)','','tvp3','tvp3.png'],
    ['Rekonstrukcja cyfrowa','','rc','rc.png'],
    ['Strona główna','','mainPage','tvp_vod.png'],
    ['Na żywo (TV)','','lives','tvp_vod.png'],
    ['Archiwum TV [I](test)[/I]','','archive','tvp_vod.png'],
    ['Seriale','18','categList','tvp_vod.png'],
    ['Filmy','136','categList','tvp_vod.png'],
    ['Programy','88','categList','tvp_vod.png'],
    ['Dokumenty','163','categList','tvp_vod.png'],
    ['Dla dzieci','24','categList','tvp_vod.png'],
    ['Teatr','202','categList','tvp_vod.png'],
    ['News','205','categList','tvp_vod.png'],
    ['ULUBIONE: VOD','','favList','tvp_vod.png'],
    ['ULUBIONE: inne serwisy TVP','','favExtList','tvp.png'],
    ['WYSZUKIWARKA','','search','tvp_vod.png']
]

hea={
    'User-Agent':base.UA,
    'Referer':baseurl,
    'X-Redge-VOD':'true',
    'API-DeviceInfo':'HbbTV;2.0.1 (ETSI 1.4.1);Chrome +DRM Samsung;Chrome +DRM Samsung;HbbTV;2.0.3'
}

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def heaGen():
    CorrelationID='smarttv_'+code_gen(32)
    hea.update({'API-CorrelationID':CorrelationID,'API-DeviceUid':addon.getSetting('DeviceUid')})
    if addon.getSetting('logged')=='true':
        hea.update({'API-Authentication':addon.getSetting('API_Authentication'),'API-ProfileUid':addon.getSetting('API_ProfileUid')})
    return hea
    
def logIn():
    kod=xbmcgui.Dialog().input(u'Wpisz kod ze strony vod.tvp/logowanie-tv:', type=xbmcgui.INPUT_ALPHANUM)#from: vod.tvp.pl/logowanie-tv
    if kod:
        url='https://vod.tvp.pl/api/subscribers/sso/tvp/login?code='+kod+'&lang=pl&platform='+platform
        #hea.update({'API-CorrelationID':addon.getSetting('CorrelationID'),'API-DeviceUid':addon.getSetting('DeviceUid')})
        hea=heaGen()
        data={
            "auth": {
                "app": "tvp",
                "type": "SSO",
                "value": ""
            },
            "rememberMe": True
        }
        resp=requests.post(url,headers=hea,json=data).json()
        if 'token' not in resp:
            xbmcgui.Dialog().notification('TVP VOD', 'Nieudane logowanie', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        else:
            addon.setSetting('API_Authentication',resp['token'])
            addon.setSetting('API_ProfileUid',resp['profiles'][0]['uid'])#logowanie na profil podstawowy (domyślnie)
            try:#dane o użytkowniku
                addon.setSetting('konto',resp['email'])
                addon.setSetting('packetsNames',str(resp['status']['packetsNames']))
                addon.setSetting('subscrTill',str(resp['aboActiveTill']))
            except:
                pass
            addon.setSetting('logged','true')
    else:
        xbmcgui.Dialog().notification('TVP VOD', 'Nie wpisano kodu', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        
        
def logOut():
    url='https://vod.tvp.pl/api/subscribers/logout?lang=pl&platform='+platform
    hea=heaGen()
    resp=requests.post(url,headers=hea)
    addon.setSetting('konto','')
    addon.setSetting('packetsNames','')
    addon.setSetting('subscrTill','')
    addon.setSetting('API_Authentication','')
    addon.setSetting('API_ProfileUid','')
    addon.setSetting('logged','false')

def vodProfiles():
    hea=heaGen()
    url='https://vod.tvp.pl/api/subscribers/detail?lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    if 'code' in resp:
        if resp['code']=='AUTHENTICATION_REQUIRED':
            paraLogOut()
    else:
        for p in resp['profiles']:
            if p['uid']==addon.getSetting('API_ProfileUid'):
                profileName=p['name']+ '[COLOR=yellow] (zalogowany)[/COLOR]'
                isUsed='true'
            else:
                profileName=p['name']
                isUsed='false'
           
            iL={'title': '','sorttitle': '','plot': ''}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':fanart}
            url = base.build_url({'mode':'changeProfile','uid':p['uid'],'used':isUsed})
            base.addItemList(url, profileName, setArt, 'video', {}, False, 'false')
        xbmcplugin.endOfDirectory(addon_handle)
    
def changeProfile(uid,used):
    if used == 'false':
        addon.setSetting('API_ProfileUid',uid)
        xbmc.executebuiltin('Container.Refresh()')
       
def main_menu():
    if addon.getSetting('logged')=='true':
        mainCategs.append(['Ulubione (aplikacja)','','favVODList','tvp_vod.png'])
        mainCategs.append(['Kontynuuj oglądanie','','VODwatched','tvp_vod.png'])###
        mainCategs.append(['Profile','','vodProfiles','tvp_vod.png'])
        mainCategs.append(['Wyloguj','','logOut','tvp_vod.png'])
    else:
        mainCategs.append(['Zaloguj','','logIn','tvp_vod.png'])
    for s in mainCategs:
        mode=s[2]
        
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_path+s[3], 'fanart':fanart}
        url = base.build_url({'mode':mode,'mainCateg':s[1]})
        base.addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def mainPage():
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/sections/main?elementsLimit=100&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    for c in resp:
        if c['showTitle']==True:            
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
            url = base.build_url({'mode':'mainPageCateg','categID':str(c['id'])})
            base.addItemList(url, c['title'], setArt)
    xbmcplugin.endOfDirectory(addon_handle)
    
def mainPageCateg(mpc):
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/sections/main?elementsLimit=100&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    for r in resp:
        if r['id']==int(mpc):
            if r['title']=='KONTYNUUJ OGLĄDANIE':
                VODmyList('watched')
            else:
                for rr in r['elements']:
                    addContToList(rr['item'])
    
    xbmcplugin.endOfDirectory(addon_handle)       
    
def sectionList(cid):
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/sections/'+cid+'?elementsLimit=30&lang=pl&maxResults=30&platform='+platform
    resp=requests.get(url,headers=hea).json()
    for r in resp['elements']:
        addContToList(r['item'])
    xbmcplugin.endOfDirectory(addon_handle)
                
def addContToList(r):
    cid=str(r['id'])
    name=r['title']
    type=r['type']
    img=getImg(r['images'])
    plot=''
    plot=detCont(r)#próba
    mod=''
    isPlayable='false'
    isFolder=True
    if type=='SERIAL':
        mod='sezonList'
        URL = base.build_url({'mode':mod,'cid':cid,'title':name})
    if type=='VOD':
        name=titleWithTill(plot,name)
        if addon.getSetting('playFromList')=='true':
            mod='playVid'
            URL = base.build_url({'mode':mod,'eid':cid})
            isPlayable='true'
            isFolder=False
        else:
            mod='progDetails'
            URL = base.build_url({'mode':mod,'eid':cid})
    if type=='EPISODE':
        name=r['season']['serial']['title']+' | '+name
        name=titleWithTill(plot,name)
        mod='playVid'
        URL = base.build_url({'mode':mod,'eid':cid})
        isPlayable='true'
        isFolder=False
    if type=='SECTION':
        mod='sectionList'
        URL = base.build_url({'mode':mod,'cid':cid})
    if type=='BANNER':#do weryfikacji
        if 'webUrl' in r:
            cid=r['webUrl'].split(',')[-1]
            if 'collections' in r['webUrl']:
                mod='sectionList'
                URL = base.build_url({'mode':mod,'cid':cid})
            elif '/programy' in r['webUrl'] or '/seriale' in r['webUrl']:
                mod='sezonList'
                URL = base.build_url({'mode':mod,'cid':cid,'title':name})
            elif '/filmy' in r['webUrl'] or '/teatr' in r['webUrl']:
                name=titleWithTill(plot,name)
                if addon.getSetting('playFromList')=='true':
                    mod='playVid'
                    URL = base.build_url({'mode':mod,'eid':cid})
                    isPlayable='true'
                    isFolder=False
                else:
                    mod='progDetails'
                    URL = base.build_url({'mode':mod,'eid':cid})
            else:
                URL = base.build_url({'mode':'mainPage'})
    
    if (type=='SERIAL' or type=='VOD' or type=='EPISODE') and r['displaySchedules'][0]['type']=='SOON':
        isPlayable='false'
        isFolder=False
    
    if type=='LIVE':
        mod='playLive'
        URL = base.build_url({'mode':mod,'cid':cid})
        plot=''
        isPlayable='true'
        isFolder=False
                
    contMenu=False
    cmItems=[]
    if type=='VOD' or type=='SERIAL' or type=='EPISODE':
        contMenu=True
        if type!='EPISODE':
            cmItems.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favAdd&cid='+cid+'&name='+quote(name)+'&mod='+mod+')'))
        cmItems.append(('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=showDet&eid='+cid+')'))
    
    if addon.getSetting('playFromList')=='true'and type!='LIVE':
        xbmcplugin.setContent(addon_handle, 'videos')

    iL={'title': '','sorttitle': '','plot': plot}
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
    base.addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)

def categList(mc):
    hea=heaGen()
    url='https://vod.tvp.pl/api/items/categories?mainCategoryId='+mc+'&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    arCateg=[['Wszystkie','all']]
    for c in resp:
        arCateg.append([c['name'],c['id']])
    for ac in arCateg:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':fanart}
        url = base.build_url({'mode':'contList','mainCateg':mc,'Categ':str(ac[1]),'page':'1'})
        base.addItemList(url, ac[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def getImg(x):
    img='https://vod.tvp.pl/static/images/no-image.jpg'
    for i in x:
        if i=='16x9':
            if len(x['16x9'])>0:
                if 'templateUrl' in x['16x9'][0] or 'url' in x['16x9'][0]:
                    img=x['16x9'][0]['templateUrl'] if 'templateUrl' in x['16x9'][0] else x['16x9'][0]['url']
                    img=img.format(width=480,height=268).replace(' ','')
    if img.startswith('//'):
        img='https:'+img
    return img

def titleWithTill(d,t):#data dostępności w tytule
    title=t
    tillPeriod=int(addon.getSetting('tillPeriod'))
    if 'Dostępny do: ' in d and ']PRAPREMIERA[' not in d:
        till=re.compile('Dostępny do: (.*)').findall(d.replace('[/B]',''))[0]
        now=datetime.datetime.now()
        if (datetime.datetime(*(time.strptime(till,'%Y-%m-%d')[0:6]))-now).days<=tillPeriod:
            title=t+' [COLOR=yellow]/do: '+till+'/[/COLOR]'
    return title
        

def contList(mc,c,pg):
    cnt=25
    p=int(pg)
    start=(p-1)*cnt
    hea=heaGen()
    sortName=addon.getSetting('sortContent')
    sortMeth={'Domyślnie':'&sort=createdAt&order=desc','Ostatnio dodane':'&sort=createdAt&order=desc','Najstarsze':'&sort=year&order=asc','Najnowsze':'&sort=year&order=desc','A-Z':'&sort=title&order=asc','Z-A':'&sort=title&order=desc',}
    sortParam=sortMeth[sortName]
    if c=='all':
        url='https://vod.tvp.pl/api/products/vods?=&firstResult='+str(start)+'&maxResults='+str(cnt)+'&mainCategoryId[]='+mc+sortParam+'&lang=pl&platform='+platform
    else:
        url='https://vod.tvp.pl/api/products/vods?=&firstResult='+str(start)+'&maxResults='+str(cnt)+'&mainCategoryId[]='+mc+'&categoryId[]='+c+sortParam+'&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    total=resp['meta']['totalCount']
    
    for r in resp['items']:
        cid=str(r['id'])
        name=r['title']
        type=r['type']
        img=getImg(r['images'])
        plot=''
        plot=detCont(r)#próba
        
        mod=''
        isPlayable='false'
        isFolder=True
        if type=='SERIAL':
            mod='sezonList'
            URL = base.build_url({'mode':mod,'cid':cid,'title':name})
        if type=='VOD':
            name=titleWithTill(plot,name)
            if addon.getSetting('playFromList')=='true':
                mod='playVid'
                URL = base.build_url({'mode':mod,'eid':cid})
                isPlayable='true'
                isFolder=False
            else:
                mod='progDetails'
                URL = base.build_url({'mode':mod,'eid':cid})
        
        if (type=='SERIAL' or type=='VOD') and r['displaySchedules'][0]['type']=='SOON':
            isPlayable='false'
            isFolder=False
                
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favAdd&cid='+cid+'&name='+quote(name)+'&mod='+mod+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=showDet&eid='+cid+')')
        ]
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        base.addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
    
    if p<math.ceil(total/cnt):
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''}
        url = base.build_url({'mode':'contList','mainCateg':mc,'Categ':c,'page':str(p+1)})
        base.addItemList(url, '[B]>>> Następna strona[/B]', setArt, 'video')
    
    if addon.getSetting('playFromList')=='true':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)
    
def sezonList(cid,tit):
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/vods/serials/'+cid+'/seasons?lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    if len(resp)==1: #jeden sezon
        sezId=str(resp[0]['id'])
        episodeList(cid,sezId,tit,'1','yes')
    else:
        for r in resp:
            sez_id=str(r['id'])
            sez_name=r['title']
            
            iL={'title': '','sorttitle': '','plot': tit}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart':fanart}
            url = base.build_url({'mode':'episodeList','cid':cid,'sezId':sez_id,'title':tit,'init':'yes','page':'1'})
            base.addItemList(url, sez_name, setArt, 'video', iL)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
       
def episodeList(cid,sezId,tit,pg,init):
    #cnt=25
    cnt=int(addon.getSetting('epCount'))
    p=int(pg)
    if init=='yes':
        hea=heaGen()
        url='https://vod.tvp.pl/api/products/vods/serials/'+cid+'/seasons/'+sezId+'/episodes?lang=pl&platform='+platform
        resp=requests.get(url,headers=hea).json()#list
        #rev_resp=list(reversed(resp))
        addon.setSetting('episodeJSON',str(resp))
    
    resp=eval(addon.getSetting('episodeJSON'))
    total=len(resp)
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        r=resp[i]
        eid=str(r['id'])
        title=r['title']
        img=getImg(r['images'])
        #st=r['externalUid']
        
        plot='[B]'+tit+'[/B]\n'
        plot+=detCont(r)#próba
        
        mod=''
        isPlayable='false'
        isFolder=True
        if addon.getSetting('playFromList')=='true':
            mod='playVid'
            isPlayable='true'
            isFolder=False
        else:
            mod='progDetails'
        
        if r['displaySchedules'][0]['type']=='SOON':
            isPlayable='false'
            isFolder=False
        
        cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=showDet&eid='+eid+')')]
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        url = base.build_url({'mode':mod,'eid':eid})
        base.addItemList(url, titleWithTill(plot,title), setArt, 'video', iL, isFolder, isPlayable, True, cmItems)

    if p<math.ceil(total/cnt):
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img_empty, 'fanart':''}
        url = base.build_url({'mode':'episodeList','init':'no','cid':cid,'sezId':sezId,'title':tit,'page':str(p+1)})
        base.addItemList(url, '[B]>>> Następna strona[/B]', setArt, 'video')
        
    if addon.getSetting('playFromList')=='true':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    #xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_PLAYLIST_ORDER)

def det(x):
    def iterTable(t,n):
        result=''
        for tt in t:
            result+=tt[n]+', '
        return result[:-2]
       
    title=x['title']
    img=getImg(x['images'])
    plot=title+'\n'
    if 'rating' in x:
        plot+='[B]Wiek: [/B]'+str(x['rating'])+'\n'
    if 'duration' in x:
        plot+='[B]Długość: [/B]'+str(int(x['duration']/60))+' min.\n'
    if 'year' in x:
        plot+='[B]Rok prod.: [/B]'+str(x['year'])+'\n'
    if 'countries' in x:
        plot+='[B]'+iterTable(x['countries'],'name')+'[/B]\n'
    if x['displaySchedules'][0]['type']!='SOON':
        if 'payable' in x:
            if x['payable']:
                plot+='Płatny\n'
            else:
                if 'payableSince' in x:
                    freeTill=datetime.datetime(*(time.strptime(x['payableSince'],'%Y-%m-%dT%H:%M:%S%z')[0:6])).strftime('%Y-%m-%d %H:%M')
                    plot+='Bezpłatny do: %s\n'%(freeTill)
                else:
                    plot+='Bezpłatny\n'
        if 'since' in x:
                plot+='[B]Data publikacji: [/B]'+x['since'].split('T')[0]+'\n'
        if 'till' in x:
                plot+='[B]Dostępny do: [/B]'+x['till'].split('T')[0]+'\n'
    else:
        plot+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
        plot+='[B]Dostępny od: [/B]'+x['displaySchedules'][0]['till'].split('T')[0]+'\n'
        if 'payableSince' in x:
            if x['displaySchedules'][0]['till'].split('T')[0]==x['payableSince'].split('T')[0] :
                plot+='Płatny\n'
            else:
                plot+='Bezpłatny\n'
        else:
            plot+='Bezpłatny\n'
    if 'description' in x:
        plot+='[B]Opis: [/B][I]'+cleanText(x['description'])+'[/I]\n'
    if 'persons' in x:
        persons=x['persons']
        if 'DIRECTOR' in persons:
            if len(persons['DIRECTOR']):
                plot+='[B]Reżyseria[/B]: '+iterTable(persons['DIRECTOR'],'name')+'\n'
        if 'ACTOR' in persons:
            if len(persons['ACTOR']):
                plot+='[B]Obsada[/B]: '+iterTable(persons['ACTOR'],'name')+'\n'
    if 'bundles' in x:
        plot+='[B]Pakiety: [/B]'+iterTable(x['bundles'],'title')+'\n'
                
    return title,img,plot

def showDet(eid):#menu kont
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/vods/'+eid+'?lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    if 'code' in resp:
        if resp['code']=='ITEM_NOT_AVAILABLE':
            plot='Materiał niedostępny'
        else:
            plot='brak danych'
    else:
        title,img,plot=det(resp)
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)
    
def progDetails(eid):
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/vods/'+eid+'?lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    if 'code' in resp:
        if resp['code']=='ITEM_NOT_AVAILABLE':
            xbmcgui.Dialog().notification('TVP_VOD', 'Materiał niedostępny', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(addon_handle)
    else:    
        title,img,plot=det(resp)
                
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        url = base.build_url({'mode':'playVid','eid':eid})
        base.addItemList(url, title, setArt, 'video', iL, False, 'true')
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)
    

def playVid(eid,resume,videoType='MOVIE',b=None,e=None):
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/'+eid+'/videos/playlist?platform='+platform+'&videoType='+videoType
    resp=requests.get(url,headers=hea).json()
    if 'code' in resp:
        if resp['code']=='ITEM_NOT_PAID':
            xbmcgui.Dialog().notification('TVP VOD', 'Materiał płatny', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:    
        url_stream=''
        protocol=''
        drm=False
        urlLic=''
        
        toHeaLic=hea
        toHeaLic.update({'API-CorrelationID':'smarttv_'+code_gen(32),'Content-Type':''})
        heaLic=urlencode(toHeaLic)
        '''
        CorrelationID='smarttv_'+code_gen(32)
        heaLic='User-Agent='+quote(base.UA)+'&API-CorrelationID='+CorrelationID+'&Content-Type=&Referer='+quote(baseurl)+'&API-DeviceInfo='+quote('HbbTV;2.0.1 (ETSI 1.4.1);Chrome +DRM Samsung;Chrome +DRM Samsung;HbbTV;2.0.3')
        heaLic+='&API-Authentication='+addon.getSetting('API_Authentication')
        heaLic+='&API-ProfileUid='+addon.getSetting('API_ProfileUid')
        heaLic+='&API-DeviceUid='+addon.getSetting('DeviceUid')
        '''
        
        if 'sources' in resp:
            if 'drm' in resp:
                url_stream=resp['sources']['DASH'][0]['src']
                protocol='mpd'
                drm=True
                urlLic=resp['drm']['WIDEVINE']['src']
            else:
                if 'HLS' in resp['sources']:
                    url_stream=resp['sources']['HLS'][0]['src']
                    if videoType=='LIVE' and 'mobile-' in url_stream: #na żywo -> kanały TV
                        url_stream=url_stream.replace('mobile-','hbbtv-')
                    if videoType=='LIVE' and 'hbbtv-' in url_stream and 'begin=' not in url_stream and 'end=' not in url_stream and b==None and e==None:
                        dif=time.altzone
                        now=datetime.datetime.now()
                        ts=(now+datetime.timedelta(seconds=dif)+datetime.timedelta(seconds=-2*60*60)).strftime('%Y%m%dT%H%M%S')
                        te=(now+datetime.timedelta(seconds=dif)+datetime.timedelta(seconds=4*60*60)).strftime('%Y%m%dT%H%M%S')
                        url_stream+='?begin='+ts+'&end='+te
                    if videoType=='LIVE' and 'hbbtv-' in url_stream and addon.getSetting('proxyTV')=='true': #proxy - usunięcie #EXT-X-DISCONTINUITY
                        proxyport = addon.getSetting('proxyport') 
                        url_stream='http://127.0.0.1:%s/MANIFEST='%(str(proxyport))+url_stream 
                    protocol='hls'
                elif 'DASH' in resp['sources']:
                    url_stream=resp['sources']['DASH'][0]['src']
                    protocol='mpd'
        
        sbt_src=subt_gen_ABO(resp)
        
        if url_stream !='':
            if not (b==None and e==None):
                url_stream+='?begin='+b+'&end='+e
            
            import inputstreamhelper
            PROTOCOL = protocol
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                #play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+base.UA+'&Referer='+baseurl)
                play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+base.UA+'&Referer='+baseurl)#K21
                if resume!=False: #start od wskazanego momentu (resume)
                    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                    play_item.setProperty('ResumeTime', resume)
                    play_item.setProperty('TotalTime', '1')
                elif videoType=='LIVE' and b==None and e==None and addon.getSetting('proxyTV')=='false':
                    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                    play_item.setProperty('ResumeTime', '43200')
                    play_item.setProperty('TotalTime', '1')
                play_item.setSubtitles(sbt_src)
                if drm==True:
                    play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                    play_item.setProperty("inputstream.adaptive.license_key", urlLic+'|'+heaLic+'|R{SSM}|')
                  
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
                '''
                #włączenie napisów gdy są w materiale
                if len(sbt_src)>0:
                    while not xbmc.Player().isPlaying():
                        xbmc.sleep(100)
                    xbmc.Player().showSubtitles(True)
                '''
        else:
            xbmcgui.Dialog().notification('TVP VOD', 'Błąd odtwarzania', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def subt_gen_ABO(d):#tablica z linkami do plików z napisami (format .ssa)
    subt=[]
    if 'subtitles' in d:
        if len(d['subtitles'])!=0:
            for n,i in enumerate(d['subtitles']):
                urlSubt=i['url']
                resp=requests.get(urlSubt)
                ttml = Ttml2SsaAddon()
                ttml.parse_ttml_from_string(resp.text)
                ttml.write2file(PATH+'/temp/subt_'+str(n)+'.ssa')
                subt.append(PATH+'/temp/subt_'+str(n)+'.ssa')
    return subt
    
def search():
    qry=xbmcgui.Dialog().input(u'Szukaj (przynajmniej 3 znaki):', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        hea=heaGen()
        u_film='https://vod.tvp.pl/api/products/vods/search/VOD?lang=pl&platform='+platform+'&keyword='+qry
        u_serial='https://vod.tvp.pl/api/products/vods/search/SERIAL?lang=pl&platform='+platform+'&keyword='+qry
        u_odc='https://vod.tvp.pl/api/products/vods/search/EPISODE?lang=pl&platform='+platform+'&keyword='+qry
        resp=requests.get(u_film,headers=hea).json()['items']
        filmCount=str(len(resp))
        addon.setSetting('searchFilm',str(resp))
        resp=requests.get(u_serial,headers=hea).json()['items']
        serialCount=str(len(resp))
        addon.setSetting('searchSerial',str(resp))
        resp=requests.get(u_odc,headers=hea).json()['items']
        odcCount=str(len(resp))
        addon.setSetting('searchOdc',str(resp))
        s=[
            ['Filmy'+' ('+filmCount+')','searchFilm'],
            ['Seriale'+' ('+serialCount+')','searchSerial'],
            ['Odcinki'+' ('+odcCount+')','searchOdc']
        ]
        
        for ss in s:
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''}
            url = base.build_url({'mode':'searchRes','cat':ss[1]})
            base.addItemList(url, ss[0], setArt, 'video')

        xbmcplugin.endOfDirectory(addon_handle)
    else:
        main_menu()

def detCont(x):
    plot=''
    if 'year' in x:
        plot+='[B]Rok prod.: [/B]'+str(x['year'])+'\n'
    if 'rating' in x:
        plot+='[B]Kat. wiekowa: [/B]'+str(x['rating'])+'\n'
    if 'displaySchedules' in x:
        if x['displaySchedules'][0]['type']!='SOON':
            if 'payable' in x:
                if x['payable']:
                    plot+='Płatny\n'
                else:
                    plot+='Bezpłatny\n'
            if 'since' in x:
                plot+='[B]Data publikacji: [/B]'+x['since'].split('T')[0]+'\n'
            if x['displaySchedules'][0]['type']=='PREMIERE':
                if 'till' in x['displaySchedules'][0]:
                    plot+='[B]Dostępny do: [/B]'+x['displaySchedules'][0]['till'].split('T')[0]+'\n'
                plot+='[COLOR=yellow]PRAPREMIERA[/COLOR]\n'
            else:
                if 'till' in x:
                    plot+='[B]Dostępny do: [/B]'+x['till'].split('T')[0]+'\n'
                if x['displaySchedules'][0]['type']=='LAST_BELL':
                    plot+='[COLOR=yellow]OSTATNIA SZANSA[/COLOR]\n'
        else:
            plot+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
            plot+='[B]Dostępny od: [/B]'+x['displaySchedules'][0]['till'].split('T')[0]+'\n'
            if 'payableSince' in x:
                if x['displaySchedules'][0]['till'].split('T')[0]==x['payableSince'].split('T')[0] :
                    plot+='Płatny\n'
                else:
                    plot+='Bezpłatny\n'
            else:
                plot+='Bezpłatny\n'
    if 'lead' in x:
        if x['lead']!='':
            plot+='[B]Opis: [/B][I]'+cleanText(x['lead'])+'[/I]'
    return plot

def searchRes(c):
    res=eval(addon.getSetting(c))
    for r in res:
        mod=''
        cid=''
        eid=''
        name=''
        title=''
        img=''
        plot=''
        isPlayable='false'
        isFolder=True
        if 'Serial' in c or 'Film' in c:
            cid=str(r['id'])
            eid=cid
            name=r['title']
            title=name
            type=r['type']
            img=getImg(r['images'])
            plot=detCont(r)
            
            if type=='SERIAL':
                mod='sezonList'
                URL=base.build_url({'mode':mod,'cid':cid,'title':name})
            if type=='VOD':
                title=titleWithTill(plot,title)
                if addon.getSetting('playFromList')=='true':
                    mod='playVid'
                    URL=base.build_url({'mode':mod,'eid':eid})
                    isPlayable='true'
                    isFolder=False
                else:
                    mod='progDetails'
                    URL=base.build_url({'mode':mod,'eid':eid})
        elif 'Odc' in c:
            eid=str(r['id'])
            title=r['fullTitle']
            img=getImg(r['images'])
            plot=detCont(r)
            title=titleWithTill(plot,title)
            
            if addon.getSetting('playFromList')=='true':
                mod='playVid'
                URL=base.build_url({'mode':mod,'eid':eid})
                isPlayable='true'
                isFolder=False
            else:
                mod='progDetails'
                URL=base.build_url({'mode':mod,'eid':eid})
        
        if r['displaySchedules'][0]['type']=='SOON':
            isPlayable='false'
            isFolder=False
                
        contMenu=False
        cmItems=[]
        if 'Serial' in c or 'Film' in c:
            contMenu=True
            cmItems=[
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favAdd&cid='+cid+'&name='+quote(name)+'&mod='+mod+')'),
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=showDet&eid='+eid+')')
            ]
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        base.addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)    

def lives():
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/lives?maxResults=0&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    
    IDs=[str(i['id']) for i in resp['items']]
    now=datetime.datetime.now()
    since=now.astimezone().strftime('%Y-%m-%dT%H:00%z')
    till=now.astimezone().strftime('%Y-%m-%dT%H:59%z')
    urlEPG='https://vod.tvp.pl/api/products/lives/programmes?liveId[]=%s&since=%s&till=%s&lang=pl&platform=%s' %('&liveId[]='.join(IDs),quote(since),quote(till),platform)
    respEPG=requests.get(urlEPG,headers=hea).json()
    
    for r in resp['items']:
        img=r['images']['16x9'][0]['templateUrl'].format(width=512,height=0).replace(' ','')#['url']
        if img.startswith('//'):
            img='https:'+img
        def gTime(x):
            return datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%S%z')[0:6]))
        try:
            EPGdata=[e for e in respEPG if e['live']['id']==r['id'] and gTime(e['since'])<now and gTime(e['till'])>now][0]
            st=gTime(EPGdata['since']).strftime('%H:%M')
            et=gTime(EPGdata['till']).strftime('%H:%M')
            desc=EPGdata['description'] if 'description' in EPGdata else ''
            plot='[B]%s-%s[/B] %s\n[I]%s[/I]'%(st,et,EPGdata['title'],desc)
        except:
            plot=''
                
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url = base.build_url({'mode':'playLive','euid':r['externalUid'],'cid':str(r['id'])})
        base.addItemList(url, r['title'], setArt, 'video', iL, False, 'true')
    xbmcplugin.endOfDirectory(addon_handle)
    
def archive():
    catchup_st=[399697,399698,399699,399700,399701,399702,399703,399704,399721,399722,399723,399724,399732,399740,399741,399742,399743,399745,399746,399747,399748,399749,399750,399751,399752,399753,399754,399755]
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/lives?maxResults=0&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    for r in resp['items']:
        if r['id'] in catchup_st:
            catch='y'
        else:
            catch='n'
            
        img=r['images']['16x9'][0]['url']
        if img.startswith('//'):
            img='https:'+img
                            
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url = base.build_url({'mode':'arch_calendar','cid':str(r['id']),'catch':catch})
        base.addItemList(url, r['title'], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

'''
def archive(): #type=RECORDING lub CATCHUP
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/lives?maxResults=0&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    for r in resp['items']:            
        img=r['images']['16x9'][0]['url']
        if img.startswith('//'):
            img='https:'+img
                            
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
        url = base.build_url({'mode':'arch_calendar','cid':str(r['id'])})
        base.addItemList(url, r['title'], setArt)
    xbmcplugin.endOfDirectory(addon_handle)
'''

def arch_calendar(cid,catch):
    today=datetime.datetime.now()
    ar_date=[]
    i=0
    replayPeriod='7'
    while i<=int(replayPeriod):#7
        day=(today-datetime.timedelta(days=i)).strftime('%Y-%m-%d')
        ar_date.append(day)
        i=i+1

    for d in ar_date:
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart': ''}
        url = base.build_url({'mode':'arch_programs','date':d,'cid':cid,'catch':catch})
        #url = base.build_url({'mode':'arch_programs','date':d,'cid':cid,'catch':catch}) #type=RECORDING lub CATCHUP
        base.addItemList(url, d, setArt, 'video')
    xbmcplugin.endOfDirectory(addon_handle)

'''
def arch_programs(d,cid): #type=RECORDING lub CATCHUP
    z=datetime.datetime.now().astimezone().strftime('%z')
    since=d+'T00:00'+z
    till=d+'T23:59'+z
    urlEPG='https://vod.tvp.pl/api/products/lives/programmes?liveId[]=%s&since=%s&till=%s&lang=pl&platform=%s' %(cid,quote(since),quote(till),platform)
    print('uuu')
    print(urlEPG)
    respEPG=requests.get(urlEPG,headers=hea).json()
    def sortFN(i):
        return i['since']
    respEPG.sort(key=sortFN,reverse=False)
    
    def gTime(x):
        return datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%S%z')[0:6]))
    now=datetime.datetime.now()
    
    for r in respEPG:
        if gTime(r['since'])<now and gTime(r['till'])>now-datetime.timedelta(days=7) and 'programRecordingId' in r: #'externalRecordingUid' in r
            pid=str(r['programRecordingId'])#str(r['externalRecordingUid'])
            title=r['title']
            st=gTime(r['since']).strftime('%H:%M')
            et=gTime(r['till']).strftime('%H:%M')
            tit='[B]%s[/B] %s'%(st,title)
            desc=r['description'] if 'description' in r else ''

            img=r['images']['16x9'][0]['url'] if 'images' in r else img_empty
            if img.startswith('//'):
                img='https:'+img
                    
            iL={'title': '','sorttitle': '','plot': desc}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
            url = base.build_url({'mode':'playArch','pid':pid})
            base.addItemList(url, tit, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos') 
    xbmcplugin.endOfDirectory(addon_handle)
'''

def arch_programs(d,cid,catch):
    z=datetime.datetime.now().astimezone().strftime('%z')
    since=d+'T00:00'+z
    till=d+'T23:59'+z
    urlEPG='https://vod.tvp.pl/api/products/lives/programmes?liveId[]=%s&since=%s&till=%s&lang=pl&platform=%s' %(cid,quote(since),quote(till),platform)
    respEPG=requests.get(urlEPG,headers=hea).json()
    def sortFN(i):
        return i['since']
    respEPG.sort(key=sortFN,reverse=False)
    
    def gTime(x):
        return datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%S%z')[0:6]))
        
    def toUTC(x,delta=0):
        ts=(datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%S%z')[0:6]))+datetime.timedelta(seconds=delta)).timestamp()
        return datetime.datetime.utcfromtimestamp(ts).strftime('%Y%m%dT%H%M%S')
    
    now=datetime.datetime.now()
    
    for r in respEPG:
        if gTime(r['since'])<now and gTime(r['till'])>now-datetime.timedelta(days=7) and 'programRecordingId' in r: #'externalRecordingUid' in r
            title=r['title']
            st=gTime(r['since']).strftime('%H:%M')
            et=gTime(r['till']).strftime('%H:%M')
            tit='[B]%s[/B] %s'%(st,title)
            desc=r['description'] if 'description' in r else ''

            img=r['images']['16x9'][0]['url'] if 'images' in r else img_empty
            if img.startswith('//'):
                img='https:'+img
            
            if catch=='y':
                begin=toUTC(r['since'])
                end=toUTC(r['till'],30*60)
                URL=base.build_url({'mode':'playArch','cid':cid,'begin':begin,'end':end})
                show=True
            else:
                if 'relatedVod' in r:
                    vid=str(r['relatedVod']['id'])
                    URL=base.build_url({'mode':'playArch','vid':vid})
                    desc+='\n[B]Źródło: [/B]VOD'
                    show=True
                elif 'externalRecordingUid' in r:
                    pid=r['externalRecordingUid']
                    URL=base.build_url({'mode':'playArch','pid':pid})
                    desc+='\n[B]Źródło: [/B]VOD ext'
                    show=True
                else:
                    show=False
            if show:                
                iL={'title': '','sorttitle': '','plot': desc}
                setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':fanart}
                base.addItemList(URL, tit, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos') 
    xbmcplugin.endOfDirectory(addon_handle)
    
def playArchExt(pid): #'externalRecordingUid' z EPG
    url_stream=''
    url='https://token-java-v2.tvp.pl/tokenizer/token/'+pid
    h={
        'User-Agent':base.UA
    }
    resp=requests.get(url,headers=h).json()
    if 'formats' in resp and resp['formats']!=None:
        urls=[f for f in resp['formats'] if f['mimeType']=='application/x-mpegurl']
        url_stream=urls[0]['url']
        protocol='hls'
        
        if url_stream !='':
            
            import inputstreamhelper
            PROTOCOL = protocol
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                #play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+base.UA)
                play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+base.UA)#K21

                #play_item.setSubtitles(sbt_src)
                '''
                if drm==True:
                    play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                    play_item.setProperty("inputstream.adaptive.license_key", urlLic+'|'+heaLic+'|R{SSM}|')
                '''  
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
                
                '''
                #włączenie napisów gdy są w materiale
                if len(sbt_src)>0:
                    while not xbmc.Player().isPlaying():
                        xbmc.sleep(100)
                    xbmc.Player().showSubtitles(True)
                '''
        else:
            xbmcgui.Dialog().notification('TVP VOD', 'Błąd odtwarzania', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        xbmcgui.Dialog().notification('TVP VOD', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def M3U_live():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('TVP_VOD', 'Ustaw nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('TVP_VOD', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    
    hea=heaGen()
    url='https://vod.tvp.pl/api/products/lives?maxResults=0&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    for r in resp['items']:
        euid=r['externalUid']
        cid=str(r['id'])
        cName = r['title']
        cLogo = r['images']['16x9'][0]['templateUrl'].format(width=512,height=0).replace(' ','')
        if cLogo.startswith('//'):
            cLogo='https:'+cLogo
            
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="TVP_VOD",%s\nplugin://plugin.video.TVP_VOD?mode=playLive&euid=%s&cid=%s\n' % (cName,cLogo,cName,euid,cid)

    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('TVP_VOD', 'Wygenerowano listę M3U.', xbmcgui.NOTIFICATION_INFO)

        
#ULUBIONE KODI
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
    
def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        isPlayable='false'
        isFolder=True
        URL=base.build_url({'mode':j[2],'cid':j[1],'eid':j[1],'title':j[0]})
        if j[2]=='playVid':
            URL=base.build_url({'mode':j[2],'eid':j[1]})
            isPlayable='true'
            isFolder=False
        
        contMenu=True
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favDel&cid='+j[1]+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=showDet&eid='+j[1]+')')
        ]
        
        iL={}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'OverlayUnwatched.png', 'fanart':''}
        base.addItemList(URL, j[0], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(c):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[1]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(c,n,m):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[1]==c:
            duplTest=True
    if not duplTest:
        js.append([n,c,m])
        xbmcgui.Dialog().notification('TVP VOD', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('TVP VOD', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)

def paraLogOut():
    addon.setSetting('konto','')
    addon.setSetting('packetsNames','')
    addon.setSetting('subscrTill','')
    addon.setSetting('API_Authentication','')
    addon.setSetting('API_ProfileUid','')
    addon.setSetting('logged','false')
    xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
    #xbmcgui.Dialog().notification('TVP_VOD', 'Wylogowanie przez zewnętrzną aplikację', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Update(plugin://plugin.video.TVP_VOD/,replace)')

#Moja lista/Kontynuacja (z apki VOD)    
def VODmyList(contType):
    hea=heaGen()
    if contType=='fav':
        url='https://vod.tvp.pl/api/subscribers/bookmarks?type=FAVOURITE&lang=pl&platform='+platform
    elif contType=='watched':
        url='https://vod.tvp.pl/api/subscribers/bookmarks?type=WATCHED&lang=pl&platform='+platform
    resp=requests.get(url,headers=hea).json()
    if 'code' in resp:
        if resp['code']=='AUTHENTICATION_REQUIRED':
            paraLogOut()
    else:
        for r in resp['items']:
            playTime=r['playTime'] if 'playTime' in r else None
            r=r['item']
            type=r['type_']#SERIAL,EPISODE,VOD
            mod=''
            cid=''
            eid=''
            name=''
            title=''
            img=''
            plot=''
            isPlayable='false'
            isFolder=True
            if type=='SERIAL' or type=='VOD':
                cid=str(r['id'])
                eid=cid
                name=r['title']
                title=name
                img=getImg(r['images'])
                plot=detCont(r)
                
                if type=='SERIAL':
                    mod='sezonList'
                    URL = base.build_url({'mode':mod,'cid':cid,'title':name})
                if type=='VOD':
                    if contType=='watched':
                        mod='playVidResume'
                        URL = base.build_url({'mode':mod,'eid':eid,'time':str(playTime)})
                        isPlayable='true'
                        isFolder=False
                    elif addon.getSetting('playFromList')=='true':
                        mod='playVid'
                        URL = base.build_url({'mode':mod,'eid':eid})
                        isPlayable='true'
                        isFolder=False
                    else:
                        mod='progDetails'
                        URL = base.build_url({'mode':mod,'eid':eid})
                
            elif type=='EPISODE':
                eid=str(r['id'])
                title=r['season']['serial']['title']+' - '+r['title']
                img=getImg(r['images'])
                plot=detCont(r)
                if contType=='watched':
                    mod='playVidResume'
                    URL = base.build_url({'mode':mod,'eid':eid,'time':str(playTime)})
                    isPlayable='true'
                    isFolder=False
                elif addon.getSetting('playFromList')=='true':
                    mod='playVid'
                    URL = base.build_url({'mode':mod,'eid':eid})
                    isPlayable='true'
                    isFolder=False
                else:
                    mod='progDetails'
                    URL = base.build_url({'mode':mod,'eid':eid})
                    
            elif type=='LIVE':
                eid=str(r['id'])
                title=r['title']+' (kanał TV)'
                img=getImg(r['images'])
                plot=title
                mod='playLive'
                URL = base.build_url({'mode':mod,'cid':eid})
                isPlayable='true'
                isFolder=False
            
            if r['displaySchedules'][0]['type']=='SOON':
                isPlayable='false'
                isFolder=False
            
            cmItems=[]
            if contType=='watched':
                cmItems.append(('[B]Usuń z listy kontynuowanych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=watchDel&eid='+eid+')'))
            cmItems.append(('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=showDet&eid='+eid+')'))
                        
            iL={'title': '','sorttitle': '','plot': plot}
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
            base.addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
        
        xbmcplugin.setContent(addon_handle, 'videos') 
        xbmcplugin.endOfDirectory(addon_handle)

def watchDel(eid):
    if addon.getSetting('logged')=='true' and addon.getSetting('synchKontOgl')=='true':
        hea=heaGen()
        url='https://vod.tvp.pl/api/subscribers/bookmarks?type=WATCHED&itemId[]='+eid+'&lang=pl&platform='+platform
        resp=requests.delete(url,headers=hea)
        if resp.status_code==204:
            xbmcgui.Dialog().notification('TVP VOD', 'Usunięto z listy Kontynuuj oglądanie', xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin('Container.Refresh()')

def age_verify():
    pin=xbmcgui.Dialog().numeric(heading='Wpisz PIN (domyślny: 1234):', type=0, defaultt='')
    if pin:
        hea=heaGen()
        url='https://vod.tvp.pl/api/subscribers/adult/pin?lang=pl&platform='+platform
        data={
            "pin": str(pin)
        }
        resp=requests.post(url,headers=hea,json=data)
    else:
        xbmcgui.Dialog().notification('TVP VOD', 'Nie wpisano PIN-u', xbmcgui.NOTIFICATION_INFO)
        
def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>','&nbsp;']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ')
    t=re.sub('<([^<]+?)>','',t)
    return t
    
def expFav(File):
    from shutil import copy2, copyfile
    fURL=PATH_profile+File+'.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+File+'.json')
    xbmcgui.Dialog().notification('TVP_VOD', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav(File):
    from shutil import copy2,copyfile
    fURL=PATH_profile+File+'.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('TVP_VOD', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
mode = params.get('mode', None)

if not mode:
    if addon.getSetting('DeviceUid')=='':
        #getSerialID()
        addon.setSetting('DeviceUid',code_gen(32))
    main_menu()
else:
    if mode=='logIn':
        logIn()
        if addon.getSetting('logged')=='true':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.TVP_VOD/,replace)')
            #main_menu()
    
    if mode=='logOut':
        logOut()
        if addon.getSetting('logged')=='false':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.TVP_VOD/,replace)')
            #main_menu()
    
    if mode=='vodProfiles':
        vodProfiles()
        
    if mode=='changeProfile':
        uid=params.get('uid')
        used=params.get('used')
        changeProfile(uid,used)
    
    if mode=='mainPage':
        mainPage()
    
    if mode=='mainPageCateg':
        mpc=params.get('categID')
        mainPageCateg(mpc)
        
    if mode=='sectionList':
        cid=params.get('cid')
        sectionList(cid)
        
    if mode=='categList':
        mc=params.get('mainCateg')
        categList(mc)
        
    if mode=='contList':
        mc=params.get('mainCateg')
        c=params.get('Categ')
        pg=params.get('page')
        contList(mc,c,pg)
    
    if mode=='sezonList':
        cid=params.get('cid')
        tit=params.get('title')
        sezonList(cid,tit)
    
    if mode=='episodeList':
        cid=params.get('cid')
        sezId=params.get('sezId')
        tit=params.get('title')
        pg=params.get('page')
        init=params.get('init')
        episodeList(cid,sezId,tit,pg,init)
    
    if mode=='showDet':
        eid=params.get('eid')
        showDet(eid)
    
    if mode=='progDetails':
        eid=params.get('eid')
        progDetails(eid)
    
    if mode=='playVid':
        eid=params.get('eid')
        playVid(eid,False)
        
    if mode=='playVidResume':#kontynuacja z apk
        eid=params.get('eid')
        time=params.get('time')
        playVid(eid,time)
        
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        cid=params.get('cid')
        favDel(cid)
        
    if mode=='favAdd':
        cid=params.get('cid')
        name=params.get('name')
        mod=params.get('mod')
        favAdd(cid,name,mod)
    
    if mode=='search':
        search()
        
    if mode=='searchRes':
        c=params.get('cat')
        searchRes(c)
        
    if mode=='favVODList':
        VODmyList('fav')
        
    if mode=='VODwatched':
        VODmyList('watched')
        
    if mode=='watchDel':
        eid=params.get('eid')
        watchDel(eid)
    
    if mode=='age_verify':
        age_verify()
    #lTV    
    if mode=='lives':
        lives()

    if mode=='playLive':
        cid=params.get('cid')
        playVid(cid,False,'LIVE')
    
    if mode=='M3U_live':
        M3U_live()
    
    #aTV
    if mode=='archive':
        archive()
        
    if mode=='arch_calendar':
        cid=params.get('cid')
        catch=params.get('catch') 
        #arch_calendar(cid)#type=RECORDING
        arch_calendar(cid,catch)
        
    if mode=='arch_programs':
        cid=params.get('cid')
        date=params.get('date')
        catch=params.get('catch')
        #arch_programs(date,cid) #type=RECORDING
        arch_programs(date,cid,catch)
        
    if mode=='playArch':
        cid=params.get('cid')
        pid=params.get('pid')
        vid=params.get('vid')
        b=params.get('begin')
        e=params.get('end')
        if cid!=None:
            playVid(cid,False,'LIVE',b,e)
        elif pid!=None:
            playArchExt(pid)
        elif vid!=None:
            playVid(vid,False)
        
        #playVid(pid,False,'RECORDING')###dla type=RECORDING - jeszcze nieobsługiwane
               
    if mode=='expFav':
        expFav('ulubione')
        
    if mode=='impFav':
        impFav('ulubione')
    
    #TVP INFO, TVP3 Regiony   
    if mode=='playProg':
        from resources.lib.tvpExt import playProg
        aid=params.get('asset_id')
        playProg(aid)
    
    if mode=='tvp3':
        from resources.lib.tvpExt import regionyList
        regionyList()
    
    if mode=='progCategs':
        from resources.lib.tvpExt import progCategs
        aid=params.get('asset_id')
        progCategs(aid)
        
    if mode=='progList':
        from resources.lib.tvpExt import progList
        aid=params.get('asset_id')
        all=params.get('all')
        progList(aid,all)
    
    if mode=='vidDir':
        from resources.lib.tvpExt import vidDir
        aid=params.get('asset_id')
        vidDir(aid)
    
    if mode=='epList':
        from resources.lib.tvpExt import epList
        aid=params.get('asset_id')
        p=params.get('page')
        epList(aid,p)
        
    if mode=='tvp_info':
        from resources.lib.tvpExt import progList
        progList('191888')
        
    if mode=='rc':
        from resources.lib.tvpExt import itemCategs
        itemCategs('35470692')
    
    #TVPGO (telewizja)
    if mode=='tvpgo':
        from resources.lib.tvp_go import menuTV
        menuTV()
    
    if mode=='liveTV':
        from resources.lib.tvp_go import channels_gen
        channels_gen()
    
    if mode=='replayTV':
        from resources.lib.tvp_go import replayChannelsGen
        replayChannelsGen()
        
    if mode=='playLiveTV':
        from resources.lib.tvp_go import PlayStream
        chCode=params.get('chCode')
        chID=params.get('chID')
        PlayStream(chCode,chID)
        
    if mode=='replayTVdate':
        from resources.lib.tvp_go import replayCalendarGen
        chCode=params.get('chCode')
        replayCalendarGen(chCode)
    
    if mode=='replayTVprogs':
        from resources.lib.tvp_go import replayProgramsGen
        chCode=params.get('chCode')
        d=params.get('date')
        replayProgramsGen(chCode,d)
    
    if mode=='playReplayTV':
        from resources.lib.tvp_go import PlayProgram
        chCode=params.get('chCode')
        progID=params.get('progID')
        #pp=addon.getSetting('playerProtocol')
        PlayProgram(chCode,progID)#pp
        
    if mode=='EPG':
        from resources.lib.tvp_go import getEPG
        stCode=params.get('stCode')
        getEPG(stCode)
        
    if mode=='BUILD_M3U':
        from resources.lib.tvp_go import generate_m3u
        generate_m3u()
    
    #
    if mode=='listTV':
        from resources.lib.tvp_go import listTV
        listTV()
        
    if mode=='calendar':
        from resources.lib.tvp_go import calendar
        code=params.get('code')
        cid=params.get('cid')
        catchup=params.get('catchup')
        calendar(code,cid,catchup)  
    
    if mode=='programs':
        from resources.lib.tvp_go import programs
        d=params.get('date')
        code=params.get('code')
        cid=params.get('cid')
        catchup=params.get('catchup')
        programs(d,code,cid,catchup)
    
    if mode=='playReplay':
        from resources.lib.tvp_go import playReplay
        b=params.get('begin')
        e=params.get('end')
        cid=params.get('cid')
        catchup=params.get('catchup')
        playReplay(cid,b,e,catchup)
    
    if mode=='noSource':
        pass
        
    #TVP SPORT    
    if mode=='tvp_sport':
        from resources.lib.tvpExt import sportTrans
        sportTrans()
    
    if mode=='playSportLive':
        from resources.lib.tvpExt import playSportLive
        aId=params.get('asset_id')
        ts=params.get('timeStart')
        te=params.get('timeEnd')
        playSportLive(aId,ts,te)
    
    #Fav Ext
    if mode=='favExtList':
        from resources.lib.favExt import favExtList
        favExtList()
        
    if mode=='favExtDel':
        from resources.lib.favExt import favExtDel
        u=params.get('url')
        favExtDel(u)
        
    if mode=='favExtAdd':
        from resources.lib.favExt import favExtAdd
        u=params.get('url')
        t=params.get('title')
        l=params.get('infoLab')
        i=params.get('img')
        favExtAdd(u,t,l,i)
        
    if mode=='expExtFav':
        expFav('ulubione_ext')
        
    if mode=='impExtFav':
        impFav('ulubione_ext')
