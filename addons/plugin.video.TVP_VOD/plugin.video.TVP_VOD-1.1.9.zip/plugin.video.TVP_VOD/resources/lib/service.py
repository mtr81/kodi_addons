# -*- coding: utf-8 -*-

from xbmc import Monitor, Player, getInfoLabel
import xbmc
import time, datetime
import random
import json
import xbmcaddon
import requests
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

addon = xbmcaddon.Addon(id='plugin.video.TVP_VOD')
baseurl='https://apps.vod.tvp.pl/'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0'
platform='SMART_TV'#ANDROID
hea={
    'User-Agent':UA,
    'Referer':baseurl,
    'X-Redge-VOD':'true',
    'API-DeviceInfo':'HbbTV;2.0.1 (ETSI 1.4.1);Chrome +DRM Samsung;Chrome +DRM Samsung;HbbTV;2.0.3'
}
def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code
    
def heaGen():
    CorrelationID='smarttv_'+code_gen(32)
    hea.update({'API-CorrelationID':CorrelationID,'API-DeviceUid':addon.getSetting('DeviceUid')})
    if addon.getSetting('logged')=='true':
        hea.update({'API-Authentication':addon.getSetting('API_Authentication'),'API-ProfileUid':addon.getSetting('API_ProfileUid')})
    return hea


class BackgroundService(Monitor):
    """ Background service code """

    def __init__(self):
        Monitor.__init__(self)
        self._player = PlayerMonitor()

    def run(self):
        """ Background loop for maintenance tasks """

        while not self.abortRequested():

            # Stop when abort requested
            if self.waitForAbort(10):
                break


class PlayerMonitor(Player):
    """ A custom Player object to check subtitles """
    
    def __init__(self):
        """ Initialises a custom Player object """
        self.__listen = False

        self.__path = None
        self.__timeplay =0
        self.__totalTime=0
        Player.__init__(self)
        
    def markWatchStatus():
        pass
        
    def onPlayBackStarted(self):  
        """ Will be called when Kodi player starts """
        self.__path = getInfoLabel('Player.FilenameAndPath')
        
        if not self.__path.startswith('plugin://plugin.video.TVP_VOD/?mode=playVid'):
            self.__listen = False
            return
        #xbmc.log('start odtwarzania', level=xbmc.LOGINFO)    
        self.__listen = True
                
        while self.__listen and self.isPlaying():
            if self.isPlaying():
                self.__timeplay=self.getTime()
                self.__totalTime=self.getTotalTime()
            time.sleep(2)
        
    def onPlayBackEnded(self):  
        """ Will be called when [Kodi] stops playing a file """
        if not self.__listen:
            return
        #xbmc.log('koniec odtwarzaniax', level=xbmc.LOGINFO)
        #xbmc.log(self.__path, level=xbmc.LOGINFO)
        if addon.getSetting('logged')=='true' and addon.getSetting('synchKontOgl')=='true':
            hea=heaGen()
            eid=dict(parse_qsl(self.__path.split('?')[-1]))['eid']
            #usunięcie z kontynuuj
            url='https://vod.tvp.pl/api/subscribers/bookmarks?type=WATCHED&itemId[]='+eid+'&lang=pl&platform='+platform
            resp=requests.delete(url,headers=hea)
            if resp.status_code==204:
                xbmc.log('@@@Usunięto z kontynuuj', level=xbmc.LOGINFO)
            #dodanie następnego odcinka sezonu (jeśli jest) do kontynnuj
            url='https://vod.tvp.pl/api/products/vods/'+eid+'?lang=pl&platform='+platform
            resp=requests.get(url,headers=hea).json()
            if resp['type_']=='EPISODE':
                sezonID=str(resp['season']['id'])
                serialID=str(resp['season']['serial']['id'])
                sortType=resp['season']['serial']['sortType']
                url_seas='https://vod.tvp.pl/api/products/vods/serials/'+serialID+'/seasons/'+sezonID+'/episodes?lang=pl&platform='+platform
                resp_seas=requests.get(url_seas,headers=hea).json()
                for i,e in enumerate(resp_seas):
                    if e['id']==int(eid):
                        try:
                            ii=i-1 if sortType=='DESC' else i+1
                            if ii>=0:
                                new_eid=resp_seas[ii]['id']
                                if resp_seas[ii]['displaySchedules'][0]['type']!='SOON':
                                    url_new='https://vod.tvp.pl/api/subscribers/bookmarks?type=WATCHED&lang=pl&platform='+platform
                                    data={
                                        "itemId": new_eid,
                                        "playTime": 1
                                    }
                                    resp_new=requests.post(url_new,headers=hea,json=data)
                                    if resp_new.status_code==204:
                                        xbmc.log('@@@Przesłano nowy odcinek na serwer', level=xbmc.LOGINFO)
                        except:
                            pass
            #status
            if 'playVidResume' in self.__path:
                pathFile='plugin://plugin.video.TVP_VOD/?mode=playVid&eid='+eid
                totalTime=int(self.__totalTime)
                now=int(time.time())
                lastplayed=datetime.datetime.fromtimestamp(now).strftime('%Y-%m-%d %H:%M:%S')
                request={
                        "jsonrpc": "2.0", 
                        "method": "Files.SetFileDetails", 
                        "params": {
                            "file": pathFile, 
                            "media": "video", 
                            "playcount": 1,
                            "lastplayed":lastplayed,
                            "resume": {
                                "position":0, 
                                "total": 0
                            }
                        },
                        "id":"1"
                }
                results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                print(results)
                
                xbmc.executebuiltin('Container.Refresh()')
                
            req={"jsonrpc": "2.0", "params": {"media": "video","file": pathFile, "properties": ["resume","playcount"]}, "method": "Files.GetFileDetails", "id": "1"}
            results = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
            print(results)
            
              
            
    def onPlayBackStopped(self):  
        """ Will be called when [user] stops Kodi playing a file """
        if not self.__listen:
            return
        #xbmc.log('@@@Odtwarzanie przerwane - STOP', level=xbmc.LOGINFO)
        #xbmc.log(self.__path, level=xbmc.LOGINFO)
        #xbmc.log(str(self.__timeplay), level=xbmc.LOGINFO)
        #xbmc.log(str(self.__totalTime), level=xbmc.LOGINFO)
        if addon.getSetting('logged')=='true' and addon.getSetting('synchKontOgl')=='true':
            hea=heaGen()
            eid=dict(parse_qsl(self.__path.split('?')[-1]))['eid']
            timePlay=int(self.__timeplay)
            totalTime=int(self.__totalTime)
            url='https://vod.tvp.pl/api/subscribers/bookmarks?type=WATCHED&lang=pl&platform='+platform
            data={
                "itemId": int(eid),
                "playTime": timePlay
            }
            resp=requests.post(url,headers=hea,json=data)
            if resp.status_code==204:
                xbmc.log('@@@Przesłano playTime na serwer', level=xbmc.LOGINFO)
            #status
            pathFile='plugin://plugin.video.TVP_VOD/?mode=playVid&eid='+eid
            if totalTime>0 and 'playVidResume' in self.__path:
                request={
                    "jsonrpc": "2.0", 
                    "method": "Files.SetFileDetails", 
                    "params": {
                        "file": pathFile, 
                        "media": "video", 
                        "resume": {
                            "position":timePlay, 
                            "total": totalTime
                        }
                    },
                    "id":"1"
                }
                results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                
                xbmc.executebuiltin('Container.Refresh()') 
            
            req={"jsonrpc": "2.0", "params": {"media": "video","file": pathFile, "properties": ["resume","playcount"]}, "method": "Files.GetFileDetails", "id": "1"}
            results = json.loads(xbmc.executeJSONRPC(json.dumps(req)))
            print(results)
                
def run():
    """ Run the BackgroundService """
    BackgroundService().run()
