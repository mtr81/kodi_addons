import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import time
import re
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0'
hea={
    'User-Agent':UA
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def tvpinfoProgList():#TVPINFO
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id=191888'
    hea.update({'Referer':'https://www.tvp.info/'})
    resp=requests.get(url,headers=hea).json()
    for i in resp['items']:
        #if i['asset_id'] in [ 24701617,33177648,14329786]:
        if True:
            title=i['title']
            asset_id=i['asset_id']
            descr=cleanText(i['lead_root'])
            img=''
            if 'logo' in i:
                if 'file_name' in i['logo'][0]:
                    imgFile=i['logo'][0]['file_name']
                    imgType=imgFile.split('.')[-1]
                    if 'width' in i['logo'][0]:
                        imgWidth=i['logo'][0]['width']
                    else:
                        imgWidth=300
                    img='http://s.v3.tvp.pl/images/%s/%s/%s/uid_%s_width_%d_gs_0.%s' %(imgFile[0],imgFile[1],imgFile[2],imgFile[:-4],imgWidth,imgType)
            li=xbmcgui.ListItem(title)
            li.setProperty("IsPlayable", 'false')
            li.setInfo(type='video', infoLabels={'title': title,'sorttitle': title,'plot': descr})
            li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''})
            url_cont = build_url({'mode':'INFO_epsd','asset_id':asset_id,'img':img})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle,xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.endOfDirectory(addon_handle)
    
def tvpinfoEpsdList(aId,IMG):#TVPINFO
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=20&parent_id='+str(aId)
    hea.update({'Referer':'https://www.tvp.info/'})
    resp=requests.get(url,headers=hea).json()
    asset_id=resp['items'][0]['asset_id']
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id='+str(asset_id)+'&filter={%22playable%22:True}'
    resp=requests.get(url).json()
    for p in resp['items']:
        if 'playable' in p and 'publication_end_long' in p:
            if p['playable']==True and int(time.time())*1000<=p['publication_end_long']:
                asset_id=p['asset_id']
                title=p['website_title'] + ' | ' + p['title'] #24.03.2022, 17:15
                if 'duration_min' in p:
                    duration=p['duration_min']
                else:
                    duration=0
                img=IMG
                if 'image' in p:
                    if 'file_name' in p['image'][0]:
                        imgFile=p['image'][0]['file_name']
                        imgType=imgFile.split('.')[-1]
                        if 'width' in p['image'][0]:
                            imgWidth=p['image'][0]['width']
                        else:
                            imgWidth=300
                        img='http://s.v3.tvp.pl/images/%s/%s/%s/uid_%s_width_%d_gs_0.%s' %(imgFile[0],imgFile[1],imgFile[2],imgFile[:-4],imgWidth,imgType)
                li=xbmcgui.ListItem(title)
                li.setProperty("IsPlayable", 'true')
                li.setInfo(type='video', infoLabels={'title': title,'sorttitle': '','plot': 'czas emisji: '+str(duration)+'min.'})
                li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''})
                url_cont = build_url({'mode':'INFO_play','asset_id':asset_id})
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=False)
    #xbmcplugin.addSortMethod(addon_handle,xbmcplugin.SORT_METHOD_TITLE)
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def PlayTVPInfo(aId):#TVPINFO
    url='https://www.tvp.pl/shared/cdn/tokenizer_v2.php?object_id='+str(aId)+'&sdt_version=1'
    resp=requests.get(url,headers=hea).json()
    stream_url=''
    if 'formats' in resp:
        formats = [f for f in resp['formats'] if f['mimeType']=='application/x-mpegurl']
        def sortFN(i):
            return i['totalBitrate']
        formats.sort(key=sortFN,reverse=True)
        stream_url=formats[0]['url']
        '''
        if 'audioLang' not in formats[0]:
            stream_url=formats[0]['url']
        else:
            src=[]
            urls=[]
            for f in formats:
                if 'audioLang' in f:
                    src.append(f['audioLang'])
                else:
                    src.append('Nieokreślony')
                urls.append(f['url'])
            select = xbmcgui.Dialog().select('Źródła', src)
            if select > -1:
                url_stream=src[select]
            else:
                quit()
        '''

    #subt=subt_gen_free(aId)

    if '.mp4' not in stream_url: #2022-09-08
        import inputstreamhelper
        PROTOCOL = 'hls'
        is_helper = inputstreamhelper.Helper(PROTOCOL)
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=stream_url)
            #play_item.setSubtitles(subt)
            play_item.setProperty("inputstream", is_helper.inputstream_addon)
            play_item.setProperty("inputstream.adaptive.manifest_type", PROTOCOL)
            play_item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        play_item=xbmcgui.ListItem(path=stream_url)
        play_item.setProperty("IsPlayable", "true")
        play_item.setSubtitles(subt)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
def sportTrans():#TVP SPORT
    count=300
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=false&count='+str(count)+'&parent_id=13010508&type=epg_item&filter={"is_live":True}&order={"release_date_long":-1}'
    hea.update({'Referer':'https://sport.tvp.pl/'})
    resp=requests.get(url).json()
    transData=[]
    for i in resp['items']:
        now=1000*int(time.time())
        if i['broadcast_end_date_long']>now:
            #asset_id=i['asset_id']
            title=i['release_date_dt']+ ' ' +i['release_date_hour'] + ' | ' + i['title']
            descr=cleanText(i['lead'])
            channel_id=i['video_id'] #sprawdzić z którego ID odtwarza
            img=''
            if 'image' in i:
                if 'file_name' in i['image'][0]:
                    imgFile=i['image'][0]['file_name']
                    imgType=imgFile.split('.')[-1]
                    imgWidth=i['image'][0]['width']
                    img='http://s.v3.tvp.pl/images/%s/%s/%s/uid_%s_width_%d_gs_0.%s' %(imgFile[0],imgFile[1],imgFile[2],imgFile[:-4],imgWidth,imgType)
            plot=descr
            timeStart=i['release_date_long']
            timeEnd=i['broadcast_end_date_long']
            transData.append([title,plot,img,channel_id,timeStart,timeEnd])
    transDataRev=transData[::-1]
    for t in transDataRev:    
        li=xbmcgui.ListItem(t[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': t[0],'sorttitle': t[0],'plot': t[1]})
        li.setArt({'thumb': t[2], 'poster': t[2], 'banner': t[2], 'icon': t[2], 'fanart': ''})
        url_cont = build_url({'mode':'playSportLive','asset_id':t[3],'timeStart':t[4],'timeEnd':t[5]})#
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def playSportLive(aId,ts,te):#TVP SPORT
    now=1000*int(time.time())
    if now>int(ts) and now<int(te):
        PlayTVPInfo(aId)
    else:
        xbmcgui.Dialog().notification('TVP SPORT', 'Transmisja nie jest jeszcze prowadzona', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>','&nbsp;','</span>']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ')
    t=re.sub('<([^<]+?)>','',t)
    return t