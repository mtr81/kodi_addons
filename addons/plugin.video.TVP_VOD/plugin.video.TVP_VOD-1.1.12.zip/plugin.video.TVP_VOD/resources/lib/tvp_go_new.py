import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import time
import datetime
import re
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
from .base import b

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
base=b(base_url,addon_handle)

addon = xbmcaddon.Addon(id='plugin.video.TVP_VOD')
PATH=addon.getAddonInfo('path')
img_path=PATH+'/resources/images/'
img_inne='https://hbb-prod.tvp.pl/apps/manager/_nuxt/img/b1966b153d6da55d855eb3ce3966dce3.png'

baseurl='http://hbbtest.v3.tvp.pl/hub_oryg/index_tvp_stream.php' #'https://hbb-prod.tvp.pl/apps/manager/hub/?name_channel=MUX3_TVP1_HD'
api_hbbtv='https://hbb-prod.tvp.pl/apps/manager/api/hub/graphql'

heaTV={
    'User-Agent':base.UA,
    'Referer':baseurl
}
hea_oth={
    'User-Agent':base.UA
}

menu_TV=[
    ['Kanały na żywo','liveTV'],
    ['Replay TV','replayTV'],
    ['Replay TV (new)','listTV'],
]

stationCode={
    'TVP1':'T1D', 
    'TVP2':'T2D', 
    'TVP Info':'INF', 
    'TVP NAUKA':'NK', 
    'TVP Sport':'KSP',
    'TVP Kultura':'T5D',
    'TVP Historia':'TKH',
    'TVP ABC':'ABC',
    'TVP Dokument':'DOK',
    'TVP Kobieta':'KBT',
    'TVP Polonia':'T4D',
    'TVP Rozrywka':'TRO',
    'TVP World':'PIE',
    'TVP Kultura 2':'KUL2',
    'TVP ABC 2':'DMPR',
    'TVP Historia 2':'H2',
    'TVP Wilno':'WILNO',
    'TVP3 Białystok':'XCC',
    'TVP3 Bydgoszcz':'XBB',
    'TVP3 Gdańsk':'XGG',
    'TVP3 Gorzów Wielkopolski':'XFF',
    'TVP3 Katowice':'XTT',
    'TVP3 Kielce':'XEE',
    'TVP3 Kraków':'XKK',
    'TVP3 Lublin':'XLL',
    'TVP3 Łódź':'XDD',
    'TVP3 Olsztyn':'XHH',
    'TVP3 Olsztyn/Elbląg':'XHHE', #XHH
    'TVP3 Opole':'XJJ',
    'TVP3 Poznań':'XPP',
    'TVP3 Rzeszów':'XRR',
    'TVP3 Szczecin':'XSS',
    'TVP3 Warszawa':'XAA',
    'TVP3 Wrocław':'XWW',
    'TVP HD':'KHSH',
    'TVP 4K':'KS4K',
    'Belsat':'TVBI',
    'TVP Parlament SEJM':'TVPPARLAMENT',
    'ALFA TVP':'ALFA',
    '_RESET': 'RESET',
    'Polskie biesiady bis':'BIESIADA',
    'TVP Opole bis':'OPOLEBIS',
}

def playerISA(url,protocol,live=True,fromStart=True):
    if protocol=='hls' and 'hbbtv-' in url and addon.getSetting('proxyTV')=='true':
        proxyport = addon.getSetting('proxyport')
        url='http://127.0.0.1:%s/MANIFEST='%(str(proxyport))+url 
    p={'hls':'application/x-mpegurl','mpd':'application/xml+dash'}
    import inputstreamhelper
    PROTOCOL = protocol#hls,mpd
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=url)
        play_item.setMimeType(p[protocol])
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty("IsPlayable", "true")
        if live and addon.getSetting('proxyTV')=='false':
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
            play_item.setProperty('ResumeTime', '43200')
            play_item.setProperty('TotalTime', '1')
        if not live and fromStart==True:
            play_item.setProperty('ResumeTime', '1')
            play_item.setProperty('TotalTime', '1')
        play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+base.UA)
        play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+base.UA)#K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)

    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
   
def menuTV():
    for m in menu_TV:    
        img=img_path+'tvp_go.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        url = base.build_url({'mode':m[1]})
        base.addItemList(url, m[0], setArt)    
    xbmcplugin.endOfDirectory(addon_handle)

def channelArrayGen():#JSON-live channel list
    strin='{"operationName":"landingPageVideos","variables":{},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"eebfa704bab5887d12e2c7835f8a2488939a7a776aac421c08e338b3386a81b4"}},"query":"query landingPageVideos {\\n  landingPageVideos {\\n    ... on DriverDataLandingPageVideos {\\n      types {\\n        default\\n        __typename\\n      }\\n      title\\n      elements {\\n        id\\n        type\\n        titles {\\n          main\\n          sub\\n          __typename\\n        }\\n        img {\\n          videoHolders {\\n            _16x9\\n            __typename\\n          }\\n          website {\\n            holder_16x9\\n            __typename\\n          }\\n          hbbtv\\n          image\\n          __typename\\n        }\\n        labels {\\n          ... on Expiring {\\n            type\\n            text\\n            __typename\\n          }\\n          ... on PEGI {\\n            type\\n            text\\n            __typename\\n          }\\n          ... on PayableOrCatchup {\\n            type\\n            text\\n            __typename\\n          }\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    ... on ListingDataLandingPageVideos {\\n      types {\\n        default\\n        __typename\\n      }\\n      title\\n      elements {\\n        id\\n        type\\n        img {\\n          videoHolders {\\n            _16x9\\n            __typename\\n          }\\n          website {\\n            holder_16x9\\n            __typename\\n          }\\n          hbbtv\\n          image\\n          __typename\\n        }\\n        labels {\\n          ... on Expiring {\\n            type\\n            text\\n            __typename\\n          }\\n          ... on PEGI {\\n            type\\n            text\\n            __typename\\n          }\\n          ... on PayableOrCatchup {\\n            type\\n            text\\n            __typename\\n          }\\n          __typename\\n        }\\n        countVideos {\\n          default\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    ... on CategoriesDataLandingPageVideos {\\n      type\\n      title\\n      elements {\\n        title\\n        id\\n        types {\\n          default\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  stationsForMainpage {\\n    id\\n    name\\n    code\\n    image_square {\\n      url\\n      __typename\\n    }\\n    background_color\\n    is_native_chanel\\n    __typename\\n  }\\n}\\n"}'
    data=json.loads(strin)
    resp=requests.post(api_hbbtv,json=data,headers=heaTV,verify=False).json()
    if 'errors' not in resp:
        ch_data=resp['data']['stationsForMainpage']
        ar_chan=[]
        for c in ch_data:
            ch_code=c['code']
            ch_name=c['name'].replace('EPG - ','').replace('Domowe Przedszkole','ABC 2')
            ch_img=unquote(c['image_square']['url']).replace('{width}','510').replace('{height}','0')
            if ch_code=='':
                ch_id=c['id']
            else:
                ch_id=''
            ar_chan.append([ch_code,ch_name,ch_img,ch_id])
    else:
        ar_chan=[]
        channels=list(stations.keys())
        for c in channels:
            if stations[c]['tvpgo_hbb']=='y':
                code=stations[c]['code'] if stations[c]['catchup']=='y' else ''
                img=stations[c]['img'].format(height='0',width='510')
                cid=stations[c]['cid'] if stations[c]['catchup']!='y' else ''
                ar_chan.append([code,c,img,cid])
    
    ar_new=[ #braki w TVP GO ver. HbbTV
        ['','TVP3 Olsztyn/Elbląg','http://s9.tvp.pl/images2/9/9/2/uid_9923ae9c5aa8a9089a9f8034651c5d9c1566388829799_width_510_play_0_pos_0_gs_0_height_0.png','aid_62977634'],
        ['','TVP Wilno','http://s3.tvp.pl/images2/3/7/2/uid_37273101aabbe28f9f6e62d62ca3dc201568710101823_width_510_play_0_pos_0_gs_0_height_0.png','aid_redir_44418549'],
        ['','Belsat',img_path+'belsat.png','aid_17251711'],
        ['','UA1','http://s2.tvp.pl/images2/2/2/e/uid_22e0d031662761cdeb669c49b31738b81645961764558_width_510_play_0_pos_0_gs_0_height_0.png','aid_58758689'],
        ['','Jasna Góra','https://s10.tvp.pl/images2/0/0/5/uid_00525b67452c04a9eb6aa0e32d4888fc1619004489426_width_510_play_0_pos_0_gs_0_height_0.jpg','aid_53415775'],
        ['','TVP Parlament SEJM','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047033'],
        ['','TVP Parlament SENAT','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047094'],
        ['','TVP Parlament KOMISJA 1','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047097'],
        ['','TVP Parlament KOMISJA 2','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047099'],
        ['','_RESET','https://s2.tvp.pl/images2/b/a/5/uid_ba59f28648294c26a618c088dff219ad_width_510_play_0_pos_0_gs_0_height_0.png','aid_70707771'],
        ['','Polskie biesiady bis','https://s4.tvp.pl/images2/4/7/1/uid_471bc3a417e84d60bfb751b309f0c330_width_510_play_0_pos_0_gs_0_height_0.png','aid_69501181'],
        ['','TVP Opole bis','https://s7.tvp.pl/images2/7/2/8/uid_7280c4ecc741432f8bc9e257bc1f601b_width_510_play_0_pos_0_gs_0_height_0.png','aid_70892600'],
    ]
    ar_chan+=ar_new
    
    return ar_chan

def channels_gen():#menu-live channel list
    channels=channelArrayGen()
    for ch in channels:        
        iL={'title': ch[1],'sorttitle': ch[1],'plot': 'EPG dostępne z poziomu menu kontekstowego'}
        setArt={'thumb': ch[2], 'poster': ch[2], 'banner': ch[2], 'icon': ch[2], 'fanart': ch[2]}
        url = base.build_url({'mode':'playLiveTV','chCode':ch[0],'chID':ch[3]})
        if ch[1] in stationCode:
            CM=True
            cmItems=[('[B]EPG[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=EPG&stCode='+stationCode[ch[1]]+')')]
        else:
            CM=True
            cmItems=[]
        base.addItemList(url, ch[1], setArt, 'video', iL, False, 'true', CM, cmItems)
    xbmcplugin.endOfDirectory(addon_handle)

def PlayStream(chCode,chId):#play live channel
    if chCode!=None:
        #strin='{"operationName":"currentProgramAsLive","variables":{"code_station":"'+chCode+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"5e24e0598acbb62526889de3d1c7984c8585eb5ba05bd84747ad597b9b8ffa6e"}},"query":"query currentProgramAsLive($code_station: String!) {\\n  currentProgramAsLive(code_station: $code_station) {\\n    occurrence {\\n      id\\n      title\\n      date_start\\n      date_end\\n      description\\n      description_long\\n      plrating\\n      description_akpa\\n      description_akpa_medium\\n      description_akpa_long\\n      station {\\n        npvr\\n        __typename\\n      }\\n      program {\\n        title\\n        __typename\\n      }\\n      __typename\\n    }\\n    date_current\\n    video {\\n      title\\n      formats {\\n        mime_type\\n        url\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n"}'
        strin='{"operationName":"currentProgramAsLive","variables":{"code_station":"'+chCode+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"75d7ec6ca0eafc3a3371c09bc178d93e3c2e5fdf7f2c712df236dea03f4cc4b0"}},"query":"query currentProgramAsLive($code_station: String!) {\\n  currentProgramAsLive(code_station: $code_station) {\\n    occurrence {\\n      id\\n      title\\n      date_start\\n      date_end\\n      description\\n      description_long\\n      plrating\\n      description_akpa\\n      description_akpa_medium\\n      description_akpa_long\\n      station {\\n        npvr\\n        __typename\\n      }\\n      program {\\n        title\\n        __typename\\n      }\\n      __typename\\n    }\\n    date_current\\n    video {\\n      ... on VideoFromTokenizerWithoutDebugInfo {\\n        title\\n        formats {\\n          mime_type\\n          url\\n          __typename\\n        }\\n        __typename\\n      }\\n      ... on VideoFromTokenizerWithDebugInfo {\\n        title\\n        formats {\\n          mime_type\\n          url\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n"}'
        data=json.loads(strin)
        resp=requests.post(api_hbbtv,json=data,headers=heaTV,verify=False).json()
        if 'errors' in resp:
            xbmcgui.Dialog().notification('TVPGO', 'Przerwa w emisji', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        elif resp['data']['currentProgramAsLive'] is not None:
            streams=resp['data']['currentProgramAsLive']['video']['formats']
            for s in streams:
                if (s['mime_type']=='application/x-mpegurl' and not ('mobile' in s['url'])):#application/dash+xml
                    if resp['data']['currentProgramAsLive']['occurrence']['title']=='Przerwa w nadawaniu':
                        url_stream=s['url'].split('?begin=')[0]
                    elif 'begin=' in s['url'] and 'end=' not in s['url']:
                        te=(datetime.datetime.utcnow()+datetime.timedelta(hours=6)).strftime('%Y%m%dT%H%M00')
                        #url_stream=s['url'].replace(s['url'].split('?')[-1],'end='+te)
                        url_stream=s['url']+'&end='+te
                        #url_stream=s['url']
                    else:
                        url_stream=s['url']

            playerISA(url_stream,'hls')
        else:
            xbmcgui.Dialog().notification('TVPGO', 'Przerwa w emisji', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    elif chCode==None:
        url_stream=''
        if 'aid' not in chId:
            strin2='{"operationName":null,"variables":{"liveId":"'+chId+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"1219b0db11741fac1c8d7953711bdd3bc27fdd3dee628b9715688fdd76a22bf9"}},"query":"query ($liveId: ID!) {\\n  getLive(liveId: $liveId) {\\n    type\\n    title\\n    subtitle\\n    lead\\n    label {\\n      type\\n      text\\n      __typename\\n    }\\n    src\\n    vast_url\\n    duration_min\\n    subtitles {\\n      src\\n      auto_desc\\n      lang\\n      text\\n      __typename\\n    }\\n    is_live\\n    formats {\\n      mime_type\\n      totalBitrate\\n      videoBitrate\\n      audioBitrate\\n      adaptive\\n      url\\n      downloadable\\n      __typename\\n    }\\n    web_url\\n    __typename\\n  }\\n}\\n"}'
            data2=json.loads(strin2)
            resp2=requests.post(api_hbbtv,json=data2,headers=heaTV,verify=False).json()
            if 'errors' not in resp2:
                streams2=resp2['data']['getLive'][0]['formats']
                for s in streams2:
                    if (s['mime_type']=='application/x-mpegurl' and not ('mobile' in s['url'])):
                        url_stream=s['url']
                        break
                playerISA(url_stream,'hls')
            else:
                xbmcgui.Dialog().notification('TVP_VOD', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        elif 'aid' in chId:
            cid=''
            if 'redir' in chId:
                url='https://api.tvp.pl/sess/TVPlayer2/api.php?id='+chId.replace('aid_redir_','')+'&@method=getTvpConfig&@callback=?'
                resp=requests.get(url,headers=hea_oth).text
                try:
                    cid=re.compile('live_video_id\": ([^,]+?),').findall(resp)[0]
                except:
                    pass
            else:
                cid=chId.split('aid_')[-1]
            if cid !='':
                url='https://token-java-v2.tvp.pl/tokenizer/token/'+cid
                resp=requests.get(url,headers=hea_oth).json()
                if "NOT_PLAYABLE" not in resp['status']:
                    for s in resp['formats']:
                        if s['mimeType']=='application/x-mpegurl':
                            url_stream=s['url']
                            break
                    playerISA(url_stream,'hls')
                else:
                    xbmcgui.Dialog().notification('TVP_VOD', 'Przerwa w emisji', xbmcgui.NOTIFICATION_INFO)
                    xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            else:
                xbmcgui.Dialog().notification('TVP_VOD', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            
def replayChannelsArrayGen(): #JSON: replay channels
    strin='{"operationName":"stations","variables":{},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"a09354753d213847242664f7350e69e2a5c970bbe003536ed51214d2da043a95"}},"query":"query stations {\\n  stations {\\n    name\\n    code\\n    image_square {\\n      url\\n      __typename\\n    }\\n    background_color\\n    __typename\\n  }\\n}\\n"}'
    data=json.loads(strin)
    resp=requests.post(api_hbbtv,json=data,headers=heaTV,verify=False).json()
    ch_data=resp['data']['stations']
    ar_chan=[]
    for ch in ch_data:
        chName=ch['name']
        chCode=ch['code']
        ar_chan.append([chName,chCode])
    ar_new=[
        ['TVP3 Białystok','XCC'],
        ['TVP3 Bydgoszcz','XBB'],
        ['TVP3 Gdańsk','XGG'],
        ['TVP3 Gorzów Wielkopolski','XFF'],
        ['TVP3 Katowice','XTT'],
        ['TVP3 Kielce','XEE'],
        ['TVP3 Kraków','XKK'],
        ['TVP3 Lublin','XLL'],
        ['TVP3 Łódź','XDD'],
        ['TVP3 Olsztyn','XHH'],
        ['TVP3 Olsztyn/Elbląg','XHHE'],
        ['TVP3 Opole','XJJ'],
        ['TVP3 Poznań','XPP'],
        ['TVP3 Rzeszów','XRR'],
        ['TVP3 Szczecin','XSS'],
        ['TVP3 Warszawa','XAA'],
        ['TVP3 Wrocław','XWW'],
    ]
    ar_chan+=ar_new
    return ar_chan

def replayChannelsGen():#menu-replay channel list
    channels=replayChannelsArrayGen()
    for ch in channels:        
        img='DefaultTVShows.png'
        iL={'title': ch[0],'sorttitle': ch[0],'plot': ''}
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
        url = base.build_url({'mode':'replayTVdate','chCode':ch[1]})
        base.addItemList(url, ch[0], setArt, infoLab=iL)    
    xbmcplugin.endOfDirectory(addon_handle)

def replayCalendarGen(chCode):#kalendarz
    now=datetime.datetime.now()
    ar_date=[]
    for i in range(0,8):
        date=(now-datetime.timedelta(days=i)).strftime('%Y-%m-%d')
        ar_date.append(date)
    
    for d in ar_date:   
        iL={'title': d,'sorttitle': d,'plot': ''}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart': ''}
        url = base.build_url({'mode':'replayTVprogs','date':d,'chCode':chCode})
        base.addItemList(url, d, setArt, infoLab=iL) 
    xbmcplugin.endOfDirectory(addon_handle)

def replayProgramsArrayGen(chCode,date):#JSON-programy wg daty
    chCode_=chCode
    if chCode_=='XHHE':
        chCode_='XHH'
    strin='{"operationName":"occurrencesProgramTV","variables":{"code_station":"'+chCode_+'","category":"","date":"'+date+'","include_images":true},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"c0c2c86badbb7f803435a5e2d5ec988391396251632ec5bb85db75b1f7e50acc"}},"query":"query occurrencesProgramTV($code_station: String, $date: Date, $category: String, $include_images: Boolean) {\\n  occurrencesProgramTV(\\n    code_station: $code_station\\n    date: $date\\n    category: $category\\n    include_images: $include_images\\n  ) {\\n    total_count\\n    items {\\n      id\\n      record_id\\n      title\\n      date_start\\n      date_end\\n      duration\\n      code_station\\n      description\\n      description_long\\n      program {\\n        id\\n        type\\n        title\\n        year\\n        lang\\n        image {\\n          type\\n          title\\n          point_of_origin\\n          url\\n          width\\n          height\\n          description\\n          __typename\\n        }\\n        program_type {\\n          id\\n          type\\n          title\\n          __typename\\n        }\\n        cycle {\\n          id\\n          type\\n          title\\n          image_logo {\\n            type\\n            title\\n            point_of_origin\\n            url\\n            width\\n            height\\n            description\\n            __typename\\n          }\\n          __typename\\n        }\\n        rating\\n        website_id\\n        has_video_vod\\n        cms_id\\n        __typename\\n      }\\n      station {\\n        id\\n        name\\n        code\\n        image {\\n          type\\n          title\\n          point_of_origin\\n          url\\n          width\\n          height\\n          description\\n          __typename\\n        }\\n        image_square {\\n          type\\n          title\\n          point_of_origin\\n          url\\n          width\\n          height\\n          description\\n          __typename\\n        }\\n        background_color\\n        is_native_chanel\\n        __typename\\n      }\\n      url\\n      url_canonical\\n      categories {\\n        id\\n        category_type\\n        title\\n        __typename\\n      }\\n      akpa_attributes\\n      plrating\\n      description_akpa\\n      description_akpa_medium\\n      description_akpa_long\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n"}'
    data=json.loads(strin)
    resp=requests.post(api_hbbtv,json=data,headers=heaTV,verify=False).json()
    ar_prog=[]
    if 'errors' not in resp:
        pr_data=resp['data']['occurrencesProgramTV']['items']
        time_now=int(time.time())*1000
        def hm(t):
            #ts=time.localtime(t/1000)
            #return addZero(ts.tm_hour)+':'+addZero(ts.tm_min)
            return datetime.datetime.fromtimestamp(t/1000).strftime('%H:%M')
        def dt(t):
            return datetime.datetime.fromtimestamp(t/1000).strftime('%Y-%m-%d')
        for p in pr_data:
            if p['date_start']<time_now and p['date_end']>time_now-8*24*60*60*1000:#7
                pID=p['record_id']
                #chCode=p['station_code']
                #pTitle='['+hm(p['date_start'])+'-'+hm(p['date_end'])+'] '+p['title']
                pTitle='[B]'+hm(p['date_start'])+'[/B]  '+p['title']
                pDescr=p['description']
                try:
                    img=p['program']['image']['url'].replace('{width}','608').replace('{height}','342')
                except:
                    img=img_inne
                if p['program']!=None:
                    progType=p['program']['program_type']['title'] if p['program']['program_type']!=None else None
                    year=p['program']['year'] if 'year' in p['program'] else None
                else:
                    progType=None
                    year=None
                blackout=True if 'InternetStreamDisabled' in p['akpa_attributes'] else False  #catchUpDisabled
                    
                ar_prog.append([pID,chCode,pTitle,pDescr,img,progType,str(year),blackout,dt(p['date_start'])])
    return ar_prog

def replayProgramsGen(chCode,date):#menu-replay program list
    programs=replayProgramsArrayGen(chCode,date)
    for p in programs:
        plot=''
        if p[5] !=None:
            plot+='[B]'+p[5]+'[/B]\n'
        if p[7]==True:
            plot+='[COLOR=yellow]Niedostępny z powodu ograniczeń licencyjnych[/COLOR]\n'
            progTitle='[COLOR=red]'+p[2]+'[/COLOR]'
        else:
            progTitle=p[2]
        if p[3] !=None:
            plot+=p[3]+'\n'
        if p[6] !='None':
            plot+='[B]Rok prod.: '+p[6]+'[/B]'
                
        title=[s for s in stationCode if stationCode[s]==chCode][0]+' | '
        title+=p[8]+' '+progTitle
            
        iL={'title': p[2],'sorttitle': p[2],'plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': p[4], 'fanart': ''}
        url = base.build_url({'mode':'playReplayTV','chCode':p[1],'progID':p[0]})
        cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favExtAdd&url='+quote(url)+'&title='+quote(title)+'&infoLab='+quote(str(iL))+'&img='+quote(p[4])+')')]
        base.addItemList(url, progTitle, setArt, 'video', iL, False, 'true', True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def PlayProgram(chCode,progID):#play program
    chCode_=chCode
    if chCode_=='XHHE':
        chCode_='XHH'
    #strin='{"operationName":"programByRecordID","variables":{"id":"'+progID+'","code_station":"'+chCode_+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"899915a5ffd6b98c3bb7691bfa96327a3c2af29d52d7a449c799d29c0e86b7b5"}},"query":"query programByRecordID($id: ID!, $code_station: String!) {\\n  programByRecordID(id: $id, code_station: $code_station) {\\n    occurrence {\\n      id\\n      title\\n      date_start\\n      date_end\\n      description\\n      description_long\\n      description_akpa_long\\n      description_akpa_medium\\n      description_akpa\\n      plrating\\n      __typename\\n    }\\n    stream {\\n      code_station\\n      ids {\\n        occurrence\\n        record\\n        __typename\\n      }\\n      urls {\\n        vast\\n        stream\\n        __typename\\n      }\\n      __typename\\n    }\\n    date_current\\n    video {\\n      title\\n      formats {\\n        mime_type\\n        url\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n"}'
    strin='{"operationName":"programByRecordID","variables":{"id":"'+progID+'","code_station":"'+chCode+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"a22d10bb7d165e70687351d1d5e4eaa4b9624633bb9857008093be4e7ab83b17"}},"query":"query programByRecordID($id: ID!, $code_station: String!) {\\n  programByRecordID(id: $id, code_station: $code_station) {\\n    occurrence {\\n      id\\n      title\\n      date_start\\n      date_end\\n      description\\n      description_long\\n      description_akpa_long\\n      description_akpa_medium\\n      description_akpa\\n      plrating\\n      __typename\\n    }\\n    stream {\\n      code_station\\n      ids {\\n        occurrence\\n        record\\n        __typename\\n      }\\n      urls {\\n        vast\\n        stream\\n        __typename\\n      }\\n      __typename\\n    }\\n    date_current\\n    video {\\n      ... on VideoFromTokenizerWithoutDebugInfo {\\n        title\\n        formats {\\n          mime_type\\n          url\\n          __typename\\n        }\\n        __typename\\n      }\\n      ... on VideoFromTokenizerWithDebugInfo {\\n        title\\n        formats {\\n          mime_type\\n          url\\n          __typename\\n        }\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n"}'
    data=json.loads(strin)
    resp=requests.post(api_hbbtv,json=data,headers=heaTV,verify=False).json()
    print(resp)
    if 'errors' not in resp:
        streams=resp['data']['programByRecordID']['video']['formats']
        mt='mime_type'
    else: #alternatywny resolver (gdy TVPHO HbbTV nie działa)
        xbmcgui.Dialog().notification('TVPGO', 'alternatywny', xbmcgui.NOTIFICATION_INFO)
        url='https://sport.tvp.pl/api/tvp-stream/stream/data?station_code='+chCode+'&record_id='+progID+'&device=android'
        resp=requests.get(url,headers=hea_oth,verify=False).json()
        url=resp['data']['stream_url']
        resp=requests.get(url,headers=hea_oth,verify=False).json()
        streams=resp['formats']
        mt='mimeType'
        
    mimeType='application/x-mpegurl'
    playerProtocol='hls'
        
    url_stream=''
    for s in streams:
        if s[mt]==mimeType  and '-hls' in s['url']: #and not 'mobile' in s['url']
            url_stream=s['url'].replace('mobile-hls','hbbtv-hls')
            break
    if url_stream=='':
        for s in streams:
            if s[mt]==mimeType: #and not 'mobile' in s['url']
                url_stream=s['url']
                break
    if 'end=' not in url_stream and '-hls' in url_stream:
        url_stream +='&end='
    elif 'end=' in url_stream:
        t_end_old=dict(parse_qsl(url_stream.split('?')[-1]))['end'] 
        t_end_new=(datetime.datetime(*(time.strptime(t_end_old,'%Y%m%dT%H%M00')[0:6]))+datetime.timedelta(seconds=30*60)).strftime('%Y%m%dT%H%M00')
        url_stream=url_stream.replace(t_end_old,t_end_new)
        
    if chCode=='XHHE': #TVP3 Olsztyn/Elbląg
        url='https://token-java-v2.tvp.pl/tokenizer/token/62977634'
        resp=requests.get(url,headers=hea_oth).json()
        if "NOT_PLAYABLE" not in resp['status']:
            for s in resp['formats']:
                if s['mimeType']==mimeType and 'mobile' not in s['url']:
                    url_stream_new=s['url']
                    url_stream=url_stream.replace(url_stream.split('?')[0],url_stream_new)
                    break
    print('URL_STREAM:'+url_stream)
        
    pathFile='plugin://plugin.video.TVP_VOD/?mode=playReplayTV&chCode='+chCode+'&progID='+progID
    request={
        "jsonrpc": "2.0", 
        "method": "Files.GetFileDetails", 
        "params": {
            "file": pathFile, 
            "media": "video", 
            "properties": ["resume"]
        },
        "id":"1"
    }
    results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'resume' not in results['result']['filedetails']:
        fromStart=True
    else:
        fromStart=False
        
    playerISA(url_stream,playerProtocol,live=False,fromStart=fromStart)
    '''
    else:
        xbmcgui.Dialog().notification('TVPGO', 'Materiał niedostępny', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    '''
def epgData(stCode):
    hea={
        'User-Agent':base.UA
    }
    period=6*60*60*1000
    date=[]
    today=datetime.datetime.now().strftime('%Y-%m-%d')
    date.append(today)
    hour=int(datetime.datetime.now().strftime('%H'))
    if hour>=18:
        date.append((datetime.datetime.now()+datetime.timedelta(days=1)).strftime('%Y-%m-%d'))
    epg=[]
    now=int(time.time())*1000
    for d in date:
        url='http://www.api.v3.tvp.pl/shared/programtv-listing.php?station_code='+stCode+'&count=500&dump=json&today_from_midnight=1&date='+d
        resp=requests.get(url,headers=hea).json()
        for r in resp['items']:
            if r['date_end']>=now and r['date_start']<=now+period:
                start=datetime.datetime.fromtimestamp(int(r['date_start']/1000)).strftime('%H:%M')
                title=r['title']
                try:
                    type=r['program']['type']['name']
                except:
                    type=''
                epg.append([start,title,type])
    return epg

def getEPG(sc):
    if sc=='XHHE':
        sc='XHH'
    epg=epgData(sc)
    plot=''
    for e in epg:
        plot+='[B]'+e[0]+'[/B] '+e[1]
        if e[2] !='':
            plot+=' [I]('+e[2]+')[/I]'
        plot+='\n'
    if plot=='':
        plot='Brak danych EPG'
    dialog = xbmcgui.Dialog()
    dialog.textviewer('EPG', plot)
    
def generate_m3u():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('TVP_VOD', 'Ustaw nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('TVP_VOD', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    c=channelArrayGen()
    for item in c:
        channelCode = item[0]
        channelName = item[1]
        channelLogo = item[2]
        if channelCode=='':
            channelID = item[3]
        else:
            channelID=''
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="TVP_VOD",%s\nplugin://plugin.video.TVP_VOD?mode=playLiveTV&chCode=%s&chID=%s\n' % (channelName,channelLogo,channelName,channelCode,channelID)

    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('TVP_VOD', 'Wygenerowano listę M3U.', xbmcgui.NOTIFICATION_INFO)

#REPLAY (new)
stations={
    'TVP1':{'code':'T1D', 'cid':'51689486','catchup':'y','img':'http://s8.tvp.pl/images2/8/a/c/uid_8ac2b72c379abf831e4d27a56988eae11638275540325_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP2':{'code':'T2D', 'cid':'51696811','catchup':'y','img':'http://s3.tvp.pl/images2/3/8/3/uid_38313bd81e2ec78f92fa8d360e738b921638275558292_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Info':{'code':'INF', 'cid':'51696820','catchup':'y','img':'http://s2.tvp.pl/images2/2/1/2/uid_2124147c0f8212d59ace8374779b28621638275572006_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'}, 
    'TVP NAUKA':{'code':'NK', 'cid':'62975271','catchup':'y','img':'http://s5.tvp.pl/images2/e/3/a/uid_e3a95bba0e16e0eed0e5fd59229cfbd01663860050881_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Sport':{'code':'KSP', 'cid':'51696827','catchup':'y','img':'http://s9.tvp.pl/images2/9/6/b/uid_96b6b3e217181c3d3925ba783fe68a131638275633849_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Kultura':{'code':'T5D', 'cid':'51696822','catchup':'y','img':'http://s9.tvp.pl/images2/9/6/1/uid_96117b8fceb8a7db897a9757240316451638275727542_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Historia':{'code':'TKH', 'cid':'51696819','catchup':'y','img':'http://s4.tvp.pl/images2/d/5/e/uid_d5e250a46a37955df5b33847a1f661921638275686065_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP ABC':{'code':'ABC', 'cid':'51696812','catchup':'y','img':'http://s5.tvp.pl/images2/5/c/8/uid_5c8ba79e2229bf9909ffa4ea9907595e1638275665760_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Dokument':{'code':'DOK','cid':'53795159','catchup':'y','img':'http://s1.tvp.pl/images2/a/f/1/uid_af1b5529d584f3e6dc893021b38901971638275709609_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Kobieta':{'code':'KBT','cid':'53795158','catchup':'y','img':'http://s3.tvp.pl/images2/3/6/2/uid_362ac36e5828f7e25f5e5d028b7abb7b1638275648497_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Polonia':{'code':'T4D','cid':'51696824','catchup':'y','img':'http://s5.tvp.pl/images2/e/7/b/uid_e7b9ee2c3a342e7b97eda1b96e48808d1638275742066_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Rozrywka':{'code':'TRO','cid':'51696825','catchup':'y','img':'http://s9.tvp.pl/images2/9/6/4/uid_9647031d5810bf7b78b1a9f30904468c1638275757901_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP World':{'code':'PIE','cid':'57181932','catchup':'n','img':'http://s6.tvp.pl/images2/6/6/e/uid_66ec3a95ffbb04ac674efd2a8ba2e4631637224384316_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Kultura 2':{'code':'KUL2','cid':'56275381','catchup':'n','img':'http://s9.tvp.pl/images2/9/a/b/uid_9ab326a136b5dd5ff06262155bcc02ca1607116286623_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP ABC 2':{'code':'DMPR','cid':'57181933','catchup':'n','img':'http://s3.tvp.pl/images2/c/d/2/uid_cd2dd2eb58a62fa3571592bd8a61ad2c1644934718964_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Historia 2':{'code':'H2','cid':'57181934','catchup':'n','img':'http://s7.tvp.pl/images2/7/f/2/uid_7f29c7a0db297706c9a0ff4e625572221614186561005_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},    
    'TVP3 Białystok':{'code':'XCC','cid':'62977549','catchup':'y','img':'http://s2.tvp.pl/images2/b/1/9/uid_b19c0fe3d69594dc055a76bd316148d71566388357439_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Bydgoszcz':{'code':'XBB','cid':'62977561','catchup':'y','img':'http://s5.tvp.pl/images2/5/e/9/uid_5e9126648da6925f4fe771d02eae724c1566388527267_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Gdańsk':{'code':'XGG','cid':'62977563','catchup':'y','img':'http://s1.tvp.pl/images2/1/6/e/uid_16ef2e3899aa0f6a86bab4e7d4ad7acb1566388553274_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Gorzów Wielkopolski':{'code':'XFF','cid':'62977572','catchup':'y','img':'http://s9.tvp.pl/images2/9/a/6/uid_9a63db7e7850c553fd5f99ef4a4764bf1566388710402_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Katowice':{'code':'XTT','cid':'62977575','catchup':'y','img':'http://s1.tvp.pl/images2/a/7/0/uid_a7082896b3af87dee93a7e82f4574aea1566388722532_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Kielce':{'code':'XEE','cid':'62977602','catchup':'y','img':'http://s6.tvp.pl/images2/f/a/a/uid_faa42ba4b4a31b226a2f1da99e1ac56d1566388734756_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Kraków':{'code':'XKK','cid':'62977608','catchup':'y','img':'http://s6.tvp.pl/images2/f/e/7/uid_fe765a5a9a4f710c1e73ca72d57dcfb41566388748581_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Lublin':{'code':'XLL','cid':'62977620','catchup':'y','img':'http://s2.tvp.pl/images2/2/c/3/uid_2c30eb4d856d156d025168f37a072a241566388774571_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Łódź':{'code':'XDD','cid':'62977613','catchup':'y','img':'http://s8.tvp.pl/images2/8/d/a/uid_8daf45383144552ab0a791a45dea90691566388793484_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Olsztyn':{'code':'XHH','cid':'62977622','catchup':'y','img':'http://s9.tvp.pl/images2/9/9/2/uid_9923ae9c5aa8a9089a9f8034651c5d9c1566388829799_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Olsztyn/Elbląg':{'code':'XHH','cid':'62977634','catchup':'y','img':'http://s9.tvp.pl/images2/9/9/2/uid_9923ae9c5aa8a9089a9f8034651c5d9c1566388829799_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},
    'TVP3 Opole':{'code':'XJJ','cid':'62977659','catchup':'y','img':'http://s4.tvp.pl/images2/4/1/1/uid_411f024dee7040009307c76894fdb19c1566389096981_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Poznań':{'code':'XPP','cid':'62977660','catchup':'y','img':'http://s4.tvp.pl/images2/d/e/3/uid_de3a8c5ef41e6cc72874d0769b392c731566388858694_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Rzeszów':{'code':'XRR','cid':'62977663','catchup':'y','img':'http://s10.tvp.pl/images2/0/5/f/uid_05ffe9f2c1085affb565b3539443df431566388871032_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Szczecin':{'code':'XSS','cid':'62977665','catchup':'y','img':'http://s5.tvp.pl/images2/5/1/0/uid_5100b76fed6bea98077a74a5d85a20d81566388884052_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP3 Warszawa HD':{'code':'XAA','cid':'14812858','catchup':'y','img':'http://s4.tvp.pl/images2/d/6/e/uid_d6ef379170d95c5d3d84c872b09a0cad1566388902716_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},# SD: 62881071
    'TVP3 Wrocław':{'code':'XWW','cid':'62977668','catchup':'y','img':'http://s4.tvp.pl/images2/d/6/e/uid_d6e43f98434ee3b9ce0848e83d26e5f81566388918436_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'y'},
    'TVP Parlament Sejm':{'code':'','cid':'16047033','catchup':'n','img':'https://hbbn.tvp.pl/apps/virtual-channel/gfx/hub-lists/channels-live/tvpparlament_sejm.png','tvpgo_hbb':'n'},#png do podmiany
    'TVP Parlament Senat':{'code':'','cid':'16047094','catchup':'n','img':'https://hbbn.tvp.pl/apps/virtual-channel/gfx/hub-lists/channels-live/tvpparlament_senat.png','tvpgo_hbb':'n'},#png do podmiany
    'TVP Parlament Komisja 1':{'code':'','cid':'16047097','catchup':'n','img':'http://s3.tvp.pl/images2/c/d/3/uid_cd316e49c8185069f085884fb881f0f51448633997759_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},
    'TVP Parlament Komisja 2':{'code':'','cid':'16047099','catchup':'n','img':'http://s6.tvp.pl/images2/f/d/9/uid_fd9c7b1a21511f29d8cedeba544e16a11448634093730_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},
    'TVP Wilno':{'code':'WILNO','cid':'53933410','catchup':'n','img':'http://s3.tvp.pl/images2/3/7/2/uid_37273101aabbe28f9f6e62d62ca3dc201568710101823_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},#44418594
    'Jasna Góra':{'code':'','cid':'53415775','catchup':'n','img':'https://s10.tvp.pl/images2/0/0/5/uid_00525b67452c04a9eb6aa0e32d4888fc1619004489426_width_{width}_play_0_pos_0_gs_0_height_{height}.jpg','tvpgo_hbb':'n'},
    'Belsat':{'code':'TVBI','cid':'17251711','catchup':'n','img':PATH+'/resources/img/belsat.png','tvpgo_hbb':'n'},
    'UA1':{'code':'','cid':'58758689','catchup':'n','img':'http://s2.tvp.pl/images2/2/2/e/uid_22e0d031662761cdeb669c49b31738b81645961764558_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},
    'Polska biesiada bis':{'code':'BIESIADA','cid':'69501181','catchup':'y_cms','img':'https://s4.tvp.pl/images2/4/7/1/uid_471bc3a417e84d60bfb751b309f0c330_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},#2023-05-11
    '_RESET':{'code':'RESET','cid':'70707771','catchup':'y_cms','img':'https://s2.tvp.pl/images2/b/a/5/uid_ba59f28648294c26a618c088dff219ad_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},#2023-05-11
    'TVP Opole bis':{'code':'OPOLEBIS','cid':'70892600','catchup':'y_cms','img':'https://s7.tvp.pl/images2/7/2/8/uid_7280c4ecc741432f8bc9e257bc1f601b_width_{width}_play_0_pos_0_gs_0_height_{height}.png','tvpgo_hbb':'n'},#2023-06-28
}

def listTV():   
    channels=list(stations.keys())
    for c in channels:
        if stations[c]['catchup']!='n':
            name=c
            cid=stations[c]['cid']
            code=stations[c]['code']
            img=stations[c]['img'].replace('{width}','510').replace('{height}','') if stations[c]['img'] !='' else 'OverlayUnwatched.png'
            catchup=stations[c]['catchup']
            
            setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':''}
            url = base.build_url({'mode':'calendar','cid':cid,'code':code,'catchup':catchup})
            base.addItemList(url, name, setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def calendar(code,cid,cu):
    today=datetime.datetime.now()
    ar_date=[]
    i=0
    replayPeriod='7'#addon.getSetting('replay_period')
    while i<=int(replayPeriod):#7
        day=(today-datetime.timedelta(days=i)).strftime('%Y-%m-%d')
        ar_date.append(day)
        i=i+1

    for d in ar_date:    
        iL={'title': d,'sorttitle': d,'plot': ''}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart': ''}
        url = base.build_url({'mode':'programs','date':d,'code':code,'cid':cid,'catchup':cu})
        base.addItemList(url, d, setArt, infoLab=iL)
    
    xbmcplugin.endOfDirectory(addon_handle)

def programs(d,code,cid,cu):
    now=int(time.time())
    #past=now-7*24*60*60
    replayPeriod='7'#addon.getSetting('replay_period')
    past=now-int(replayPeriod)*24*60*60
    url='http://www.api.v3.tvp.pl/shared/programtv-listing.php?station_code='+code+'&count=1000&dump=json&today_from_midnight=0&date='+d
    resp1=requests.get(url,headers=hea_oth).json()
    d1=(datetime.datetime(*(time.strptime(d,'%Y-%m-%d')[0:6]))-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    url='http://www.api.v3.tvp.pl/shared/programtv-listing.php?station_code='+code+'&count=1000&dump=json&today_from_midnight=0&date='+d1
    resp2=requests.get(url,headers=hea_oth).json()
    resp=resp2['items']+resp1['items']
    for r in resp:
        date=datetime.datetime.fromtimestamp(int(r['date_start']/1000)).strftime('%Y-%m-%d')
        if date==d and r['date_start']>=1000*past and r['date_start']<=1000*now:
            title='[B]'+datetime.datetime.fromtimestamp(int(r['date_start']/1000)).strftime('%H:%M')+'[/B] '
            title+=r['title']
            try:
                type=r['program']['type']['name']
                title+=' [I]('+type+')[/I]'
            except:
                pass
            plot=''
            img='OverlayUnwatched.png'
            if 'program' in r:
                p=r['program']
                if cu=='y_cms':
                    cid=p['cms_id'] if p['cms_id']!=None else ''
                year=p['year'] if 'year' in p else ''
                desc=p['description_long'] if 'description_long' in p else ''
                try:
                    type=p['type']['name'] if 'type' in p else ''
                except:
                    type=''
                land='/'.join(p['land']) if 'land' in p else ''
                
                if type !='':
                    plot+='[B]'+type+'[/B]\n'
                if year !='':
                    plot+='[B]Rok prod: [/B]'+str(year)+'\n'
                if land !='':
                    plot+='[B]Kraj: [/B]'+land+'\n'
                if desc !='':
                    plot+='[I]'+desc+'[/I]'
                
                if 'image_source' in p:
                    imgSrc=[]
                    if p['image_source']=='program_type':
                        imgSrc=p['images']
                        imgType='images2'
                    elif p['image_source']=='akpa_type' or  p['image_source']=='cms_type':
                        try:
                            imgSrc=p['akpa_images']
                            imgType='images-akpa'
                        except:
                            imgSrc=[]
                    
                    if len(imgSrc)>0:
                        try:
                            imgFile,imgExt=imgSrc[0]['fileName'].split('.')
                            imgW=imgSrc[0]['width']
                            imgH=imgSrc[0]['height']
                            img='https://s1.tvp.pl/%s/a/0/0/uid_%s_width_%s_play_0_pos_0_gs_0_height_%s.%s' %(imgType,imgFile,imgW,imgH,imgExt)
                        except:
                            img=img_inne
                    else:
                        img=img_inne

            begin=datetime.datetime.utcfromtimestamp(int(r['date_start']/1000)).strftime('%Y%m%dT%H%M%S')
            end=datetime.datetime.utcfromtimestamp(int(r['date_end']/1000+15*60)).strftime('%Y%m%dT%H%M%S')#wydłużenie czasu zakończenia o 15 minut ze względu na możliwe opóźnienia w ramówce      
            
            if cid!='':
                url_ch = base.build_url({'mode':'playReplay','begin':begin,'end':end,'cid':cid,'catchup':cu})
                isPlayable='true'
            else:
                url_ch = base.build_url({'mode':'noSource'})
                isPlayable='false'
                title='[COLOR=red]'+title+'[/COLOR]'
                                   
            if cu=='y':
                tit=[s for s in stations if stations[s]['cid']==cid][0]+' | '
                tit+=d+' '+title
            elif cu=='y_cms':
                tit=title
                        
            iL={'title': d,'sorttitle': d,'plot': plot}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''}
            cmItems=[('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favExtAdd&url='+quote(url_ch)+'&title='+quote(tit)+'&infoLab='+quote(str(iL))+'&img='+quote(img)+')')]
            base.addItemList(url_ch, title, setArt, 'video', iL, False, isPlayable, True, cmItems)
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)
    
def playReplay(cid,b,e,cu):
    pathFile='plugin://plugin.video.TVP_TV/?mode=playReplay&begin='+b+'&end='+e+'&cid='+cid
    request={
        "jsonrpc": "2.0", 
        "method": "Files.GetFileDetails", 
        "params": {
            "file": pathFile, 
            "media": "video", 
            "properties": ["resume"]
        },
        "id":"1"
    }
    results = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    if 'resume' not in results['result']['filedetails']:
        fromStart=True
    else:
        fromStart=False
   
    url='https://token-java-v2.tvp.pl/tokenizer/token/'+cid
    resp=requests.get(url,headers=hea_oth).json()
    url_stream=''
    protocol=''
    if resp['formats']!=None:
        formats = [f for f in resp['formats'] if f['mimeType']=='application/x-mpegurl' and 'mobile-' not in f['url']]
        def sortFN(i):
            return i['totalBitrate']
        formats.sort(key=sortFN,reverse=True)
        if cu=='y':  
            streams=[f for f in formats if 'hbbtv-' in f['url']] #tylko streamy /hbbtv-hls/
            url_stream=streams[0]['url']+'?begin='+b+'&end='+e
        elif cu=='y_cms':
            url_stream=formats[0]['url']
        protocol='hls'
        if url_stream !='':
            playerISA(url_stream,protocol,live=False,fromStart=fromStart)    
        else:
            xbmcgui.Dialog().notification('TVP_VOD', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        xbmcgui.Dialog().notification('TVP_VOD', 'Brak źródła', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
