import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import time
import datetime
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.TVP_VOD')
PATH=addon.getAddonInfo('path')
img_path=PATH+'/resources/images/'

def build_url(query):
    return base_url + '?' + urlencode(query)

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0'
baseurl='https://hbb-prod.tvp.pl/apps/manager/hub/?name_channel=MUX3_TVP1_HD'

heaTV={
    'User-Agent':UA,
    'Referer':baseurl
}

menu_TV=[
    ['Kanały na żywo','liveTV'],
    ['Replay TV','replayTV']
]

stationCode={
    'TVP1':'T1D', 
    'TVP2':'T2D', 
    'TVP Info':'INF', 
    'TVP NAUKA':'NK', 
    'TVP Sport':'KSP',
    'TVP Kultura':'T5D',
    'TVP Historia':'TKH',
    'TVP ABC':'ABC',
    'TVP Dokument':'DOK',
    'TVP Kobieta':'KBT',
    'TVP Polonia':'T4D',
    'TVP Rozrywka':'TRO',
    'TVP World':'WORLD',
    'TVP Kultura 2':'KUL2',
    'TVP ABC 2':'DMPR',
    'TVP Historia 2':'H2',
    'TVP Wilno':'WILNO',
    'TVP3 Białystok':'XCC',
    'TVP3 Bydgoszcz':'XBB',
    'TVP3 Gdańsk':'XGG',
    'TVP3 Gorzów Wielkopolski':'XFF',
    'TVP3 Katowice':'XTT',
    'TVP3 Kielce':'XEE',
    'TVP3 Kraków':'XKK',
    'TVP3 Lublin':'XLL',
    'TVP3 Łódź':'XDD',
    'TVP3 Olsztyn':'XHH',
    'TVP3 Opole':'XJJ',
    'TVP3 Poznań':'XPP',
    'TVP3 Rzeszów':'XRR',
    'TVP3 Szczecin':'XSS',
    'TVP3 Warszawa':'XAA',
    'TVP3 Wrocław':'XWW',
    'TVP HD':'KHSH',
    'TVP 4K':'KS4K',
    'Belsat':'TVBI',
    'TVP Parlament SEJM':'TVPPARLAMENT',
    'ALFA TVP':'ALFA'
}

def menuTV():
    for m in menu_TV:
        li=xbmcgui.ListItem(m[0])
        li.setProperty("IsPlayable", 'false')
        li.setInfo(type='video', infoLabels={'title': '','sorttitle': '','plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
        url_ch = build_url({'mode':m[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_ch, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def channelArrayGen():#JSON-live channel list
    #strin='{"operationName":null,"variables":{"categoryId":null},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"5c29325c442c94a4004432d70f94e336b8c258801fe16946875a873e818c8aca"}}}'
    strin='{"operationName":null,"variables":{"categoryId":null},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"5c29325c442c94a4004432d70f94e336b8c258801fe16946875a873e818c8aca"}},"query":"query ($categoryId: String) {\\n  getLandingPageVideos(categoryId: $categoryId) {\\n    type\\n    title\\n    elements {\\n      id\\n      title\\n      subtitle\\n      type\\n      img {\\n        hbbtv\\n        image\\n        website_holder_16x9\\n        video_holder_16x9\\n        __typename\\n      }\\n      broadcast_start_ts\\n      broadcast_end_ts\\n      sportType\\n      label {\\n        type\\n        text\\n        __typename\\n      }\\n      stats {\\n        video_count\\n        __typename\\n      }\\n      __typename\\n    }\\n    __typename\\n  }\\n  getStationsForMainpage {\\n    items {\\n      id\\n      name\\n      code\\n      image_square {\\n        url\\n        __typename\\n      }\\n      background_color\\n      isNativeChanel\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}'
    data=json.loads(strin)
    resp=requests.post('https://hbb-prod.tvp.pl/apps/manager/api/hub/graphql',json=data,headers=heaTV).json()
    ch_data=resp['data']['getStationsForMainpage']['items']
    ar_chan=[]
    for c in ch_data:
        ch_code=c['code']
        ch_name=c['name'].replace('EPG - ','').replace('Domowe Przedszkole','ABC 2')
        ch_img=c['image_square']['url'].replace('{width}','300').replace('{height}','0')
        if ch_code=='':
            ch_id=c['id']
        else:
            ch_id=''
        ar_chan.append([ch_code,ch_name,ch_img,ch_id])
    ar_new=[
        ['','Belsat',img_path+'belsat.png','aid_17251711'],
        ['','Jasna Góra','https://s10.tvp.pl/images2/0/0/5/uid_00525b67452c04a9eb6aa0e32d4888fc1619004489426_width_300_play_0_pos_0_gs_0_height_0.jpg','aid_53415775'],
        ['','TVP Parlament SEJM','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047033'],
        ['','TVP Parlament SENAT','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047094'],
        ['','TVP Parlament KOMISJA 1','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047097'],
        ['','TVP Parlament KOMISJA 2','https://s.tvp.pl/files/tvp-parlament/gfx/logo/tvp-parlament.png','aid_16047099']
    ]
    ar_chan+=ar_new
    return ar_chan

def channels_gen():#menu-live channel list
    channels=channelArrayGen()
    for ch in channels:
        li=xbmcgui.ListItem(ch[1])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': ch[1],'sorttitle': ch[1],'plot': 'EPG dostępne z poziomu menu kontekstowego'})
        li.setArt({'thumb': ch[2], 'poster': ch[2], 'banner': ch[2], 'icon': ch[2], 'fanart': ch[2]})
        url_ch = build_url({'mode':'playLiveTV','chCode':ch[0],'chID':ch[3]})
        
        if ch[1] in stationCode:
            contMenu = []
            contMenu.append(('[B]EPG[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=EPG&stCode='+stationCode[ch[1]]+')'))
            li.addContextMenuItems(contMenu, replaceItems=False)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_ch, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def PlayStream(chCode,chId):#play live channel
    def player(u):
        import inputstreamhelper
        PROTOCOL = 'hls'
        is_helper = inputstreamhelper.Helper(PROTOCOL)
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=u)
            play_item.setMimeType('application/x-mpegurl')
            play_item.setContentLookup(False)
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
            play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
            play_item.setProperty("IsPlayable", "true")
            play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)

        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    if chCode!=None:
        #strin='{"extensions":{"persistedQuery":{"sha256Hash":"0b9649840619e548b01c33ae4bba6027f86eac5c48279adc04e9ac2533781e6b","version":1}},"operationName": null,"variables":{"stationCode": "'+chCode+'"}}'
        strin='{"operationName":null,"variables":{"stationCode":"'+chCode+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"0b9649840619e548b01c33ae4bba6027f86eac5c48279adc04e9ac2533781e6b"}},"query":"query ($stationCode: String!) {\\n  currentProgramAsLive(stationCode: $stationCode) {\\n    id\\n    title\\n    subtitle\\n    date_start\\n    date_end\\n    date_current\\n    description\\n    description_long\\n    description_akpa_long\\n    description_akpa_medium\\n    description_akpa\\n    plrating\\n    npvr\\n    formats {\\n      mimeType\\n      url\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}'
        data=json.loads(strin)
        resp=requests.post('https://hbb-prod.tvp.pl/apps/manager/api/hub/graphql',json=data,headers=heaTV).json()
        if resp['data']['currentProgramAsLive'] is not None:
            streams=resp['data']['currentProgramAsLive']['formats']
            for s in streams:
                if (s['mimeType']=='application/x-mpegurl' and not ('mobile' in s['url'])):#application/dash+xml
                    if resp['data']['currentProgramAsLive']['subtitle']=='Przerwa w nadawaniu':
                        url_stream=s['url'].split('?begin=')[0]
                    elif 'begin=' in s['url']:
                        te=(datetime.datetime.utcnow()+datetime.timedelta(hours=6)).strftime('%Y%m%dT%H%M00')
                        #url_stream=s['url'].replace(s['url'].split('?')[-1],'end='+te)
                        url_stream=s['url']+'&end='+te
                        #url_stream=s['url']
                    else:
                        url_stream=s['url']
            '''
            if '&end' not in url_stream:
                url_stream +='&end='
            '''
            import inputstreamhelper
            PROTOCOL = 'hls'#mpd
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=url_stream)
                #play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'false')
                play_item.setProperty('ResumeTime', '43200')
                play_item.setProperty('TotalTime', '1')
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)

            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        else:
            xbmcgui.Dialog().notification('TVPGO', 'Przerwa w emisji', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    elif chCode==None:
        url_stream=''
        if 'aid' not in chId:
            #strin2='{"operationName":null,"variables":{"liveId":"'+chId+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"f2fd34978dc0aea320ba2567f96aa72a184ca2d1e55b2a16dc0915bd03b54fb3"}}}'
            strin2='{"operationName":null,"variables":{"liveId":"'+chId+'"},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"f2fd34978dc0aea320ba2567f96aa72a184ca2d1e55b2a16dc0915bd03b54fb3"}},"query":"query ($liveId: String!) {\\n  getLive(liveId: $liveId) {\\n    error\\n    data {\\n      type\\n      title\\n      subtitle\\n      lead\\n      label {\\n        type\\n        text\\n        __typename\\n      }\\n      src\\n      vast_url\\n      duration_min\\n      subtitles {\\n        src\\n        autoDesc\\n        lang\\n        text\\n        __typename\\n      }\\n      is_live\\n      formats {\\n        mimeType\\n        totalBitrate\\n        videoBitrate\\n        audioBitrate\\n        adaptive\\n        url\\n        downloadable\\n        __typename\\n      }\\n      web_url\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}'
            data2=json.loads(strin2)
            resp2=requests.post('https://hbb-prod.tvp.pl/apps/manager/api/hub/graphql',json=data2,headers=heaTV).json()
            streams2=resp2['data']['getLive']['data'][0]['formats']
            for s in streams2:
                if (s['mimeType']=='application/x-mpegurl' and not ('mobile' in s['url'])):
                    url_stream=s['url']
                    break
            player(url_stream)
        elif 'aid' in chId:
            url='https://token-java-v2.tvp.pl/tokenizer/token/'+chId.split('aid_')[-1]
            hea_oth={
                'User-Agent':UA
            }
            resp=requests.get(url,headers=hea_oth).json()
            if "NOT_PLAYABLE" not in resp['status']:
                for s in resp['formats']:
                    if s['mimeType']=='application/x-mpegurl':
                        url_stream=s['url']
                        break
                player(url_stream)
            else:
                xbmcgui.Dialog().notification('TVP_VOD', 'Przerwa w emisji', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
            
        

def replayChannelsArrayGen(): #JSON: replay channels
    #strin='{"extensions":{"persistedQuery":{"sha256Hash": "18a5c6b18b6443bd317f69ff092b6d7068733640159eaf216c35f583ea73ac23","version":1}},"operationName": null,"variables":{}}'
    strin='{"operationName":null,"variables":{},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"18a5c6b18b6443bd317f69ff092b6d7068733640159eaf216c35f583ea73ac23"}},"query":"{\\n  getStations {\\n    items {\\n      name\\n      code\\n      image_square {\\n        url\\n        __typename\\n      }\\n      background_color\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}'
    data=json.loads(strin)
    resp=requests.post('https://hbb-prod.tvp.pl/apps/manager/api/hub/graphql',json=data,headers=heaTV).json()
    ch_data=resp['data']['getStations']['items']
    ar_chan=[]
    for ch in ch_data:
        chName=ch['name']
        chCode=ch['code']
        ar_chan.append([chName,chCode])
    ar_new=[
        ['TVP3 Białystok','XCC'],
        ['TVP3 Bydgoszcz','XBB'],
        ['TVP3 Gdańsk','XGG'],
        ['TVP3 Gorzów Wielkopolski','XFF'],
        ['TVP3 Katowice','XTT'],
        ['TVP3 Kielce','XEE'],
        ['TVP3 Kraków','XKK'],
        ['TVP3 Lublin','XLL'],
        ['TVP3 Łódź','XDD'],
        ['TVP3 Olsztyn','XHH'],
        ['TVP3 Opole','XJJ'],
        ['TVP3 Poznań','XPP'],
        ['TVP3 Rzeszów','XRR'],
        ['TVP3 Szczecin','XSS'],
        ['TVP3 Warszawa','XAA'],
        ['TVP3 Wrocław','XWW']
    ]
    ar_chan+=ar_new
    return ar_chan

def replayChannelsGen():#menu-replay channel list
    channels=replayChannelsArrayGen()
    for ch in channels:
        li=xbmcgui.ListItem(ch[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': ch[0],'sorttitle': ch[0],'plot': ''})
        li.setArt({'thumb': 'DefaultTVShows.png', 'poster': 'DefaultTVShows.png', 'banner': 'DefaultTVShows.png', 'icon': 'DefaultTVShows.png', 'fanart': ''})
        #li.setArt({'thumb': ch[2], 'poster': ch[2], 'banner': ch[2], 'icon': ch[2], 'fanart': ''})
        url_ch = build_url({'mode':'replayTVdate','chCode':ch[1]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_ch, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def addZero(x):
    if x<=9:
        return '0'+str(x)
    else:
        return str(x)

def replayCalendarGen(chCode):#kalendarz
    time_now=int(time.time())

    def getDate(x):
        ts=time.localtime(x)
        return str(ts.tm_year)+'-'+str(addZero(ts.tm_mon))+'-'+str(addZero(ts.tm_mday))

    ar_date=[]
    i=0
    while i<=7:
        day=time_now-i*24*60*60
        ar_date.append(getDate(day))
        i=i+1

    for d in ar_date:
        li=xbmcgui.ListItem(d)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': d,'sorttitle': d,'plot': ''})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': 'DefaultYear.png', 'fanart': ''})
        url_ch = build_url({'mode':'replayTVprogs','date':d,'chCode':chCode})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_ch, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def replayProgramsArrayGen(chCode,date):#JSON-programy wg daty
    #strin='{"extensions":{"persistedQuery":{"sha256Hash": "5750d5b161a9ac4e18ae0a5c789d460763ed2bc0835446df9be712017965f8c5","version": 1}},"operationName": null,"variables":{"categorytvp": "","date":"'+date+'","station_code": "'+chCode+'"}}'
    strin='{"operationName":null,"variables":{"station_code":"'+chCode+'","date":"'+date+'","categorytvp":""},"extensions":{"persistedQuery":{"version":1,"sha256Hash":"5750d5b161a9ac4e18ae0a5c789d460763ed2bc0835446df9be712017965f8c5"}},"query":"query ($station_code: String, $date: String, $categorytvp: String) {\\n  getProgramsFromStation(\\n    station_code: $station_code\\n    date: $date\\n    categorytvp: $categorytvp\\n  ) {\\n    total_count\\n    items {\\n      id\\n      record_id\\n      title\\n      date_start\\n      date_end\\n      duration\\n      station_code\\n      description\\n      description_long\\n      program {\\n        has_video_vod\\n        website_id\\n        cms_id\\n        id\\n        title\\n        year\\n        lang\\n        image {\\n          type\\n          title\\n          point_of_origin\\n          url\\n          width\\n          height\\n          description\\n          __typename\\n        }\\n        program_type {\\n          id\\n          image_logo {\\n            type\\n            title\\n            point_of_origin\\n            url\\n            width\\n            height\\n            description\\n            __typename\\n          }\\n          title\\n          __typename\\n        }\\n        cycle {\\n          id\\n          title\\n          image_logo {\\n            type\\n            title\\n            point_of_origin\\n            url\\n            width\\n            height\\n            description\\n            __typename\\n          }\\n          __typename\\n        }\\n        __typename\\n      }\\n      station {\\n        id\\n        name\\n        code\\n        image {\\n          type\\n          title\\n          point_of_origin\\n          url\\n          width\\n          height\\n          description\\n          __typename\\n        }\\n        image_square {\\n          type\\n          title\\n          point_of_origin\\n          url\\n          width\\n          height\\n          description\\n          __typename\\n        }\\n        background_color\\n        __typename\\n      }\\n      url\\n      url_canonical\\n      categories {\\n        id\\n        category_type\\n        title\\n        __typename\\n      }\\n      akpa_attributes\\n      plrating\\n      __typename\\n    }\\n    __typename\\n  }\\n}"}'
    data=json.loads(strin)
    resp=requests.post('https://hbb-prod.tvp.pl/apps/manager/api/hub/graphql',json=data,headers=heaTV).json()
    pr_data=resp['data']['getProgramsFromStation']['items']
    ar_prog=[]
    time_now=int(time.time())*1000
    def hm(t):
        ts=time.localtime(t/1000)
        return addZero(ts.tm_hour)+':'+addZero(ts.tm_min)
    for p in pr_data:
        if p['date_start']<time_now and p['date_end']>time_now-7*24*60*60*1000:
            pID=p['record_id']
            chCode=p['station_code']
            #pTitle='['+hm(p['date_start'])+'-'+hm(p['date_end'])+'] '+p['title']
            pTitle='[B]'+hm(p['date_start'])+'[/B]  '+p['title']
            pDescr=p['description']
            try:
                img=p['program']['image']['url'].replace('{width}','608').replace('{height}','342')
            except:
                img='https://hbb-prod.tvp.pl/apps/manager/_nuxt/img/b1966b153d6da55d855eb3ce3966dce3.png'
            if p['program']!=None:
                progType=p['program']['program_type']['title'] if p['program']['program_type']!=None else None
                year=p['program']['year'] if 'year' in p['program'] else None
            else:
                progType=None
                year=None
            blackout=True if 'InternetStreamDisabled' in p['akpa_attributes'] else False  #catchUpDisabled
                
            ar_prog.append([pID,chCode,pTitle,pDescr,img,progType,str(year),blackout])
    return ar_prog

def replayProgramsGen(chCode,date):#menu-replay program list
    programs=replayProgramsArrayGen(chCode,date)
    for p in programs:
        plot=''
        if p[5] !=None:
            plot+='[B]'+p[5]+'[/B]\n'
        if p[7]==True:
            plot+='[COLOR=yellow]Niedostępny z powodu ograniczeń licencyjnych[/COLOR]\n'
            progTitle='[COLOR=red]'+p[2]+'[/COLOR]'
        else:
            progTitle=p[2]
        if p[3] !=None:
            plot+=p[3]+'\n'
        if p[6] !='None':
            plot+='[B]Rok prod.: '+p[6]+'[/B]'
        li=xbmcgui.ListItem(progTitle)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': p[2],'sorttitle': p[2],'plot': plot})
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': p[4], 'fanart': ''})
        url_ch = build_url({'mode':'playReplayTV','chCode':p[1],'progID':p[0]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_ch, listitem=li, isFolder=False)
        
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def PlayProgram(chCode,progID):#play program
    strin='{"extensions":{"persistedQuery":{"sha256Hash": "52d98fa9bb2b66075e8d230809fd5d991d16fa6a97719b2b4984797f5a506c4a","version": 1}},"operationName": null,"query": "query ($programId: String!, $stationCode: String!) {\\n  programByRecordId(programId: $programId, stationCode: $stationCode) {\\n    id\\n    title\\n    programId\\n    program_title\\n    subtitle\\n    date_start\\n    date_end\\n    date_current\\n    description\\n    description_long\\n    description_akpa_long\\n    description_akpa_medium\\n    description_akpa\\n    plrating\\n    formats {\\n      mimeType\\n      url\\n      __typename\\n    }\\n    __typename\\n  }\\n}","variables": {"programId":"'+progID+'","stationCode": "'+chCode+'"}}'
    data=json.loads(strin)
    resp=requests.post('https://hbb-prod.tvp.pl/apps/manager/api/hub/graphql',json=data,headers=heaTV).json()
    if 'errors' not in resp:
        print(resp)
        streams=resp['data']['programByRecordId']['formats']
        for s in streams:
            if (s['mimeType']=='application/dash+xml' and not ('mobile' in s['url'])):#application/x-mpegurl
                url_stream=s['url']
                break
        if 'end=' not in url_stream:
            url_stream +='&end='
        else:
            t_end_old=dict(parse_qsl(url_stream.split('?')[-1]))['end'] 
            t_end_new=(datetime.datetime(*(time.strptime(t_end_old,'%Y%m%dT%H%M00')[0:6]))+datetime.timedelta(seconds=30*60)).strftime('%Y%m%dT%H%M00')
            url_stream=url_stream.replace(t_end_old,t_end_new)

        import inputstreamhelper
        PROTOCOL = 'mpd'#hls
        is_helper = inputstreamhelper.Helper(PROTOCOL)
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=url_stream)
            #play_item.setMimeType('application/xml+dash')
            play_item.setContentLookup(False)
            play_item.setProperty('inputstream', is_helper.inputstream_addon)
            play_item.setProperty("IsPlayable", "true")
            play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
            play_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
            play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)

        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification('TVPGO', 'Materiał niedostępny', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def epgData(stCode):
    hea={
        'User-Agent':UA
    }
    period=6*60*60*1000
    date=[]
    today=datetime.datetime.now().strftime('%Y-%m-%d')
    date.append(today)
    hour=int(datetime.datetime.now().strftime('%H'))
    if hour>=18:
        date.append((datetime.datetime.now()+datetime.timedelta(days=1)).strftime('%Y-%m-%d'))
    epg=[]
    now=int(time.time())*1000
    for d in date:
        url='http://www.api.v3.tvp.pl/shared/programtv-listing.php?station_code='+stCode+'&count=500&dump=json&today_from_midnight=1&date='+d
        resp=requests.get(url,headers=hea).json()
        for r in resp['items']:
            if r['date_end']>=now and r['date_start']<=now+period:
                start=datetime.datetime.fromtimestamp(int(r['date_start']/1000)).strftime('%H:%M')
                title=r['title']
                try:
                    type=r['program']['type']['name']
                except:
                    type=''
                epg.append([start,title,type])
    return epg

def getEPG(sc):
    epg=epgData(sc)
    plot=''
    for e in epg:
        plot+='[B]'+e[0]+'[/B] '+e[1]
        if e[2] !='':
            plot+=' [I]('+e[2]+')[/I]'
        plot+='\n'
    if plot=='':
        plot='Brak danych EPG'
    dialog = xbmcgui.Dialog()
    dialog.textviewer('EPG', plot)
    
def generate_m3u():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('TVP_VOD', 'Ustaw nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('TVP_VOD', 'Generuję liste M3U.', xbmcgui.NOTIFICATION_INFO)
    data = '#EXTM3U\n'
    c=channelArrayGen()
    for item in c:
        channelCode = item[0]
        channelName = item[1]
        channelLogo = item[2]
        if channelCode=='':
            channelID = item[3]
        else:
            channelID=''
        data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="TVP_VOD",%s\nplugin://plugin.video.TVP_VOD?mode=playLiveTV&chCode=%s&chID=%s\n' % (channelName,channelLogo,channelName,channelCode,channelID)

    f = xbmcvfs.File(path_m3u + file_name, 'w')
    f.write(data)
    f.close()
    xbmcgui.Dialog().notification('TVP_VOD', 'Wygenerowano listę M3U.', xbmcgui.NOTIFICATION_INFO)
    