import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import time
import re
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.TVP_VOD')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0'
hea={
    'User-Agent':UA
}

def build_url(query):
    return base_url + '?' + urlencode(query)

   
#FAV ext

def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)
  
def favExtList():
    fURL=PATH_profile+'ulubione_ext.json'
    js=openJSON(fURL)
    for j in js:
        URL=j[0]
        if 'play' in URL:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        li=xbmcgui.ListItem(j[1])
        li.setProperty("IsPlayable", isPlayable)
        li.setInfo(type='video', infoLabels=eval(j[2]))
        li.setArt({'thumb': j[3], 'poster': j[3], 'banner': j[3], 'icon': j[3], 'fanart':''})
                
        contMenu = []
        contMenu.append(('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favExtDel&url='+quote(j[0])+')'))
        li.addContextMenuItems(contMenu, replaceItems=False)
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=URL, listitem=li, isFolder=isFolder)
    
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favExtDel(c):
    fURL=PATH_profile+'ulubione_ext.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==c:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favExtAdd(u,t,l,i):
    fURL=PATH_profile+'ulubione_ext.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,l,i])
        xbmcgui.Dialog().notification('TVP VOD', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('TVP VOD', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)