import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import json
import time
import re
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.video.TVP_VOD')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0'
hea={
    'User-Agent':UA
}

def build_url(query):
    return base_url + '?' + urlencode(query)

def playProg(aId):#TVPINFO
    url='https://www.tvp.pl/shared/cdn/tokenizer_v2.php?object_id='+str(aId)+'&sdt_version=1'
    resp=requests.get(url,headers=hea).json()
    stream_url=''
    if 'formats' in resp:
        formats = [f for f in resp['formats'] if f['mimeType']=='application/x-mpegurl']
        def sortFN(i):
            return i['totalBitrate']
        formats.sort(key=sortFN,reverse=True)
        stream_url=formats[0]['url']
        '''
        if 'audioLang' not in formats[0]:
            stream_url=formats[0]['url']
        else:
            src=[]
            urls=[]
            for f in formats:
                if 'audioLang' in f:
                    src.append(f['audioLang'])
                else:
                    src.append('Nieokreślony')
                urls.append(f['url'])
            select = xbmcgui.Dialog().select('Źródła', src)
            if select > -1:
                url_stream=src[select]
            else:
                quit()
        '''

    #subt=subt_gen_free(aId)

    if '.mp4' not in stream_url: #2022-09-08
        import inputstreamhelper
        PROTOCOL = 'hls'
        is_helper = inputstreamhelper.Helper(PROTOCOL)
        if is_helper.check_inputstream():
            play_item = xbmcgui.ListItem(path=stream_url)
            #play_item.setSubtitles(subt)
            play_item.setProperty("inputstream", is_helper.inputstream_addon)
            play_item.setProperty("inputstream.adaptive.manifest_type", PROTOCOL)
            play_item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    else:
        play_item=xbmcgui.ListItem(path=stream_url)
        play_item.setProperty("IsPlayable", "true")
        play_item.setSubtitles(subt)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
def sportTrans():#TVP SPORT
    count=300
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=false&count='+str(count)+'&parent_id=13010508&type=epg_item&filter={"is_live":True}&order={"release_date_long":-1}'
    hea.update({'Referer':'https://sport.tvp.pl/'})
    resp=requests.get(url).json()
    transData=[]
    for i in resp['items']:
        now=1000*int(time.time())
        if i['broadcast_end_date_long']>now:
            #asset_id=i['asset_id']
            title=i['release_date_dt']+ ' ' +i['release_date_hour'] + ' | ' + i['title']
            descr=cleanText(i['lead'])
            channel_id=i['video_id'] #sprawdzić z którego ID odtwarza
            img=''
            if 'image' in i:
                if 'file_name' in i['image'][0]:
                    imgFile=i['image'][0]['file_name']
                    imgType=imgFile.split('.')[-1]
                    imgWidth=i['image'][0]['width']
                    img='http://s.v3.tvp.pl/images/%s/%s/%s/uid_%s_width_%d_gs_0.%s' %(imgFile[0],imgFile[1],imgFile[2],imgFile[:-4],imgWidth,imgType)
            plot=descr
            timeStart=i['release_date_long']
            timeEnd=i['broadcast_end_date_long']
            transData.append([title,plot,img,channel_id,timeStart,timeEnd])
    transDataRev=transData[::-1]
    for t in transDataRev:    
        li=xbmcgui.ListItem(t[0])
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': t[0],'sorttitle': t[0],'plot': t[1]})
        li.setArt({'thumb': t[2], 'poster': t[2], 'banner': t[2], 'icon': t[2], 'fanart': ''})
        url_cont = build_url({'mode':'playSportLive','asset_id':t[3],'timeStart':t[4],'timeEnd':t[5]})#
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def playSportLive(aId,ts,te):#TVP SPORT
    now=1000*int(time.time())
    if now>int(ts) and now<int(te):
        playProg(aId)
    else:
        xbmcgui.Dialog().notification('TVP SPORT', 'Transmisja nie jest jeszcze prowadzona', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

#rc
def itemCategs(aid):
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id='+aid
    #hea.update({'Referer':'https://regiony.tvp.pl/'})
    resp=requests.get(url,headers=hea).json()
    #progDir=[r['asset_id'] for r in resp['items'] if 'object_type' in r and r['object_type']=='directory_series'][0]
    
    for i in resp['items']:
        img=''
        li=xbmcgui.ListItem(i['title'])
        li.setProperty("IsPlayable", 'false')
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''})
        url_cont = build_url({'mode':'progList','asset_id':str(i['asset_id'])})#
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)


#tvp3
def regionyList():
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id=38345166'
    #hea.update({'Referer':'https://regiony.tvp.pl/'})
    resp=requests.get(url,headers=hea).json()
    
    li=xbmcgui.ListItem('Pasmo wspólne')
    li.setProperty("IsPlayable", 'false')
    li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
    url_cont = build_url({'mode':'progCategs','asset_id':'38345015'})#
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
    
    for i in resp['items']:
        li=xbmcgui.ListItem(i['title'])
        li.setProperty("IsPlayable", 'false')
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
        url_cont = build_url({'mode':'progCategs','asset_id':str(i['asset_id'])})#
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def progCategs(aid):
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id='+aid
    #hea.update({'Referer':'https://regiony.tvp.pl/'})
    resp=requests.get(url,headers=hea).json()
    progDir=[r['asset_id'] for r in resp['items'] if 'object_type' in r and r['object_type']=='directory_series'][0]
    
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id='+str(progDir)
    resp=requests.get(url,headers=hea).json()
    
    li=xbmcgui.ListItem('Wszystkie programy')
    li.setProperty("IsPlayable", 'false')
    li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
    url_cont = build_url({'mode':'progList','asset_id':str(progDir),'all':'true'})#
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
    
    for i in resp['items']:
        img=''
        if 'image' in i:
            img=getImage(i['image'])
        li=xbmcgui.ListItem(i['title'])
        li.setProperty("IsPlayable", 'false')
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart': ''})
        url_cont = build_url({'mode':'progList','asset_id':str(i['asset_id'])})#
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def getImage(ai):
    img=''
    if len(ai)>0:
        try:
            imgFile,imgExt=ai[0]['file_name'].split('.')
            imgW=ai[0]['width'] if 'width' in ai[0] and ai[0]['width']>0 else '320'
            imgH=ai[0]['height'] if 'height' in ai[0] and ai[0]['height']>0 else '180'
            #img='https://s.tvp.pl/images/a/1/1/uid_%s_width_%s_play_0_pos_0_gs_0.%s'%(imgFile,imgW,imgExt)
            #img='https://s1.tvp.pl/%s/a/0/0/uid_%s_width_%s_play_0_pos_0_gs_0_height_%s.%s' %('images2',imgFile,imgW,imgH,imgExt)
            img='http://s.v3.tvp.pl/images/%s/%s/%s/uid_%s_width_%s_gs_0.%s' %(imgFile[0],imgFile[1],imgFile[2],imgFile,imgW,imgExt)
        except:
            img=''
    return img

def progList(aid,all=None):
    if all=='true':
        url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=false&count=200&parent_id='+aid+'&type=website&order={"title":1}'
    else:
        url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id='+aid+'&type=website&order={"title":1}'
    #hea.update({'Referer':'https://regiony.tvp.pl/'})
    resp=requests.get(url,headers=hea).json()
    
    for i in resp['items']:
        Aid=str(i['asset_id'])
        title=i['title']
        desc=i['lead'] if 'lead' in i else ''
        if desc=='!!! pusty LEAD !!!':
            desc=i['lead_root'] if 'lead_root' in i and i['lead_root']!='!!! pusty LEAD !!!' else ''
        img=''
        if 'logo' in i:
            img=getImage(i['logo'])
        elif 'image_16x9' in i:
            img=getImage(i['image_16x9'])
        elif 'image' in i:
            img=getImage(i['image'])
        elif 'image_vod' in i:
            img=getImage(i['image_vod'])
        
        if 38608004 in i['parents']: #programy z pasma wspólnego
            if '/regiony-tvp/' not in i['url']: #przekierowanie na www innego regionu 
                Aid=i['url'].split('/')[3]
        
        
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'false')
        iL={'title': title,'sorttitle': '','plot': cleanText(desc)}
        li.setInfo(type='video', infoLabels=iL)
        li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''})
        url_cont = build_url({'mode':'vidDir','asset_id':Aid})
        #url_cont = build_url({'mode':'epList','asset_id':str(i['asset_id']),'page':'1'})
        
        contMenu = []
        contMenu.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.TVP_VOD?mode=favExtAdd&url='+quote(url_cont)+'&title='+quote(title)+'&infoLab='+quote(str(iL))+'&img='+quote(img)+')'))
        li.addContextMenuItems(contMenu, replaceItems=False)
      
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle)

def vidDir(aid):#sprawdzenie czy materiały wideo są grupowane w kategoriach
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=true&count=100&parent_id='+aid
    #hea.update({'Referer':'https://regiony.tvp.pl/'})
    resp=requests.get(url,headers=hea).json()
    dirs=[i for i in resp['items'] if 'object_type' in i and i['object_type']=='directory_video']
    if len(dirs)>1:
        if len(dirs)==2 and dirs[0]['title']==dirs[1]['title']:#dot. rc (zdublowane katalogi z video)
            epList(str(dirs[0]['asset_id']),'1')
        else:
            for j,d in enumerate(dirs):
                if j==0 or (j>0 and d['title']!=dirs[j-1]['title']):#dot. rc (zdublowane katalogi z video)
                    li=xbmcgui.ListItem(d['title'])
                    li.setProperty("IsPlayable", 'false')
                    li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
                    url_cont = build_url({'mode':'epList','asset_id':str(d['asset_id']),'page':'1'})
                    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)
            xbmcplugin.endOfDirectory(addon_handle)
    else:
        epList(aid,'1')
    
    

def epList(aid,pg):
    cnt=addon.getSetting('epCount')
    start=(int(pg)-1)*int(cnt)
    
    url='http://www.api.v3.tvp.pl/shared/listing.php?dump=json&direct=false&count='+cnt+'&parent_id='+aid+'&object_type=video&filter={%22playable%22:True}&order={"release_date_long":-1}&offset='+str(start)
    #hea.update({'Referer':'https://regiony.tvp.pl/'})
    resp=requests.get(url,headers=hea).json()
    for i in resp['items']:
        title=i['title']
        if 'website_title' in i:
            title=i['website_title']+ ' | '+title
        desc=i['lead'] if 'lead' in i else ''
        if desc=='!!! pusty LEAD !!!':
            desc=i['lead_root'] if 'lead_root' in i and i['lead_root']!='!!! pusty LEAD !!!' else ''
        if desc=='':
            desc=i['description_root'] if 'description_root' in i and i['description_root']!='!!! pusty LEAD !!!' else ''
        dur=i['duration_min'] if 'duration_min' in i else 0
        
        plot=''
        if dur>0:
            plot+='[B]Długość: [/B]'+str(dur)+' min.\n'
        if desc!='':
            plot+='[I]'+cleanText(desc)+'[/I]'
        
        img=''
        if 'image_16x9' in i:
            img=getImage(i['image_16x9'])
        elif 'image' in i:
            img=getImage(i['image'])
        
        li=xbmcgui.ListItem(title)
        li.setProperty("IsPlayable", 'true')
        li.setInfo(type='video', infoLabels={'title': title,'sorttitle': '','plot': plot})
        li.setArt({'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': ''})
        url_cont = build_url({'mode':'playProg','asset_id':i['asset_id']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=False)

    if start+int(cnt)<resp['total_count']:
        li=xbmcgui.ListItem('[B][COLOR=yellow]>>> Następna strona[/COLOR][/B]')
        li.setProperty("IsPlayable", 'false')
        li.setArt({'thumb': '', 'poster': '', 'banner': '', 'icon': '', 'fanart': ''})
        url_cont = build_url({'mode':'epList','asset_id':aid,'page':str(int(pg)+1)})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_cont, listitem=li, isFolder=True)

    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>','&nbsp;','</span>']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ')
    t=re.sub('<([^<]+?)>','',t)
    return t
    