# -*- coding: utf-8 -*-
#import os
#import sys

import xbmc
import xbmcgui#
import xbmcplugin#
import xbmcaddon
import xbmcvfs

from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl
import random

class b:
    def __init__(self, base_url=None, addon_handle=None):
        self.base_url=base_url
        self.addon_handle=addon_handle
        self.UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'
        self.baseurl='https://apps.vod.tvp.pl/'
        self.hea={
            'User-Agent':self.UA,
            'Referer':self.baseurl,
            'X-Redge-VOD':'true',
            'API-DeviceInfo':'HbbTV;2.0.1 (ETSI 1.4.1);Chrome +DRM Samsung;Chrome +DRM Samsung;HbbTV;2.0.3'
        }
        self.apiVOD='https://vod.tvp.pl/api/'
        self.platform='SMART_TV'#ANDROID
        
        self.addon=xbmcaddon.Addon(id='plugin.video.TVP_VOD')
        self.PATH_profile=xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(self.PATH_profile):
            xbmcvfs.mkdir(self.PATH_profile)
            
    def build_url(self, query):
        return self.base_url + '?' + urlencode(query)

    def addItemList(self, url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
        li=xbmcgui.ListItem(name)
        li.setProperty("IsPlayable", isPla)
        if medType:
            li.setInfo(type=medType, infoLabels=infoLab)
        li.setArt(setArt) 
        if contMenu:
            li.addContextMenuItems(cmItems, replaceItems=False)
        xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=url, listitem=li, isFolder=isF)
        
    def code_gen(self,x):
        base='0123456789abcdef'
        code=''
        for i in range(0,x):
            code+=base[random.randint(0,15)]
        return code
        
    def heaGen(self):
        CorrelationID='smarttv_'+self.code_gen(32)
        hea=self.hea
        hea.update({'API-CorrelationID':CorrelationID,'API-DeviceUid':self.addon.getSetting('DeviceUid')})
        if self.addon.getSetting('logged')=='true':
            hea.update({'API-Authentication':self.addon.getSetting('API_Authentication'),'API-ProfileUid':self.addon.getSetting('API_ProfileUid')})
        return hea
