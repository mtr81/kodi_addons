# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import json
import time
#import random
#import base64
from html import unescape
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.audio.jazzfm')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
PATH=addon.getAddonInfo('path')
imgPATH=PATH+'/resources/img/'
img_empty=imgPATH+'empty.png'
fanart=imgPATH+'fanart.jpg'
icon_main=PATH+'icon.png'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='https://podkasty.radiojazz.fm/'
hea={
    'User-Agent':UA,
}


def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(u):
    import inputstreamhelper
    PROTOCOL = 'hls'
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=u)
        play_item.setMimeType('application/x-mpegurl')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty('IsPlayable', 'true')
        play_item.setProperty('inputstream.adaptive.stream_headers','User-Agent='+UA+'&Referer='+baseurl)
        play_item.setProperty('inputstream.adaptive.manifest_headers','User-Agent='+UA+'&Referer='+baseurl)#K21
        play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def directPlayer(u):
    play_item = xbmcgui.ListItem(path=u)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)


def cleanTxt(t):
    return unescape(t)

def main_menu():
    resp=requests.get(baseurl,headers=hea).text
    resp1=resp.split('grid-cols-cards')[1].split('</main')[0].split('</a')
    for r in resp1:
        if 'href=' in r and '<img' in r:
            name,img=re.compile('alt=\"([^\"]+?)\" src=\"([^\"]+?)\"').findall(r)[0]
            link=re.compile('href=\"([^\"]+?)\"').findall(r)[0]
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            URL=build_url({'mode':'epList','link':link})
            addItemList(URL, cleanTxt(name), setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)
 
    
def epList(link):
    resp=requests.get(link,headers=hea).text
    resp1=resp.split('<main')[1].split('</main')[0].split('</article')
    for r in resp1:
        if 'play-episode-button' in r:
            r1=r.split('<relative-time')[1]
            date=re.compile('title=\"([^\"]+?)\"').findall(r1)[0]
            comment='[B]Data dodania:[/B] %s'%(date)
            
            dur=re.compile('datetime=\"PT([^\"]+?)S\"').findall(r)[0]
            
            r2=r.split('play-episode-button')[1]
            img=re.compile('imageSrc=\"([^\"]+?)\"').findall(r2)[0]
            title=re.compile('title=\"([^\"]+?)\"').findall(r2)[0]
            title=cleanTxt(title)
            link=re.compile('src=\"([^\"]+?)\"').findall(r2)[0]
            
            iL={'title':title,'comment':comment,'duration':int(float(dur)),'mediatype':'song'}
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
            URL=build_url({'mode':'playPodc','link':link})
            addItemList(URL, title, setArt, 'music', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'songs')
    xbmcplugin.endOfDirectory(addon_handle)    

def playPodc(link):
    stream_url=link+'|User-Agent='+UA
    directPlayer(stream_url)


mode = params.get('mode', None)

if not mode:
    main_menu()
else:
            
    if mode=='epList':
        link=params.get('link')
        epList(link)
        
    if mode=='playPodc':
        link=params.get('link')
        playPodc(link)
        