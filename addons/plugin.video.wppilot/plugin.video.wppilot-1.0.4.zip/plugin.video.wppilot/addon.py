# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.wppilot')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/empty.png'
fanart=''

mode = addon.getSetting('mode')
#UA='MMozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/110.0'
UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='https://pilot.wp.pl/'
deviceType='android_tv'#web
basevod='https://pilot.wp.pl/vod/'
platform='ANDROID_TV'#'BROWSER'

hea={
        'referer':baseurl,
        'User-Agent':UA,
        'content-type': 'application/json'
}
'''
cookies={
    'netviapisessid':'',
    'netviapisessval':'',
}
'''
def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        li.setInfo(type=medType, infoLabels=infoLab)#{'title': name,'sorttitle': name,'plot': plot}
    li.setArt(setArt) #{'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF) #build_url({'mode':'playSource','cid':cid})

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code

def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':
        items=[
            ['Lista kanałów','tvList','DefaultTVShows.png'],
            ['VOD','vod','DefaultAddonVideo.png'],
            ['Wyszukiwarka VOD','search','DefaultAddonsSearch.png'],
            ['Ulubione','favList','DefaultMusicRecentlyAdded.png'],
            ['Wyloguj','logOut','OverlayUnwatched.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','OverlayUnwatched.png']
        ]
    for i in items:
        setArt={'icon': i[2]}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)   

def logIn():
    password=addon.getSetting('password')
    username=addon.getSetting('username')
    if password!='' and username!='':
        url='https://pilot.wp.pl/api/v1/user_auth/login?device_type='+deviceType
        hea.update({'Referer':baseurl+'tv/'})
        data={
            "device": deviceType,
            "login": username,
            "password": password
        }
        resp=requests.Session().post(url,headers=hea,json=data)
        resp1=resp.json()
        if 'error' in resp1['_meta']:
            if resp1['_meta']['error']['name']=='login_incorrect_username_or_password':
                xbmcgui.Dialog().notification('WP Pilot', 'Złe dane logowania', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('WP Pilot', 'Nieokreslony błąd logowania: '+resp1['_meta']['error']['name'], xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        else:
            addon.setSetting('cookies',str(dict(resp.cookies)))
            addon.setSetting('AccInfo',resp1['data']['type'])
            packets()
            addon.setSetting('logged','true')
            
        
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Podaj login i hasło w Ustawieniach', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def packets():
    cookies=eval(addon.getSetting('cookies'))
    hea.update({'Referer':baseurl+'tv/'})
    url='https://pilot.wp.pl/api/v1/package_order?device_type='+deviceType
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    prods=[r['name'] for r in resp['data']]
    addon.setSetting('packets',str(prods))
    
def logOut():
    cookies=eval(addon.getSetting('cookies'))
    hea.update({'Referer':baseurl+'tv/'})
    url='https://pilot.wp.pl/api/v1/user_auth/logout?device_type='+deviceType
    resp=requests.Session().post(url,headers=hea,cookies=cookies).json()
    try:
        if resp['data']['status']=='ok':
            addon.setSetting('logged','false')
            addon.setSetting('cookies','')
            addon.setSetting('AccInfo','')
            addon.setSetting('packets','')
    except:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def relogin():#gdy wylogowano z poziomu innego urządzenia
    addon.setSetting('logged','false')
    addon.setSetting('cookies','')
    addon.setSetting('AccInfo','')
    addon.setSetting('packets','')
    logIn()
    #xbmcgui.Dialog().notification('WP Pilot', 'Przelogowano', xbmcgui.NOTIFICATION_INFO)
    
def locTime(x):
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    z=(y+diff+datetime.timedelta(seconds=1)).strftime('%H:%M')
    return z

def locTimeFull(x):
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%S%z')[0:6]))
    z=y.strftime('%Y-%m-%d %H:%M')
    return z
        
def getEPG(arCid):
    import math
    cnt=math.ceil(len(arCid)/20)
    chGroups=[]
    for i in range(0,cnt):
        chGroups.append(','.join(arCid[20*i:20*(i+1)]))
    epg={}
    for cg in chGroups:
        url='https://pilot.wp.pl/api/v2/epg?channels='+cg+'&limit=12&device_type=web'
        hea.update({'Referer':baseurl+'tv/'})
        cookies=eval(addon.getSetting('cookies'))
        resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
        for r in resp['data']:
            progs=''
            for e in r['entries']:
                ts=locTime(e['start'])
                #te=locTime(e['end'])
                title=e['title']
                categ=e['category']
                progs+='[B]%s[/B] %s [I](%s)[/I]\n'%(ts,title,categ)
            epg[str(r['channel_id'])]=progs
    return epg
                

def channels():
    url='https://pilot.wp.pl/api/v2/channels/list?device_type='+deviceType
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if 'error' in resp['_meta']:
        if resp['_meta']['error']['name']=='not_authorized':
            relogin()
            channels()#
        else:
            return False
    else:
        chans=[r for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        return chans

def tvList():
    #url='https://wp-pilot-gatsby.wpcdn.pl/v1.90.0-4421814/desktop/page-data/sq/d/1603732150.json'
    url='https://pilot.wp.pl/api/v2/channels/list?device_type='+deviceType
    cookies=eval(addon.getSetting('cookies')) if addon.getSetting('cookies')!='' else {}
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if 'error' in resp['_meta']:
        if resp['_meta']['error']['name']=='not_authorized':
            relogin()
            tvList()#
        else:
            xbmcplugin.endOfDirectory(addon_handle)
    else:
        accType=addon.getSetting('AccInfo')
        chans=[r for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        cids=[str(r['id']) for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        epg=getEPG(cids)
        for c in chans:
            name=c['name']
            img=c['icon']
            cid=str(c['id'])
            plot=epg[cid] if cid in epg else ''
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
            iL={'title': name,'sorttitle': name,'plot': plot}
            url=build_url({'mode':'playSource','cid':cid})
            addItemList(url, name, setArt, 'video', iL, isF=False, isPla='true')
        xbmcplugin.endOfDirectory(addon_handle)    

def closeStream(cid,sid):
    url='https://pilot.wp.pl/api/v1/channels/close?device_type='+deviceType
    hea.update({'Referer':baseurl+'tv/'})
    cookies=eval(addon.getSetting('cookies'))
    data={
        "channelId": cid,
        "t": sid
    }
    resp=requests.Session().post(url,headers=hea,cookies=cookies,json=data).json()

def playSource(c):
    url='https://pilot.wp.pl/api/v2/channel/%s?device_type=%s'%(c,deviceType)
    hea.update({'Referer':baseurl+'tv/'})
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if resp['data']==None:
        if resp['_meta']['error']['code']==300:
            closeStream(resp['_meta']['error']['info']['channel_id'],resp['_meta']['error']['info']['stream_token'])
            resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
        elif resp['_meta']['error']['name']=='not_authorized':
            relogin()
            playSource(c)#
        elif resp['_meta']['error']['name']=='user_channel_blocked':
            xbmcgui.Dialog().notification('WP Pilot', 'Kanał tymczasowo wyłączony przez nadawcę ze względów licencyjnych.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    if resp['data']!=None:
        drm=False
        custStream=False
        if resp['data']['stream_channel']['drms']!=None:
            try:
                stream_url=[r['url'] for r in resp['data']['stream_channel']['custom_streams'] if 'dash' in r['type']][0][0]
                custStream=True
            except:
                stream_url=[r['url'] for r in resp['data']['stream_channel']['streams'] if 'dash' in r['type']][0][0]
                   
            #weryfikacja czy manifest jest zabezpieczony DRM
            respDRM=requests.Session().get(stream_url,headers=hea).text
            if '<ContentProtection' in respDRM:
                protocol='mpd'
                drm=True
                licUrl=baseurl+resp['data']['stream_channel']['drms']['widevine']
                cookie='; '.join([str(x) + '=' + str(y) for x, y in cookies.items()])
                hea1={
                    'User-Agent':UA,
                    'referer':basevod,
                    'origin':'https://pilot.wp.pl/tv/',
                    'cookie':cookie,
                    'content-type':'',
                }
                heaLic=urlencode(hea1)
                xbmc.log('@#@z DRM, url_stream: %s' % (stream_url), xbmc.LOGINFO)
        
        if resp['data']['stream_channel']['drms']==None or drm==False:
            stream_url=[r['url'] for r in resp['data']['stream_channel']['streams'] if 'hls' in r['type']][0][0]
            protocol='hls'
            drm=False
            xbmc.log('@#@bez DRM, url_stream: %s' % (stream_url), xbmc.LOGINFO)
            
        if not resp['data']['stream_channel']['is_audio_only']:#TV
                                   
            import inputstreamhelper
            PROTOCOL = protocol#'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=stream_url)
                #play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+baseurl)
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
                #play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                if drm:
                    play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                    play_item.setProperty('inputstream.adaptive.license_key', licUrl+'|'+heaLic+'|R{SSM}|')
                          
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
                if not custStream and '.mpd' in stream_url:
                    xbmcgui.Dialog().notification('WP Pilot', 'Wyłączenie odtwarzacza za 3 minuty.', xbmcgui.NOTIFICATION_INFO)
                                
        else: #radio
            stream_url+='|User-Agent='+UA+'&Referer='+baseurl
            play_item = xbmcgui.ListItem(path=stream_url)
            play_item.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
        
        
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Brak źródła: '+resp['_meta']['error']['name'], xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

#VOD
def heaGen():
    CorrelationID='client_'+code_gen(8)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(12)
    hea.update({'API-CorrelationId':CorrelationID,'API-DeviceUid':addon.getSetting('DeviceUid'),'Referer':basevod})
    return hea
    
def sortMethod():
    sm=''
    m=addon.getSetting('sortContent')
    tb={
        'Ostatnio dodane':'sort=createdAt&order=desc',
        'Najnowsze':'sort=year&order=desc',
        'Najstarsze':'sort=year&order=asc',
        'A-Z':'sort=title&order=asc',
        'Z-A':'sort=title&order=desc'
    }
    return tb[m]

def titleWithTill(d,t):#data dostępności w tytule
    title=t
    tillPeriod=int(addon.getSetting('tillPeriod'))
    if 'Dostępny do: ' in d:
        till=re.compile('Dostępny do: (.*)').findall(d.replace('[/B]',''))[0]
        now=datetime.datetime.now()
        if (datetime.datetime(*(time.strptime(till,'%Y-%m-%d %H:%M')[0:6]))-now).days<=tillPeriod:
            title=t+' [COLOR=yellow]/do: '+till+'/[/COLOR]'
    return title    

mainCategs=[
    ['SERIALE','categList','33','DefaultAddonVideo.png'],
    ['FILMY','categList','17','DefaultAddonVideo.png'],
    ['PROGRAMY','categList','98','DefaultAddonVideo.png'],
    ['SPORT','categList','106','DefaultAddonVideo.png'],
    ['DLA DZIECI','categList','70','DefaultAddonVideo.png']
]

def vod():
    for s in mainCategs:
        setArt={'icon': s[3]}
        url=build_url({'mode':s[1],'mainCateg':s[2]})
        addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)
    
def categList(mc):
    u=basevod+'api/items/categories?mainCategoryId='+mc+'&lang=pl&platform='+platform
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.get(u,headers=hea_,cookies=cookies).json()
    arCateg=[['Wszystkie','all']]
    for c in resp:
        arCateg.append([c['name'],c['id']])
    for ac in arCateg:
        setArt={'icon': 'OverlayUnwatched.png'}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':str(ac[1]),'page':'1'})
        addItemList(url, ac[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def getImg(x):#
    if '16x9' in x:
        img=x['16x9'][0]['url']
    elif '4x3' in x:
        img=x['4x3'][0]['url']
    else:
        img=''
    if img.startswith('//'):
        img='https:'+img
    return img

def detCont(x):#
    plot=''
    if 'year' in x:
        plot+='[B]Rok prod.: [/B]'+str(x['year'])+'\n'
    if 'rating' in x:
        plot+='[B]Kat. wiekowa: [/B]'+str(x['rating'])+'\n'
    if 'displaySchedules' in x:
        if x['displaySchedules'][0]['type']!='SOON':
            '''
            if 'payable' in x:
                if x['payable']:
                    plot+='Płatny\n'
                else:
                    plot+='Bezpłatny\n'
            '''
            if 'since' in x:
                plot+='[B]Data publikacji: [/B]'+x['since'].split('T')[0]+'\n'
            '''
            if x['displaySchedules'][0]['type']=='PREMIERE':
                if 'till' in x['displaySchedules'][0]:
                    plot+='[B]Dostępny do: [/B]'+x['displaySchedules'][0]['till'].split('T')[0]+'\n'
                plot+='[COLOR=yellow]PRAPREMIERA[/COLOR]\n'
            else:
                if 'till' in x:
                    plot+='[B]Dostępny do: [/B]'+x['till'].split('T')[0]+'\n'
                if x['displaySchedules'][0]['type']=='LAST_BELL':
                    plot+='[COLOR=yellow]OSTATNIA SZANSA[/COLOR]\n'
            '''
            if 'till' in x['displaySchedules'][0]:
                plot+='[B]Dostępny do: [/B]'+locTimeFull(x['displaySchedules'][0]['till'])+'\n'
            if x['displaySchedules'][0]['type']=='LAST_BELL':
                plot+='[COLOR=yellow]OSTATNIA SZANSA[/COLOR]\n'
        else:
            plot+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
            plot+='[B]Dostępny od: [/B]'+locTimeFull(x['displaySchedules'][0]['till'])+'\n'
            '''
            if 'payableSince' in x:
                if x['displaySchedules'][0]['till'].split(' ')[0]==x['payableSince'].split('T')[0] :
                    plot+='Płatny\n'
                else:
                    plot+='Bezpłatny\n'
            else:
                plot+='Bezpłatny\n'
            '''
    if 'lead' in x:
        if x['lead']!='':
            plot+='[B]Opis: [/B][I]'+cleanText(x['lead'])+'[/I]'
    return plot

    
def contList(mc,c,p):
    cnt=addon.getSetting('epCount')
    start=(int(p)-1)*int(cnt)
    if c=='all':
        u=basevod+'api/products/vods?'+sortMethod()+'&firstResult='+str(start)+'&maxResults='+cnt+'&mainCategoryId[]='+mc+'&lang=pl&platform='+platform
    else:
        u=basevod+'api/products/vods?'+sortMethod()+'&firstResult='+str(start)+'&maxResults='+cnt+'&mainCategoryId[]='+mc+'&categoryId[]='+c+'&lang=pl&platform='+platform
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.get(u,headers=hea_,cookies=cookies).json()
    total=resp['meta']['totalCount']
    
    for r in resp['items']:
        cid=str(r['id'])
        name=r['title']
        type=r['type']
        img=getImg(r['images'])
        plot=''
        plot=detCont(r)#
        #tid=r['shareUrl'].replace(baseurl,'').replace(',','_').replace('-','_').replace('/','_')
        
        mod=''
        isPlayable='false'
        isFolder=True
        if type=='SERIAL':
            mod='sezonList'
            URL = build_url({'mode':mod,'cid':cid,'title':name})
        if type=='VOD':
            name=titleWithTill(plot,name)
            if addon.getSetting('playFromList')=='true':
                mod='playVid'
                URL = build_url({'mode':mod,'eid':cid})
                isPlayable='true'
                isFolder=False
            else:
                mod='progDetails'
                URL = build_url({'mode':mod,'eid':cid})
        
        if (type=='SERIAL' or type=='VOD') and r['displaySchedules'][0]['type']=='SOON':
            isPlayable='false'
            isFolder=False
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=favAdd&url='+quote(URL)+'&title='+quote(name)+'&cid='+quote(cid)+'&iL='+quote(str(iL))+'&img='+quote(img)+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&eid='+cid+')')
        ]
        addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, contMenu=True, cmItems=cmItems)
    
    if start+int(cnt)+1<total:
        name='[B]>>> Następna strona[/B]'
        setArt={'icon': img_empty}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':c,'page':str(int(p)+1)})
        addItemList(url, name, setArt)
    
    if addon.getSetting('playFromList')=='true':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)

def sezonList(cid,tit):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/products/vods/serials/'+cid+'/seasons?lang=pl&platform='+platform
    resp=requests.get(u,headers=hea_,cookies=cookies).json()
    if len(resp)==1: #jeden sezon
        sezId=str(resp[0]['id'])
        episodeList(cid,sezId,tit,'1','yes')
    else:
        for r in resp:
            sez_id=str(r['id'])
            sez_name=r['title']
            if sez_name=='':
                sez_name='sezon '+str(r['number'])
            
            setArt={}
            iL={'title': '','sorttitle': '','plot': tit}
            url = build_url({'mode':'episodeList','cid':cid,'sezId':sez_id,'title':tit,'init':'yes','page':'1'})
            addItemList(url, sez_name, setArt, 'video', iL)
        xbmcplugin.setContent(addon_handle, 'videos')
        xbmcplugin.endOfDirectory(addon_handle)

def episodeList(cid,sezId,tit,pg,init):
    cnt=int(addon.getSetting('epCount'))
    p=int(pg)
    if init=='yes':
        hea_=heaGen()
        cookies=eval(addon.getSetting('cookies'))
        u=basevod+'api/products/vods/serials/'+cid+'/seasons/'+sezId+'/episodes?lang=pl&platform='+platform
        resp=requests.get(u,headers=hea_,cookies=cookies).json()#list
        addon.setSetting('episodeJSON',str(resp))
    
    resp=eval(addon.getSetting('episodeJSON'))
    total=len(resp)
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        r=resp[i]
        eid=str(r['id'])
        title=''
        episode=r['number']
        '''
        season=r['season']['number']
        if season!='':
            title+='sezon '+str(season)+' '
        '''
        title+='odcinek '+str(episode)
        episodeName=r['title']
        if episodeName !='':
            title+=' | '+r['title']
        img=getImg(r['images'])
        #st=r['externalUid']
        
        plot='[B]'+tit+'[/B]\n'
        plot+=detCont(r)#próba
        
        mod=''
        isPlayable='false'
        isFolder=True
        if addon.getSetting('playFromList')=='true':
            mod='playVid'
            isPlayable='true'
            isFolder=False
        else:
            mod='progDetails'
        
        if r['displaySchedules'][0]['type']=='SOON':
            isPlayable='false'
            isFolder=False
               
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        name=titleWithTill(plot,title)
        URL=build_url({'mode':mod,'eid':eid})
        cmItems=[('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&eid='+eid+')')]
        addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, contMenu=True, cmItems=cmItems)
    
    if p<math.ceil(total/cnt):
        name='[B]>>> Następna strona[/B]'
        setArt={'icon': img_empty}
        url = build_url({'mode':'episodeList','init':'no','cid':cid,'sezId':sezId,'title':tit,'page':str(p+1)})
        addItemList(url, name, setArt)
    
    if addon.getSetting('playFromList')=='true':
        xbmcplugin.setContent(addon_handle, 'videos')
    
    xbmcplugin.endOfDirectory(addon_handle)
    xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
    #xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_PLAYLIST_ORDER)
        
def det(x):
    def iterTable(t,n):
        result=''
        for tt in t:
            result+=tt[n]+', '
        return result[:-2]
    
    title=''
    if x['type']=='EPISODE':
        episode=x['number']
        '''
        season=x['season']['number']
        if season!='':
            title+='sezon '+str(season)+' '
        '''
        title+='odcinek '+str(episode)
        episodeName=x['title']
        if episodeName !='':
            title+=' | '+x['title']
    else:
        title=x['title']
    img=getImg(x['images'])
    plot=title+'\n'
    if 'rating' in x:
        plot+='[B]Wiek: [/B]'+str(x['rating'])+'\n'
    if 'duration' in x:
        plot+='[B]Długość: [/B]'+str(int(x['duration']/60))+' min.\n'
    if 'year' in x:
        plot+='[B]Rok prod.: [/B]'+str(x['year'])+'\n'
    if 'countries' in x:#???
        plot+='[B]'+iterTable(x['countries'],'name')+'[/B]\n'
    if 'genres' in x:
        if len(x['genres']):
            plot+='[B]Gatunek[/B]: '+iterTable(x['genres'],'name')+'\n'
    if x['displaySchedules'][0]['type']!='SOON':
        '''
        if 'payable' in x:
            if x['payable']:
                plot+='Płatny\n'
            else:
                plot+='Bezpłatny\n'
        '''
        if 'since' in x:
                plot+='[B]Data publikacji: [/B]'+x['since'].split('T')[0]+'\n'
        if 'till' in x['displaySchedules'][0]:#2023-03-15
                plot+='[B]Dostępny do: [/B]'+locTimeFull(x['displaySchedules'][0]['till'])+'\n'
    else:
        plot+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
        plot+='[B]Dostępny od: [/B]'+locTimeFull(x['displaySchedules'][0]['till'])+'\n'
        '''
        if 'payableSince' in x:
            if x['displaySchedules'][0]['till'].split(' ')[0]==x['payableSince'].split(' ')[0] :
                plot+='Płatny\n'
            else:
                plot+='Bezpłatny\n'
        else:
            plot+='Bezpłatny\n'
        '''
    if 'description' in x:
        plot+='[B]Opis: [/B][I]'+cleanText(x['lead'])+'[/I]\n'
    if 'directors' in x:#???
        if len(x['directors']):
            plot+='[B]Reżyseria[/B]: '+iterTable(x['directors'],'name')+'\n'
    if 'actors' in x:#???
        if len(x['actors']):
            plot+='[B]Obsada[/B]: '+iterTable(x['actors'],'name')+'\n'
    if 'provider' in x:#???
        if 'name' in x['provider']:
            plot+='[B]Dystrybutor[/B]: '+x['provider']['name']+'\n'
                
    return title,img,plot
    
def showDet(eid):#menu kont
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/products/vods/'+eid+'?lang=pl&platform='+platform
    resp=requests.get(u,headers=hea_,cookies=cookies).json()
    title,img,plot=det(resp)
    
    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)
    
def progDetails(eid):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/products/vods/'+eid+'?lang=pl&platform='+platform
    resp=requests.get(u,headers=hea_,cookies=cookies).json()
    title,img,plot=det(resp)

    iL={'title': '','sorttitle': '','plot': plot}
    setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
    url = build_url({'mode':'playVid','eid':eid})
    addItemList(url, title, setArt, 'video', iL, False, 'true')
    
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def playVid(eid,resume):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))

    u=basevod+'api/products/vods/'+eid+'?lang=pl&platform='+platform
    resp=requests.get(u,headers=hea_,cookies=cookies).json()
    if 'bundles' not in resp and resp['type']=='EPISODE':
        serieId=resp['season']['serial']['id']
        u=basevod+'api/products/vods/serials/'+str(serieId)+'?lang=pl&platform='+platform
        resp=requests.get(u,headers=hea_,cookies=cookies).json()
    try:
        availPack=[r['title'] for r in resp['bundles']]
        availTest=False
        for a in availPack:
            if a in eval(addon.getSetting('packets')):
                availTest=True
        if availTest==False:
            xbmcgui.Dialog().notification('WP Pilot', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    except:
        xbmcgui.Dialog().notification('WP Pilot', 'Brak info o dostępności', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        u=basevod+'api/subscribers/detail?lang=pl&platform='+platform
        resp=requests.get(u,headers=hea_,cookies=cookies).json()
        #AUTH CHECK 1 ---> relogin
        if 'code' in resp:
            if resp['code']=='AUTHENTICATION_REQUIRED':
                relogin()
                #playVid(eid,resume)#
                cookies=eval(addon.getSetting('cookies'))
                resp=requests.get(u,headers=hea_,cookies=cookies).json()
        #AUTH CHECK 2 after relogin
        if 'code' in resp:
            if resp['code']=='AUTHENTICATION_REQUIRED':
                xbmcgui.Dialog().notification('WP Pilot', 'Brak dostępu - problem z autoryzacją', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        else:
            session_uid=resp['httpSession']['uid'] if 'httpSession' in resp else None
            if session_uid!=None:
            
                u=basevod+'api/products/'+eid+'/videos/playlist?platform='+platform+'&videoType=MOVIE'
                resp=requests.get(u,headers=hea_,cookies=cookies).json()
                protocol='mpd'
                stream_url=resp['sources']['DASH'][0]['src']
                if stream_url.startswith('//'):
                    stream_url='https:'+stream_url
                cookie='; '.join([str(x) + '=' + str(y) for x, y in cookies.items()])
                cookie+='; session_uid='+session_uid
                #cookie='netviapisessid='+cookies['netviapisessid']+'; netviapisessval='+cookies['netviapisessval']+'; session_uid='+session_uid
                hea1={
                    'User-Agent':UA,
                    'referer':basevod,
                    'origin':'https://pilot.wp.pl',
                    'cookie':cookie,
                    'content-type':'',
                }
                heaLic=urlencode(hea1)
                lic_url=resp['drm']['WIDEVINE']['src']+'|'+heaLic+'|R{SSM}|'#
                    
                #subt=resp['movie']['video']['subtitles']
                #subActive=False
                
               
                import inputstreamhelper
                PROTOCOL = protocol
                is_helper = inputstreamhelper.Helper(PROTOCOL)
                if is_helper.check_inputstream():
                    play_item = xbmcgui.ListItem(path=stream_url)
                    play_item.setMimeType('application/xml+dash')
                    play_item.setContentLookup(False)
                    play_item.setProperty('inputstream', is_helper.inputstream_addon)
                    play_item.setProperty("IsPlayable", "true")
                    play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                    play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+basevod) #K21
                    play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+basevod)
                    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                    if resume!=False: #start od wskazanego momentu (resume)
                        play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                        play_item.setProperty('ResumeTime', resume)
                        play_item.setProperty('TotalTime', '1')
                    '''
                    if 'pol' in subt:
                        if subt['pol']['default']==True:
                            play_item.setSubtitles([subt['pol']['src']])
                            subActive=True
                    '''        
                    #play_item.setSubtitles(sbt_src)
                    play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                    play_item.setProperty("inputstream.adaptive.license_key", lic_url)
                              
                    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
                    '''
                    if subActive==True:
                        while not xbmc.Player().isPlaying():
                            xbmc.sleep(100)
                        xbmc.Player().showSubtitles(True)
                    '''
            else:
                xbmcgui.Dialog().notification('WP Pilot', 'Brak session_uid', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def search():
    qry=xbmcgui.Dialog().input(u'Szukaj (przynajmniej 3 znaki):', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        hea_=heaGen()
        cookies=eval(addon.getSetting('cookies'))
        
        u_film=basevod+'api/products/vods/search/VOD?lang=pl&platform='+platform+'&keyword='+qry
        u_serial=basevod+'api/products/vods/search/SERIAL?lang=pl&platform='+platform+'&keyword='+qry
        u_odc=basevod+'api/products/vods/search/EPISODE?lang=pl&platform='+platform+'&keyword='+qry
        resp=requests.get(u_film,headers=hea_,cookies=cookies).json()['items']
        filmCount=str(len(resp))
        addon.setSetting('searchFilm',str(resp))
        resp=requests.get(u_serial,headers=hea_,cookies=cookies).json()['items']
        serialCount=str(len(resp))
        addon.setSetting('searchSerial',str(resp))
        resp=requests.get(u_odc,headers=hea_,cookies=cookies).json()['items']
        odcCount=str(len(resp))
        addon.setSetting('searchOdc',str(resp))
        s=[
            ['Filmy'+' ('+filmCount+')','searchFilm'],
            ['Seriale'+' ('+serialCount+')','searchSerial'],
            ['Odcinki'+' ('+odcCount+')','searchOdc']
        ]
        
        for ss in s:
            setArt={'icon': 'OverlayUnwatched.png'}
            url = build_url({'mode':'searchRes','cat':ss[1]})
            addItemList(url, ss[0], setArt) 
            
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        main_menu()
        
def searchRes(c):
    res=eval(addon.getSetting(c))
    for r in res:
        mod=''
        cid=''
        eid=''
        name=''
        title=''
        img=''
        plot=''
        isPlayable='false'
        isFolder=True
        if 'Serial' in c or 'Film' in c:
            cid=str(r['id'])
            eid=cid
            name=r['title']
            title=name
            type=r['type']
            img=getImg(r['images'])
            plot=detCont(r)
            
            if type=='SERIAL':
                mod='sezonList'
                URL=build_url({'mode':mod,'cid':cid,'title':name})
            if type=='VOD':
                title=titleWithTill(plot,title)
                if addon.getSetting('playFromList')=='true':
                    mod='playVid'
                    URL=build_url({'mode':mod,'eid':eid})
                    isPlayable='true'
                    isFolder=False
                else:
                    mod='progDetails'
                    URL=build_url({'mode':mod,'eid':eid})
        elif 'Odc' in c:
            eid=str(r['id'])
            title=r['fullTitle']
            epNumber=str(r['number'])if 'number' in r else ''
            sezNumber=''
            if 'season' in r:
                sezNumber=str(r['season']['number']) if 'number' in r['season'] else ''
            if epNumber!='' or sezNumber !='':
                title+=' | '
                if sezNumber !='':
                    title+='Sezon '+sezNumber
                if epNumber !='':
                    title+=' Odcinek '+epNumber
            img=getImg(r['images'])
            plot=detCont(r)
            title=titleWithTill(plot,title)
            
            if addon.getSetting('playFromList')=='true':
                mod='playVid'
                URL=build_url({'mode':mod,'eid':eid})
                isPlayable='true'
                isFolder=False
            else:
                mod='progDetails'
                URL=build_url({'mode':mod,'eid':eid})
        
        if r['displaySchedules'][0]['type']=='SOON':
            isPlayable='false'
            isFolder=False
        
        iL={'title': '','sorttitle': '','plot': plot}
        setArt={'thumb': '', 'poster': '', 'banner': '', 'icon': img, 'fanart':img}
        if 'Serial' in c or 'Film' in c:
            contMenu=True
            cmItems=[
                ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=favAdd&url='+quote(URL)+'&title='+quote(name)+'&cid='+quote(eid)+'&iL='+quote(str(iL))+'&img='+quote(img)+')'),
                ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&eid='+eid+')')
            ]
        else:
            contMenu=False
            cmItems=[]
        addItemList(URL, title, setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems) 
        
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)    


def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('WP Pilot', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('WP Pilot', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    if chans !=False:
        data = '#EXTM3U\n'
        for c in chans:
            name=c['name']
            img=c['icon']
            cid=str(c['id'])
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="WP Pilot" ,%s\nplugin://plugin.video.wppilot?mode=playSource&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('WP Pilot', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)

def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ').replace('&oacute;','ó').replace('&ouml;','ö').replace('&nbsp;',' ').replace('&ndash;',' - ')
    t=re.sub('<([^<]+?)>','',t)
    return t
    
#FAV
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)

def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        if 'playVid' in j[0]:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        contMenu=True
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=favDel&url='+quote(j[0])+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&cid='+quote(j[2])+')')
        ]
        setArt={'icon':j[4], 'fanart':j[4]}
        iL=eval(j[3])
        addItemList(j[0], j[1], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,c,l,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,c,l,i])
        xbmcgui.Dialog().notification('WP Pilot', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('WP Pilot', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('WP Pilot', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)

mode = params.get('mode', None)

if not mode:
    if addon.getSetting('DeviceUid')=='' or addon.getSetting('DeviceUid')==None:
        addon.setSetting('DeviceUid',code_gen(32))
    main_menu()
else:
    if mode=='logIn':
        logIn()
        if addon.getSetting('logged')=='true':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/,replace)')
    
    if mode=='logOut':
        logOut()
        if addon.getSetting('logged')=='false':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/,replace)')
    
    if mode=='tvList':
        tvList()
        
    if mode=='playSource':
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            playSource(cid)
        else:
            xbmcgui.Dialog().notification('WP Pilot', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
        
    if mode=='vod':
        vod()
    
    if mode=='categList':
        mc=params.get('mainCateg')
        categList(mc)
        
    if mode=='contList':
        mc=params.get('mainCateg')
        c=params.get('Categ')
        pg=params.get('page')
        contList(mc,c,pg)
        
    if mode=='sezonList':
        cid=params.get('cid')
        tit=params.get('title')
        sezonList(cid,tit)

    if mode=='episodeList':
        cid=params.get('cid')
        sezId=params.get('sezId')
        tit=params.get('title')
        pg=params.get('page')
        init=params.get('init')
        episodeList(cid,sezId,tit,pg,init)
    
    if mode=='showDet':
        eid=params.get('eid')
        showDet(eid)
    
    if mode=='progDetails':
        eid=params.get('eid')
        progDetails(eid)
    
    if mode=='playVid':
        eid=params.get('eid')
        playVid(eid,False)

    if mode=='search':
        search()
        
    if mode=='searchRes':
        c=params.get('cat')
        searchRes(c)
    
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('WP Pilot', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
    #FAV
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        c=params.get('cid')
        l=params.get('iL')
        i=params.get('img')
        favAdd(u,t,c,l,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
