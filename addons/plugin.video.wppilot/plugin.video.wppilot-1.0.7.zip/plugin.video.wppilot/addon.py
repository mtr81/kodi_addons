# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.wppilot')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='https://pilot.wp.pl/'
deviceType='android_tv'#web
basevod='https://pilot.wp.pl/vod/'
platform='ANDROID_TV'#'BROWSER'
vodUrlParams={
    'platform':platform,
    'lang':'POL'
}

hea={
        'referer':baseurl,
        'User-Agent':UA,
        'content-type': 'application/json'
}
'''
cookies={
    'netviapisessid':'',
    'netviapisessval':'',
}
'''
def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def ISAplayer(protocol,stream_url,hea_pla,lickey='',drm_conf={}):
    import inputstreamhelper
    PROTOCOL = protocol
    is_helper = inputstreamhelper.Helper(PROTOCOL)
    if is_helper.check_inputstream():
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setMimeType('application/xml+dash')
        play_item.setContentLookup(False)
        play_item.setProperty('inputstream', is_helper.inputstream_addon)
        play_item.setProperty('IsPlayable', 'true')
        play_item.setProperty('inputstream.adaptive.manifest_headers', hea_pla) #K21
        play_item.setProperty('inputstream.adaptive.stream_headers', hea_pla)
        if lickey!='':
            kodiVer=xbmc.getInfoLabel('System.BuildVersion')
            if int(kodiVer.split('.')[0])<22:
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                play_item.setProperty('inputstream.adaptive.license_key', lickey)
            else:
                play_item.setProperty('inputstream.adaptive.drm', json.dumps(drm_conf))
                  
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def directPlayer(stream_url):
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
    
def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code


def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':
        items=[
            ['Lista kanałów','tvList','DefaultTVShows.png'],
            ['VOD','vod','DefaultAddonVideo.png'],
            ['Wyszukiwarka VOD','search','DefaultAddonsSearch.png'],
            ['Ulubione','favList','DefaultMusicRecentlyAdded.png'],
            ['Wyloguj','logOut','DefaultUser.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','DefaultUser.png']
        ]
    for i in items:
        setArt={'icon': i[2],'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)   

def logIn():
    password=addon.getSetting('password')
    username=addon.getSetting('username')
    if password!='' and username!='':
        url='https://pilot.wp.pl/api/v1/user_auth/login?device_type='+deviceType
        hea.update({'Referer':baseurl+'tv/'})
        data={
            "device": deviceType,
            "login": username,
            "password": password
        }
        resp=requests.Session().post(url,headers=hea,json=data)
        resp1=resp.json()
        if 'error' in resp1['_meta']:
            if resp1['_meta']['error']['name']=='login_incorrect_username_or_password':
                xbmcgui.Dialog().notification('WP Pilot', 'Złe dane logowania', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('WP Pilot', 'Nieokreslony błąd logowania: '+resp1['_meta']['error']['name'], xbmcgui.NOTIFICATION_INFO)
                xbmc.log('@@@Błąd logowania: '+str(resp1), level=xbmc.LOGINFO)
        else:
            addon.setSetting('cookies',str(dict(resp.cookies)))
            addon.setSetting('AccInfo',resp1['data']['type'])
            packets()
            addon.setSetting('logged','true')
                
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Podaj login i hasło w Ustawieniach', xbmcgui.NOTIFICATION_INFO)

def packets():
    cookies=eval(addon.getSetting('cookies'))
    hea.update({'Referer':baseurl+'tv/'})
    url='https://pilot.wp.pl/api/v1/package_order?device_type='+deviceType
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    now=int(time.time())
    prods=[r['name'] for r in resp['data'] if r['ends_at']>now]
    addon.setSetting('packets',str(prods))
    
def logOut():
    cookies=eval(addon.getSetting('cookies'))
    hea.update({'Referer':baseurl+'tv/'})
    url='https://pilot.wp.pl/api/v1/user_auth/logout?device_type='+deviceType
    resp=requests.Session().post(url,headers=hea,cookies=cookies).json()
    try:
        if resp['data']['status']=='ok':
            addon.setSetting('logged','false')
            addon.setSetting('cookies','')
            addon.setSetting('AccInfo','')
            addon.setSetting('packets','')
    except:
        xbmc.log('@@@Błąd wylogowania: '+str(resp), level=xbmc.LOGINFO)

def relogin():#gdy wylogowano z poziomu innego urządzenia
    addon.setSetting('logged','false')
    addon.setSetting('cookies','')
    addon.setSetting('AccInfo','')
    addon.setSetting('packets','')
    logIn()
    xbmc.log('@@@Przelogowano', level=xbmc.LOGINFO)
    
def locTime(x): #TV
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    z=(y+diff+datetime.timedelta(seconds=1)).strftime('%H:%M')
    return z

def locTimeFull(x): #VOD
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%S%z')[0:6]))
    z=y.strftime('%Y-%m-%d %H:%M')
    return z
        
def getEPG(arCid):
    import math
    cnt=math.ceil(len(arCid)/20)
    chGroups=[]
    for i in range(0,cnt):
        chGroups.append(','.join(arCid[20*i:20*(i+1)]))
    epg={}
    for cg in chGroups:
        url='https://pilot.wp.pl/api/v2/epg?channels='+cg+'&limit=12&device_type=web'
        hea.update({'Referer':baseurl+'tv/'})
        cookies=eval(addon.getSetting('cookies'))
        resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
        for r in resp['data']:
            progs=''
            for e in r['entries']:
                ts=locTime(e['start'])
                #te=locTime(e['end'])
                title=e['title']
                categ=e['category']
                progs+='[B]%s[/B] %s [I](%s)[/I]\n'%(ts,title,categ)
            epg[str(r['channel_id'])]=progs
    return epg

def channels():
    url='https://pilot.wp.pl/api/v3/channels/list?device_type='+deviceType #v2
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if 'error' in resp['_meta']:
        if resp['_meta']['error']['name']=='not_authorized':
            relogin()
            channels()#
        else:
            return False
    else:
        chans=[r for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        return chans

def tvList():
    url='https://pilot.wp.pl/api/v3/channels/list?device_type='+deviceType #v2
    cookies=eval(addon.getSetting('cookies')) if addon.getSetting('cookies')!='' else {}
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if 'error' in resp['_meta']:
        if resp['_meta']['error']['name']=='not_authorized':
            relogin()
            tvList()#
        else:
            xbmcplugin.endOfDirectory(addon_handle)
    else:
        accType=addon.getSetting('AccInfo')
        chans=[r for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        cids=[str(r['id']) for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        epg=getEPG(cids)
        for c in chans:
            name=c['name']
            img=c['icon']['dark']
            cid=str(c['id'])
            plot=epg[cid] if cid in epg else ''
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
            iL={'title': name,'sorttitle': name,'plot': plot}
            url=build_url({'mode':'playSource','cid':cid})
            addItemList(url, name, setArt, 'video', iL, isF=False, isPla='true')
        
        xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
        xbmcplugin.endOfDirectory(addon_handle)    

def closeStream():
    url='https://pilot.wp.pl/api/v2/channels/close?device_type='+deviceType #v1
    hea.update({'Referer':baseurl+'tv/'})
    cookies=eval(addon.getSetting('cookies'))
    '''
    data={
        "channelId": cid,
        "t": sid
    }
    '''
    data={
        'token':addon.getSetting('playerToken')
    }
    resp=requests.Session().post(url,headers=hea,cookies=cookies,json=data).json()

def playSource(c):
    closeStream()
    deviceType='web'
    url='https://pilot.wp.pl/api/v3/channel/%s?device_type=%s'%(c,deviceType) #v2
    hea.update({'Referer':baseurl+'tv/'})
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if resp['data']==None:
        if resp['_meta']['error']['code']==300:
            closeStream(resp['_meta']['error']['info']['stream_token'])
            resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
        elif resp['_meta']['error']['name']=='not_authorized':
            relogin()
            playSource(c)#
        elif resp['_meta']['error']['name']=='user_channel_blocked':
            xbmcgui.Dialog().notification('WP Pilot', 'Kanał tymczasowo wyłączony przez nadawcę ze względów licencyjnych.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    if resp['data']!=None:
        addon.setSetting('playerToken',resp['data']['token'])
        lickey=''
        drm_config={}
        
        custStream=False
        if resp['data']['stream_channel']['drms']!=None:
            try:
                stream_url=[r['url'] for r in resp['data']['stream_channel']['custom_streams'] if 'dash' in r['type']][0][0]
                custStream=True
            except:
                stream_url=[r['url'] for r in resp['data']['stream_channel']['streams'] if 'dash' in r['type']][0][0]
                  
            #weryfikacja czy manifest jest zabezpieczony DRM
            respDRM=requests.Session().get(stream_url,headers=hea).text
            if '<ContentProtection' in respDRM:
                protocol='mpd'
                licUrl=baseurl[:-1]+resp['data']['stream_channel']['drms']['widevine']
                cookie='; '.join([str(x) + '=' + str(y) for x, y in cookies.items()])
                hea1={
                    'User-Agent':UA,
                    'Referer':basevod,
                    'Origin':'https://pilot.wp.pl/tv/',
                    'Cookie':cookie,
                    'Content-Type':''
                }
                heaLic=urlencode(hea1)
                lickey='%s|%s|%s|'%(licUrl,heaLic,'R{SSM}')
                #K22
                drm_config={
                    "com.widevine.alpha": {
                        "license": {
                            "server_url": licUrl,
                            "req_headers": heaLic
                        }
                    }
                }
                xbmc.log('@#@z DRM, url_stream: %s' % (stream_url), xbmc.LOGINFO)
        
        if resp['data']['stream_channel']['drms']==None or lickey=='':
            stream_url=[r['url'] for r in resp['data']['stream_channel']['streams'] if 'hls' in r['type']][0][0]
            protocol='hls'
            xbmc.log('@#@bez DRM, url_stream: %s' % (stream_url), xbmc.LOGINFO)
            
        if not resp['data']['stream_channel']['is_audio_only']:#TV
            
            if not custStream and '.mpd' in stream_url and 'tvnplayer' not in stream_url:
                #proxy -> wymiana tokena w segmentach AV
                proxyport = addon.getSetting('proxyport') #proxy
                stream_url='http://127.0.0.1:%s/MANIFEST='%(str(proxyport))+stream_url #proxy
                xbmc.log('@@@proxy - wymiana tokena w segmentach AV (strumienie DASH z videostar)', level=xbmc.LOGINFO)
            
            hea_pla='User-Agent='+UA+'&Referer='+baseurl
            
            ISAplayer(protocol,stream_url,hea_pla,lickey,drm_config)
                
        else: #radio
            stream_url+='|User-Agent='+UA+'&Referer='+baseurl
            directPlayer(stream_url)
    
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Brak źródła: '+resp['_meta']['error']['name'], xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

#VOD
def heaGen():
    CorrelationID='client_'+code_gen(8)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(12)
    hea.update({'API-CorrelationId':CorrelationID,'API-DeviceUid':addon.getSetting('DeviceUid'),'Referer':basevod})
    return hea

sortMeths={
    'Ostatnio dodane':{'sort':'createdAt','order':'desc'},
    'Najnowsze':{'sort':'year','order':'desc'},
    'Najstarsze':{'sort':'year','order':'asc'},
    'A-Z':{'sort':'title','order':'asc'},
    'Z-A':{'sort':'title','order':'desc'}
}
    
def titleWithTill(d,t):#data dostępności w tytule
    title=t
    if 'LAST_BELL' in d:
        title=t+' [COLOR=yellow]/do: '+d.split('|')[1]+'/[/COLOR]'
    if 'SOON' in d:
        title='[COLOR=gray]%s[/COLOR]'%(title)

    return title

mainCategs=[
    ['SERIALE','categList','33','DefaultAddonVideo.png'],
    ['FILMY','categList','17','DefaultAddonVideo.png'],
    ['PROGRAMY','categList','98','DefaultAddonVideo.png'],
    ['SPORT','categList','106','DefaultAddonVideo.png'],
    ['DLA DZIECI','categList','70','DefaultAddonVideo.png']
]

def vod():
    for s in mainCategs:
        setArt={'icon': s[3],'fanart':fanart}
        url=build_url({'mode':s[1],'mainCateg':s[2]})
        addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)
    
def categList(mc):
    u=basevod+'api/items/categories'
    hea_=heaGen()
    vodUrlParams.update({'mainCategoryId':mc})
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    arCateg=[['Wszystkie','all']]
    for c in resp:
        arCateg.append([c['name'],c['id']])
    for ac in arCateg:
        setArt={'icon': 'DefaultGenre.png','fanart':fanart}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':str(ac[1]),'page':'1'})
        addItemList(url, ac[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def getImg(x):#helper
    if '16x9' in x:
        img=x['16x9'][0]['templateUrl']
    elif '4x3' in x:
        img=x['4x3'][0]['templateUrl']
    else:
        img=''
    if img!='':
        img=img.format(width=1024,height=576).replace(' ','')
        
    if img.startswith('//'):
        img='https:'+img
    return img

def convDate(d,f='%Y-%m-%d %H:%M',str=True): #helper
    date=datetime.datetime(*(time.strptime(d,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    
    is_dst = time.daylight and time.localtime().tm_isdst
    offset = time.altzone if is_dst else time.timezone
    
    dateLoc=date-datetime.timedelta(seconds=offset)
    res=dateLoc.strftime(f) if str else dateLoc
    
    return res
    

def detCont(x):#helper
    #types: VOD,SERIAL,EPISODE,PROGRAMME
    title=x['title'] 
    year=x['year'] if 'year' in x else 0
    rating=str(x['rating']) if 'rating' in x else ''
    ep=0
    if x['type']=='EPISODE':
        ep=x['number'] if 'episode' in x else 0
    elif x['type']=='PROGRAMME':
        if 'episode' in x:
            ep=x['episode']['number']
    if 'season' in x:
        seas=x['season']['number'] if x['type']=='EPISODE' else 0
    else:
        seas=0
    desc=cleanText(x['lead']) if 'lead' in x else ''
    dur=x['duration'] if 'duration' in x else 0
    
    country=[c['name'] for c in x['countries']] if 'countries' in x else []
    actors=[c['name'] for c in x['actors']] if 'actors' in x else []
    directors=[c['name'] for c in x['directors']] if 'directors' in x else []
    scriptwriters=[c['name'] for c in x['scriptwriters']] if 'scriptwriters' in x else []
    genre=[c['name'] for c in x['genres']] if 'genres' in x else []

    
    #dostępność
    packets=''
    if 'bundles' in x:
        packets=', '.join([r['title'] for r in x['bundles']])
    
    avail=''
    availLabel=''
    if 'displaySchedules' in x:
        i_cur=0#[i for i,t in enumerate(x['displaySchedules']) if t['active'] ][0]
        
        if x['displaySchedules'][i_cur]['type']!='SOON':
            if 'payable' in x:
                if x['payable']:
                    avail+='[COLOR=yellow]Płatny[/COLOR]\n'
                    if packets!='':
                        avail+='[B]Pakiety: [/B]%s\n'%(packets)
                else:
                    if x['type']=='VOD' or x['type']=='EPISODE':
                        avail+='[B][COLOR=yellow]Bezpłatny\n[/COLOR][/B]'
                        if 'payableSince' in x:
                            avail+='[COLOR=yellow]do: %s\n[/COLOR]'%(x['payableSince'])

            if 'since' in x['displaySchedules'][i_cur]:
                avail+='[B]Data publikacji: [/B]'+x['displaySchedules'][i_cur]['since'].split('T')[0]+'\n'
            
            if x['displaySchedules'][i_cur]['type']=='PREMIERE':
                if 'till' in x['displaySchedules'][i_cur]:
                    avail+='[B]Dostępny do: [/B]'+locTimeFull(x['displaySchedules'][i_cur]['till'])+'\n'
                avail+='[COLOR=yellow]PRAPREMIERA[/COLOR]\n'
            else:
                if 'till' in x['displaySchedules'][i_cur]:
                    avail+='[B]Dostępny do: [/B]'+locTimeFull(x['displaySchedules'][i_cur]['till'])+'\n'
                if x['displaySchedules'][i_cur]['type']=='LAST_BELL':
                    availLabel='LAST_BELL|'+locTimeFull(x['displaySchedules'][i_cur]['till'])
                    avail+='[COLOR=yellow]OSTATNIA SZANSA[/COLOR]\n'
            
        else:
            availLabel='SOON'
            if 'till' in x['displaySchedules'][i_cur]:
                avail+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
                avail+='[B]Dostępny od: [/B]'+locTimeFull(x['displaySchedules'][i_cur]['till'])+'\n'
    else:
        if x['type']=='PROGRAMME':
            now=datetime.datetime.now()
            since=convDate(x['till'])
            dateSince=convDate(x['till'],str=False)
            if now<dateSince:
                availLabel='SOON'
            
            if 'catchupTill' in x:
                till=convDate(x['catchupTill'])
                avail='[B]Dostępny od: [/B]%s\n[B]Dostępny do: [/B]%s\n'%(since,till)               
                
                dateTill=convDate(x['catchupTill'],str=False)
                if (dateTill-now).total_seconds()<3*24*60*60 and now<dateTill:
                    availLabel='LAST_BELL|'+till
            
    desc=avail+desc
    
    #Dostawca
    if 'live' in x:
        provider=x['live']['title']
        desc='[B]Kanał: [/B][COLOR=cyan]%s[/COLOR]\n'%(provider)+desc
    
    iL={}
    if x['type'] in ['EPISODE','PROGRAMME']:
        iL={'title': title,'sorttitle': title,'mpaa':rating,'plot': desc,'year':year,'duration':dur,'episode':ep,'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'season':seas,'genre':genre,'mediatype':'episode'} #'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'season':seas,'genre':genre
    elif x['type'] in ['VOD','SERIAL']:
        iL={'title': title,'sorttitle': title,'mpaa':rating,'plot': desc,'year':year,'duration':dur,'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'genre':genre,'mediatype':'movie'} #'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'genre':genre
        if x['type']=='SERIAL':
            iL['mediatype']='tvshow'
    else:
        iL={'plot':title}

    return iL,availLabel

def addContToList(r): #2024-05-28
    isShow=True
    
    cid=str(r['id'])
    name=r['title']
    type=r['type']
    img=getImg(r['images'])
    iL,availLabel=detCont(r)
    mod=''
    isPlayable='false'
    isFolder=True
        
    if type=='SERIAL':
        mod='sezonList'
        URL = build_url({'mode':mod,'cid':cid,'title':name})
    
    elif type=='VOD':
        name=titleWithTill(availLabel,name)
        
        mod='playVid'
        URL = build_url({'mode':mod,'eid':cid,'ct':'VOD'})
        isPlayable='true'
        isFolder=False

    elif type=='EPISODE':
        name=''
        episode=r['number']
        name+='odcinek '+str(episode)
        episodeName=r['title']
        if episodeName !='':
            name+=' | '+r['title']
        
        name=titleWithTill(availLabel,name)
        mod='playVid'
        URL = build_url({'mode':mod,'eid':cid,'ct':'EPISODE'})
        isPlayable='true'
        isFolder=False
    
    elif type=='PROGRAMME':
        name=r['title']
        episode=r['episodeNumber'] if 'episodeNumber' in r else None
        if episode!=None:
            name+=' odcinek %s'%(str(episode))
        
        name=titleWithTill(availLabel,name)
        mod='playVid'
        URL = build_url({'mode':mod,'eid':cid,'ct':'PROGRAMME'})
        isPlayable='true'
        isFolder=False
    
    if type in ['SERIAL','VOD','EPISODE','PROGRAMME'] and availLabel=='SOON':#r['displaySchedules'][i_cur]['type']=='SOON':
        isPlayable='false'
        isFolder=False
        URL = build_url({'mode':'noPlay'})
    
    xbmcplugin.setContent(addon_handle, 'videos')
    
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':img}
    
    cmItems = []
    if type in ['SERIAL','VOD','EPISODE','PROGRAMME']:
        cmItems=[
            ('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=favAdd&url='+quote(URL)+'&title='+quote(name)+'&cid='+quote(cid)+'&iL='+quote(str(iL))+'&img='+quote(img)+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&eid='+cid+'&ct='+type+')')
        ]
      
    if isShow:
        addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)

def setSortMeth():
    sortMeth=addon.getSetting('sortMeth')
    sortMeth='Ostatnio dodane' if sortMeth=='' else sortMeth
    
    labs=list(sortMeths)
    
    select=xbmcgui.Dialog().select('Sortuj wg:', labs)
    if select>-1:
        new_sm=labs[select]
    else:
        new_sm=sortMeth
    
    if new_sm!=sortMeth:
        addon.setSetting('sortMeth',new_sm)
        xbmc.executebuiltin('Container.Refresh()')
    
def contList(mc,c,p):
    sortMeth=addon.getSetting('sortMeth')
    sortMeth='Ostatnio dodane' if sortMeth=='' else sortMeth
    #wybór metody sortowania
    if p=='1':
        tit='[COLOR=cyan][B] Sortowanie: [/B][/COLOR]%s'%(sortMeth)
        url=build_url({'mode':'setSortMeth'})
        img='DefaultMusicPlaylists.png'
        setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': fanart}
        addItemList(url, tit, setArt, isF=False)

    cnt=addon.getSetting('epCount')
    start=(int(p)-1)*int(cnt)
    vodUrlParams.update({
        'firstResult':str(start),
        'maxResults':cnt,
        'mainCategoryId[]':mc
    })
    vodUrlParams.update(sortMeths[sortMeth])
    if c!='all':
        vodUrlParams['categoryId[]']=c
    
    if mc=='33':
        vodUrlParams['itemType[]']='SERIAL'
    elif mc=='17':
        vodUrlParams['itemType[]']=['PROGRAMME','VOD']
    elif mc in ['98','106','70']:
        vodUrlParams['itemType[]']=['PROGRAMME','VOD','SERIAL']
        
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/items'#'api/products/vods'
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    total=resp['meta']['totalCount']
    
    for r in resp['items']:
        addContToList(r)
        
    if start+int(cnt)+1<total:
        name='[COLOR=cyan][B]>>> Następna strona[/B][/COLOR]'
        setArt={'icon': img_empty,'fanart':fanart}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':c,'page':str(int(p)+1)})
        addItemList(url, name, setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)

def sezonList(cid,tit):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/products/vods/serials/'+cid+'/seasons'
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    '''
    if len(resp)==1: #jeden sezon
        sezId=str(resp[0]['id'])
        episodeList(cid,sezId,tit,'1','yes')
    else:
    '''
    for r in resp:
        sez_id=str(r['id'])
        sez_name=r['title']
        if sez_name=='':
            sez_name='sezon '+str(r['number'])
        
        setArt={'icon':'DefaultAddonVideo.png','fanart':fanart}
        iL={'title': '','sorttitle': '','plot': tit}
        url = build_url({'mode':'episodeList','cid':cid,'sezId':sez_id,'title':tit,'init':'yes','page':'1'})
        addItemList(url, sez_name, setArt, 'video', iL)
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def episodeList(cid,sezId,tit,pg,init):
    cnt=int(addon.getSetting('epCount'))
    p=int(pg)
    if init=='yes':
        hea_=heaGen()
        cookies=eval(addon.getSetting('cookies'))
        u=basevod+'api/products/vods/serials/'+cid+'/seasons/'+sezId
        u_ep=u+'/episodes'
        resp=requests.get(u_ep,headers=hea_,cookies=cookies,params=vodUrlParams).json()#list
        if len(resp)==0:
            u_prog=u+'/programmes'
            resp=requests.get(u_prog,headers=hea_,cookies=cookies,params=vodUrlParams).json()#list
        saveF(PATH_profile+'/episodeJSON.txt',str(resp))
    
    resp=eval(openF(PATH_profile+'/episodeJSON.txt'))
    total=len(resp)
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        addContToList(resp[i])
        
    if p<math.ceil(total/cnt):
        name='[B]>>> Następna strona[/B]'
        setArt={'icon': img_empty,'fanart':fanart}
        url = build_url({'mode':'episodeList','init':'no','cid':cid,'sezId':sezId,'title':tit,'page':str(p+1)})
        addItemList(url, name, setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)
            
def showDet(eid,ct):#menu kont
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    if ct=='PROGRAMME':
        u=basevod+'api/products/lives/programmes/'+eid
    else:
        u=basevod+'api/products/vods/'+eid
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    iL,availLabel=detCont(resp)
    
    plot=''
    if iL['mediatype']=='episode':
        if iL['season']!=0:
            plot+='[B]Sezon:[/B] %s\n'%(str(iL['season']))
        plot+='[B]Odcinek:[/B] %s\n'%(str(iL['episode']))
    if iL['year']!=0:
        plot+='[B]Rok prod:[/B] %s\n'%(str(iL['year']))
    if len(iL['country'])>0:
        plot+='[B]Kraj:[/B] %s\n'%(', '.join(iL['country']))
    if len(iL['genre'])>0:
        plot+='[B]Gatunek:[/B] %s\n'%(', '.join(iL['genre']))
    if iL['duration']!=0:
        plot+='[B]Czas:[/B] %s min.\n'%(str(int(iL['duration']/60)))
    if iL['mpaa']!='':
        plot+='[B]Ograniczenia wiekowe:[/B] %s lat\n'%(str(iL['mpaa']))

    if len(iL['cast'])>0:
        plot+='[B]Obsada:[/B] %s\n'%(', '.join(iL['cast']))
    if len(iL['director'])>0:
        plot+='[B]Reżyseria:[/B] %s\n'%(', '.join(iL['director']))
    if len(iL['writer'])>0:
        plot+='[B]Scenariusz:[/B] %s\n'%(', '.join(iL['writer']))

    plot+=iL['plot']

    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)

def playVid(eid,ct,resume):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/subscribers/detail'
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    #AUTH CHECK 1 ---> relogin
    if 'code' in resp:
        if resp['code']=='AUTHENTICATION_REQUIRED':
            relogin()
            #playVid(eid,resume)#
            cookies=eval(addon.getSetting('cookies'))
            resp=requests.get(u,headers=hea_,cookies=cookies).json()
    #AUTH CHECK 2 after relogin
    if 'code' in resp:
        if resp['code']=='AUTHENTICATION_REQUIRED':
            xbmcgui.Dialog().notification('WP Pilot', 'Brak dostępu - problem z autoryzacją', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    else:
        #ver dostępności
        if ct=='PROGRAMME':
            u=basevod+'api/subscribers/products/lives/programmes/'+eid
            resp2=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
            if 'code' in resp2:
                xbmcgui.Dialog().notification('WP Pilot', 'Błąd odtwarzania: '+resp2['code'], xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                return
            if not resp2['available']:
                xbmcgui.Dialog().notification('WP Pilot', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                return
            
            if not resp2['catchupAvailable']:
                xbmcgui.Dialog().notification('WP Pilot', 'Nagranie niedostępne', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                return
            
            u=basevod+'api/products/lives/programmes/'+eid
            resp2=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
            pid=str(resp2['programRecordingId'])
        else:
            u=basevod+'api/products/vods/'+eid
            resp2=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
            #print(resp)
            
            if 'bundles' not in resp2 and resp2['type']=='EPISODE':
                serieId=resp2['season']['serial']['id']
                u=basevod+'api/products/vods/serials/'+str(serieId)
                resp2=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
            
            availTest=True
            if 'bundles' in resp2:
                packets()
                availPack=[r['title'] for r in resp2['bundles']]
                availTest=False
                for a in availPack:
                    if a in eval(addon.getSetting('packets')):
                        availTest=True
            if availTest==False:
                xbmcgui.Dialog().notification('WP Pilot', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
                return
            else:
                pid=eid
        
        session_uid=resp['httpSession']['uid'] if 'httpSession' in resp else None
        if session_uid!=None:
        
            u=basevod+'api/products/'+pid+'/videos/playlist'
            contType='CATCHUP' if ct=='PROGRAMME' else 'MOVIE'
            paramsURL={'videoType':contType}
            paramsURL.update(vodUrlParams)
            resp=requests.get(u,headers=hea_,cookies=cookies,params=paramsURL).json()
            #print(resp)
            protocol='mpd'
            stream_url=resp['sources']['DASH'][0]['src']
            if stream_url.startswith('//'):
                stream_url='https:'+stream_url
            cookie='; '.join([str(x) + '=' + str(y) for x, y in cookies.items()])
            cookie+='; session_uid='+session_uid
            #cookie='netviapisessid='+cookies['netviapisessid']+'; netviapisessval='+cookies['netviapisessval']+'; session_uid='+session_uid
            hea1={
                'User-Agent':UA,
                'Referer':basevod,
                'Origin':'https://pilot.wp.pl',
                'Cookie':cookie,
                'Content-Type':''
            }
            licurl=resp['drm']['WIDEVINE']['src']
            heaLic=urlencode(hea1)
            lickey='%s|%s|%s|'%(licurl,heaLic,'R{SSM}')
            
            #K22
            drm_config={
                "com.widevine.alpha": {
                    "license": {
                        "server_url": licurl,
                        "req_headers": heaLic
                    }
                }
            }
                            
            hea_pla='User-Agent='+UA+'&Referer='+basevod
            
            ISAplayer(protocol,stream_url,hea_pla,lickey,drm_config)
            
        else:
            xbmcgui.Dialog().notification('WP Pilot', 'Brak session_uid', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def searchRes(qry):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    vodUrlParams['keyword']=qry
    
    #seriale
    u=basevod+'api/products/vods/search/SERIAL'
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    countS=0
    if 'items' in resp:
        countS=len(resp['items'])
        saveF(PATH_profile+'searchSerial.txt',str(resp['items']))
    
    #Catchup
    vodUrlParams['catchup']=True
    u=basevod+'api/products/lives/programmes/search'
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    countC=0
    if 'items' in resp:
        countC=len(resp['items'])
        saveF(PATH_profile+'searchCatchup.txt',str(resp['items']))
        
    menu=[
        ['Seriale','Serial',countS],
        ['Catch-ups','Catchup',countC],
    ]
    for m in menu:
        if m[2]>0:
            img='DefaultGenre.png'
            title='%s [I](%s)[/I]'%(m[0],str(m[2]))
            setArt={'icon': img,'fanart':fanart}
            url = build_url({'mode':'searchContList','ct':m[1]})
            addItemList(url, title, setArt)
    
    xbmcplugin.endOfDirectory(addon_handle)
           
def searchContList(t):
    items=eval(openF('%ssearch%s.txt'%(PATH_profile,t)))
    for i in items:
        addContToList(i)
    
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)
    


def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('WP Pilot', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('WP Pilot', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    if chans !=False:
        data = '#EXTM3U\n'
        for c in chans:
            name=c['name']
            img=c['icon']['dark']
            cid=str(c['id'])
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="WP Pilot" ,%s\nplugin://plugin.video.wppilot?mode=playSource&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('WP Pilot', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)

def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ').replace('&oacute;','ó').replace('&ouml;','ö').replace('&nbsp;',' ').replace('&ndash;',' - ')
    t=re.sub('<([^<]+?)>','',t)
    return t
    
#FAV
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)

def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        if 'playVid' in j[0]:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        contMenu=True
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=favDel&url='+quote(j[0])+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&cid='+quote(j[2])+')')
        ]
        setArt={'icon':j[4], 'fanart':j[4]}
        iL=eval(j[3])
        addItemList(j[0], j[1], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,c,l,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,c,l,i])
        xbmcgui.Dialog().notification('WP Pilot', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('WP Pilot', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('WP Pilot', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)

mode = params.get('mode', None)

if not mode:
    if addon.getSetting('DeviceUid')=='' or addon.getSetting('DeviceUid')==None:
        addon.setSetting('DeviceUid',code_gen(32))
    main_menu()
else:
    if mode=='logIn':
        logIn()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/,replace)')
    
    if mode=='logOut':
        logOut()
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/,replace)')
    
    if mode=='tvList':
        tvList()
        
    if mode=='playSource':
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            playSource(cid)
        else:
            xbmcgui.Dialog().notification('WP Pilot', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
        
    if mode=='vod':
        vod()
    
    if mode=='categList':
        mc=params.get('mainCateg')
        categList(mc)
    
    if mode=='setSortMeth':
        setSortMeth()
    
    if mode=='contList':
        mc=params.get('mainCateg')
        c=params.get('Categ')
        pg=params.get('page')
        contList(mc,c,pg)
        
    if mode=='sezonList':
        cid=params.get('cid')
        tit=params.get('title')
        sezonList(cid,tit)

    if mode=='episodeList':
        cid=params.get('cid')
        sezId=params.get('sezId')
        tit=params.get('title')
        pg=params.get('page')
        init=params.get('init')
        episodeList(cid,sezId,tit,pg,init)
    
    if mode=='showDet':
        eid=params.get('eid')
        ct=params.get('ct')
        showDet(eid,ct)

    if mode=='playVid':
        eid=params.get('eid')
        ct=params.get('ct')
        playVid(eid,ct,False)
        
    if mode=='noPlay':
        pass

    if mode=='search':   
        query = xbmcgui.Dialog().input('Szukaj (przynajmniej 3 znaki):', type=xbmcgui.INPUT_ALPHANUM)
        xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
        if query:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/?mode=searchRes&q='+query+')')
        else:
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/,replace)')
    
    if mode=='searchRes':
        q=params.get('q')
        searchRes(q)
        
    if mode=='searchContList':
        ct=params.get('ct')
        searchContList(ct)
    
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('WP Pilot', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
    #FAV
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        c=params.get('cid')
        l=params.get('iL')
        i=params.get('img')
        favAdd(u,t,c,l,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
