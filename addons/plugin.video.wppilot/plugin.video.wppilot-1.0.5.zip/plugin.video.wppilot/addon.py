# -*- coding: utf-8 -*-
import os
import sys

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import re
import base64
import json
import random
import time
import datetime
import math
from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
params = dict(parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon(id='plugin.video.wppilot')

PATH=addon.getAddonInfo('path')
PATH_profile=xbmcvfs.translatePath(addon.getAddonInfo('profile'))
if not xbmcvfs.exists(PATH_profile):
    xbmcvfs.mkdir(PATH_profile)
img_empty=PATH+'/resources/img/empty.png'
fanart=PATH+'/resources/img/fanart.jpg'

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'
baseurl='https://pilot.wp.pl/'
deviceType='android_tv'#web
basevod='https://pilot.wp.pl/vod/'
platform='ANDROID_TV'#'BROWSER'
vodUrlParams={
    'platform':platform,
    'lang':'pl'
}

hea={
        'referer':baseurl,
        'User-Agent':UA,
        'content-type': 'application/json'
}
'''
cookies={
    'netviapisessid':'',
    'netviapisessval':'',
}
'''
def build_url(query):
    return base_url + '?' + urlencode(query)

def addItemList(url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
    li=xbmcgui.ListItem(name)
    li.setProperty("IsPlayable", isPla)
    if medType:
        kodiVer=xbmc.getInfoLabel('System.BuildVersion')
        if kodiVer.startswith('19.'):
            li.setInfo(type=medType, infoLabels=infoLab)
        else:
            types={'video':'getVideoInfoTag','music':'getMusicInfoTag'}
            if medType!=False:
                setMedType=getattr(li,types[medType])
                vi=setMedType()
            
                labels={
                    'year':'setYear', #int
                    'episode':'setEpisode', #int
                    'season':'setSeason', #int
                    'rating':'setRating', #float
                    'mpaa':'setMpaa',
                    'plot':'setPlot',
                    'plotoutline':'setPlotOutline',
                    'title':'setTitle',
                    'originaltitle':'setOriginalTitle',
                    'sorttitle':'setSortTitle',
                    'genre':'setGenres', #list
                    'country':'setCountries', #list
                    'director':'setDirectors', #list
                    'studio':'setStudios', #list
                    'writer':'setWriters',#list
                    'duration':'setDuration', #int (in sec)
                    'tag':'setTags', #list
                    'trailer':'setTrailer', #str (path)
                    'mediatype':'setMediaType',
                    'cast':'setCast', #list        
                }
                
                if 'cast' in infoLab:
                    if infoLab['cast']!=None:
                        cast=[xbmc.Actor(c) for c in infoLab['cast']]
                        infoLab['cast']=cast
                
                for i in list(infoLab):
                    if i in list(labels):
                        setLab=getattr(vi,labels[i])
                        setLab(infoLab[i])
    li.setArt(setArt) 
    if contMenu:
        li.addContextMenuItems(cmItems, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isF)

def openF(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    return cont
    
def saveF(u,t):
    with open(u, 'w', encoding='utf-8') as f:
        f.write(t)

def code_gen(x):
    base='0123456789abcdef'
    code=''
    for i in range(0,x):
        code+=base[random.randint(0,15)]
    return code


def main_menu():
    items=[]
    if addon.getSetting('logged')=='true':
        items=[
            ['Lista kanałów','tvList','DefaultTVShows.png'],
            ['VOD','vod','DefaultAddonVideo.png'],
            ['Wyszukiwarka VOD','search','DefaultAddonsSearch.png'],
            ['Ulubione','favList','DefaultMusicRecentlyAdded.png'],
            ['Wyloguj','logOut','DefaultUser.png']
        ]
    else:
        items=[
            ['Zaloguj','logIn','DefaultUser.png']
        ]
    for i in items:
        setArt={'icon': i[2],'fanart':fanart}
        url = build_url({'mode':i[1]})
        addItemList(url, i[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)   

def logIn():
    password=addon.getSetting('password')
    username=addon.getSetting('username')
    if password!='' and username!='':
        url='https://pilot.wp.pl/api/v1/user_auth/login?device_type='+deviceType
        hea.update({'Referer':baseurl+'tv/'})
        data={
            "device": deviceType,
            "login": username,
            "password": password
        }
        resp=requests.Session().post(url,headers=hea,json=data)
        resp1=resp.json()
        if 'error' in resp1['_meta']:
            if resp1['_meta']['error']['name']=='login_incorrect_username_or_password':
                xbmcgui.Dialog().notification('WP Pilot', 'Złe dane logowania', xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification('WP Pilot', 'Nieokreslony błąd logowania: '+resp1['_meta']['error']['name'], xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        else:
            addon.setSetting('cookies',str(dict(resp.cookies)))
            addon.setSetting('AccInfo',resp1['data']['type'])
            packets()
            addon.setSetting('logged','true')
            
        
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Podaj login i hasło w Ustawieniach', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def packets():
    cookies=eval(addon.getSetting('cookies'))
    hea.update({'Referer':baseurl+'tv/'})
    url='https://pilot.wp.pl/api/v1/package_order?device_type='+deviceType
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    now=int(time.time())
    prods=[r['name'] for r in resp['data'] if r['ends_at']>now]
    addon.setSetting('packets',str(prods))
    
def logOut():
    cookies=eval(addon.getSetting('cookies'))
    hea.update({'Referer':baseurl+'tv/'})
    url='https://pilot.wp.pl/api/v1/user_auth/logout?device_type='+deviceType
    resp=requests.Session().post(url,headers=hea,cookies=cookies).json()
    try:
        if resp['data']['status']=='ok':
            addon.setSetting('logged','false')
            addon.setSetting('cookies','')
            addon.setSetting('AccInfo','')
            addon.setSetting('packets','')
    except:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def relogin():#gdy wylogowano z poziomu innego urządzenia
    addon.setSetting('logged','false')
    addon.setSetting('cookies','')
    addon.setSetting('AccInfo','')
    addon.setSetting('packets','')
    logIn()
    xbmc.log('@@@Przelogowano', level=xbmc.LOGINFO)
    
def locTime(x): #TV
    diff=(datetime.datetime.now()-datetime.datetime.utcnow())
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%SZ')[0:6]))
    z=(y+diff+datetime.timedelta(seconds=1)).strftime('%H:%M')
    return z

def locTimeFull(x): #VOD
    y=datetime.datetime(*(time.strptime(x,'%Y-%m-%dT%H:%M:%S%z')[0:6]))
    z=y.strftime('%Y-%m-%d %H:%M')
    return z
        
def getEPG(arCid):
    import math
    cnt=math.ceil(len(arCid)/20)
    chGroups=[]
    for i in range(0,cnt):
        chGroups.append(','.join(arCid[20*i:20*(i+1)]))
    epg={}
    for cg in chGroups:
        url='https://pilot.wp.pl/api/v2/epg?channels='+cg+'&limit=12&device_type=web'
        hea.update({'Referer':baseurl+'tv/'})
        cookies=eval(addon.getSetting('cookies'))
        resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
        for r in resp['data']:
            progs=''
            for e in r['entries']:
                ts=locTime(e['start'])
                #te=locTime(e['end'])
                title=e['title']
                categ=e['category']
                progs+='[B]%s[/B] %s [I](%s)[/I]\n'%(ts,title,categ)
            epg[str(r['channel_id'])]=progs
    return epg

def channels():
    url='https://pilot.wp.pl/api/v2/channels/list?device_type='+deviceType
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if 'error' in resp['_meta']:
        if resp['_meta']['error']['name']=='not_authorized':
            relogin()
            channels()#
        else:
            return False
    else:
        chans=[r for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        return chans

def tvList():
    url='https://pilot.wp.pl/api/v2/channels/list?device_type='+deviceType
    cookies=eval(addon.getSetting('cookies')) if addon.getSetting('cookies')!='' else {}
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if 'error' in resp['_meta']:
        if resp['_meta']['error']['name']=='not_authorized':
            relogin()
            tvList()#
        else:
            xbmcplugin.endOfDirectory(addon_handle)
    else:
        accType=addon.getSetting('AccInfo')
        chans=[r for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        cids=[str(r['id']) for r in resp['data'] if r['access_status']=='free' or r['access_status']=='subscribed']
        epg=getEPG(cids)
        for c in chans:
            name=c['name']
            img=c['icon']
            cid=str(c['id'])
            plot=epg[cid] if cid in epg else ''
            
            setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart': img}
            iL={'title': name,'sorttitle': name,'plot': plot}
            url=build_url({'mode':'playSource','cid':cid})
            addItemList(url, name, setArt, 'video', iL, isF=False, isPla='true')
        
        xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.addSortMethod(handle=addon_handle,sortMethod=xbmcplugin.SORT_METHOD_TITLE)
        xbmcplugin.endOfDirectory(addon_handle)    

def closeStream(cid,sid):
    url='https://pilot.wp.pl/api/v1/channels/close?device_type='+deviceType
    hea.update({'Referer':baseurl+'tv/'})
    cookies=eval(addon.getSetting('cookies'))
    data={
        "channelId": cid,
        "t": sid
    }
    resp=requests.Session().post(url,headers=hea,cookies=cookies,json=data).json()

def playSource(c):
    url='https://pilot.wp.pl/api/v2/channel/%s?device_type=%s'%(c,deviceType)
    hea.update({'Referer':baseurl+'tv/'})
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
    if resp['data']==None:
        if resp['_meta']['error']['code']==300:
            closeStream(resp['_meta']['error']['info']['channel_id'],resp['_meta']['error']['info']['stream_token'])
            resp=requests.Session().get(url,headers=hea,cookies=cookies).json()
        elif resp['_meta']['error']['name']=='not_authorized':
            relogin()
            playSource(c)#
        elif resp['_meta']['error']['name']=='user_channel_blocked':
            xbmcgui.Dialog().notification('WP Pilot', 'Kanał tymczasowo wyłączony przez nadawcę ze względów licencyjnych.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
    
    if resp['data']!=None:
        drm=False
        custStream=False
        if resp['data']['stream_channel']['drms']!=None:
            try:
                stream_url=[r['url'] for r in resp['data']['stream_channel']['custom_streams'] if 'dash' in r['type']][0][0]
                custStream=True
            except:
                stream_url=[r['url'] for r in resp['data']['stream_channel']['streams'] if 'dash' in r['type']][0][0]
                  
            #weryfikacja czy manifest jest zabezpieczony DRM
            respDRM=requests.Session().get(stream_url,headers=hea).text
            if '<ContentProtection' in respDRM:
                protocol='mpd'
                drm=True
                licUrl=baseurl+resp['data']['stream_channel']['drms']['widevine']
                cookie='; '.join([str(x) + '=' + str(y) for x, y in cookies.items()])
                hea1={
                    'User-Agent':UA,
                    'referer':basevod,
                    'origin':'https://pilot.wp.pl/tv/',
                    'cookie':cookie,
                    'content-type':'',
                }
                heaLic=urlencode(hea1)
                xbmc.log('@#@z DRM, url_stream: %s' % (stream_url), xbmc.LOGINFO)
        
        if resp['data']['stream_channel']['drms']==None or drm==False:
            stream_url=[r['url'] for r in resp['data']['stream_channel']['streams'] if 'hls' in r['type']][0][0]
            protocol='hls'
            drm=False
            xbmc.log('@#@bez DRM, url_stream: %s' % (stream_url), xbmc.LOGINFO)
            
        if not resp['data']['stream_channel']['is_audio_only']:#TV
            
            if not custStream and '.mpd' in stream_url:
                #proxy -> wymiana tokena w segmentach AV
                proxyport = addon.getSetting('proxyport') #proxy
                stream_url='http://127.0.0.1:%s/MANIFEST='%(str(proxyport))+stream_url #proxy
                xbmc.log('@@@proxy - wymiana tokena w segmentach AV (strumienie DASH z videostar)', level=xbmc.LOGINFO)
            
            import inputstreamhelper
            PROTOCOL = protocol#'hls'
            is_helper = inputstreamhelper.Helper(PROTOCOL)
            if is_helper.check_inputstream():
                play_item = xbmcgui.ListItem(path=stream_url)
                play_item.setMimeType('application/xml+dash')
                play_item.setContentLookup(False)
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty("IsPlayable", "true")
                play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+baseurl)
                play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+baseurl)
                if drm:
                    play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                    play_item.setProperty('inputstream.adaptive.license_key', licUrl+'|'+heaLic+'|R{SSM}|')
                          
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
                                
        else: #radio
            stream_url+='|User-Agent='+UA+'&Referer='+baseurl
            play_item = xbmcgui.ListItem(path=stream_url)
            play_item.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
            
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Brak źródła: '+resp['_meta']['error']['name'], xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

#VOD
def heaGen():
    CorrelationID='client_'+code_gen(8)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(4)+'-'+code_gen(12)
    hea.update({'API-CorrelationId':CorrelationID,'API-DeviceUid':addon.getSetting('DeviceUid'),'Referer':basevod})
    return hea
    
def sortMethod(): #helper
    m=addon.getSetting('sortContent')
    tb={
        'Ostatnio dodane':{'sort':'createdAt','order':'desc'},
        'Najnowsze':{'sort':'year','order':'desc'},
        'Najstarsze':{'sort':'year','order':'asc'},
        'A-Z':{'sort':'title','order':'asc'},
        'Z-A':{'sort':'title','order':'desc'}
    }
    return tb[m]

def titleWithTill(d,t):#data dostępności w tytule
    title=t
    if 'LAST_BELL' in d:
        title=t+' [COLOR=yellow]/do: '+d.split('|')[1]+'/[/COLOR]'
    if 'SOON' in d:
        title='[COLOR=gray]%s[/COLOR]'%(title)

    return title

mainCategs=[
    ['SERIALE','categList','33','DefaultAddonVideo.png'],
    ['FILMY','categList','17','DefaultAddonVideo.png'],
    ['PROGRAMY','categList','98','DefaultAddonVideo.png'],
    ['SPORT','categList','106','DefaultAddonVideo.png'],
    ['DLA DZIECI','categList','70','DefaultAddonVideo.png']
]

def vod():
    for s in mainCategs:
        setArt={'icon': s[3],'fanart':fanart}
        url=build_url({'mode':s[1],'mainCateg':s[2]})
        addItemList(url, s[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)
    
def categList(mc):
    u=basevod+'api/items/categories'
    hea_=heaGen()
    vodUrlParams.update({'mainCategoryId':mc})
    cookies=eval(addon.getSetting('cookies'))
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    arCateg=[['Wszystkie','all']]
    for c in resp:
        arCateg.append([c['name'],c['id']])
    for ac in arCateg:
        setArt={'icon': 'DefaultGenre.png','fanart':fanart}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':str(ac[1]),'page':'1'})
        addItemList(url, ac[0], setArt)
    xbmcplugin.endOfDirectory(addon_handle)

def getImg(x):#helper
    if '16x9' in x:
        img=x['16x9'][0]['templateUrl']
    elif '4x3' in x:
        img=x['4x3'][0]['templateUrl']
    else:
        img=''
    if img!='':
        img=img.format(width=1024,height=576).replace(' ','')
        
    if img.startswith('//'):
        img='https:'+img
    return img

def detCont(x):#helper
    #types: VOD,SERIAL,EPISODE
    title=x['title'] 
    year=x['year'] if 'year' in x else 0
    rating=str(x['rating']) if 'rating' in x else ''
    ep=x['number'] if x['type']=='EPISODE' else 0
    if 'season' in x:
        seas=x['season']['number'] if x['type']=='EPISODE' else 0
    else:
        seas=0
    desc=cleanText(x['lead']) if 'lead' in x else ''
    dur=x['duration'] if 'duration' in x else 0
    
    country=[c['name'] for c in x['countries']] if 'countries' in x else []
    actors=[c['name'] for c in x['actors']] if 'actors' in x else []
    directors=[c['name'] for c in x['directors']] if 'directors' in x else []
    scriptwriters=[c['name'] for c in x['scriptwriters']] if 'scriptwriters' in x else []
    genre=[c['name'] for c in x['genres']] if 'genres' in x else []

    
    #dostępność
    packets=''
    if 'bundles' in x:
        packets=', '.join([r['title'] for r in x['bundles']])
    
    avail=''
    availLabel=''
    if 'displaySchedules' in x:
        i_cur=0#[i for i,t in enumerate(x['displaySchedules']) if t['active'] ][0]
        
        if x['displaySchedules'][i_cur]['type']!='SOON':
            if 'payable' in x:
                if x['payable']:
                    avail+='[COLOR=yellow]Płatny[/COLOR]\n'
                    if packets!='':
                        avail+='[B]Pakiety: [/B]%s\n'%(packets)
                else:
                    if x['type']=='VOD' or x['type']=='EPISODE':
                        avail+='[B][COLOR=yellow]Bezpłatny\n[/COLOR][/B]'
                        if 'payableSince' in x:
                            avail+='[COLOR=yellow]do: %s\n[/COLOR]'%(x['payableSince'])

            if 'since' in x['displaySchedules'][i_cur]:
                avail+='[B]Data publikacji: [/B]'+x['displaySchedules'][i_cur]['since'].split('T')[0]+'\n'
            
            if x['displaySchedules'][i_cur]['type']=='PREMIERE':
                if 'till' in x['displaySchedules'][i_cur]:
                    avail+='[B]Dostępny do: [/B]'+locTimeFull(x['displaySchedules'][i_cur]['till'])+'\n'
                avail+='[COLOR=yellow]PRAPREMIERA[/COLOR]\n'
            else:
                if 'till' in x['displaySchedules'][i_cur]:
                    avail+='[B]Dostępny do: [/B]'+locTimeFull(x['displaySchedules'][i_cur]['till'])+'\n'
                if x['displaySchedules'][i_cur]['type']=='LAST_BELL':
                    availLabel='LAST_BELL|'+locTimeFull(x['displaySchedules'][i_cur]['till'])
                    avail+='[COLOR=yellow]OSTATNIA SZANSA[/COLOR]\n'
            
        else:
            availLabel='SOON'
            if 'till' in x['displaySchedules'][i_cur]:
                avail+='[COLOR=yellow]WKRÓTCE[/COLOR]\n'
                avail+='[B]Dostępny od: [/B]'+locTimeFull(x['displaySchedules'][i_cur]['till'])+'\n'
    
    desc=avail+desc
    
    #Dostawca
    if 'live' in x:
        provider=x['live']['title']
        desc='[B]Kanał: [/B][COLOR=cyan]%s[/COLOR]\n'%(provider)+desc
    
    iL={}
    if x['type']=='EPISODE':
        iL={'title': title,'sorttitle': title,'mpaa':rating,'plot': desc,'year':year,'duration':dur,'episode':ep,'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'season':seas,'genre':genre,'mediatype':'episode'} #'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'season':seas,'genre':genre
    elif x['type'] in ['VOD','SERIAL']:
        iL={'title': title,'sorttitle': title,'mpaa':rating,'plot': desc,'year':year,'duration':dur,'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'genre':genre,'mediatype':'movie'} #'director':directors,'country':country,'cast':actors,'writer':scriptwriters,'genre':genre
        if x['type']=='SERIAL':
            iL['mediatype']='tvshow'
    else:
        iL={'plot':title}

    return iL,availLabel

def addContToList(r): #2024-05-28
    isShow=True
    
    cid=str(r['id'])
    name=r['title']
    type=r['type']
    img=getImg(r['images'])
    iL,availLabel=detCont(r)
    mod=''
    isPlayable='false'
    isFolder=True
        
    if type=='SERIAL':
        mod='sezonList'
        URL = build_url({'mode':mod,'cid':cid,'title':name})
    
    elif type=='VOD':
        name=titleWithTill(availLabel,name)
        
        mod='playVid'
        URL = build_url({'mode':mod,'eid':cid})
        isPlayable='true'
        isFolder=False

    elif type=='EPISODE':
        name=''
        episode=r['number']
        name+='odcinek '+str(episode)
        episodeName=r['title']
        if episodeName !='':
            name+=' | '+r['title']
        
        name=titleWithTill(availLabel,name)
        mod='playVid'
        URL = build_url({'mode':mod,'eid':cid})
        isPlayable='true'
        isFolder=False
        
    if (type=='SERIAL' or type=='VOD' or type=='EPISODE') and availLabel=='SOON':#r['displaySchedules'][i_cur]['type']=='SOON':
        isPlayable='false'
        isFolder=False
        URL = base.build_url({'mode':'noPlay'})
    
    xbmcplugin.setContent(addon_handle, 'videos')
    
    setArt={'thumb': img, 'poster': img, 'banner': img, 'icon': img, 'fanart':img}
    
    cmItems = []
    if type=='VOD' or type=='SERIAL' or type=='EPISODE':
        if type!='EPISODE':
            cmItems.append(('[B]Dodaj do ulubionych[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=favAdd&url='+quote(URL)+'&title='+quote(name)+'&cid='+quote(cid)+'&iL='+quote(str(iL))+'&img='+quote(img)+')'))
        cmItems.append(('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&eid='+cid+')'))
      
    if isShow:
        addItemList(URL, name, setArt, 'video', iL, isFolder, isPlayable, True, cmItems)
    
def contList(mc,c,p):
    cnt=addon.getSetting('epCount')
    start=(int(p)-1)*int(cnt)
    vodUrlParams.update({
        'firstResult':str(start),
        'maxResults':cnt,
        'mainCategoryId[]':mc
    })
    vodUrlParams.update(sortMethod())
    if c!='all':
        vodUrlParams['categoryId[]']=c
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/products/vods'
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    total=resp['meta']['totalCount']
    
    for r in resp['items']:
        addContToList(r)
        
    if start+int(cnt)+1<total:
        name='[COLOR=cyan][B]>>> Następna strona[/B][/COLOR]'
        setArt={'icon': img_empty,'fanart':fanart}
        url = build_url({'mode':'contList','mainCateg':mc,'Categ':c,'page':str(int(p)+1)})
        addItemList(url, name, setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)

def sezonList(cid,tit):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/products/vods/serials/'+cid+'/seasons'
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    '''
    if len(resp)==1: #jeden sezon
        sezId=str(resp[0]['id'])
        episodeList(cid,sezId,tit,'1','yes')
    else:
    '''
    for r in resp:
        sez_id=str(r['id'])
        sez_name=r['title']
        if sez_name=='':
            sez_name='sezon '+str(r['number'])
        
        setArt={'icon':'DefaultAddonVideo.png','fanart':fanart}
        iL={'title': '','sorttitle': '','plot': tit}
        url = build_url({'mode':'episodeList','cid':cid,'sezId':sez_id,'title':tit,'init':'yes','page':'1'})
        addItemList(url, sez_name, setArt, 'video', iL)
    xbmcplugin.setContent(addon_handle, 'videos')
    xbmcplugin.endOfDirectory(addon_handle)

def episodeList(cid,sezId,tit,pg,init):
    cnt=int(addon.getSetting('epCount'))
    p=int(pg)
    if init=='yes':
        hea_=heaGen()
        cookies=eval(addon.getSetting('cookies'))
        u=basevod+'api/products/vods/serials/'+cid+'/seasons/'+sezId+'/episodes'
        resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()#list
        saveF(PATH_profile+'/episodeJSON.txt',str(resp))
    
    resp=eval(openF(PATH_profile+'/episodeJSON.txt'))
    total=len(resp)
    start=cnt*(p-1)
    stop=min(cnt*(p-1)+cnt,total)
    for i in range(start,stop):
        addContToList(resp[i])
        
    if p<math.ceil(total/cnt):
        name='[B]>>> Następna strona[/B]'
        setArt={'icon': img_empty,'fanart':fanart}
        url = build_url({'mode':'episodeList','init':'no','cid':cid,'sezId':sezId,'title':tit,'page':str(p+1)})
        addItemList(url, name, setArt)
    
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)
            
def showDet(eid):#menu kont
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))
    u=basevod+'api/products/vods/'+eid
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    iL,availLabel=detCont(resp)
    
    plot=''
    if iL['mediatype']=='episode':
        if iL['season']!=0:
            plot+='[B]Sezon:[/B] %s\n'%(str(iL['season']))
        plot+='[B]Odcinek:[/B] %s\n'%(str(iL['episode']))
    if iL['year']!=0:
        plot+='[B]Rok prod:[/B] %s\n'%(str(iL['year']))
    if len(iL['country'])>0:
        plot+='[B]Kraj:[/B] %s\n'%(', '.join(iL['country']))
    if len(iL['genre'])>0:
        plot+='[B]Gatunek:[/B] %s\n'%(', '.join(iL['genre']))
    if iL['duration']!=0:
        plot+='[B]Czas:[/B] %s min.\n'%(str(int(iL['duration']/60)))
    if iL['mpaa']!='':
        plot+='[B]Ograniczenia wiekowe:[/B] %s lat\n'%(str(iL['mpaa']))

    if len(iL['cast'])>0:
        plot+='[B]Obsada:[/B] %s\n'%(', '.join(iL['cast']))
    if len(iL['director'])>0:
        plot+='[B]Reżyseria:[/B] %s\n'%(', '.join(iL['director']))
    if len(iL['writer'])>0:
        plot+='[B]Scenariusz:[/B] %s\n'%(', '.join(iL['writer']))

    plot+=iL['plot']

    dialog = xbmcgui.Dialog()
    dialog.textviewer('Szczegóły', plot)

def playVid(eid,resume):
    hea_=heaGen()
    cookies=eval(addon.getSetting('cookies'))

    u=basevod+'api/products/vods/'+eid
    resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    if 'bundles' not in resp and resp['type']=='EPISODE':
        serieId=resp['season']['serial']['id']
        u=basevod+'api/products/vods/serials/'+str(serieId)
        resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
    #try:
    availTest=True
    if 'bundles' in resp:
        packets()
        availPack=[r['title'] for r in resp['bundles']]
        availTest=False
        for a in availPack:
            if a in eval(addon.getSetting('packets')):
                availTest=True
    if availTest==False:
        xbmcgui.Dialog().notification('WP Pilot', 'Brak w pakiecie', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

    else:
        u=basevod+'api/subscribers/detail'
        resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()
        #AUTH CHECK 1 ---> relogin
        if 'code' in resp:
            if resp['code']=='AUTHENTICATION_REQUIRED':
                relogin()
                #playVid(eid,resume)#
                cookies=eval(addon.getSetting('cookies'))
                resp=requests.get(u,headers=hea_,cookies=cookies).json()
        #AUTH CHECK 2 after relogin
        if 'code' in resp:
            if resp['code']=='AUTHENTICATION_REQUIRED':
                xbmcgui.Dialog().notification('WP Pilot', 'Brak dostępu - problem z autoryzacją', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        else:
            session_uid=resp['httpSession']['uid'] if 'httpSession' in resp else None
            if session_uid!=None:
            
                u=basevod+'api/products/'+eid+'/videos/playlist'
                paramsURL={'videoType':'MOVIE'}
                paramsURL.update(vodUrlParams)
                resp=requests.get(u,headers=hea_,cookies=cookies,params=paramsURL).json()
                protocol='mpd'
                stream_url=resp['sources']['DASH'][0]['src']
                if stream_url.startswith('//'):
                    stream_url='https:'+stream_url
                cookie='; '.join([str(x) + '=' + str(y) for x, y in cookies.items()])
                cookie+='; session_uid='+session_uid
                #cookie='netviapisessid='+cookies['netviapisessid']+'; netviapisessval='+cookies['netviapisessval']+'; session_uid='+session_uid
                hea1={
                    'User-Agent':UA,
                    'referer':basevod,
                    'origin':'https://pilot.wp.pl',
                    'cookie':cookie,
                    'content-type':'',
                }
                heaLic=urlencode(hea1)
                lic_url=resp['drm']['WIDEVINE']['src']+'|'+heaLic+'|R{SSM}|'#
                    
                #subt=resp['movie']['video']['subtitles']
                #subActive=False
                
                import inputstreamhelper
                PROTOCOL = protocol
                is_helper = inputstreamhelper.Helper(PROTOCOL)
                if is_helper.check_inputstream():
                    play_item = xbmcgui.ListItem(path=stream_url)
                    play_item.setMimeType('application/xml+dash')
                    play_item.setContentLookup(False)
                    play_item.setProperty('inputstream', is_helper.inputstream_addon)
                    play_item.setProperty("IsPlayable", "true")
                    play_item.setProperty('inputstream.adaptive.manifest_type', PROTOCOL)
                    play_item.setProperty('inputstream.adaptive.manifest_headers', 'User-Agent='+UA+'&Referer='+basevod) #K21
                    play_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent='+UA+'&Referer='+basevod)
                    play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                    if resume!=False: #start od wskazanego momentu (resume)
                        play_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
                        play_item.setProperty('ResumeTime', resume)
                        play_item.setProperty('TotalTime', '1')
                    '''
                    if 'pol' in subt:
                        if subt['pol']['default']==True:
                            play_item.setSubtitles([subt['pol']['src']])
                            subActive=True
                    '''        
                    #play_item.setSubtitles(sbt_src)
                    play_item.setProperty("inputstream.adaptive.license_type", 'com.widevine.alpha')
                    play_item.setProperty("inputstream.adaptive.license_key", lic_url)
                              
                    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)
                    '''
                    if subActive==True:
                        while not xbmc.Player().isPlaying():
                            xbmc.sleep(100)
                        xbmc.Player().showSubtitles(True)
                    '''
            else:
                xbmcgui.Dialog().notification('WP Pilot', 'Brak session_uid', xbmcgui.NOTIFICATION_INFO)
                xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def search():
    qry=xbmcgui.Dialog().input('Szukaj (przynajmniej 3 znaki):', type=xbmcgui.INPUT_ALPHANUM)
    if qry:
        hea_=heaGen()
        cookies=eval(addon.getSetting('cookies'))
        vodUrlParams['keyword']=qry
        type={'VOD':'Filmy','SERIAL':'Seriale','EPISODE':'Odcinki'}
        count={}
        
        for t in list(type):
            u=basevod+'api/products/vods/search/'+t
            resp=requests.get(u,headers=hea_,cookies=cookies,params=vodUrlParams).json()['items']
            count[t]=str(len(resp))
            saveF(PATH_profile+'/%s.txt'%(t),str(resp))
        
            setArt={'icon': 'DefaultAddonVideo.png','fanart':fanart}
            url = build_url({'mode':'searchRes','cat':t})
            addItemList(url, type[t]+' (%s)'%(count[t]), setArt) 
            
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        main_menu()
        
def searchRes(c):
    res=eval(openF(PATH_profile+'/%s.txt'%(c)))
    for r in res:
        addContToList(r)
        
    xbmcplugin.setContent(addon_handle, 'videos')    
    xbmcplugin.endOfDirectory(addon_handle)    


def listM3U():
    file_name = addon.getSetting('fname')
    path_m3u = addon.getSetting('path_m3u')
    if file_name == '' or path_m3u == '':
        xbmcgui.Dialog().notification('WP Pilot', 'Podaj nazwę pliku oraz katalog docelowy.', xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification('WP Pilot', 'Generuję listę M3U.', xbmcgui.NOTIFICATION_INFO)
    chans=channels()
    if chans !=False:
        data = '#EXTM3U\n'
        for c in chans:
            name=c['name']
            img=c['icon']
            cid=str(c['id'])
            data += '#EXTINF:0 tvg-id="%s" tvg-logo="%s" group-title="WP Pilot" ,%s\nplugin://plugin.video.wppilot?mode=playSource&cid=%s\n' %(name,img,name,cid)
        
        f = xbmcvfs.File(path_m3u + file_name, 'w')
        f.write(data)
        f.close()
        xbmcgui.Dialog().notification('WP Pilot', 'Wygenerowano listę M3U', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Błąd przy generowaniu listy M3U', xbmcgui.NOTIFICATION_INFO)

def cleanText(t):
    toDel=['<p>','</p>','<strong>','</strong>']
    for d in toDel:
        t=t.replace(d,'')
    t=t.replace('<br>',' ').replace('&oacute;','ó').replace('&ouml;','ö').replace('&nbsp;',' ').replace('&ndash;',' - ')
    t=re.sub('<([^<]+?)>','',t)
    return t
    
#FAV
def openJSON(u):
    try:
        f=open(u,'r',encoding = 'utf-8')
    except:
        f=open(u,'w+',encoding = 'utf-8')
    cont=f.read()
    f.close()
    try:
        js=eval(cont)
    except:
        js=[]
    return js
    
def saveJSON(u,j):
    with open(u, 'w', encoding='utf-8') as f:
        json.dump(j, f, ensure_ascii=False, indent=4)

def favList():
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for j in js:
        if 'playVid' in j[0]:
            isPlayable='true'
            isFolder=False
        else:
            isPlayable='false'
            isFolder=True

        contMenu=True
        cmItems=[
            ('[B]Usuń z ulubionych[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=favDel&url='+quote(j[0])+')'),
            ('[B]Szczegóły[/B]','RunPlugin(plugin://plugin.video.wppilot?mode=showDet&cid='+quote(j[2])+')')
        ]
        setArt={'icon':j[4], 'fanart':j[4]}
        iL=eval(j[3])
        addItemList(j[0], j[1], setArt, 'video', iL, isFolder, isPlayable, contMenu, cmItems)
        
    xbmcplugin.setContent(addon_handle, 'videos')     
    xbmcplugin.endOfDirectory(addon_handle)

def favDel(u):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    for i,j in enumerate(js):
        if  j[0]==u:
            del js[i]
    saveJSON(fURL,js)
    xbmc.executebuiltin('Container.Refresh()')

def favAdd(u,t,c,l,i):
    fURL=PATH_profile+'ulubione.json'
    js=openJSON(fURL)
    duplTest=False
    for j in js:
        if j[0]==u:
            duplTest=True
    if not duplTest:
        js.append([u,t,c,l,i])
        xbmcgui.Dialog().notification('WP Pilot', 'Dodano do ulubionych', xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification('WP Pilot', 'Materiał jest już w ulubionych', xbmcgui.NOTIFICATION_INFO)
    saveJSON(fURL,js)
    
def expFav():
    from shutil import copy2, copyfile
    fURL=PATH_profile+'ulubione.json'
    targetPATH=xbmcgui.Dialog().browse(0, 'Wybierz lokalizację docelową', '', '', enableMultiple = False)
    #copy2(fURL,targetPATH)
    copyfile(fURL, targetPATH+'ulubione.json')
    xbmcgui.Dialog().notification('WP Pilot', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)
    
def impFav():
    from shutil import copy2,copyfile
    fURL=PATH_profile+'ulubione.json'
    sourcePATH=xbmcgui.Dialog().browse(1, 'Wybierz plik', '', '.json', enableMultiple = False)
    copyfile(sourcePATH,fURL)
    #copy2(sourcePATH,fURL)
    xbmcgui.Dialog().notification('WP Pilot', 'Plik zapisany', xbmcgui.NOTIFICATION_INFO)

mode = params.get('mode', None)

if not mode:
    if addon.getSetting('DeviceUid')=='' or addon.getSetting('DeviceUid')==None:
        addon.setSetting('DeviceUid',code_gen(32))
    main_menu()
else:
    if mode=='logIn':
        logIn()
        if addon.getSetting('logged')=='true':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/,replace)')
    
    if mode=='logOut':
        logOut()
        if addon.getSetting('logged')=='false':
            xbmcplugin.endOfDirectory(addon_handle, cacheToDisc=False)
            xbmc.executebuiltin('Container.Update(plugin://plugin.video.wppilot/,replace)')
    
    if mode=='tvList':
        tvList()
        
    if mode=='playSource':
        if addon.getSetting('logged')=='true':
            cid=params.get('cid')
            playSource(cid)
        else:
            xbmcgui.Dialog().notification('WP Pilot', 'Wymagane logowanie we wtyczce', xbmcgui.NOTIFICATION_INFO)
        
    if mode=='vod':
        vod()
    
    if mode=='categList':
        mc=params.get('mainCateg')
        categList(mc)
        
    if mode=='contList':
        mc=params.get('mainCateg')
        c=params.get('Categ')
        pg=params.get('page')
        contList(mc,c,pg)
        
    if mode=='sezonList':
        cid=params.get('cid')
        tit=params.get('title')
        sezonList(cid,tit)

    if mode=='episodeList':
        cid=params.get('cid')
        sezId=params.get('sezId')
        tit=params.get('title')
        pg=params.get('page')
        init=params.get('init')
        episodeList(cid,sezId,tit,pg,init)
    
    if mode=='showDet':
        eid=params.get('eid')
        showDet(eid)

    if mode=='playVid':
        eid=params.get('eid')
        playVid(eid,False)
        
    if mode=='noPlay':
        pass

    if mode=='search':
        search()
        
    if mode=='searchRes':
        c=params.get('cat')
        searchRes(c)
    
    if mode=='listM3U':
        if addon.getSetting('logged')=='true':
            listM3U()
        else:
            xbmcgui.Dialog().notification('WP Pilot', 'Operacja wymaga zalogowania', xbmcgui.NOTIFICATION_INFO)
    #FAV
    if mode=='favList':
        favList()
        
    if mode=='favDel':
        u=params.get('url')
        favDel(u)
        
    if mode=='favAdd':
        u=params.get('url')
        t=params.get('title')
        c=params.get('cid')
        l=params.get('iL')
        i=params.get('img')
        favAdd(u,t,c,l,i)
    
    if mode=='expFav':
        expFav()
        
    if mode=='impFav':
        impFav()
