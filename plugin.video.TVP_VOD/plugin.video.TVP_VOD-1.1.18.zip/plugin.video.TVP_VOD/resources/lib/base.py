# -*- coding: utf-8 -*-
#import os
#import sys

import xbmc
import xbmcgui#
import xbmcplugin#
import xbmcaddon
import xbmcvfs

from urllib.parse import urlencode, quote_plus, quote, unquote, parse_qsl

class b:
    def __init__(self, base_url=None, addon_handle=None):
        self.base_url=base_url
        self.addon_handle=addon_handle
        self.UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0'
        
        self.addon=xbmcaddon.Addon(id='plugin.video.TVP_VOD')
        self.PATH_profile=xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(self.PATH_profile):
            xbmcvfs.mkdir(self.PATH_profile)
            
    def build_url(self, query):
        return self.base_url + '?' + urlencode(query)

    def addItemList(self, url, name, setArt, medType=False, infoLab={}, isF=True, isPla='false', contMenu=False, cmItems=[]):
        li=xbmcgui.ListItem(name)
        li.setProperty("IsPlayable", isPla)
        if medType:
            li.setInfo(type=medType, infoLabels=infoLab)
        li.setArt(setArt) 
        if contMenu:
            li.addContextMenuItems(cmItems, replaceItems=False)
        xbmcplugin.addDirectoryItem(handle=self.addon_handle, url=url, listitem=li, isFolder=isF)
